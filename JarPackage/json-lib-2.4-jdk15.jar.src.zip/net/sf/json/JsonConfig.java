/*      */ package net.sf.json;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import net.sf.json.processors.DefaultDefaultValueProcessor;
/*      */ import net.sf.json.processors.DefaultValueProcessor;
/*      */ import net.sf.json.processors.DefaultValueProcessorMatcher;
/*      */ import net.sf.json.processors.JsonBeanProcessor;
/*      */ import net.sf.json.processors.JsonBeanProcessorMatcher;
/*      */ import net.sf.json.processors.JsonValueProcessor;
/*      */ import net.sf.json.processors.JsonValueProcessorMatcher;
/*      */ import net.sf.json.processors.PropertyNameProcessor;
/*      */ import net.sf.json.processors.PropertyNameProcessorMatcher;
/*      */ import net.sf.json.util.CycleDetectionStrategy;
/*      */ import net.sf.json.util.JavaIdentifierTransformer;
/*      */ import net.sf.json.util.JsonEventListener;
/*      */ import net.sf.json.util.NewBeanInstanceStrategy;
/*      */ import net.sf.json.util.PropertyExclusionClassMatcher;
/*      */ import net.sf.json.util.PropertyFilter;
/*      */ import net.sf.json.util.PropertySetStrategy;
/*      */ import org.apache.commons.collections.map.MultiKeyMap;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JsonConfig
/*      */ {
/*   55 */   public static final DefaultValueProcessorMatcher DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER = DefaultValueProcessorMatcher.DEFAULT;
/*   56 */   public static final JsonBeanProcessorMatcher DEFAULT_JSON_BEAN_PROCESSOR_MATCHER = JsonBeanProcessorMatcher.DEFAULT;
/*   57 */   public static final JsonValueProcessorMatcher DEFAULT_JSON_VALUE_PROCESSOR_MATCHER = JsonValueProcessorMatcher.DEFAULT;
/*   58 */   public static final NewBeanInstanceStrategy DEFAULT_NEW_BEAN_INSTANCE_STRATEGY = NewBeanInstanceStrategy.DEFAULT;
/*   59 */   public static final PropertyExclusionClassMatcher DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER = PropertyExclusionClassMatcher.DEFAULT;
/*   60 */   public static final PropertyNameProcessorMatcher DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER = PropertyNameProcessorMatcher.DEFAULT;
/*      */   public static final int MODE_LIST = 1;
/*      */   public static final int MODE_OBJECT_ARRAY = 2;
/*      */   public static final int MODE_SET = 2;
/*   64 */   private static final Class DEFAULT_COLLECTION_TYPE = List.class;
/*   65 */   private static final CycleDetectionStrategy DEFAULT_CYCLE_DETECTION_STRATEGY = CycleDetectionStrategy.STRICT;
/*   66 */   private static final String[] DEFAULT_EXCLUDES = new String[] { "class", "declaringClass", "metaClass" };
/*   67 */   private static final JavaIdentifierTransformer DEFAULT_JAVA_IDENTIFIER_TRANSFORMER = JavaIdentifierTransformer.NOOP;
/*   68 */   private static final DefaultValueProcessor DEFAULT_VALUE_PROCESSOR = (DefaultValueProcessor)new DefaultDefaultValueProcessor();
/*   69 */   private static final String[] EMPTY_EXCLUDES = new String[0];
/*      */ 
/*      */   
/*   72 */   private int arrayMode = 1;
/*   73 */   private MultiKeyMap beanKeyMap = new MultiKeyMap();
/*   74 */   private Map beanProcessorMap = new HashMap();
/*   75 */   private MultiKeyMap beanTypeMap = new MultiKeyMap();
/*      */   
/*      */   private Map classMap;
/*   78 */   private Class collectionType = DEFAULT_COLLECTION_TYPE;
/*   79 */   private CycleDetectionStrategy cycleDetectionStrategy = DEFAULT_CYCLE_DETECTION_STRATEGY;
/*   80 */   private Map defaultValueMap = new HashMap();
/*   81 */   private DefaultValueProcessorMatcher defaultValueProcessorMatcher = DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER;
/*      */   private Class enclosedType;
/*   83 */   private List eventListeners = new ArrayList();
/*   84 */   private String[] excludes = EMPTY_EXCLUDES;
/*   85 */   private Map exclusionMap = new HashMap();
/*      */   
/*      */   private boolean handleJettisonEmptyElement;
/*      */   private boolean handleJettisonSingleElementArray;
/*      */   private boolean ignoreDefaultExcludes;
/*      */   private boolean ignoreTransientFields;
/*      */   private boolean ignorePublicFields = true;
/*      */   private boolean javascriptCompliant;
/*   93 */   private JavaIdentifierTransformer javaIdentifierTransformer = DEFAULT_JAVA_IDENTIFIER_TRANSFORMER;
/*      */   private PropertyFilter javaPropertyFilter;
/*   95 */   private Map javaPropertyNameProcessorMap = new HashMap();
/*   96 */   private PropertyNameProcessorMatcher javaPropertyNameProcessorMatcher = DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
/*   97 */   private JsonBeanProcessorMatcher jsonBeanProcessorMatcher = DEFAULT_JSON_BEAN_PROCESSOR_MATCHER;
/*      */   private PropertyFilter jsonPropertyFilter;
/*   99 */   private Map jsonPropertyNameProcessorMap = new HashMap();
/*  100 */   private PropertyNameProcessorMatcher jsonPropertyNameProcessorMatcher = DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
/*  101 */   private JsonValueProcessorMatcher jsonValueProcessorMatcher = DEFAULT_JSON_VALUE_PROCESSOR_MATCHER;
/*  102 */   private Map keyMap = new HashMap();
/*  103 */   private NewBeanInstanceStrategy newBeanInstanceStrategy = DEFAULT_NEW_BEAN_INSTANCE_STRATEGY;
/*  104 */   private PropertyExclusionClassMatcher propertyExclusionClassMatcher = DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER;
/*      */   
/*      */   private PropertySetStrategy propertySetStrategy;
/*      */   private Class rootClass;
/*      */   private boolean skipJavaIdentifierTransformationInMapKeys;
/*      */   private boolean triggerEvents;
/*  110 */   private Map typeMap = new HashMap();
/*  111 */   private List ignoreFieldAnnotations = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowNonStringKeys = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addJsonEventListener(JsonEventListener listener) {
/*  129 */     if (!this.eventListeners.contains(listener)) {
/*  130 */       this.eventListeners.add(listener);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearJavaPropertyNameProcessors() {
/*  139 */     this.javaPropertyNameProcessorMap.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearJsonBeanProcessors() {
/*  147 */     this.beanProcessorMap.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearJsonEventListeners() {
/*  155 */     this.eventListeners.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearJsonPropertyNameProcessors() {
/*  163 */     this.jsonPropertyNameProcessorMap.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearJsonValueProcessors() {
/*  171 */     this.beanKeyMap.clear();
/*  172 */     this.beanTypeMap.clear();
/*  173 */     this.keyMap.clear();
/*  174 */     this.typeMap.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearPropertyExclusions() {
/*  182 */     this.exclusionMap.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearPropertyNameProcessors() {
/*  192 */     clearJavaPropertyNameProcessors();
/*      */   }
/*      */   
/*      */   public JsonConfig copy() {
/*  196 */     JsonConfig jsc = new JsonConfig();
/*  197 */     jsc.beanKeyMap.putAll((Map)this.beanKeyMap);
/*  198 */     jsc.beanTypeMap.putAll((Map)this.beanTypeMap);
/*  199 */     jsc.classMap = new HashMap();
/*  200 */     if (this.classMap != null) {
/*  201 */       jsc.classMap.putAll(this.classMap);
/*      */     }
/*  203 */     jsc.cycleDetectionStrategy = this.cycleDetectionStrategy;
/*  204 */     if (this.eventListeners != null) {
/*  205 */       jsc.eventListeners.addAll(this.eventListeners);
/*      */     }
/*  207 */     if (this.excludes != null) {
/*  208 */       jsc.excludes = new String[this.excludes.length];
/*  209 */       System.arraycopy(this.excludes, 0, jsc.excludes, 0, this.excludes.length);
/*      */     } 
/*  211 */     jsc.handleJettisonEmptyElement = this.handleJettisonEmptyElement;
/*  212 */     jsc.handleJettisonSingleElementArray = this.handleJettisonSingleElementArray;
/*  213 */     jsc.ignoreDefaultExcludes = this.ignoreDefaultExcludes;
/*  214 */     jsc.ignoreTransientFields = this.ignoreTransientFields;
/*  215 */     jsc.ignorePublicFields = this.ignorePublicFields;
/*  216 */     jsc.javaIdentifierTransformer = this.javaIdentifierTransformer;
/*  217 */     jsc.javascriptCompliant = this.javascriptCompliant;
/*  218 */     jsc.keyMap.putAll(this.keyMap);
/*  219 */     jsc.beanProcessorMap.putAll(this.beanProcessorMap);
/*  220 */     jsc.rootClass = this.rootClass;
/*  221 */     jsc.skipJavaIdentifierTransformationInMapKeys = this.skipJavaIdentifierTransformationInMapKeys;
/*  222 */     jsc.triggerEvents = this.triggerEvents;
/*  223 */     jsc.typeMap.putAll(this.typeMap);
/*  224 */     jsc.jsonPropertyFilter = this.jsonPropertyFilter;
/*  225 */     jsc.javaPropertyFilter = this.javaPropertyFilter;
/*  226 */     jsc.jsonBeanProcessorMatcher = this.jsonBeanProcessorMatcher;
/*  227 */     jsc.newBeanInstanceStrategy = this.newBeanInstanceStrategy;
/*  228 */     jsc.defaultValueProcessorMatcher = this.defaultValueProcessorMatcher;
/*  229 */     jsc.defaultValueMap.putAll(this.defaultValueMap);
/*  230 */     jsc.propertySetStrategy = this.propertySetStrategy;
/*      */     
/*  232 */     jsc.collectionType = this.collectionType;
/*  233 */     jsc.enclosedType = this.enclosedType;
/*  234 */     jsc.jsonValueProcessorMatcher = this.jsonValueProcessorMatcher;
/*  235 */     jsc.javaPropertyNameProcessorMatcher = this.javaPropertyNameProcessorMatcher;
/*  236 */     jsc.javaPropertyNameProcessorMap.putAll(this.javaPropertyNameProcessorMap);
/*  237 */     jsc.jsonPropertyNameProcessorMatcher = this.jsonPropertyNameProcessorMatcher;
/*  238 */     jsc.jsonPropertyNameProcessorMap.putAll(this.jsonPropertyNameProcessorMap);
/*  239 */     jsc.propertyExclusionClassMatcher = this.propertyExclusionClassMatcher;
/*  240 */     jsc.exclusionMap.putAll(this.exclusionMap);
/*  241 */     jsc.ignoreFieldAnnotations.addAll(this.ignoreFieldAnnotations);
/*  242 */     jsc.allowNonStringKeys = this.allowNonStringKeys;
/*  243 */     return jsc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void disableEventTriggering() {
/*  251 */     this.triggerEvents = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enableEventTriggering() {
/*  259 */     this.triggerEvents = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DefaultValueProcessor findDefaultValueProcessor(Class target) {
/*  270 */     if (!this.defaultValueMap.isEmpty()) {
/*  271 */       Object key = this.defaultValueProcessorMatcher.getMatch(target, this.defaultValueMap.keySet());
/*  272 */       DefaultValueProcessor processor = (DefaultValueProcessor)this.defaultValueMap.get(key);
/*  273 */       if (processor != null) {
/*  274 */         return processor;
/*      */       }
/*      */     } 
/*  277 */     return DEFAULT_VALUE_PROCESSOR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyNameProcessor findJavaPropertyNameProcessor(Class beanClass) {
/*  288 */     if (!this.javaPropertyNameProcessorMap.isEmpty()) {
/*  289 */       Object key = this.javaPropertyNameProcessorMatcher.getMatch(beanClass, this.javaPropertyNameProcessorMap.keySet());
/*  290 */       return (PropertyNameProcessor)this.javaPropertyNameProcessorMap.get(key);
/*      */     } 
/*      */     
/*  293 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonBeanProcessor findJsonBeanProcessor(Class target) {
/*  304 */     if (!this.beanProcessorMap.isEmpty()) {
/*  305 */       Object key = this.jsonBeanProcessorMatcher.getMatch(target, this.beanProcessorMap.keySet());
/*  306 */       return (JsonBeanProcessor)this.beanProcessorMap.get(key);
/*      */     } 
/*  308 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyNameProcessor findJsonPropertyNameProcessor(Class beanClass) {
/*  319 */     if (!this.jsonPropertyNameProcessorMap.isEmpty()) {
/*  320 */       Object key = this.jsonPropertyNameProcessorMatcher.getMatch(beanClass, this.jsonPropertyNameProcessorMap.keySet());
/*  321 */       return (PropertyNameProcessor)this.jsonPropertyNameProcessorMap.get(key);
/*      */     } 
/*      */     
/*  324 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonValueProcessor findJsonValueProcessor(Class propertyType) {
/*  335 */     if (!this.typeMap.isEmpty()) {
/*  336 */       Object key = this.jsonValueProcessorMatcher.getMatch(propertyType, this.typeMap.keySet());
/*  337 */       return (JsonValueProcessor)this.typeMap.get(key);
/*      */     } 
/*      */     
/*  340 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonValueProcessor findJsonValueProcessor(Class beanClass, Class propertyType, String key) {
/*  360 */     JsonValueProcessor jsonValueProcessor = null;
/*  361 */     jsonValueProcessor = (JsonValueProcessor)this.beanKeyMap.get(beanClass, key);
/*  362 */     if (jsonValueProcessor != null) {
/*  363 */       return jsonValueProcessor;
/*      */     }
/*      */     
/*  366 */     jsonValueProcessor = (JsonValueProcessor)this.beanTypeMap.get(beanClass, propertyType);
/*  367 */     if (jsonValueProcessor != null) {
/*  368 */       return jsonValueProcessor;
/*      */     }
/*      */     
/*  371 */     jsonValueProcessor = (JsonValueProcessor)this.keyMap.get(key);
/*  372 */     if (jsonValueProcessor != null) {
/*  373 */       return jsonValueProcessor;
/*      */     }
/*      */     
/*  376 */     Object tkey = this.jsonValueProcessorMatcher.getMatch(propertyType, this.typeMap.keySet());
/*  377 */     jsonValueProcessor = (JsonValueProcessor)this.typeMap.get(tkey);
/*  378 */     if (jsonValueProcessor != null) {
/*  379 */       return jsonValueProcessor;
/*      */     }
/*      */     
/*  382 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonValueProcessor findJsonValueProcessor(Class propertyType, String key) {
/*  399 */     JsonValueProcessor jsonValueProcessor = null;
/*  400 */     jsonValueProcessor = (JsonValueProcessor)this.keyMap.get(key);
/*  401 */     if (jsonValueProcessor != null) {
/*  402 */       return jsonValueProcessor;
/*      */     }
/*      */     
/*  405 */     Object tkey = this.jsonValueProcessorMatcher.getMatch(propertyType, this.typeMap.keySet());
/*  406 */     jsonValueProcessor = (JsonValueProcessor)this.typeMap.get(tkey);
/*  407 */     if (jsonValueProcessor != null) {
/*  408 */       return jsonValueProcessor;
/*      */     }
/*      */     
/*  411 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyNameProcessor findPropertyNameProcessor(Class beanClass) {
/*  424 */     return findJavaPropertyNameProcessor(beanClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getArrayMode() {
/*  434 */     return this.arrayMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getClassMap() {
/*  444 */     return this.classMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class getCollectionType() {
/*  454 */     return this.collectionType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CycleDetectionStrategy getCycleDetectionStrategy() {
/*  463 */     return this.cycleDetectionStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DefaultValueProcessorMatcher getDefaultValueProcessorMatcher() {
/*  472 */     return this.defaultValueProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class getEnclosedType() {
/*  482 */     return this.enclosedType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getExcludes() {
/*  490 */     return this.excludes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaIdentifierTransformer getJavaIdentifierTransformer() {
/*  499 */     return this.javaIdentifierTransformer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyFilter getJavaPropertyFilter() {
/*  507 */     return this.javaPropertyFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyNameProcessorMatcher getJavaPropertyNameProcessorMatcher() {
/*  516 */     return this.javaPropertyNameProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonBeanProcessorMatcher getJsonBeanProcessorMatcher() {
/*  525 */     return this.jsonBeanProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized List getJsonEventListeners() {
/*  533 */     return this.eventListeners;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyFilter getJsonPropertyFilter() {
/*  541 */     return this.jsonPropertyFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyNameProcessorMatcher getJsonPropertyNameProcessorMatcher() {
/*  550 */     return this.javaPropertyNameProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonValueProcessorMatcher getJsonValueProcessorMatcher() {
/*  559 */     return this.jsonValueProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection getMergedExcludes() {
/*  567 */     Collection exclusions = new HashSet(); int i;
/*  568 */     for (i = 0; i < this.excludes.length; i++) {
/*  569 */       String exclusion = this.excludes[i];
/*  570 */       if (!StringUtils.isBlank(this.excludes[i])) {
/*  571 */         exclusions.add(exclusion.trim());
/*      */       }
/*      */     } 
/*      */     
/*  575 */     if (!this.ignoreDefaultExcludes) {
/*  576 */       for (i = 0; i < DEFAULT_EXCLUDES.length; i++) {
/*  577 */         if (!exclusions.contains(DEFAULT_EXCLUDES[i])) {
/*  578 */           exclusions.add(DEFAULT_EXCLUDES[i]);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  583 */     return exclusions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection getMergedExcludes(Class target) {
/*  592 */     if (target == null) {
/*  593 */       return getMergedExcludes();
/*      */     }
/*      */     
/*  596 */     Collection exclusionSet = getMergedExcludes();
/*  597 */     if (!this.exclusionMap.isEmpty()) {
/*  598 */       Object key = this.propertyExclusionClassMatcher.getMatch(target, this.exclusionMap.keySet());
/*  599 */       Set set = (Set)this.exclusionMap.get(key);
/*  600 */       if (set != null && !set.isEmpty()) {
/*  601 */         for (Iterator i = set.iterator(); i.hasNext(); ) {
/*  602 */           Object e = i.next();
/*  603 */           if (!exclusionSet.contains(e)) {
/*  604 */             exclusionSet.add(e);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  610 */     return exclusionSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NewBeanInstanceStrategy getNewBeanInstanceStrategy() {
/*  619 */     return this.newBeanInstanceStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyExclusionClassMatcher getPropertyExclusionClassMatcher() {
/*  628 */     return this.propertyExclusionClassMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyNameProcessorMatcher getPropertyNameProcessorMatcher() {
/*  639 */     return getJavaPropertyNameProcessorMatcher();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertySetStrategy getPropertySetStrategy() {
/*  648 */     return this.propertySetStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class getRootClass() {
/*  658 */     return this.rootClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAllowNonStringKeys() {
/*  667 */     return this.allowNonStringKeys;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEventTriggeringEnabled() {
/*  676 */     return this.triggerEvents;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHandleJettisonEmptyElement() {
/*  686 */     return this.handleJettisonEmptyElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHandleJettisonSingleElementArray() {
/*  696 */     return this.handleJettisonSingleElementArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnoreDefaultExcludes() {
/*  705 */     return this.ignoreDefaultExcludes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnoreJPATransient() {
/*  714 */     return this.ignoreFieldAnnotations.contains("javax.persistence.Transient");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnoreTransientFields() {
/*  723 */     return this.ignoreTransientFields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnorePublicFields() {
/*  732 */     return this.ignorePublicFields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isJavascriptCompliant() {
/*  741 */     return this.javascriptCompliant;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSkipJavaIdentifierTransformationInMapKeys() {
/*  750 */     return this.skipJavaIdentifierTransformationInMapKeys;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerDefaultValueProcessor(Class target, DefaultValueProcessor defaultValueProcessor) {
/*  761 */     if (target != null && defaultValueProcessor != null) {
/*  762 */       this.defaultValueMap.put(target, defaultValueProcessor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerJavaPropertyNameProcessor(Class target, PropertyNameProcessor propertyNameProcessor) {
/*  774 */     if (target != null && propertyNameProcessor != null) {
/*  775 */       this.javaPropertyNameProcessorMap.put(target, propertyNameProcessor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerJsonBeanProcessor(Class target, JsonBeanProcessor jsonBeanProcessor) {
/*  787 */     if (target != null && jsonBeanProcessor != null) {
/*  788 */       this.beanProcessorMap.put(target, jsonBeanProcessor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerJsonPropertyNameProcessor(Class target, PropertyNameProcessor propertyNameProcessor) {
/*  800 */     if (target != null && propertyNameProcessor != null) {
/*  801 */       this.jsonPropertyNameProcessorMap.put(target, propertyNameProcessor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerJsonValueProcessor(Class beanClass, Class propertyType, JsonValueProcessor jsonValueProcessor) {
/*  814 */     if (beanClass != null && propertyType != null && jsonValueProcessor != null) {
/*  815 */       this.beanTypeMap.put(beanClass, propertyType, jsonValueProcessor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerJsonValueProcessor(Class propertyType, JsonValueProcessor jsonValueProcessor) {
/*  827 */     if (propertyType != null && jsonValueProcessor != null) {
/*  828 */       this.typeMap.put(propertyType, jsonValueProcessor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerJsonValueProcessor(Class beanClass, String key, JsonValueProcessor jsonValueProcessor) {
/*  841 */     if (beanClass != null && key != null && jsonValueProcessor != null) {
/*  842 */       this.beanKeyMap.put(beanClass, key, jsonValueProcessor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerJsonValueProcessor(String key, JsonValueProcessor jsonValueProcessor) {
/*  854 */     if (key != null && jsonValueProcessor != null) {
/*  855 */       this.keyMap.put(key, jsonValueProcessor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerPropertyExclusion(Class target, String propertyName) {
/*  867 */     if (target != null && propertyName != null) {
/*  868 */       Set set = (Set)this.exclusionMap.get(target);
/*  869 */       if (set == null) {
/*  870 */         set = new HashSet();
/*  871 */         this.exclusionMap.put(target, set);
/*      */       } 
/*  873 */       if (!set.contains(propertyName)) {
/*  874 */         set.add(propertyName);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerPropertyExclusions(Class target, String[] properties) {
/*  887 */     if (target != null && properties != null && properties.length > 0) {
/*  888 */       Set set = (Set)this.exclusionMap.get(target);
/*  889 */       if (set == null) {
/*  890 */         set = new HashSet();
/*  891 */         this.exclusionMap.put(target, set);
/*      */       } 
/*  893 */       for (int i = 0; i < properties.length; i++) {
/*  894 */         if (!set.contains(properties[i])) {
/*  895 */           set.add(properties[i]);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerPropertyNameProcessor(Class target, PropertyNameProcessor propertyNameProcessor) {
/*  911 */     registerJavaPropertyNameProcessor(target, propertyNameProcessor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void removeJsonEventListener(JsonEventListener listener) {
/*  922 */     this.eventListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/*  929 */     this.excludes = EMPTY_EXCLUDES;
/*  930 */     this.ignoreDefaultExcludes = false;
/*  931 */     this.ignoreTransientFields = false;
/*  932 */     this.ignorePublicFields = true;
/*  933 */     this.javascriptCompliant = false;
/*  934 */     this.javaIdentifierTransformer = DEFAULT_JAVA_IDENTIFIER_TRANSFORMER;
/*  935 */     this.cycleDetectionStrategy = DEFAULT_CYCLE_DETECTION_STRATEGY;
/*  936 */     this.skipJavaIdentifierTransformationInMapKeys = false;
/*  937 */     this.triggerEvents = false;
/*  938 */     this.handleJettisonEmptyElement = false;
/*  939 */     this.handleJettisonSingleElementArray = false;
/*  940 */     this.arrayMode = 1;
/*  941 */     this.rootClass = null;
/*  942 */     this.classMap = null;
/*  943 */     this.keyMap.clear();
/*  944 */     this.typeMap.clear();
/*  945 */     this.beanKeyMap.clear();
/*  946 */     this.beanTypeMap.clear();
/*  947 */     this.jsonPropertyFilter = null;
/*  948 */     this.javaPropertyFilter = null;
/*  949 */     this.jsonBeanProcessorMatcher = DEFAULT_JSON_BEAN_PROCESSOR_MATCHER;
/*  950 */     this.newBeanInstanceStrategy = DEFAULT_NEW_BEAN_INSTANCE_STRATEGY;
/*  951 */     this.defaultValueProcessorMatcher = DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER;
/*  952 */     this.defaultValueMap.clear();
/*  953 */     this.propertySetStrategy = null;
/*      */     
/*  955 */     this.collectionType = DEFAULT_COLLECTION_TYPE;
/*  956 */     this.enclosedType = null;
/*  957 */     this.jsonValueProcessorMatcher = DEFAULT_JSON_VALUE_PROCESSOR_MATCHER;
/*  958 */     this.javaPropertyNameProcessorMap.clear();
/*  959 */     this.javaPropertyNameProcessorMatcher = DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
/*  960 */     this.jsonPropertyNameProcessorMap.clear();
/*  961 */     this.jsonPropertyNameProcessorMatcher = DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER;
/*  962 */     this.beanProcessorMap.clear();
/*  963 */     this.propertyExclusionClassMatcher = DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER;
/*  964 */     this.exclusionMap.clear();
/*  965 */     this.ignoreFieldAnnotations.clear();
/*  966 */     this.allowNonStringKeys = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllowNonStringKeys(boolean allowNonStringKeys) {
/*  974 */     this.allowNonStringKeys = allowNonStringKeys;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArrayMode(int arrayMode) {
/*  985 */     if (arrayMode == 2) {
/*  986 */       this.arrayMode = arrayMode;
/*  987 */     } else if (arrayMode == 2) {
/*  988 */       this.arrayMode = arrayMode;
/*  989 */       this.collectionType = Set.class;
/*      */     } else {
/*  991 */       this.arrayMode = 1;
/*  992 */       this.enclosedType = DEFAULT_COLLECTION_TYPE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClassMap(Map classMap) {
/* 1003 */     this.classMap = classMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCollectionType(Class collectionType) {
/* 1013 */     if (collectionType != null) {
/* 1014 */       if (!Collection.class.isAssignableFrom(collectionType)) {
/* 1015 */         throw new JSONException("The configured collectionType is not a Collection: " + collectionType.getName());
/*      */       }
/* 1017 */       this.collectionType = collectionType;
/*      */     } else {
/* 1019 */       collectionType = DEFAULT_COLLECTION_TYPE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCycleDetectionStrategy(CycleDetectionStrategy cycleDetectionStrategy) {
/* 1029 */     this.cycleDetectionStrategy = (cycleDetectionStrategy == null) ? DEFAULT_CYCLE_DETECTION_STRATEGY : cycleDetectionStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultValueProcessorMatcher(DefaultValueProcessorMatcher defaultValueProcessorMatcher) {
/* 1039 */     this.defaultValueProcessorMatcher = (defaultValueProcessorMatcher == null) ? DEFAULT_DEFAULT_VALUE_PROCESSOR_MATCHER : defaultValueProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnclosedType(Class enclosedType) {
/* 1050 */     this.enclosedType = enclosedType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExcludes(String[] excludes) {
/* 1059 */     this.excludes = (excludes == null) ? EMPTY_EXCLUDES : excludes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHandleJettisonEmptyElement(boolean handleJettisonEmptyElement) {
/* 1069 */     this.handleJettisonEmptyElement = handleJettisonEmptyElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHandleJettisonSingleElementArray(boolean handleJettisonSingleElementArray) {
/* 1079 */     this.handleJettisonSingleElementArray = handleJettisonSingleElementArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIgnoreDefaultExcludes(boolean ignoreDefaultExcludes) {
/* 1087 */     this.ignoreDefaultExcludes = ignoreDefaultExcludes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIgnoreJPATransient(boolean ignoreJPATransient) {
/* 1095 */     if (ignoreJPATransient) {
/* 1096 */       addIgnoreFieldAnnotation("javax.persistence.Transient");
/*      */     } else {
/* 1098 */       removeIgnoreFieldAnnotation("javax.persistence.Transient");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addIgnoreFieldAnnotation(String annotationClassName) {
/* 1107 */     if (annotationClassName != null && !this.ignoreFieldAnnotations.contains(annotationClassName)) {
/* 1108 */       this.ignoreFieldAnnotations.add(annotationClassName);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeIgnoreFieldAnnotation(String annotationClassName) {
/* 1117 */     if (annotationClassName != null) this.ignoreFieldAnnotations.remove(annotationClassName);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addIgnoreFieldAnnotation(Class annotationClass) {
/* 1125 */     if (annotationClass != null && !this.ignoreFieldAnnotations.contains(annotationClass.getName())) {
/* 1126 */       this.ignoreFieldAnnotations.add(annotationClass.getName());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeIgnoreFieldAnnotation(Class annotationClass) {
/* 1135 */     if (annotationClass != null) this.ignoreFieldAnnotations.remove(annotationClass.getName());
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List getIgnoreFieldAnnotations() {
/* 1143 */     return Collections.unmodifiableList(this.ignoreFieldAnnotations);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIgnoreTransientFields(boolean ignoreTransientFields) {
/* 1151 */     this.ignoreTransientFields = ignoreTransientFields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIgnorePublicFields(boolean ignorePublicFields) {
/* 1159 */     this.ignorePublicFields = ignorePublicFields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJavascriptCompliant(boolean javascriptCompliant) {
/* 1167 */     this.javascriptCompliant = javascriptCompliant;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJavaIdentifierTransformer(JavaIdentifierTransformer javaIdentifierTransformer) {
/* 1176 */     this.javaIdentifierTransformer = (javaIdentifierTransformer == null) ? DEFAULT_JAVA_IDENTIFIER_TRANSFORMER : javaIdentifierTransformer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJavaPropertyFilter(PropertyFilter javaPropertyFilter) {
/* 1187 */     this.javaPropertyFilter = javaPropertyFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJavaPropertyNameProcessorMatcher(PropertyNameProcessorMatcher propertyNameProcessorMatcher) {
/* 1196 */     this.javaPropertyNameProcessorMatcher = (propertyNameProcessorMatcher == null) ? DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER : propertyNameProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJsonBeanProcessorMatcher(JsonBeanProcessorMatcher jsonBeanProcessorMatcher) {
/* 1206 */     this.jsonBeanProcessorMatcher = (jsonBeanProcessorMatcher == null) ? DEFAULT_JSON_BEAN_PROCESSOR_MATCHER : jsonBeanProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJsonPropertyFilter(PropertyFilter jsonPropertyFilter) {
/* 1217 */     this.jsonPropertyFilter = jsonPropertyFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJsonPropertyNameProcessorMatcher(PropertyNameProcessorMatcher propertyNameProcessorMatcher) {
/* 1226 */     this.jsonPropertyNameProcessorMatcher = (propertyNameProcessorMatcher == null) ? DEFAULT_PROPERTY_NAME_PROCESSOR_MATCHER : propertyNameProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setJsonValueProcessorMatcher(JsonValueProcessorMatcher jsonValueProcessorMatcher) {
/* 1236 */     this.jsonValueProcessorMatcher = (jsonValueProcessorMatcher == null) ? DEFAULT_JSON_VALUE_PROCESSOR_MATCHER : jsonValueProcessorMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNewBeanInstanceStrategy(NewBeanInstanceStrategy newBeanInstanceStrategy) {
/* 1246 */     this.newBeanInstanceStrategy = (newBeanInstanceStrategy == null) ? DEFAULT_NEW_BEAN_INSTANCE_STRATEGY : newBeanInstanceStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPropertyExclusionClassMatcher(PropertyExclusionClassMatcher propertyExclusionClassMatcher) {
/* 1256 */     this.propertyExclusionClassMatcher = (propertyExclusionClassMatcher == null) ? DEFAULT_PROPERTY_EXCLUSION_CLASS_MATCHER : propertyExclusionClassMatcher;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPropertyNameProcessorMatcher(PropertyNameProcessorMatcher propertyNameProcessorMatcher) {
/* 1268 */     setJavaPropertyNameProcessorMatcher(propertyNameProcessorMatcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPropertySetStrategy(PropertySetStrategy propertySetStrategy) {
/* 1277 */     this.propertySetStrategy = propertySetStrategy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRootClass(Class rootClass) {
/* 1287 */     this.rootClass = rootClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSkipJavaIdentifierTransformationInMapKeys(boolean skipJavaIdentifierTransformationInMapKeys) {
/* 1295 */     this.skipJavaIdentifierTransformationInMapKeys = skipJavaIdentifierTransformationInMapKeys;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterDefaultValueProcessor(Class target) {
/* 1305 */     if (target != null) {
/* 1306 */       this.defaultValueMap.remove(target);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterJavaPropertyNameProcessor(Class target) {
/* 1317 */     if (target != null) {
/* 1318 */       this.javaPropertyNameProcessorMap.remove(target);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterJsonBeanProcessor(Class target) {
/* 1329 */     if (target != null) {
/* 1330 */       this.beanProcessorMap.remove(target);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterJsonPropertyNameProcessor(Class target) {
/* 1341 */     if (target != null) {
/* 1342 */       this.jsonPropertyNameProcessorMap.remove(target);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterJsonValueProcessor(Class propertyType) {
/* 1353 */     if (propertyType != null) {
/* 1354 */       this.typeMap.remove(propertyType);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterJsonValueProcessor(Class beanClass, Class propertyType) {
/* 1366 */     if (beanClass != null && propertyType != null) {
/* 1367 */       this.beanTypeMap.remove(beanClass, propertyType);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterJsonValueProcessor(Class beanClass, String key) {
/* 1379 */     if (beanClass != null && key != null) {
/* 1380 */       this.beanKeyMap.remove(beanClass, key);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterJsonValueProcessor(String key) {
/* 1391 */     if (key != null) {
/* 1392 */       this.keyMap.remove(key);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterPropertyExclusion(Class target, String propertyName) {
/* 1404 */     if (target != null && propertyName != null) {
/* 1405 */       Set set = (Set)this.exclusionMap.get(target);
/* 1406 */       if (set == null) {
/* 1407 */         set = new HashSet();
/* 1408 */         this.exclusionMap.put(target, set);
/*      */       } 
/* 1410 */       set.remove(propertyName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterPropertyExclusions(Class target) {
/* 1421 */     if (target != null) {
/* 1422 */       Set set = (Set)this.exclusionMap.get(target);
/* 1423 */       if (set != null) {
/* 1424 */         set.clear();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unregisterPropertyNameProcessor(Class target) {
/* 1438 */     unregisterJavaPropertyNameProcessor(target);
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\JsonConfig.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */