/*     */ package net.sf.json;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import net.sf.json.util.JSONUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONFunction
/*     */   implements Serializable
/*     */ {
/*  34 */   private static final String[] EMPTY_PARAM_ARRAY = new String[0];
/*     */   
/*     */   private String[] params;
/*     */   
/*     */   private String text;
/*     */   
/*     */   public static JSONFunction parse(String str) {
/*  41 */     if (!JSONUtils.isFunction(str)) {
/*  42 */       throw new JSONException("String is not a function. " + str);
/*     */     }
/*  44 */     String params = JSONUtils.getFunctionParams(str);
/*  45 */     String text = JSONUtils.getFunctionBody(str);
/*  46 */     return new JSONFunction((params != null) ? StringUtils.split(params, ",") : null, (text != null) ? text : "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONFunction(String text) {
/*  62 */     this(null, text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONFunction(String[] params, String text) {
/*  72 */     this.text = (text != null) ? text.trim() : "";
/*  73 */     if (params != null) {
/*  74 */       if (params.length == 1 && params[0].trim().equals("")) {
/*     */         
/*  76 */         this.params = EMPTY_PARAM_ARRAY;
/*     */       } else {
/*  78 */         this.params = new String[params.length];
/*  79 */         System.arraycopy(params, 0, this.params, 0, params.length);
/*     */         
/*  81 */         for (int i = 0; i < params.length; i++) {
/*  82 */           this.params[i] = this.params[i].trim();
/*     */         }
/*     */       } 
/*     */     } else {
/*  86 */       this.params = EMPTY_PARAM_ARRAY;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  91 */     if (this == obj) {
/*  92 */       return true;
/*     */     }
/*  94 */     if (obj == null) {
/*  95 */       return false;
/*     */     }
/*     */     
/*  98 */     if (obj instanceof String) {
/*     */       try {
/* 100 */         JSONFunction jSONFunction = parse((String)obj);
/* 101 */         return equals(jSONFunction);
/* 102 */       } catch (JSONException e) {
/* 103 */         return false;
/*     */       } 
/*     */     }
/*     */     
/* 107 */     if (!(obj instanceof JSONFunction)) {
/* 108 */       return false;
/*     */     }
/*     */     
/* 111 */     JSONFunction other = (JSONFunction)obj;
/* 112 */     if (this.params.length != other.params.length) {
/* 113 */       return false;
/*     */     }
/* 115 */     EqualsBuilder builder = new EqualsBuilder();
/* 116 */     for (int i = 0; i < this.params.length; i++) {
/* 117 */       builder.append(this.params[i], other.params[i]);
/*     */     }
/* 119 */     builder.append(this.text, other.text);
/* 120 */     return builder.isEquals();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getParams() {
/* 127 */     return this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 134 */     return this.text;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 138 */     HashCodeBuilder builder = new HashCodeBuilder();
/* 139 */     for (int i = 0; i < this.params.length; i++) {
/* 140 */       builder.append(this.params[i]);
/*     */     }
/* 142 */     builder.append(this.text);
/* 143 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     StringBuffer b = new StringBuffer("function(");
/* 151 */     if (this.params.length > 0) {
/* 152 */       for (int i = 0; i < this.params.length - 1; i++) {
/* 153 */         b.append(this.params[i]).append(',');
/*     */       }
/*     */       
/* 156 */       b.append(this.params[this.params.length - 1]);
/*     */     } 
/* 158 */     b.append("){");
/* 159 */     if (this.text.length() > 0) {
/* 160 */       b.append(' ').append(this.text).append(' ');
/*     */     }
/*     */ 
/*     */     
/* 164 */     b.append('}');
/* 165 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\JSONFunction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */