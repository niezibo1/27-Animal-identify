/*     */ package net.sf.json.test;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import junit.framework.Assert;
/*     */ import net.sf.ezmorph.Morpher;
/*     */ import net.sf.ezmorph.object.IdentityObjectMorpher;
/*     */ import net.sf.json.JSON;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONException;
/*     */ import net.sf.json.JSONFunction;
/*     */ import net.sf.json.JSONNull;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.JSONSerializer;
/*     */ import net.sf.json.util.JSONUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONAssert
/*     */   extends Assert
/*     */ {
/*     */   public static void assertEquals(JSON expected, JSON actual) {
/*  43 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(JSONArray expected, JSONArray actual) {
/*  50 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(JSONArray expected, String actual) {
/*  57 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(JSONFunction expected, String actual) {
/*  64 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(JSONNull expected, String actual) {
/*  71 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(JSONObject expected, JSONObject actual) {
/*  78 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(JSONObject expected, String actual) {
/*  85 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, JSON expected, JSON actual) {
/*  92 */     String header = (message == null) ? "" : (message + ": ");
/*  93 */     if (expected == null) {
/*  94 */       Assert.fail(header + "expected was null");
/*     */     }
/*  96 */     if (actual == null) {
/*  97 */       Assert.fail(header + "actual was null");
/*     */     }
/*  99 */     if (expected == actual || expected.equals(actual)) {
/*     */       return;
/*     */     }
/*     */     
/* 103 */     if (expected instanceof JSONArray) {
/* 104 */       if (actual instanceof JSONArray) {
/* 105 */         assertEquals(header, (JSONArray)expected, (JSONArray)actual);
/*     */       } else {
/* 107 */         Assert.fail(header + "actual is not a JSONArray");
/*     */       } 
/* 109 */     } else if (expected instanceof JSONObject) {
/* 110 */       if (actual instanceof JSONObject) {
/* 111 */         assertEquals(header, (JSONObject)expected, (JSONObject)actual);
/*     */       } else {
/* 113 */         Assert.fail(header + "actual is not a JSONObject");
/*     */       } 
/* 115 */     } else if (expected instanceof JSONNull) {
/* 116 */       if (actual instanceof JSONNull) {
/*     */         return;
/*     */       }
/* 119 */       Assert.fail(header + "actual is not a JSONNull");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String expected, JSONArray actual) {
/* 128 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, JSONArray expected, JSONArray actual) {
/* 135 */     String header = (message == null) ? "" : (message + ": ");
/* 136 */     if (expected == null) {
/* 137 */       Assert.fail(header + "expected array was null");
/*     */     }
/* 139 */     if (actual == null) {
/* 140 */       Assert.fail(header + "actual array was null");
/*     */     }
/* 142 */     if (expected == actual || expected.equals(actual)) {
/*     */       return;
/*     */     }
/* 145 */     if (actual.size() != expected.size()) {
/* 146 */       Assert.fail(header + "arrays sizes differed, expected.length()=" + expected.size() + " actual.length()=" + actual.size());
/*     */     }
/*     */ 
/*     */     
/* 150 */     int max = expected.size();
/* 151 */     for (int i = 0; i < max; i++) {
/* 152 */       Object o1 = expected.get(i);
/* 153 */       Object o2 = actual.get(i);
/*     */ 
/*     */       
/* 156 */       if (JSONNull.getInstance().equals(o1)) {
/*     */         
/* 158 */         if (JSONNull.getInstance().equals(o2)) {
/*     */           continue;
/*     */         }
/*     */         
/* 162 */         Assert.fail(header + "arrays first differed at element [" + i + "];");
/*     */       
/*     */       }
/* 165 */       else if (JSONNull.getInstance().equals(o2)) {
/*     */         
/* 167 */         Assert.fail(header + "arrays first differed at element [" + i + "];");
/*     */       } 
/*     */ 
/*     */       
/* 171 */       if (o1 instanceof JSONArray && o2 instanceof JSONArray) {
/* 172 */         JSONArray e = (JSONArray)o1;
/* 173 */         JSONArray a = (JSONArray)o2;
/* 174 */         assertEquals(header + "arrays first differed at element " + i + ";", e, a);
/*     */       }
/* 176 */       else if (o1 instanceof String && o2 instanceof JSONFunction) {
/* 177 */         assertEquals(header + "arrays first differed at element [" + i + "];", (String)o1, (JSONFunction)o2);
/*     */       }
/* 179 */       else if (o1 instanceof JSONFunction && o2 instanceof String) {
/* 180 */         assertEquals(header + "arrays first differed at element [" + i + "];", (JSONFunction)o1, (String)o2);
/*     */       }
/* 182 */       else if (o1 instanceof JSONObject && o2 instanceof JSONObject) {
/* 183 */         assertEquals(header + "arrays first differed at element [" + i + "];", (JSONObject)o1, (JSONObject)o2);
/*     */       }
/* 185 */       else if (o1 instanceof JSONArray && o2 instanceof JSONArray) {
/* 186 */         assertEquals(header + "arrays first differed at element [" + i + "];", (JSONArray)o1, (JSONArray)o2);
/*     */       }
/* 188 */       else if (o1 instanceof JSONFunction && o2 instanceof JSONFunction) {
/* 189 */         Assert.assertEquals(header + "arrays first differed at element [" + i + "];", o1, o2);
/*     */       
/*     */       }
/* 192 */       else if (o1 instanceof String) {
/* 193 */         Assert.assertEquals(header + "arrays first differed at element [" + i + "];", (String)o1, String.valueOf(o2));
/*     */       }
/* 195 */       else if (o2 instanceof String) {
/* 196 */         Assert.assertEquals(header + "arrays first differed at element [" + i + "];", String.valueOf(o1), (String)o2);
/*     */       } else {
/*     */         
/* 199 */         Morpher m1 = JSONUtils.getMorpherRegistry().getMorpherFor(o1.getClass());
/*     */         
/* 201 */         Morpher m2 = JSONUtils.getMorpherRegistry().getMorpherFor(o2.getClass());
/*     */         
/* 203 */         if (m1 != null && m1 != IdentityObjectMorpher.getInstance()) {
/* 204 */           Assert.assertEquals(header + "arrays first differed at element [" + i + "];", o1, JSONUtils.getMorpherRegistry().morph(o1.getClass(), o2));
/*     */         
/*     */         }
/* 207 */         else if (m2 != null && m2 != IdentityObjectMorpher.getInstance()) {
/* 208 */           Assert.assertEquals(header + "arrays first differed at element [" + i + "];", JSONUtils.getMorpherRegistry().morph(o1.getClass(), o1), o2);
/*     */         }
/*     */         else {
/*     */           
/* 212 */           Assert.assertEquals(header + "arrays first differed at element [" + i + "];", o1, o2);
/*     */         } 
/*     */       } 
/*     */       continue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, JSONArray expected, String actual) {
/*     */     try {
/* 225 */       assertEquals(message, expected, JSONArray.fromObject(actual));
/* 226 */     } catch (JSONException e) {
/* 227 */       String header = (message == null) ? "" : (message + ": ");
/* 228 */       Assert.fail(header + "actual is not a JSONArray");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String expected, JSONFunction actual) {
/* 236 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, JSONFunction expected, String actual) {
/* 243 */     String header = (message == null) ? "" : (message + ": ");
/* 244 */     if (expected == null) {
/* 245 */       Assert.fail(header + "expected function was null");
/*     */     }
/* 247 */     if (actual == null) {
/* 248 */       Assert.fail(header + "actual string was null");
/*     */     }
/*     */     
/*     */     try {
/* 252 */       Assert.assertEquals(header, expected, JSONFunction.parse(actual));
/* 253 */     } catch (JSONException jsone) {
/* 254 */       Assert.fail(header + "'" + actual + "' is not a function");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String expected, JSONNull actual) {
/* 262 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, JSONNull expected, String actual) {
/* 269 */     String header = (message == null) ? "" : (message + ": ");
/* 270 */     if (actual == null) {
/* 271 */       Assert.fail(header + "actual string was null");
/* 272 */     } else if (expected == null) {
/* 273 */       Assert.assertEquals(header, "null", actual);
/*     */     } else {
/* 275 */       Assert.assertEquals(header, expected.toString(), actual);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String expected, JSONObject actual) {
/* 283 */     assertEquals((String)null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, JSONObject expected, JSONObject actual) {
/* 290 */     String header = (message == null) ? "" : (message + ": ");
/* 291 */     if (expected == null) {
/* 292 */       Assert.fail(header + "expected object was null");
/*     */     }
/* 294 */     if (actual == null) {
/* 295 */       Assert.fail(header + "actual object was null");
/*     */     }
/* 297 */     if (expected == actual) {
/*     */       return;
/*     */     }
/*     */     
/* 301 */     if (expected.isNullObject()) {
/* 302 */       if (actual.isNullObject()) {
/*     */         return;
/*     */       }
/* 305 */       Assert.fail(header + "actual is not a null JSONObject");
/*     */     
/*     */     }
/* 308 */     else if (actual.isNullObject()) {
/* 309 */       Assert.fail(header + "actual is a null JSONObject");
/*     */     } 
/*     */ 
/*     */     
/* 313 */     Assert.assertEquals(header + "names sizes differed, expected.names().length()=" + expected.names().size() + " actual.names().length()=" + actual.names().size(), expected.names().size(), actual.names().size());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     for (Iterator keys = expected.keys(); keys.hasNext(); ) {
/* 319 */       String key = keys.next();
/* 320 */       Object o1 = expected.opt(key);
/* 321 */       Object o2 = actual.opt(key);
/*     */       
/* 323 */       if (JSONNull.getInstance().equals(o1)) {
/*     */         
/* 325 */         if (JSONNull.getInstance().equals(o2)) {
/*     */           continue;
/*     */         }
/*     */         
/* 329 */         Assert.fail(header + "objects differed at key [" + key + "];");
/*     */       
/*     */       }
/* 332 */       else if (JSONNull.getInstance().equals(o2)) {
/*     */         
/* 334 */         Assert.fail(header + "objects differed at key [" + key + "];");
/*     */       } 
/*     */ 
/*     */       
/* 338 */       if (o1 instanceof String && o2 instanceof JSONFunction) {
/* 339 */         assertEquals(header + "objects differed at key [" + key + "];", (String)o1, (JSONFunction)o2); continue;
/*     */       } 
/* 341 */       if (o1 instanceof JSONFunction && o2 instanceof String) {
/* 342 */         assertEquals(header + "objects differed at key [" + key + "];", (JSONFunction)o1, (String)o2); continue;
/*     */       } 
/* 344 */       if (o1 instanceof JSONObject && o2 instanceof JSONObject) {
/* 345 */         assertEquals(header + "objects differed at key [" + key + "];", (JSONObject)o1, (JSONObject)o2); continue;
/*     */       } 
/* 347 */       if (o1 instanceof JSONArray && o2 instanceof JSONArray) {
/* 348 */         assertEquals(header + "objects differed at key [" + key + "];", (JSONArray)o1, (JSONArray)o2); continue;
/*     */       } 
/* 350 */       if (o1 instanceof JSONFunction && o2 instanceof JSONFunction) {
/* 351 */         Assert.assertEquals(header + "objects differed at key [" + key + "];", o1, o2);
/*     */         continue;
/*     */       } 
/* 354 */       if (o1 instanceof String) {
/* 355 */         Assert.assertEquals(header + "objects differed at key [" + key + "];", (String)o1, String.valueOf(o2)); continue;
/*     */       } 
/* 357 */       if (o2 instanceof String) {
/* 358 */         Assert.assertEquals(header + "objects differed at key [" + key + "];", String.valueOf(o1), (String)o2);
/*     */         continue;
/*     */       } 
/* 361 */       Morpher m1 = JSONUtils.getMorpherRegistry().getMorpherFor(o1.getClass());
/*     */       
/* 363 */       Morpher m2 = JSONUtils.getMorpherRegistry().getMorpherFor(o2.getClass());
/*     */       
/* 365 */       if (m1 != null && m1 != IdentityObjectMorpher.getInstance()) {
/* 366 */         Assert.assertEquals(header + "objects differed at key [" + key + "];", o1, JSONUtils.getMorpherRegistry().morph(o1.getClass(), o2));
/*     */         continue;
/*     */       } 
/* 369 */       if (m2 != null && m2 != IdentityObjectMorpher.getInstance()) {
/* 370 */         Assert.assertEquals(header + "objects differed at key [" + key + "];", JSONUtils.getMorpherRegistry().morph(o1.getClass(), o1), o2);
/*     */         
/*     */         continue;
/*     */       } 
/* 374 */       Assert.assertEquals(header + "objects differed at key [" + key + "];", o1, o2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, JSONObject expected, String actual) {
/*     */     try {
/* 386 */       assertEquals(message, expected, JSONObject.fromObject(actual));
/* 387 */     } catch (JSONException e) {
/* 388 */       String header = (message == null) ? "" : (message + ": ");
/* 389 */       Assert.fail(header + "actual is not a JSONObject");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, String expected, JSONArray actual) {
/*     */     try {
/* 398 */       assertEquals(message, JSONArray.fromObject(expected), actual);
/* 399 */     } catch (JSONException e) {
/* 400 */       String header = (message == null) ? "" : (message + ": ");
/* 401 */       Assert.fail(header + "expected is not a JSONArray");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, String expected, JSONFunction actual) {
/* 409 */     String header = (message == null) ? "" : (message + ": ");
/* 410 */     if (expected == null) {
/* 411 */       Assert.fail(header + "expected string was null");
/*     */     }
/* 413 */     if (actual == null) {
/* 414 */       Assert.fail(header + "actual function was null");
/*     */     }
/*     */     
/*     */     try {
/* 418 */       Assert.assertEquals(header, JSONFunction.parse(expected), actual);
/* 419 */     } catch (JSONException jsone) {
/* 420 */       Assert.fail(header + "'" + expected + "' is not a function");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, String expected, JSONNull actual) {
/* 428 */     String header = (message == null) ? "" : (message + ": ");
/* 429 */     if (expected == null) {
/* 430 */       Assert.fail(header + "expected was null");
/* 431 */     } else if (actual == null) {
/* 432 */       Assert.assertEquals(header, expected, "null");
/*     */     } else {
/* 434 */       Assert.assertEquals(header, expected, actual.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, String expected, JSONObject actual) {
/*     */     try {
/* 443 */       assertEquals(message, JSONObject.fromObject(expected), actual);
/* 444 */     } catch (JSONException e) {
/* 445 */       String header = (message == null) ? "" : (message + ": ");
/* 446 */       Assert.fail(header + "expected is not a JSONObject");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertJsonEquals(String expected, String actual) {
/* 454 */     assertJsonEquals(null, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertJsonEquals(String message, String expected, String actual) {
/* 461 */     String header = (message == null) ? "" : (message + ": ");
/* 462 */     if (expected == null) {
/* 463 */       Assert.fail(header + "expected was null");
/*     */     }
/* 465 */     if (actual == null) {
/* 466 */       Assert.fail(header + "actual was null");
/*     */     }
/*     */     
/* 469 */     JSON json1 = null;
/* 470 */     JSON json2 = null;
/*     */     try {
/* 472 */       json1 = JSONSerializer.toJSON(expected);
/* 473 */     } catch (JSONException jsone) {
/* 474 */       Assert.fail(header + "expected is not a valid JSON string");
/*     */     } 
/*     */     try {
/* 477 */       json2 = JSONSerializer.toJSON(actual);
/* 478 */     } catch (JSONException jsone) {
/* 479 */       Assert.fail(header + "actual is not a valid JSON string");
/*     */     } 
/* 481 */     assertEquals(header, json1, json2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNotNull(JSON json) {
/* 493 */     assertNotNull(null, json);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNotNull(String message, JSON json) {
/* 505 */     String header = (message == null) ? "" : (message + ": ");
/* 506 */     if (json instanceof JSONObject) {
/* 507 */       Assert.assertFalse(header + "Object is null", ((JSONObject)json).isNullObject());
/* 508 */     } else if (JSONNull.getInstance().equals(json)) {
/*     */       
/* 510 */       Assert.fail(header + "Object is null");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNull(JSON json) {
/* 523 */     assertNull(null, json);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNull(String message, JSON json) {
/* 535 */     String header = (message == null) ? "" : (message + ": ");
/* 536 */     if (json instanceof JSONObject) {
/* 537 */       Assert.assertTrue(header + "Object is not null", ((JSONObject)json).isNullObject());
/* 538 */     } else if (!JSONNull.getInstance().equals(json)) {
/*     */       
/* 540 */       Assert.fail(header + "Object is not null");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\test\JSONAssert.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */