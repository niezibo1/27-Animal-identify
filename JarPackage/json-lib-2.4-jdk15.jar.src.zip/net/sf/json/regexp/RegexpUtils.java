/*    */ package net.sf.json.regexp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegexpUtils
/*    */ {
/* 25 */   private static String javaVersion = "1.3.1";
/*    */   static {
/* 27 */     javaVersion = System.getProperty("java.version");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RegexpMatcher getMatcher(String pattern) {
/* 36 */     if (isJDK13()) {
/* 37 */       return new Perl5RegexpMatcher(pattern);
/*    */     }
/* 39 */     return new JdkRegexpMatcher(pattern);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RegexpMatcher getMatcher(String pattern, boolean multiline) {
/* 49 */     if (isJDK13()) {
/* 50 */       return new Perl5RegexpMatcher(pattern, true);
/*    */     }
/* 52 */     return new JdkRegexpMatcher(pattern, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isJDK13() {
/* 60 */     return (javaVersion.indexOf("1.3") != -1);
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\regexp\RegexpUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */