package net.sf.json.regexp;

public interface RegexpMatcher {
  String getGroupIfMatches(String paramString, int paramInt);
  
  boolean matches(String paramString);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\regexp\RegexpMatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */