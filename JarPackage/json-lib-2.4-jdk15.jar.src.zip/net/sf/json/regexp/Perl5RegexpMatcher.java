/*    */ package net.sf.json.regexp;
/*    */ 
/*    */ import org.apache.commons.lang.exception.NestableRuntimeException;
/*    */ import org.apache.oro.text.regex.MalformedPatternException;
/*    */ import org.apache.oro.text.regex.Pattern;
/*    */ import org.apache.oro.text.regex.Perl5Compiler;
/*    */ import org.apache.oro.text.regex.Perl5Matcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Perl5RegexpMatcher
/*    */   implements RegexpMatcher
/*    */ {
/* 33 */   private static final Perl5Compiler compiler = new Perl5Compiler();
/*    */   private Pattern pattern;
/*    */   
/*    */   public Perl5RegexpMatcher(String pattern) {
/* 37 */     this(pattern, false);
/*    */   }
/*    */   
/*    */   public Perl5RegexpMatcher(String pattern, boolean multiline) {
/*    */     try {
/* 42 */       if (multiline) {
/* 43 */         this.pattern = compiler.compile(pattern, 32776);
/*    */       } else {
/* 45 */         this.pattern = compiler.compile(pattern, 32768);
/*    */       } 
/* 47 */     } catch (MalformedPatternException mpe) {
/* 48 */       throw new NestableRuntimeException(mpe);
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getGroupIfMatches(String str, int group) {
/* 53 */     Perl5Matcher perl5Matcher = new Perl5Matcher();
/* 54 */     if (perl5Matcher.matches(str, this.pattern)) {
/* 55 */       return perl5Matcher.getMatch().group(1);
/*    */     }
/* 57 */     return "";
/*    */   }
/*    */   
/*    */   public boolean matches(String str) {
/* 61 */     return (new Perl5Matcher()).matches(str, this.pattern);
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\regexp\Perl5RegexpMatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */