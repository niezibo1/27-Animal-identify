/*    */ package net.sf.json.regexp;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdkRegexpMatcher
/*    */   implements RegexpMatcher
/*    */ {
/*    */   private final Pattern pattern;
/*    */   
/*    */   public JdkRegexpMatcher(String pattern) {
/* 31 */     this(pattern, false);
/*    */   }
/*    */   
/*    */   public JdkRegexpMatcher(String pattern, boolean multiline) {
/* 35 */     if (multiline) {
/* 36 */       this.pattern = Pattern.compile(pattern, 8);
/*    */     } else {
/* 38 */       this.pattern = Pattern.compile(pattern);
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getGroupIfMatches(String str, int group) {
/* 43 */     Matcher matcher = this.pattern.matcher(str);
/* 44 */     if (matcher.matches()) {
/* 45 */       return matcher.group(group);
/*    */     }
/* 47 */     return "";
/*    */   }
/*    */   
/*    */   public boolean matches(String str) {
/* 51 */     return this.pattern.matcher(str).matches();
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\regexp\JdkRegexpMatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */