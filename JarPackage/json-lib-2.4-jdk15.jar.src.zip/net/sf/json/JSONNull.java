/*     */ package net.sf.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JSONNull
/*     */   implements JSON
/*     */ {
/*  33 */   private static JSONNull instance = new JSONNull();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSONNull getInstance() {
/*  40 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  55 */     return (object == null || object == this || object == instance || (object instanceof JSONObject && ((JSONObject)object).isNullObject()) || "null".equals(object));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  61 */     return 37 + "null".hashCode();
/*     */   }
/*     */   
/*     */   public boolean isArray() {
/*  65 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  69 */     throw new JSONException("Object is null");
/*     */   }
/*     */   
/*     */   public int size() {
/*  73 */     throw new JSONException("Object is null");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  82 */     return "null";
/*     */   }
/*     */   
/*     */   public String toString(int indentFactor) {
/*  86 */     return toString();
/*     */   }
/*     */   
/*     */   public String toString(int indentFactor, int indent) {
/*  90 */     StringBuffer sb = new StringBuffer();
/*  91 */     for (int i = 0; i < indent; i++) {
/*  92 */       sb.append(' ');
/*     */     }
/*  94 */     sb.append(toString());
/*  95 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public Writer write(Writer writer) {
/*     */     try {
/* 100 */       writer.write(toString());
/* 101 */       return writer;
/* 102 */     } catch (IOException e) {
/* 103 */       throw new JSONException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\JSONNull.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */