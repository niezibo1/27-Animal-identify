/*    */ package net.sf.json;
/*    */ 
/*    */ import org.apache.commons.lang.exception.NestableRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSONException
/*    */   extends NestableRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 6995087065217051815L;
/*    */   
/*    */   public JSONException() {}
/*    */   
/*    */   public JSONException(String msg) {
/* 34 */     super(msg, null);
/*    */   }
/*    */   
/*    */   public JSONException(String msg, Throwable cause) {
/* 38 */     super(msg, cause);
/*    */   }
/*    */   
/*    */   public JSONException(Throwable cause) {
/* 42 */     super((cause == null) ? null : cause.toString(), cause);
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\JSONException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */