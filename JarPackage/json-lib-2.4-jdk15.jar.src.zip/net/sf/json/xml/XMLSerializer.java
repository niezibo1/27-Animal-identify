/*      */ package net.sf.json.xml;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ import net.sf.json.JSON;
/*      */ import net.sf.json.JSONArray;
/*      */ import net.sf.json.JSONException;
/*      */ import net.sf.json.JSONFunction;
/*      */ import net.sf.json.JSONNull;
/*      */ import net.sf.json.JSONObject;
/*      */ import net.sf.json.util.JSONUtils;
/*      */ import nu.xom.Attribute;
/*      */ import nu.xom.Builder;
/*      */ import nu.xom.Document;
/*      */ import nu.xom.Element;
/*      */ import nu.xom.Elements;
/*      */ import nu.xom.Node;
/*      */ import nu.xom.Serializer;
/*      */ import nu.xom.Text;
/*      */ import org.apache.commons.lang.ArrayUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XMLSerializer
/*      */ {
/*   82 */   private static final String[] EMPTY_ARRAY = new String[0];
/*      */   private static final String JSON_PREFIX = "json_";
/*   84 */   private static final Log log = LogFactory.getLog(XMLSerializer.class);
/*      */   
/*      */   private String arrayName;
/*      */   
/*      */   private String elementName;
/*      */   
/*      */   private String[] expandableProperties;
/*      */   
/*      */   private boolean forceTopLevelObject;
/*      */   
/*      */   private boolean namespaceLenient;
/*      */   
/*   96 */   private Map namespacesPerElement = new TreeMap();
/*      */   
/*      */   private String objectName;
/*      */   
/*      */   private boolean removeNamespacePrefixFromElements;
/*      */   
/*      */   private String rootName;
/*      */   
/*  104 */   private Map rootNamespace = new TreeMap();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean skipNamespaces;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean skipWhitespace;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean trimSpaces;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean typeHintsCompatibility;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean typeHintsEnabled;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMLSerializer() {
/*  132 */     setObjectName("o");
/*  133 */     setArrayName("a");
/*  134 */     setElementName("e");
/*  135 */     setTypeHintsEnabled(true);
/*  136 */     setTypeHintsCompatibility(true);
/*  137 */     setNamespaceLenient(false);
/*  138 */     setSkipNamespaces(false);
/*  139 */     setRemoveNamespacePrefixFromElements(false);
/*  140 */     setTrimSpaces(false);
/*  141 */     setExpandableProperties(EMPTY_ARRAY);
/*  142 */     setSkipNamespaces(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNamespace(String prefix, String uri) {
/*  152 */     addNamespace(prefix, uri, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNamespace(String prefix, String uri, String elementName) {
/*  165 */     if (StringUtils.isBlank(uri)) {
/*      */       return;
/*      */     }
/*  168 */     if (prefix == null) {
/*  169 */       prefix = "";
/*      */     }
/*  171 */     if (StringUtils.isBlank(elementName)) {
/*  172 */       this.rootNamespace.put(prefix.trim(), uri.trim());
/*      */     } else {
/*  174 */       Map nameSpaces = (Map)this.namespacesPerElement.get(elementName);
/*  175 */       if (nameSpaces == null) {
/*  176 */         nameSpaces = new TreeMap();
/*  177 */         this.namespacesPerElement.put(elementName, nameSpaces);
/*      */       } 
/*  179 */       nameSpaces.put(prefix, uri);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearNamespaces() {
/*  187 */     this.rootNamespace.clear();
/*  188 */     this.namespacesPerElement.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearNamespaces(String elementName) {
/*  199 */     if (StringUtils.isBlank(elementName)) {
/*  200 */       this.rootNamespace.clear();
/*      */     } else {
/*  202 */       this.namespacesPerElement.remove(elementName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getArrayName() {
/*  210 */     return this.arrayName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getElementName() {
/*  217 */     return this.elementName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getExpandableProperties() {
/*  224 */     return this.expandableProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getObjectName() {
/*  231 */     return this.objectName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRootName() {
/*  238 */     return this.rootName;
/*      */   }
/*      */   
/*      */   public boolean isForceTopLevelObject() {
/*  242 */     return this.forceTopLevelObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNamespaceLenient() {
/*  250 */     return this.namespaceLenient;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRemoveNamespacePrefixFromElements() {
/*  258 */     return this.removeNamespacePrefixFromElements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSkipNamespaces() {
/*  266 */     return this.skipNamespaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSkipWhitespace() {
/*  273 */     return this.skipWhitespace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTrimSpaces() {
/*  281 */     return this.trimSpaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTypeHintsCompatibility() {
/*  288 */     return this.typeHintsCompatibility;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTypeHintsEnabled() {
/*  295 */     return this.typeHintsEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSON read(String xml) {
/*      */     JSONObject jSONObject;
/*  307 */     JSON json = null;
/*      */     try {
/*  309 */       Document doc = (new Builder()).build(new StringReader(xml));
/*  310 */       Element root = doc.getRootElement();
/*  311 */       if (isNullObject(root)) {
/*  312 */         return (JSON)JSONNull.getInstance();
/*      */       }
/*  314 */       String defaultType = getType(root, "string");
/*  315 */       if (isArray(root, true)) {
/*  316 */         json = processArrayElement(root, defaultType);
/*  317 */         if (this.forceTopLevelObject) {
/*  318 */           String key = removeNamespacePrefix(root.getQualifiedName());
/*  319 */           jSONObject = (new JSONObject()).element(key, json);
/*      */         } 
/*      */       } else {
/*  322 */         json = processObjectElement(root, defaultType);
/*  323 */         if (this.forceTopLevelObject) {
/*  324 */           String key = removeNamespacePrefix(root.getQualifiedName());
/*  325 */           jSONObject = (new JSONObject()).element(key, json);
/*      */         } 
/*      */       } 
/*  328 */     } catch (JSONException jsone) {
/*  329 */       throw jsone;
/*  330 */     } catch (Exception e) {
/*  331 */       throw new JSONException(e);
/*      */     } 
/*  333 */     return (JSON)jSONObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSON readFromFile(File file) {
/*  345 */     if (file == null) {
/*  346 */       throw new JSONException("File is null");
/*      */     }
/*  348 */     if (!file.canRead()) {
/*  349 */       throw new JSONException("Can't read input file");
/*      */     }
/*  351 */     if (file.isDirectory()) {
/*  352 */       throw new JSONException("File is a directory");
/*      */     }
/*      */     try {
/*  355 */       return readFromStream(new FileInputStream(file));
/*  356 */     } catch (IOException ioe) {
/*  357 */       throw new JSONException(ioe);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSON readFromFile(String path) {
/*  370 */     return readFromStream(Thread.currentThread().getContextClassLoader().getResourceAsStream(path));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSON readFromStream(InputStream stream) {
/*      */     try {
/*  385 */       StringBuffer xml = new StringBuffer();
/*  386 */       BufferedReader in = new BufferedReader(new InputStreamReader(stream));
/*  387 */       String line = null;
/*  388 */       while ((line = in.readLine()) != null) {
/*  389 */         xml.append(line);
/*      */       }
/*  391 */       return read(xml.toString());
/*  392 */     } catch (IOException ioe) {
/*  393 */       throw new JSONException(ioe);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNamespace(String prefix) {
/*  403 */     removeNamespace(prefix, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNamespace(String prefix, String elementName) {
/*  415 */     if (prefix == null) {
/*  416 */       prefix = "";
/*      */     }
/*  418 */     if (StringUtils.isBlank(elementName)) {
/*  419 */       this.rootNamespace.remove(prefix.trim());
/*      */     } else {
/*  421 */       Map nameSpaces = (Map)this.namespacesPerElement.get(elementName);
/*  422 */       nameSpaces.remove(prefix);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArrayName(String arrayName) {
/*  431 */     this.arrayName = StringUtils.isBlank(arrayName) ? "a" : arrayName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setElementName(String elementName) {
/*  439 */     this.elementName = StringUtils.isBlank(elementName) ? "e" : elementName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExpandableProperties(String[] expandableProperties) {
/*  446 */     this.expandableProperties = (expandableProperties == null) ? EMPTY_ARRAY : expandableProperties;
/*      */   }
/*      */   
/*      */   public void setForceTopLevelObject(boolean forceTopLevelObject) {
/*  450 */     this.forceTopLevelObject = forceTopLevelObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNamespace(String prefix, String uri) {
/*  461 */     setNamespace(prefix, uri, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNamespace(String prefix, String uri, String elementName) {
/*  474 */     if (StringUtils.isBlank(uri)) {
/*      */       return;
/*      */     }
/*  477 */     if (prefix == null) {
/*  478 */       prefix = "";
/*      */     }
/*  480 */     if (StringUtils.isBlank(elementName)) {
/*  481 */       this.rootNamespace.clear();
/*  482 */       this.rootNamespace.put(prefix.trim(), uri.trim());
/*      */     } else {
/*  484 */       Map nameSpaces = (Map)this.namespacesPerElement.get(elementName);
/*  485 */       if (nameSpaces == null) {
/*  486 */         nameSpaces = new TreeMap();
/*  487 */         this.namespacesPerElement.put(elementName, nameSpaces);
/*      */       } 
/*  489 */       nameSpaces.clear();
/*  490 */       nameSpaces.put(prefix, uri);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNamespaceLenient(boolean namespaceLenient) {
/*  498 */     this.namespaceLenient = namespaceLenient;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectName(String objectName) {
/*  506 */     this.objectName = StringUtils.isBlank(objectName) ? "o" : objectName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRemoveNamespacePrefixFromElements(boolean removeNamespacePrefixFromElements) {
/*  514 */     this.removeNamespacePrefixFromElements = removeNamespacePrefixFromElements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRootName(String rootName) {
/*  521 */     this.rootName = StringUtils.isBlank(rootName) ? null : rootName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSkipNamespaces(boolean skipNamespaces) {
/*  529 */     this.skipNamespaces = skipNamespaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSkipWhitespace(boolean skipWhitespace) {
/*  536 */     this.skipWhitespace = skipWhitespace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTrimSpaces(boolean trimSpaces) {
/*  544 */     this.trimSpaces = trimSpaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTypeHintsCompatibility(boolean typeHintsCompatibility) {
/*  551 */     this.typeHintsCompatibility = typeHintsCompatibility;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTypeHintsEnabled(boolean typeHintsEnabled) {
/*  558 */     this.typeHintsEnabled = typeHintsEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String write(JSON json) {
/*  570 */     return write(json, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String write(JSON json, String encoding) {
/*  584 */     if (JSONNull.getInstance().equals(json)) {
/*      */       
/*  586 */       Element element = null;
/*  587 */       element = newElement((getRootName() == null) ? getObjectName() : getRootName());
/*  588 */       element.addAttribute(new Attribute(addJsonPrefix("null"), "true"));
/*  589 */       Document document = new Document(element);
/*  590 */       return writeDocument(document, encoding);
/*  591 */     }  if (json instanceof JSONArray) {
/*  592 */       JSONArray jsonArray = (JSONArray)json;
/*  593 */       Element element = processJSONArray(jsonArray, newElement((getRootName() == null) ? getArrayName() : getRootName()), this.expandableProperties);
/*      */ 
/*      */       
/*  596 */       Document document = new Document(element);
/*  597 */       return writeDocument(document, encoding);
/*      */     } 
/*  599 */     JSONObject jsonObject = (JSONObject)json;
/*  600 */     Element root = null;
/*  601 */     if (jsonObject.isNullObject()) {
/*  602 */       root = newElement(getObjectName());
/*  603 */       root.addAttribute(new Attribute(addJsonPrefix("null"), "true"));
/*      */     } else {
/*  605 */       root = processJSONObject(jsonObject, newElement((getRootName() == null) ? getObjectName() : getRootName()), this.expandableProperties, true);
/*      */     } 
/*      */ 
/*      */     
/*  609 */     Document doc = new Document(root);
/*  610 */     return writeDocument(doc, encoding);
/*      */   }
/*      */ 
/*      */   
/*      */   private String addJsonPrefix(String str) {
/*  615 */     if (!isTypeHintsCompatibility()) {
/*  616 */       return "json_" + str;
/*      */     }
/*  618 */     return str;
/*      */   }
/*      */   
/*      */   private void addNameSpaceToElement(Element element) {
/*  622 */     String elementName = null;
/*  623 */     if (element instanceof CustomElement) {
/*  624 */       elementName = ((CustomElement)element).getQName();
/*      */     } else {
/*  626 */       elementName = element.getQualifiedName();
/*      */     } 
/*  628 */     Map nameSpaces = (Map)this.namespacesPerElement.get(elementName);
/*  629 */     if (nameSpaces != null && !nameSpaces.isEmpty()) {
/*  630 */       setNamespaceLenient(true);
/*  631 */       Iterator entries = nameSpaces.entrySet().iterator();
/*  632 */       while (entries.hasNext()) {
/*  633 */         Map.Entry entry = entries.next();
/*  634 */         String prefix = (String)entry.getKey();
/*  635 */         String uri = (String)entry.getValue();
/*  636 */         if (StringUtils.isBlank(prefix)) {
/*  637 */           element.setNamespaceURI(uri); continue;
/*      */         } 
/*  639 */         element.addNamespaceDeclaration(prefix, uri);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean checkChildElements(Element element, boolean isTopLevel) {
/*  646 */     int childCount = element.getChildCount();
/*  647 */     Elements elements = element.getChildElements();
/*  648 */     int elementCount = elements.size();
/*      */     
/*  650 */     if (childCount == 1 && element.getChild(0) instanceof Text) {
/*  651 */       return isTopLevel;
/*      */     }
/*      */     
/*  654 */     if (childCount == elementCount) {
/*  655 */       if (elementCount == 0) {
/*  656 */         return true;
/*      */       }
/*  658 */       if (elementCount == 1) {
/*  659 */         if (this.skipWhitespace || element.getChild(0) instanceof Text) {
/*  660 */           return true;
/*      */         }
/*  662 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  667 */     if (childCount > elementCount) {
/*  668 */       for (int j = 0; j < childCount; j++) {
/*  669 */         Node node = element.getChild(j);
/*  670 */         if (node instanceof Text) {
/*  671 */           Text text = (Text)node;
/*  672 */           if (StringUtils.isNotBlank(StringUtils.strip(text.getValue())) && !this.skipWhitespace)
/*      */           {
/*  674 */             return false;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  680 */     String childName = elements.get(0).getQualifiedName();
/*      */     
/*  682 */     for (int i = 1; i < elementCount; i++) {
/*  683 */       if (childName.compareTo(elements.get(i).getQualifiedName()) != 0)
/*      */       {
/*  685 */         return false;
/*      */       }
/*      */     } 
/*      */     
/*  689 */     return true;
/*      */   }
/*      */   
/*      */   private String getClass(Element element) {
/*  693 */     Attribute attribute = element.getAttribute(addJsonPrefix("class"));
/*  694 */     String clazz = null;
/*  695 */     if (attribute != null) {
/*  696 */       String clazzText = attribute.getValue().trim();
/*      */       
/*  698 */       if ("object".compareToIgnoreCase(clazzText) == 0) {
/*  699 */         clazz = "object";
/*  700 */       } else if ("array".compareToIgnoreCase(clazzText) == 0) {
/*  701 */         clazz = "array";
/*      */       } 
/*      */     } 
/*  704 */     return clazz;
/*      */   }
/*      */   
/*      */   private String getType(Element element) {
/*  708 */     return getType(element, null);
/*      */   }
/*      */   
/*      */   private String getType(Element element, String defaultType) {
/*  712 */     Attribute attribute = element.getAttribute(addJsonPrefix("type"));
/*  713 */     String type = null;
/*  714 */     if (attribute != null) {
/*  715 */       String typeText = attribute.getValue().trim();
/*      */       
/*  717 */       if ("boolean".compareToIgnoreCase(typeText) == 0) {
/*  718 */         type = "boolean";
/*  719 */       } else if ("number".compareToIgnoreCase(typeText) == 0) {
/*  720 */         type = "number";
/*  721 */       } else if ("integer".compareToIgnoreCase(typeText) == 0) {
/*  722 */         type = "integer";
/*  723 */       } else if ("float".compareToIgnoreCase(typeText) == 0) {
/*  724 */         type = "float";
/*  725 */       } else if ("object".compareToIgnoreCase(typeText) == 0) {
/*  726 */         type = "object";
/*  727 */       } else if ("array".compareToIgnoreCase(typeText) == 0) {
/*  728 */         type = "array";
/*  729 */       } else if ("string".compareToIgnoreCase(typeText) == 0) {
/*  730 */         type = "string";
/*  731 */       } else if ("function".compareToIgnoreCase(typeText) == 0) {
/*  732 */         type = "function";
/*      */       }
/*      */     
/*  735 */     } else if (defaultType != null) {
/*  736 */       log.info("Using default type " + defaultType);
/*  737 */       type = defaultType;
/*      */     } 
/*      */     
/*  740 */     return type;
/*      */   }
/*      */   
/*      */   private boolean hasNamespaces(Element element) {
/*  744 */     int namespaces = 0;
/*  745 */     for (int i = 0; i < element.getNamespaceDeclarationCount(); i++) {
/*  746 */       String prefix = element.getNamespacePrefix(i);
/*  747 */       String uri = element.getNamespaceURI(prefix);
/*  748 */       if (!StringUtils.isBlank(uri))
/*      */       {
/*      */         
/*  751 */         namespaces++; } 
/*      */     } 
/*  753 */     return (namespaces > 0);
/*      */   }
/*      */   
/*      */   private boolean isArray(Element element, boolean isTopLevel) {
/*  757 */     boolean isArray = false;
/*  758 */     String clazz = getClass(element);
/*  759 */     if (clazz != null && clazz.equals("array")) {
/*  760 */       isArray = true;
/*  761 */     } else if (element.getAttributeCount() == 0) {
/*  762 */       isArray = checkChildElements(element, isTopLevel);
/*  763 */     } else if (element.getAttributeCount() == 1 && (element.getAttribute(addJsonPrefix("class")) != null || element.getAttribute(addJsonPrefix("type")) != null)) {
/*      */       
/*  765 */       isArray = checkChildElements(element, isTopLevel);
/*  766 */     } else if (element.getAttributeCount() == 2 && element.getAttribute(addJsonPrefix("class")) != null && element.getAttribute(addJsonPrefix("type")) != null) {
/*      */       
/*  768 */       isArray = checkChildElements(element, isTopLevel);
/*      */     } 
/*      */     
/*  771 */     if (isArray)
/*      */     {
/*  773 */       for (int j = 0; j < element.getNamespaceDeclarationCount(); j++) {
/*  774 */         String prefix = element.getNamespacePrefix(j);
/*  775 */         String uri = element.getNamespaceURI(prefix);
/*  776 */         if (!StringUtils.isBlank(uri)) {
/*  777 */           return false;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  782 */     return isArray;
/*      */   }
/*      */   
/*      */   private boolean isFunction(Element element) {
/*  786 */     int attrCount = element.getAttributeCount();
/*  787 */     if (attrCount > 0) {
/*  788 */       Attribute typeAttr = element.getAttribute(addJsonPrefix("type"));
/*  789 */       Attribute paramsAttr = element.getAttribute(addJsonPrefix("params"));
/*  790 */       if (attrCount == 1 && paramsAttr != null) {
/*  791 */         return true;
/*      */       }
/*  793 */       if (attrCount == 2 && paramsAttr != null && typeAttr != null && (typeAttr.getValue().compareToIgnoreCase("string") == 0 || typeAttr.getValue().compareToIgnoreCase("function") == 0))
/*      */       {
/*      */         
/*  796 */         return true;
/*      */       }
/*      */     } 
/*  799 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isNullObject(Element element) {
/*  803 */     if (element.getChildCount() == 0) {
/*  804 */       if (element.getAttributeCount() == 0)
/*  805 */         return true; 
/*  806 */       if (element.getAttribute(addJsonPrefix("null")) != null)
/*  807 */         return true; 
/*  808 */       if (element.getAttributeCount() == 1 && (element.getAttribute(addJsonPrefix("class")) != null || element.getAttribute(addJsonPrefix("type")) != null))
/*      */       {
/*  810 */         return true; } 
/*  811 */       if (element.getAttributeCount() == 2 && element.getAttribute(addJsonPrefix("class")) != null && element.getAttribute(addJsonPrefix("type")) != null)
/*      */       {
/*  813 */         return true;
/*      */       }
/*      */     } 
/*  816 */     if (this.skipWhitespace && element.getChildCount() == 1 && element.getChild(0) instanceof Text) {
/*  817 */       return true;
/*      */     }
/*  819 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isObject(Element element, boolean isTopLevel) {
/*  823 */     boolean isObject = false;
/*  824 */     if (!isArray(element, isTopLevel) && !isFunction(element)) {
/*  825 */       if (hasNamespaces(element)) {
/*  826 */         return true;
/*      */       }
/*      */       
/*  829 */       int attributeCount = element.getAttributeCount();
/*  830 */       if (attributeCount > 0) {
/*  831 */         int attrs = (element.getAttribute(addJsonPrefix("null")) == null) ? 0 : 1;
/*  832 */         attrs += (element.getAttribute(addJsonPrefix("class")) == null) ? 0 : 1;
/*  833 */         attrs += (element.getAttribute(addJsonPrefix("type")) == null) ? 0 : 1;
/*  834 */         switch (attributeCount) {
/*      */           case 1:
/*  836 */             if (attrs == 0) {
/*  837 */               return true;
/*      */             }
/*      */             break;
/*      */           case 2:
/*  841 */             if (attrs < 2) {
/*  842 */               return true;
/*      */             }
/*      */             break;
/*      */           case 3:
/*  846 */             if (attrs < 3) {
/*  847 */               return true;
/*      */             }
/*      */             break;
/*      */           default:
/*  851 */             return true;
/*      */         } 
/*      */       
/*      */       } 
/*  855 */       int childCount = element.getChildCount();
/*  856 */       if (childCount == 1 && element.getChild(0) instanceof Text) {
/*  857 */         return isTopLevel;
/*      */       }
/*      */       
/*  860 */       isObject = true;
/*      */     } 
/*  862 */     return isObject;
/*      */   }
/*      */   
/*      */   private Element newElement(String name) {
/*  866 */     if (name.indexOf(':') != -1) {
/*  867 */       this.namespaceLenient = true;
/*      */     }
/*  869 */     return this.namespaceLenient ? new CustomElement(name) : new Element(name);
/*      */   }
/*      */   
/*      */   private JSON processArrayElement(Element element, String defaultType) {
/*  873 */     JSONArray jsonArray = new JSONArray();
/*      */     
/*  875 */     int childCount = element.getChildCount();
/*  876 */     for (int i = 0; i < childCount; i++) {
/*  877 */       Node child = element.getChild(i);
/*  878 */       if (child instanceof Text) {
/*  879 */         Text text = (Text)child;
/*  880 */         if (StringUtils.isNotBlank(StringUtils.strip(text.getValue()))) {
/*  881 */           jsonArray.element(text.getValue());
/*      */         }
/*  883 */       } else if (child instanceof Element) {
/*  884 */         setValue(jsonArray, (Element)child, defaultType);
/*      */       } 
/*      */     } 
/*  887 */     return (JSON)jsonArray;
/*      */   }
/*      */   
/*      */   private Object processElement(Element element, String type) {
/*  891 */     if (isNullObject(element))
/*  892 */       return JSONNull.getInstance(); 
/*  893 */     if (isArray(element, false))
/*  894 */       return processArrayElement(element, type); 
/*  895 */     if (isObject(element, false)) {
/*  896 */       return processObjectElement(element, type);
/*      */     }
/*  898 */     return trimSpaceFromValue(element.getValue());
/*      */   }
/*      */ 
/*      */   
/*      */   private Element processJSONArray(JSONArray array, Element root, String[] expandableProperties) {
/*  903 */     int l = array.size();
/*  904 */     for (int i = 0; i < l; i++) {
/*  905 */       Object value = array.get(i);
/*  906 */       Element element = processJSONValue(value, root, null, expandableProperties);
/*  907 */       root.appendChild((Node)element);
/*      */     } 
/*  909 */     return root;
/*      */   }
/*      */ 
/*      */   
/*      */   private Element processJSONObject(JSONObject jsonObject, Element root, String[] expandableProperties, boolean isRoot) {
/*  914 */     if (jsonObject.isNullObject()) {
/*  915 */       root.addAttribute(new Attribute(addJsonPrefix("null"), "true"));
/*  916 */       return root;
/*  917 */     }  if (jsonObject.isEmpty()) {
/*  918 */       return root;
/*      */     }
/*      */     
/*  921 */     if (isRoot && 
/*  922 */       !this.rootNamespace.isEmpty()) {
/*  923 */       setNamespaceLenient(true);
/*  924 */       Iterator entries = this.rootNamespace.entrySet().iterator();
/*  925 */       while (entries.hasNext()) {
/*  926 */         Map.Entry entry = entries.next();
/*  927 */         String prefix = (String)entry.getKey();
/*  928 */         String uri = (String)entry.getValue();
/*  929 */         if (StringUtils.isBlank(prefix)) {
/*  930 */           root.setNamespaceURI(uri); continue;
/*      */         } 
/*  932 */         root.addNamespaceDeclaration(prefix, uri);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  938 */     addNameSpaceToElement(root);
/*      */     
/*  940 */     Object[] names = jsonObject.names().toArray();
/*      */     
/*  942 */     Arrays.sort(names);
/*  943 */     Element element = null;
/*  944 */     for (int i = 0; i < names.length; i++) {
/*  945 */       String name = (String)names[i];
/*  946 */       Object value = jsonObject.get(name);
/*  947 */       if (name.startsWith("@xmlns")) {
/*  948 */         setNamespaceLenient(true);
/*  949 */         int colon = name.indexOf(':');
/*  950 */         if (colon == -1) {
/*      */           
/*  952 */           if (StringUtils.isBlank(root.getNamespaceURI())) {
/*  953 */             root.setNamespaceURI(String.valueOf(value));
/*      */           }
/*      */         } else {
/*  956 */           String prefix = name.substring(colon + 1);
/*  957 */           if (StringUtils.isBlank(root.getNamespaceURI(prefix))) {
/*  958 */             root.addNamespaceDeclaration(prefix, String.valueOf(value));
/*      */           }
/*      */         } 
/*  961 */       } else if (name.startsWith("@")) {
/*  962 */         root.addAttribute(new Attribute(name.substring(1), String.valueOf(value)));
/*  963 */       } else if (name.equals("#text")) {
/*  964 */         if (value instanceof JSONArray) {
/*  965 */           root.appendChild(((JSONArray)value).join("", true));
/*      */         } else {
/*  967 */           root.appendChild(String.valueOf(value));
/*      */         } 
/*  969 */       } else if (value instanceof JSONArray && (((JSONArray)value).isExpandElements() || ArrayUtils.contains((Object[])expandableProperties, name))) {
/*      */ 
/*      */         
/*  972 */         JSONArray array = (JSONArray)value;
/*  973 */         int l = array.size();
/*  974 */         for (int j = 0; j < l; j++) {
/*  975 */           Object item = array.get(j);
/*  976 */           element = newElement(name);
/*  977 */           if (item instanceof JSONObject) {
/*  978 */             element = processJSONValue(item, root, element, expandableProperties);
/*      */           }
/*  980 */           else if (item instanceof JSONArray) {
/*  981 */             element = processJSONValue(item, root, element, expandableProperties);
/*      */           } else {
/*  983 */             element = processJSONValue(item, root, element, expandableProperties);
/*      */           } 
/*  985 */           addNameSpaceToElement(element);
/*  986 */           root.appendChild((Node)element);
/*      */         } 
/*      */       } else {
/*  989 */         element = newElement(name);
/*  990 */         element = processJSONValue(value, root, element, expandableProperties);
/*  991 */         addNameSpaceToElement(element);
/*  992 */         root.appendChild((Node)element);
/*      */       } 
/*      */     } 
/*  995 */     return root;
/*      */   }
/*      */ 
/*      */   
/*      */   private Element processJSONValue(Object value, Element root, Element target, String[] expandableProperties) {
/* 1000 */     if (target == null) {
/* 1001 */       target = newElement(getElementName());
/*      */     }
/* 1003 */     if (JSONUtils.isBoolean(value)) {
/* 1004 */       if (isTypeHintsEnabled()) {
/* 1005 */         target.addAttribute(new Attribute(addJsonPrefix("type"), "boolean"));
/*      */       }
/* 1007 */       target.appendChild(value.toString());
/* 1008 */     } else if (JSONUtils.isNumber(value)) {
/* 1009 */       if (isTypeHintsEnabled()) {
/* 1010 */         target.addAttribute(new Attribute(addJsonPrefix("type"), "number"));
/*      */       }
/* 1012 */       target.appendChild(value.toString());
/* 1013 */     } else if (JSONUtils.isFunction(value)) {
/* 1014 */       if (value instanceof String) {
/* 1015 */         value = JSONFunction.parse((String)value);
/*      */       }
/* 1017 */       JSONFunction func = (JSONFunction)value;
/* 1018 */       if (isTypeHintsEnabled()) {
/* 1019 */         target.addAttribute(new Attribute(addJsonPrefix("type"), "function"));
/*      */       }
/* 1021 */       String params = ArrayUtils.toString(func.getParams());
/* 1022 */       params = params.substring(1);
/* 1023 */       params = params.substring(0, params.length() - 1);
/* 1024 */       target.addAttribute(new Attribute(addJsonPrefix("params"), params));
/* 1025 */       target.appendChild((Node)new Text("<![CDATA[" + func.getText() + "]]>"));
/* 1026 */     } else if (JSONUtils.isString(value)) {
/* 1027 */       if (isTypeHintsEnabled()) {
/* 1028 */         target.addAttribute(new Attribute(addJsonPrefix("type"), "string"));
/*      */       }
/* 1030 */       target.appendChild(value.toString());
/* 1031 */     } else if (value instanceof JSONArray) {
/* 1032 */       if (isTypeHintsEnabled()) {
/* 1033 */         target.addAttribute(new Attribute(addJsonPrefix("class"), "array"));
/*      */       }
/* 1035 */       target = processJSONArray((JSONArray)value, target, expandableProperties);
/* 1036 */     } else if (value instanceof JSONObject) {
/* 1037 */       if (isTypeHintsEnabled()) {
/* 1038 */         target.addAttribute(new Attribute(addJsonPrefix("class"), "object"));
/*      */       }
/* 1040 */       target = processJSONObject((JSONObject)value, target, expandableProperties, false);
/* 1041 */     } else if (JSONUtils.isNull(value)) {
/* 1042 */       if (isTypeHintsEnabled()) {
/* 1043 */         target.addAttribute(new Attribute(addJsonPrefix("class"), "object"));
/*      */       }
/* 1045 */       target.addAttribute(new Attribute(addJsonPrefix("null"), "true"));
/*      */     } 
/* 1047 */     return target;
/*      */   }
/*      */   
/*      */   private JSON processObjectElement(Element element, String defaultType) {
/* 1051 */     if (isNullObject(element)) {
/* 1052 */       return (JSON)JSONNull.getInstance();
/*      */     }
/* 1054 */     JSONObject jsonObject = new JSONObject();
/*      */     
/* 1056 */     if (!this.skipNamespaces) {
/* 1057 */       for (int k = 0; k < element.getNamespaceDeclarationCount(); k++) {
/* 1058 */         String prefix = element.getNamespacePrefix(k);
/* 1059 */         String uri = element.getNamespaceURI(prefix);
/* 1060 */         if (!StringUtils.isBlank(uri)) {
/*      */ 
/*      */           
/* 1063 */           if (!StringUtils.isBlank(prefix)) {
/* 1064 */             prefix = ":" + prefix;
/*      */           }
/* 1066 */           setOrAccumulate(jsonObject, "@xmlns" + prefix, trimSpaceFromValue(uri));
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 1071 */     int attrCount = element.getAttributeCount();
/* 1072 */     for (int i = 0; i < attrCount; i++) {
/* 1073 */       Attribute attr = element.getAttribute(i);
/* 1074 */       String attrname = attr.getQualifiedName();
/* 1075 */       if (!isTypeHintsEnabled() || (addJsonPrefix("class").compareToIgnoreCase(attrname) != 0 && addJsonPrefix("type").compareToIgnoreCase(attrname) != 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1080 */         String attrvalue = attr.getValue();
/* 1081 */         setOrAccumulate(jsonObject, "@" + removeNamespacePrefix(attrname), trimSpaceFromValue(attrvalue));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1086 */     int childCount = element.getChildCount();
/* 1087 */     for (int j = 0; j < childCount; j++) {
/* 1088 */       Node child = element.getChild(j);
/* 1089 */       if (child instanceof Text) {
/* 1090 */         Text text = (Text)child;
/* 1091 */         if (StringUtils.isNotBlank(StringUtils.strip(text.getValue()))) {
/* 1092 */           setOrAccumulate(jsonObject, "#text", trimSpaceFromValue(text.getValue()));
/*      */         }
/* 1094 */       } else if (child instanceof Element) {
/* 1095 */         setValue(jsonObject, (Element)child, defaultType);
/*      */       } 
/*      */     } 
/*      */     
/* 1099 */     return (JSON)jsonObject;
/*      */   }
/*      */   
/*      */   private String removeNamespacePrefix(String name) {
/* 1103 */     if (isRemoveNamespacePrefixFromElements()) {
/* 1104 */       int colon = name.indexOf(':');
/* 1105 */       return (colon != -1) ? name.substring(colon + 1) : name;
/*      */     } 
/* 1107 */     return name;
/*      */   }
/*      */   
/*      */   private void setOrAccumulate(JSONObject jsonObject, String key, Object value) {
/* 1111 */     if (jsonObject.has(key)) {
/* 1112 */       jsonObject.accumulate(key, value);
/* 1113 */       Object val = jsonObject.get(key);
/* 1114 */       if (val instanceof JSONArray) {
/* 1115 */         ((JSONArray)val).setExpandElements(true);
/*      */       }
/*      */     } else {
/* 1118 */       jsonObject.element(key, value);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setValue(JSONArray jsonArray, Element element, String defaultType) {
/* 1123 */     String clazz = getClass(element);
/* 1124 */     String type = getType(element);
/* 1125 */     type = (type == null) ? defaultType : type;
/*      */     
/* 1127 */     if (hasNamespaces(element) && !this.skipNamespaces) {
/* 1128 */       jsonArray.element(simplifyValue(null, processElement(element, type))); return;
/*      */     } 
/* 1130 */     if (element.getAttributeCount() > 0) {
/* 1131 */       if (isFunction(element)) {
/* 1132 */         Attribute paramsAttribute = element.getAttribute(addJsonPrefix("params"));
/* 1133 */         String[] params = null;
/* 1134 */         String text = element.getValue();
/* 1135 */         params = StringUtils.split(paramsAttribute.getValue(), ",");
/* 1136 */         jsonArray.element(new JSONFunction(params, text));
/*      */         return;
/*      */       } 
/* 1139 */       jsonArray.element(simplifyValue(null, processElement(element, type)));
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1144 */     boolean classProcessed = false;
/* 1145 */     if (clazz != null) {
/* 1146 */       if (clazz.compareToIgnoreCase("array") == 0) {
/* 1147 */         jsonArray.element(processArrayElement(element, type));
/* 1148 */         classProcessed = true;
/* 1149 */       } else if (clazz.compareToIgnoreCase("object") == 0) {
/* 1150 */         jsonArray.element(simplifyValue(null, processObjectElement(element, type)));
/* 1151 */         classProcessed = true;
/*      */       } 
/*      */     }
/* 1154 */     if (!classProcessed) {
/* 1155 */       if (type.compareToIgnoreCase("boolean") == 0) {
/* 1156 */         jsonArray.element(Boolean.valueOf(element.getValue()));
/* 1157 */       } else if (type.compareToIgnoreCase("number") == 0) {
/*      */         
/*      */         try {
/* 1160 */           jsonArray.element(Integer.valueOf(element.getValue()));
/* 1161 */         } catch (NumberFormatException e) {
/* 1162 */           jsonArray.element(Double.valueOf(element.getValue()));
/*      */         } 
/* 1164 */       } else if (type.compareToIgnoreCase("integer") == 0) {
/* 1165 */         jsonArray.element(Integer.valueOf(element.getValue()));
/* 1166 */       } else if (type.compareToIgnoreCase("float") == 0) {
/* 1167 */         jsonArray.element(Double.valueOf(element.getValue()));
/* 1168 */       } else if (type.compareToIgnoreCase("function") == 0) {
/* 1169 */         String[] params = null;
/* 1170 */         String text = element.getValue();
/* 1171 */         Attribute paramsAttribute = element.getAttribute(addJsonPrefix("params"));
/* 1172 */         if (paramsAttribute != null) {
/* 1173 */           params = StringUtils.split(paramsAttribute.getValue(), ",");
/*      */         }
/* 1175 */         jsonArray.element(new JSONFunction(params, text));
/* 1176 */       } else if (type.compareToIgnoreCase("string") == 0) {
/*      */         
/* 1178 */         Attribute paramsAttribute = element.getAttribute(addJsonPrefix("params"));
/* 1179 */         if (paramsAttribute != null) {
/* 1180 */           String[] params = null;
/* 1181 */           String text = element.getValue();
/* 1182 */           params = StringUtils.split(paramsAttribute.getValue(), ",");
/* 1183 */           jsonArray.element(new JSONFunction(params, text));
/*      */         }
/* 1185 */         else if (isArray(element, false)) {
/* 1186 */           jsonArray.element(processArrayElement(element, defaultType));
/* 1187 */         } else if (isObject(element, false)) {
/* 1188 */           jsonArray.element(simplifyValue(null, processObjectElement(element, defaultType)));
/*      */         } else {
/*      */           
/* 1191 */           jsonArray.element(trimSpaceFromValue(element.getValue()));
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void setValue(JSONObject jsonObject, Element element, String defaultType) {
/* 1199 */     String clazz = getClass(element);
/* 1200 */     String type = getType(element);
/* 1201 */     type = (type == null) ? defaultType : type;
/*      */ 
/*      */ 
/*      */     
/* 1205 */     String key = removeNamespacePrefix(element.getQualifiedName());
/* 1206 */     if (hasNamespaces(element) && !this.skipNamespaces) {
/* 1207 */       setOrAccumulate(jsonObject, key, simplifyValue(jsonObject, processElement(element, type)));
/*      */       return;
/*      */     } 
/* 1210 */     if (element.getAttributeCount() > 0 && 
/* 1211 */       isFunction(element)) {
/* 1212 */       Attribute paramsAttribute = element.getAttribute(addJsonPrefix("params"));
/* 1213 */       String text = element.getValue();
/* 1214 */       String[] params = StringUtils.split(paramsAttribute.getValue(), ",");
/* 1215 */       setOrAccumulate(jsonObject, key, new JSONFunction(params, text));
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1224 */     boolean classProcessed = false;
/* 1225 */     if (clazz != null) {
/* 1226 */       if (clazz.compareToIgnoreCase("array") == 0) {
/* 1227 */         setOrAccumulate(jsonObject, key, processArrayElement(element, type));
/* 1228 */         classProcessed = true;
/* 1229 */       } else if (clazz.compareToIgnoreCase("object") == 0) {
/* 1230 */         setOrAccumulate(jsonObject, key, simplifyValue(jsonObject, processObjectElement(element, type)));
/*      */         
/* 1232 */         classProcessed = true;
/*      */       } 
/*      */     }
/* 1235 */     if (!classProcessed) {
/* 1236 */       if (type.compareToIgnoreCase("boolean") == 0) {
/* 1237 */         setOrAccumulate(jsonObject, key, Boolean.valueOf(element.getValue()));
/* 1238 */       } else if (type.compareToIgnoreCase("number") == 0) {
/*      */         
/*      */         try {
/* 1241 */           setOrAccumulate(jsonObject, key, Integer.valueOf(element.getValue()));
/* 1242 */         } catch (NumberFormatException e) {
/* 1243 */           setOrAccumulate(jsonObject, key, Double.valueOf(element.getValue()));
/*      */         } 
/* 1245 */       } else if (type.compareToIgnoreCase("integer") == 0) {
/* 1246 */         setOrAccumulate(jsonObject, key, Integer.valueOf(element.getValue()));
/* 1247 */       } else if (type.compareToIgnoreCase("float") == 0) {
/* 1248 */         setOrAccumulate(jsonObject, key, Double.valueOf(element.getValue()));
/* 1249 */       } else if (type.compareToIgnoreCase("function") == 0) {
/* 1250 */         String[] params = null;
/* 1251 */         String text = element.getValue();
/* 1252 */         Attribute paramsAttribute = element.getAttribute(addJsonPrefix("params"));
/* 1253 */         if (paramsAttribute != null) {
/* 1254 */           params = StringUtils.split(paramsAttribute.getValue(), ",");
/*      */         }
/* 1256 */         setOrAccumulate(jsonObject, key, new JSONFunction(params, text));
/* 1257 */       } else if (type.compareToIgnoreCase("string") == 0) {
/*      */         
/* 1259 */         Attribute paramsAttribute = element.getAttribute(addJsonPrefix("params"));
/* 1260 */         if (paramsAttribute != null) {
/* 1261 */           String[] params = null;
/* 1262 */           String text = element.getValue();
/* 1263 */           params = StringUtils.split(paramsAttribute.getValue(), ",");
/* 1264 */           setOrAccumulate(jsonObject, key, new JSONFunction(params, text));
/*      */         }
/* 1266 */         else if (isArray(element, false)) {
/* 1267 */           setOrAccumulate(jsonObject, key, processArrayElement(element, defaultType));
/* 1268 */         } else if (isObject(element, false)) {
/* 1269 */           setOrAccumulate(jsonObject, key, simplifyValue(jsonObject, processObjectElement(element, defaultType)));
/*      */         } else {
/*      */           
/* 1272 */           setOrAccumulate(jsonObject, key, trimSpaceFromValue(element.getValue()));
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private Object simplifyValue(JSONObject parent, Object json) {
/* 1280 */     if (json instanceof JSONObject) {
/* 1281 */       JSONObject object = (JSONObject)json;
/* 1282 */       if (parent != null) {
/*      */         
/* 1284 */         Iterator entries = parent.entrySet().iterator();
/* 1285 */         while (entries.hasNext()) {
/* 1286 */           Map.Entry entry = entries.next();
/* 1287 */           String key = (String)entry.getKey();
/* 1288 */           Object value = entry.getValue();
/* 1289 */           if (key.startsWith("@xmlns") && value.equals(object.opt(key))) {
/* 1290 */             object.remove(key);
/*      */           }
/*      */         } 
/*      */       } 
/* 1294 */       if (object.size() == 1 && object.has("#text")) {
/* 1295 */         return object.get("#text");
/*      */       }
/*      */     } 
/* 1298 */     return json;
/*      */   }
/*      */   private String trimSpaceFromValue(String value) {
/* 1301 */     if (isTrimSpaces()) {
/* 1302 */       return value.trim();
/*      */     }
/* 1304 */     return value;
/*      */   }
/*      */   private String writeDocument(Document doc, String encoding) {
/* 1307 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*      */     try {
/* 1309 */       XomSerializer serializer = (encoding == null) ? new XomSerializer(this, baos) : new XomSerializer(this, baos, encoding);
/*      */       
/* 1311 */       serializer.write(doc);
/* 1312 */       encoding = serializer.getEncoding();
/* 1313 */     } catch (IOException ioe) {
/* 1314 */       throw new JSONException(ioe);
/*      */     } 
/*      */     
/* 1317 */     String str = null;
/*      */     try {
/* 1319 */       str = baos.toString(encoding);
/* 1320 */     } catch (UnsupportedEncodingException uee) {
/* 1321 */       throw new JSONException(uee);
/*      */     } 
/* 1323 */     return str;
/*      */   }
/*      */   
/*      */   private static class CustomElement extends Element {
/*      */     private static String getName(String name) {
/* 1328 */       int colon = name.indexOf(':');
/* 1329 */       if (colon != -1) {
/* 1330 */         return name.substring(colon + 1);
/*      */       }
/* 1332 */       return name;
/*      */     }
/*      */     private String prefix;
/*      */     private static String getPrefix(String name) {
/* 1336 */       int colon = name.indexOf(':');
/* 1337 */       if (colon != -1) {
/* 1338 */         return name.substring(0, colon);
/*      */       }
/* 1340 */       return "";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public CustomElement(String name) {
/* 1346 */       super(getName(name));
/* 1347 */       this.prefix = getPrefix(name);
/*      */     }
/*      */     
/*      */     public final String getQName() {
/* 1351 */       if (this.prefix.length() == 0) {
/* 1352 */         return getLocalName();
/*      */       }
/* 1354 */       return this.prefix + ":" + getLocalName();
/*      */     } }
/*      */   
/*      */   private class XomSerializer extends Serializer {
/*      */     private final XMLSerializer this$0;
/*      */     
/*      */     public XomSerializer(XMLSerializer this$0, OutputStream out) {
/* 1361 */       super(out);
/*      */       this.this$0 = this$0;
/*      */     }
/*      */     public XomSerializer(XMLSerializer this$0, OutputStream out, String encoding) throws UnsupportedEncodingException {
/* 1365 */       super(out, encoding);
/*      */       this.this$0 = this$0;
/*      */     }
/*      */     protected void write(Text text) throws IOException {
/* 1369 */       String value = text.getValue();
/* 1370 */       if (value.startsWith("<![CDATA[") && value.endsWith("]]>")) {
/* 1371 */         value = value.substring(9);
/* 1372 */         value = value.substring(0, value.length() - 3);
/* 1373 */         writeRaw("<![CDATA[");
/* 1374 */         writeRaw(value);
/* 1375 */         writeRaw("]]>");
/*      */       } else {
/* 1377 */         super.write(text);
/*      */       } 
/*      */     }
/*      */     
/*      */     protected void writeEmptyElementTag(Element element) throws IOException {
/* 1382 */       if (element instanceof XMLSerializer.CustomElement && this.this$0.isNamespaceLenient()) {
/* 1383 */         writeTagBeginning((XMLSerializer.CustomElement)element);
/* 1384 */         writeRaw("/>");
/*      */       } else {
/* 1386 */         super.writeEmptyElementTag(element);
/*      */       } 
/*      */     }
/*      */     
/*      */     protected void writeEndTag(Element element) throws IOException {
/* 1391 */       if (element instanceof XMLSerializer.CustomElement && this.this$0.isNamespaceLenient()) {
/* 1392 */         writeRaw("</");
/* 1393 */         writeRaw(((XMLSerializer.CustomElement)element).getQName());
/* 1394 */         writeRaw(">");
/*      */       } else {
/* 1396 */         super.writeEndTag(element);
/*      */       } 
/*      */     }
/*      */     
/*      */     protected void writeNamespaceDeclaration(String prefix, String uri) throws IOException {
/* 1401 */       if (!StringUtils.isBlank(uri)) {
/* 1402 */         super.writeNamespaceDeclaration(prefix, uri);
/*      */       }
/*      */     }
/*      */     
/*      */     protected void writeStartTag(Element element) throws IOException {
/* 1407 */       if (element instanceof XMLSerializer.CustomElement && this.this$0.isNamespaceLenient()) {
/* 1408 */         writeTagBeginning((XMLSerializer.CustomElement)element);
/* 1409 */         writeRaw(">");
/*      */       } else {
/* 1411 */         super.writeStartTag(element);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void writeTagBeginning(XMLSerializer.CustomElement element) throws IOException {
/* 1416 */       writeRaw("<");
/* 1417 */       writeRaw(element.getQName());
/* 1418 */       writeAttributes(element);
/* 1419 */       writeNamespaceDeclarations(element);
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\xml\XMLSerializer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */