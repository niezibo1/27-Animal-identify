package net.sf.json.xml;

public interface JSONTypes {
  public static final String ARRAY = "array";
  
  public static final String BOOLEAN = "boolean";
  
  public static final String FLOAT = "float";
  
  public static final String FUNCTION = "function";
  
  public static final String INTEGER = "integer";
  
  public static final String NUMBER = "number";
  
  public static final String OBJECT = "object";
  
  public static final String STRING = "string";
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\xml\JSONTypes.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */