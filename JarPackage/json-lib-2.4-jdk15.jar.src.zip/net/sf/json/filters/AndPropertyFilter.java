/*    */ package net.sf.json.filters;
/*    */ 
/*    */ import net.sf.json.util.PropertyFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AndPropertyFilter
/*    */   implements PropertyFilter
/*    */ {
/*    */   private PropertyFilter filter1;
/*    */   private PropertyFilter filter2;
/*    */   
/*    */   public AndPropertyFilter(PropertyFilter filter1, PropertyFilter filter2) {
/* 29 */     this.filter1 = filter1;
/* 30 */     this.filter2 = filter2;
/*    */   }
/*    */   
/*    */   public boolean apply(Object source, String name, Object value) {
/* 34 */     if (this.filter1 != null && this.filter1.apply(source, name, value) && this.filter2 != null && this.filter2.apply(source, name, value))
/*    */     {
/* 36 */       return true;
/*    */     }
/* 38 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\filters\AndPropertyFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */