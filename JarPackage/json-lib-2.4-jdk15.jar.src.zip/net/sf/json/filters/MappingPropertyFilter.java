/*    */ package net.sf.json.filters;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import net.sf.json.util.PropertyFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MappingPropertyFilter
/*    */   implements PropertyFilter
/*    */ {
/* 29 */   private Map filters = new HashMap();
/*    */   
/*    */   public MappingPropertyFilter() {
/* 32 */     this(null);
/*    */   }
/*    */   
/*    */   public MappingPropertyFilter(Map filters) {
/* 36 */     if (filters != null) {
/* 37 */       Iterator i = filters.entrySet().iterator();
/* 38 */       while (i.hasNext()) {
/* 39 */         Map.Entry entry = i.next();
/* 40 */         Object key = entry.getKey();
/* 41 */         Object filter = entry.getValue();
/* 42 */         if (filter instanceof PropertyFilter) {
/* 43 */           this.filters.put(key, filter);
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void addPropertyFilter(Object target, PropertyFilter filter) {
/* 50 */     if (filter != null) {
/* 51 */       this.filters.put(target, filter);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean apply(Object source, String name, Object value) {
/* 56 */     Iterator i = this.filters.entrySet().iterator();
/* 57 */     while (i.hasNext()) {
/* 58 */       Map.Entry entry = i.next();
/* 59 */       Object key = entry.getKey();
/* 60 */       if (keyMatches(key, source, name, value)) {
/* 61 */         PropertyFilter filter = (PropertyFilter)entry.getValue();
/* 62 */         return filter.apply(source, name, value);
/*    */       } 
/*    */     } 
/* 65 */     return false;
/*    */   }
/*    */   
/*    */   public void removePropertyFilter(Object target) {
/* 69 */     if (target != null)
/* 70 */       this.filters.remove(target); 
/*    */   }
/*    */   
/*    */   protected abstract boolean keyMatches(Object paramObject1, Object paramObject2, String paramString, Object paramObject3);
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\filters\MappingPropertyFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */