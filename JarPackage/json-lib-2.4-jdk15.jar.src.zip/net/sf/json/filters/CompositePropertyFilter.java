/*    */ package net.sf.json.filters;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.sf.json.util.PropertyFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositePropertyFilter
/*    */   implements PropertyFilter
/*    */ {
/* 29 */   private List filters = new ArrayList();
/*    */   
/*    */   public CompositePropertyFilter() {
/* 32 */     this(null);
/*    */   }
/*    */   
/*    */   public CompositePropertyFilter(List filters) {
/* 36 */     if (filters != null) {
/* 37 */       for (Iterator i = filters.iterator(); i.hasNext(); ) {
/* 38 */         Object filter = i.next();
/* 39 */         if (filter instanceof PropertyFilter) {
/* 40 */           this.filters.add(filter);
/*    */         }
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public void addPropertyFilter(PropertyFilter filter) {
/* 47 */     if (filter != null) {
/* 48 */       this.filters.add(filter);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean apply(Object source, String name, Object value) {
/* 53 */     for (Iterator i = this.filters.iterator(); i.hasNext(); ) {
/* 54 */       PropertyFilter filter = i.next();
/* 55 */       if (filter.apply(source, name, value)) {
/* 56 */         return true;
/*    */       }
/*    */     } 
/* 59 */     return false;
/*    */   }
/*    */   
/*    */   public void removePropertyFilter(PropertyFilter filter) {
/* 63 */     if (filter != null)
/* 64 */       this.filters.remove(filter); 
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\filters\CompositePropertyFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */