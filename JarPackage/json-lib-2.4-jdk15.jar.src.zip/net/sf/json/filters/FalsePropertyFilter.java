/*    */ package net.sf.json.filters;
/*    */ 
/*    */ import net.sf.json.util.PropertyFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FalsePropertyFilter
/*    */   implements PropertyFilter
/*    */ {
/*    */   public boolean apply(Object source, String name, Object value) {
/* 26 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\filters\FalsePropertyFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */