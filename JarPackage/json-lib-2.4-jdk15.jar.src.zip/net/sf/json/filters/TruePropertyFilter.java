/*    */ package net.sf.json.filters;
/*    */ 
/*    */ import net.sf.json.util.PropertyFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TruePropertyFilter
/*    */   implements PropertyFilter
/*    */ {
/*    */   public boolean apply(Object source, String name, Object value) {
/* 26 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\filters\TruePropertyFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */