/*    */ package net.sf.json.processors;
/*    */ 
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JsonBeanProcessorMatcher
/*    */ {
/* 31 */   public static final JsonBeanProcessorMatcher DEFAULT = new DefaultJsonBeanProcessorMatcher();
/*    */ 
/*    */   
/*    */   public abstract Object getMatch(Class paramClass, Set paramSet);
/*    */ 
/*    */   
/*    */   private static final class DefaultJsonBeanProcessorMatcher
/*    */     extends JsonBeanProcessorMatcher
/*    */   {
/*    */     private DefaultJsonBeanProcessorMatcher() {}
/*    */ 
/*    */     
/*    */     public Object getMatch(Class target, Set set) {
/* 44 */       if (target != null && set != null && set.contains(target)) {
/* 45 */         return target;
/*    */       }
/* 47 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\JsonBeanProcessorMatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */