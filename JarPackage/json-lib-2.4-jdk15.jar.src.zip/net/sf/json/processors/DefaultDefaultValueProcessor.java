/*    */ package net.sf.json.processors;
/*    */ 
/*    */ import net.sf.json.JSONArray;
/*    */ import net.sf.json.JSONNull;
/*    */ import net.sf.json.util.JSONUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultDefaultValueProcessor
/*    */   implements DefaultValueProcessor
/*    */ {
/*    */   public Object getDefaultValue(Class type) {
/* 30 */     if (JSONUtils.isArray(type))
/* 31 */       return new JSONArray(); 
/* 32 */     if (JSONUtils.isNumber(type)) {
/* 33 */       if (JSONUtils.isDouble(type)) {
/* 34 */         return new Double(0.0D);
/*    */       }
/* 36 */       return new Integer(0);
/*    */     } 
/* 38 */     if (JSONUtils.isBoolean(type))
/* 39 */       return Boolean.FALSE; 
/* 40 */     if (JSONUtils.isString(type)) {
/* 41 */       return "";
/*    */     }
/* 43 */     return JSONNull.getInstance();
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\DefaultDefaultValueProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */