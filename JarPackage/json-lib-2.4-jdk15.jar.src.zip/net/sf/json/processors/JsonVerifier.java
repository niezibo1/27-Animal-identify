/*    */ package net.sf.json.processors;
/*    */ 
/*    */ import net.sf.json.JSONNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JsonVerifier
/*    */ {
/*    */   public static boolean isValidJsonValue(Object value) {
/* 40 */     if (JSONNull.getInstance().equals(value) || value instanceof net.sf.json.JSON || value instanceof Boolean || value instanceof Byte || value instanceof Short || value instanceof Integer || value instanceof Long || value instanceof Double || value instanceof java.math.BigInteger || value instanceof java.math.BigDecimal || value instanceof net.sf.json.JSONFunction || value instanceof net.sf.json.JSONString || value instanceof String)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 47 */       return true;
/*    */     }
/* 49 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\JsonVerifier.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */