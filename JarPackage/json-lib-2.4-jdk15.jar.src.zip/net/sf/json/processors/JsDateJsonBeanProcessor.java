/*    */ package net.sf.json.processors;
/*    */ 
/*    */ import java.sql.Date;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import net.sf.json.JSONObject;
/*    */ import net.sf.json.JsonConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsDateJsonBeanProcessor
/*    */   implements JsonBeanProcessor
/*    */ {
/*    */   public JSONObject processBean(Object bean, JsonConfig jsonConfig) {
/* 49 */     JSONObject jsonObject = null;
/* 50 */     if (bean instanceof Date) {
/* 51 */       bean = new Date(((Date)bean).getTime());
/*    */     }
/* 53 */     if (bean instanceof Date) {
/* 54 */       Calendar c = Calendar.getInstance();
/* 55 */       c.setTime((Date)bean);
/* 56 */       jsonObject = (new JSONObject()).element("year", c.get(1)).element("month", c.get(2)).element("day", c.get(5)).element("hours", c.get(11)).element("minutes", c.get(12)).element("seconds", c.get(13)).element("milliseconds", c.get(14));
/*    */ 
/*    */     
/*    */     }
/*    */     else {
/*    */ 
/*    */ 
/*    */       
/* 64 */       jsonObject = new JSONObject(true);
/*    */     } 
/* 66 */     return jsonObject;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\JsDateJsonBeanProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */