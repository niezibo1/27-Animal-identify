/*    */ package net.sf.json.processors;
/*    */ 
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DefaultValueProcessorMatcher
/*    */ {
/* 31 */   public static final DefaultValueProcessorMatcher DEFAULT = new DefaultDefaultValueProcessorMatcher();
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract Object getMatch(Class paramClass, Set paramSet);
/*    */ 
/*    */   
/*    */   private static final class DefaultDefaultValueProcessorMatcher
/*    */     extends DefaultValueProcessorMatcher
/*    */   {
/*    */     private DefaultDefaultValueProcessorMatcher() {}
/*    */ 
/*    */     
/*    */     public Object getMatch(Class target, Set set) {
/* 45 */       if (target != null && set != null && set.contains(target)) {
/* 46 */         return target;
/*    */       }
/* 48 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\DefaultValueProcessorMatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */