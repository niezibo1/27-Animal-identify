/*    */ package net.sf.json.processors;
/*    */ 
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JsonValueProcessorMatcher
/*    */ {
/* 31 */   public static final JsonValueProcessorMatcher DEFAULT = new DefaultJsonValueProcessorMatcher();
/*    */ 
/*    */   
/*    */   public abstract Object getMatch(Class paramClass, Set paramSet);
/*    */ 
/*    */   
/*    */   private static final class DefaultJsonValueProcessorMatcher
/*    */     extends JsonValueProcessorMatcher
/*    */   {
/*    */     private DefaultJsonValueProcessorMatcher() {}
/*    */ 
/*    */     
/*    */     public Object getMatch(Class target, Set set) {
/* 44 */       if (target != null && set != null && set.contains(target)) {
/* 45 */         return target;
/*    */       }
/* 47 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\JsonValueProcessorMatcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */