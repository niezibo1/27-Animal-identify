package net.sf.json.processors;

public interface PropertyNameProcessor {
  String processPropertyName(Class paramClass, String paramString);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\PropertyNameProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */