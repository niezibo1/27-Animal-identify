package net.sf.json.processors;

public interface DefaultValueProcessor {
  Object getDefaultValue(Class paramClass);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\DefaultValueProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */