/*    */ package net.sf.json.processors;
/*    */ 
/*    */ import net.sf.json.JsonConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsDateJsonValueProcessor
/*    */   implements JsonValueProcessor
/*    */ {
/* 32 */   private JsonBeanProcessor processor = new JsDateJsonBeanProcessor();
/*    */ 
/*    */   
/*    */   public Object processArrayValue(Object value, JsonConfig jsonConfig) {
/* 36 */     return process(value, jsonConfig);
/*    */   }
/*    */   
/*    */   public Object processObjectValue(String key, Object value, JsonConfig jsonConfig) {
/* 40 */     return process(value, jsonConfig);
/*    */   }
/*    */   
/*    */   private Object process(Object value, JsonConfig jsonConfig) {
/* 44 */     return this.processor.processBean(value, jsonConfig);
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\JsDateJsonValueProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */