package net.sf.json.processors;

import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

public interface JsonBeanProcessor {
  JSONObject processBean(Object paramObject, JsonConfig paramJsonConfig);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\JsonBeanProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */