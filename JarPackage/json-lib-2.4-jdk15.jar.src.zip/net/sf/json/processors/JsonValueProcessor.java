package net.sf.json.processors;

import net.sf.json.JsonConfig;

public interface JsonValueProcessor {
  Object processArrayValue(Object paramObject, JsonConfig paramJsonConfig);
  
  Object processObjectValue(String paramString, Object paramObject, JsonConfig paramJsonConfig);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\processors\JsonValueProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */