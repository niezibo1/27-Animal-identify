/*     */ package net.sf.json;
/*     */ 
/*     */ import net.sf.json.util.JSONTokener;
/*     */ import net.sf.json.util.JSONUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONSerializer
/*     */ {
/*     */   public static Object toJava(JSON json) {
/*  42 */     return toJava(json, new JsonConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object toJava(JSON json, JsonConfig jsonConfig) {
/*  56 */     if (JSONUtils.isNull(json)) {
/*  57 */       return null;
/*     */     }
/*     */     
/*  60 */     Object object = null;
/*     */     
/*  62 */     if (json instanceof JSONArray) {
/*  63 */       if (jsonConfig.getArrayMode() == 2) {
/*  64 */         object = JSONArray.toArray((JSONArray)json, jsonConfig);
/*     */       } else {
/*  66 */         object = JSONArray.toCollection((JSONArray)json, jsonConfig);
/*     */       } 
/*     */     } else {
/*  69 */       object = JSONObject.toBean((JSONObject)json, jsonConfig);
/*     */     } 
/*     */     
/*  72 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSON toJSON(Object object) {
/*  84 */     return toJSON(object, new JsonConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JSON toJSON(Object object, JsonConfig jsonConfig) {
/*  97 */     JSON json = null;
/*  98 */     if (object == null) {
/*  99 */       json = JSONNull.getInstance();
/* 100 */     } else if (object instanceof JSONString) {
/* 101 */       json = toJSON((JSONString)object, jsonConfig);
/* 102 */     } else if (object instanceof String) {
/* 103 */       json = toJSON((String)object, jsonConfig);
/* 104 */     } else if (JSONUtils.isArray(object)) {
/* 105 */       json = JSONArray.fromObject(object, jsonConfig);
/*     */     } else {
/*     */       try {
/* 108 */         json = JSONObject.fromObject(object, jsonConfig);
/* 109 */       } catch (JSONException e) {
/* 110 */         if (object instanceof JSONTokener) {
/* 111 */           ((JSONTokener)object).reset();
/*     */         }
/* 113 */         json = JSONArray.fromObject(object, jsonConfig);
/*     */       } 
/*     */     } 
/*     */     
/* 117 */     return json;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JSON toJSON(JSONString string, JsonConfig jsonConfig) {
/* 126 */     return toJSON(string.toJSONString(), jsonConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JSON toJSON(String string, JsonConfig jsonConfig) {
/* 135 */     JSON json = null;
/* 136 */     if (string.startsWith("[")) {
/* 137 */       json = JSONArray.fromObject(string, jsonConfig);
/* 138 */     } else if (string.startsWith("{")) {
/* 139 */       json = JSONObject.fromObject(string, jsonConfig);
/* 140 */     } else if ("null".equals(string)) {
/* 141 */       json = JSONNull.getInstance();
/*     */     } else {
/* 143 */       throw new JSONException("Invalid JSON String");
/*     */     } 
/*     */     
/* 146 */     return json;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\JSONSerializer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */