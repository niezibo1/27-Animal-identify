/*    */ package net.sf.json.groovy;
/*    */ 
/*    */ import groovy.lang.GroovyObjectSupport;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import java.net.URL;
/*    */ import net.sf.json.JSON;
/*    */ import net.sf.json.JSONSerializer;
/*    */ import net.sf.json.JsonConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonSlurper
/*    */   extends GroovyObjectSupport
/*    */ {
/*    */   private JsonConfig jsonConfig;
/*    */   
/*    */   public JsonSlurper() {
/* 44 */     this(new JsonConfig());
/*    */   }
/*    */   
/*    */   public JsonSlurper(JsonConfig jsonConfig) {
/* 48 */     this.jsonConfig = (jsonConfig != null) ? jsonConfig : new JsonConfig();
/*    */   }
/*    */   
/*    */   public JSON parse(File file) throws IOException {
/* 52 */     return parse(new FileReader(file));
/*    */   }
/*    */   
/*    */   public JSON parse(URL url) throws IOException {
/* 56 */     return parse(url.openConnection().getInputStream());
/*    */   }
/*    */   
/*    */   public JSON parse(InputStream input) throws IOException {
/* 60 */     return parse(new InputStreamReader(input));
/*    */   }
/*    */   
/*    */   public JSON parse(String uri) throws IOException {
/* 64 */     return parse(new URL(uri));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JSON parse(Reader reader) throws IOException {
/* 70 */     StringBuffer buffer = new StringBuffer();
/* 71 */     BufferedReader in = new BufferedReader(reader);
/* 72 */     String line = null;
/* 73 */     while ((line = in.readLine()) != null) {
/* 74 */       buffer.append(line).append("\n");
/*    */     }
/* 76 */     return parseText(buffer.toString());
/*    */   }
/*    */   
/*    */   public JSON parseText(String text) {
/* 80 */     return JSONSerializer.toJSON(text, this.jsonConfig);
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\groovy\JsonSlurper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */