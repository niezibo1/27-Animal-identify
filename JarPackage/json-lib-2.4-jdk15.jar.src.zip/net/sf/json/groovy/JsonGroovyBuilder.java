/*     */ package net.sf.json.groovy;
/*     */ 
/*     */ import groovy.lang.Closure;
/*     */ import groovy.lang.GroovyObjectSupport;
/*     */ import groovy.lang.MissingMethodException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ import net.sf.json.JSON;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONException;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.JSONSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonGroovyBuilder
/*     */   extends GroovyObjectSupport
/*     */ {
/* 116 */   private Stack stack = new Stack();
/* 117 */   private Map properties = new HashMap();
/*     */   private JSON current;
/*     */   
/*     */   public Object getProperty(String name) {
/* 121 */     if (!this.stack.isEmpty()) {
/* 122 */       Object top = this.stack.peek();
/* 123 */       if (top instanceof JSONObject) {
/* 124 */         JSONObject json = (JSONObject)top;
/* 125 */         if (json.containsKey(name)) {
/* 126 */           return json.get(name);
/*     */         }
/* 128 */         return _getProperty(name);
/*     */       } 
/*     */       
/* 131 */       return _getProperty(name);
/*     */     } 
/*     */     
/* 134 */     return _getProperty(name);
/*     */   }
/*     */   private static final String JSON = "json";
/*     */   
/*     */   public Object invokeMethod(String name, Object arg) {
/* 139 */     if ("json".equals(name) && this.stack.isEmpty()) {
/* 140 */       return createObject(name, arg);
/*     */     }
/*     */     
/* 143 */     Object[] args = (Object[])arg;
/* 144 */     if (args.length == 0) {
/* 145 */       throw new MissingMethodException(name, getClass(), args);
/*     */     }
/*     */     
/* 148 */     Object value = null;
/* 149 */     if (args.length > 1) {
/* 150 */       JSONArray array = new JSONArray();
/* 151 */       this.stack.push(array);
/* 152 */       for (int i = 0; i < args.length; i++) {
/* 153 */         if (args[i] instanceof Closure) {
/* 154 */           append(name, createObject((Closure)args[i]));
/* 155 */         } else if (args[i] instanceof Map) {
/* 156 */           append(name, createObject((Map)args[i]));
/* 157 */         } else if (args[i] instanceof List) {
/* 158 */           append(name, createArray((List)args[i]));
/*     */         } else {
/* 160 */           _append(name, args[i], this.stack.peek());
/*     */         } 
/*     */       } 
/* 163 */       this.stack.pop();
/*     */     }
/* 165 */     else if (args[0] instanceof Closure) {
/* 166 */       value = createObject((Closure)args[0]);
/* 167 */     } else if (args[0] instanceof Map) {
/* 168 */       value = createObject((Map)args[0]);
/* 169 */     } else if (args[0] instanceof List) {
/* 170 */       value = createArray((List)args[0]);
/*     */     } 
/*     */ 
/*     */     
/* 174 */     if (this.stack.isEmpty()) {
/* 175 */       JSONObject object = new JSONObject();
/* 176 */       object.accumulate(name, this.current);
/* 177 */       this.current = (JSON)object;
/*     */     } else {
/* 179 */       JSON top = this.stack.peek();
/* 180 */       if (top instanceof JSONObject) {
/* 181 */         append(name, (this.current == null) ? value : this.current);
/*     */       }
/*     */     } 
/*     */     
/* 185 */     return this.current;
/*     */   }
/*     */   
/*     */   public void setProperty(String name, Object value) {
/* 189 */     if (value instanceof groovy.lang.GString) {
/* 190 */       value = value.toString();
/*     */       try {
/* 192 */         value = JSONSerializer.toJSON(value);
/* 193 */       } catch (JSONException jsone) {}
/*     */     
/*     */     }
/* 196 */     else if (value instanceof Closure) {
/* 197 */       value = createObject((Closure)value);
/* 198 */     } else if (value instanceof Map) {
/* 199 */       value = createObject((Map)value);
/* 200 */     } else if (value instanceof List) {
/* 201 */       value = createArray((List)value);
/*     */     } 
/*     */     
/* 204 */     append(name, value);
/*     */   }
/*     */   
/*     */   private Object _getProperty(String name) {
/* 208 */     if (this.properties.containsKey(name)) {
/* 209 */       return this.properties.get(name);
/*     */     }
/* 211 */     return super.getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   private void append(String key, Object value) {
/* 216 */     Object target = null;
/* 217 */     if (!this.stack.isEmpty()) {
/* 218 */       target = this.stack.peek();
/* 219 */       this.current = (JSON)target;
/* 220 */       _append(key, value, this.current);
/*     */     } else {
/* 222 */       this.properties.put(key, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void _append(String key, Object value, JSON target) {
/* 227 */     if (target instanceof JSONObject) {
/* 228 */       ((JSONObject)target).accumulate(key, value);
/* 229 */     } else if (target instanceof JSONArray) {
/* 230 */       ((JSONArray)target).element(value);
/*     */     } 
/*     */   }
/*     */   
/*     */   private JSON createArray(List list) {
/* 235 */     JSONArray array = new JSONArray();
/* 236 */     this.stack.push(array);
/* 237 */     for (Iterator elements = list.iterator(); elements.hasNext(); ) {
/* 238 */       Object element = elements.next();
/* 239 */       if (element instanceof Closure) {
/* 240 */         element = createObject((Closure)element);
/* 241 */       } else if (element instanceof Map) {
/* 242 */         element = createObject((Map)element);
/* 243 */       } else if (element instanceof List) {
/* 244 */         element = createArray((List)element);
/*     */       } 
/* 246 */       array.element(element);
/*     */     } 
/* 248 */     this.stack.pop();
/* 249 */     return (JSON)array;
/*     */   }
/*     */   
/*     */   private JSON createObject(Closure closure) {
/* 253 */     JSONObject object = new JSONObject();
/* 254 */     this.stack.push(object);
/* 255 */     closure.setDelegate(this);
/* 256 */     closure.setResolveStrategy(1);
/* 257 */     closure.call();
/* 258 */     this.stack.pop();
/* 259 */     return (JSON)object;
/*     */   }
/*     */   
/*     */   private JSON createObject(Map map) {
/* 263 */     JSONObject object = new JSONObject();
/* 264 */     this.stack.push(object);
/* 265 */     Iterator properties = map.entrySet().iterator();
/* 266 */     while (properties.hasNext()) {
/* 267 */       Map.Entry property = properties.next();
/* 268 */       String key = String.valueOf(property.getKey());
/* 269 */       Object value = property.getValue();
/* 270 */       if (value instanceof Closure) {
/* 271 */         value = createObject((Closure)value);
/* 272 */       } else if (value instanceof Map) {
/* 273 */         value = createObject((Map)value);
/* 274 */       } else if (value instanceof List) {
/* 275 */         value = createArray((List)value);
/*     */       } 
/* 277 */       object.element(key, value);
/*     */     } 
/* 279 */     this.stack.pop();
/* 280 */     return (JSON)object;
/*     */   }
/*     */   
/*     */   private JSON createObject(String name, Object arg) {
/* 284 */     Object[] args = (Object[])arg;
/* 285 */     if (args.length == 0) {
/* 286 */       throw new MissingMethodException(name, getClass(), args);
/*     */     }
/*     */     
/* 289 */     if (args.length == 1) {
/* 290 */       if (args[0] instanceof Closure)
/* 291 */         return createObject((Closure)args[0]); 
/* 292 */       if (args[0] instanceof Map)
/* 293 */         return createObject((Map)args[0]); 
/* 294 */       if (args[0] instanceof List) {
/* 295 */         return createArray((List)args[0]);
/*     */       }
/* 297 */       throw new JSONException("Unsupported type");
/*     */     } 
/*     */     
/* 300 */     JSONArray array = new JSONArray();
/* 301 */     this.stack.push(array);
/* 302 */     for (int i = 0; i < args.length; i++) {
/* 303 */       if (args[i] instanceof Closure) {
/* 304 */         append(name, createObject((Closure)args[i]));
/* 305 */       } else if (args[i] instanceof Map) {
/* 306 */         append(name, createObject((Map)args[i]));
/* 307 */       } else if (args[i] instanceof List) {
/* 308 */         append(name, createArray((List)args[i]));
/*     */       } else {
/* 310 */         _append(name, args[i], this.stack.peek());
/*     */       } 
/*     */     } 
/* 313 */     this.stack.pop();
/* 314 */     return (JSON)array;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\groovy\JsonGroovyBuilder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */