package net.sf.json.groovy;

import groovy.lang.Closure;
import groovy.lang.GroovyObject;
import groovy.lang.MetaClass;
import groovy.lang.Reference;
import java.lang.ref.SoftReference;
import org.codehaus.groovy.reflection.ClassInfo;
import org.codehaus.groovy.runtime.GeneratedClosure;
import org.codehaus.groovy.runtime.callsite.CallSite;
import org.codehaus.groovy.runtime.callsite.CallSiteArray;

public class GJson implements GroovyObject {
  public GJson() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
    //   7: astore_1
    //   8: aload_0
    //   9: invokevirtual $getStaticMetaClass : ()Lgroovy/lang/MetaClass;
    //   12: dup
    //   13: invokestatic $get$$class$groovy$lang$MetaClass : ()Ljava/lang/Class;
    //   16: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   19: checkcast groovy/lang/MetaClass
    //   22: aload_0
    //   23: swap
    //   24: putfield metaClass : Lgroovy/lang/MetaClass;
    //   27: pop
    //   28: return
    //   29: nop
    // Line number table:
    //   Java source line number -> byte code offset
    //   #28	-> 8
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   4	24	0	this	Lnet/sf/json/groovy/GJson;
  }
  
  public static void enhanceClasses() {
    // Byte code:
    //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
    //   3: astore_0
    //   4: aload_0
    //   5: ldc 0
    //   7: aaload
    //   8: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   11: invokeinterface callStatic : (Ljava/lang/Class;)Ljava/lang/Object;
    //   16: astore_1
    //   17: aload_0
    //   18: ldc 1
    //   20: aaload
    //   21: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   24: invokeinterface callStatic : (Ljava/lang/Class;)Ljava/lang/Object;
    //   29: astore_2
    //   30: aload_0
    //   31: ldc 2
    //   33: aaload
    //   34: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   37: invokeinterface callStatic : (Ljava/lang/Class;)Ljava/lang/Object;
    //   42: astore_3
    //   43: aload_0
    //   44: ldc 3
    //   46: aaload
    //   47: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   50: invokeinterface callStatic : (Ljava/lang/Class;)Ljava/lang/Object;
    //   55: astore #4
    //   57: aload_1
    //   58: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   61: ifeq -> 70
    //   64: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   67: goto -> 80
    //   70: aload_2
    //   71: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   74: ifne -> 64
    //   77: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   80: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   83: ifeq -> 92
    //   86: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   89: goto -> 102
    //   92: aload_3
    //   93: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   96: ifne -> 86
    //   99: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   102: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   105: ifeq -> 114
    //   108: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   111: goto -> 125
    //   114: aload #4
    //   116: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   119: ifne -> 108
    //   122: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   125: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   128: ifeq -> 147
    //   131: aload_0
    //   132: ldc 4
    //   134: aaload
    //   135: invokestatic $get$$class$groovy$lang$ExpandoMetaClass : ()Ljava/lang/Class;
    //   138: invokeinterface call : (Ljava/lang/Object;)Ljava/lang/Object;
    //   143: pop
    //   144: goto -> 147
    //   147: return
    //   148: return
    //   149: nop
    // Line number table:
    //   Java source line number -> byte code offset
    //   #30	-> 4
    //   #31	-> 17
    //   #32	-> 30
    //   #33	-> 43
    //   #34	-> 57
    //   #35	-> 131
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   17	131	1	s	Ljava/lang/Object;
    //   30	118	2	l	Ljava/lang/Object;
    //   43	105	3	m	Ljava/lang/Object;
    //   57	91	4	j	Ljava/lang/Object;
  }
  
  private static boolean enhanceString() {
    // Byte code:
    //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
    //   3: astore_0
    //   4: aload_0
    //   5: ldc 5
    //   7: aaload
    //   8: aload_0
    //   9: ldc 6
    //   11: aaload
    //   12: aload_0
    //   13: ldc 7
    //   15: aaload
    //   16: invokestatic $get$$class$java$lang$String : ()Ljava/lang/Class;
    //   19: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   24: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   29: new net/sf/json/groovy/GJson$_enhanceString_closure1
    //   32: dup
    //   33: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   36: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   39: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   42: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   47: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   50: ifne -> 57
    //   53: iconst_1
    //   54: goto -> 58
    //   57: iconst_0
    //   58: ifeq -> 177
    //   61: aload_0
    //   62: ldc 8
    //   64: aaload
    //   65: invokestatic $get$$class$java$lang$String : ()Ljava/lang/Class;
    //   68: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   73: ldc 'asType'
    //   75: invokestatic getMethodPointer : (Ljava/lang/Object;Ljava/lang/String;)Lgroovy/lang/Closure;
    //   78: new groovy/lang/Reference
    //   81: dup_x1
    //   82: swap
    //   83: invokespecial <init> : (Ljava/lang/Object;)V
    //   86: astore_1
    //   87: new net/sf/json/groovy/GJson$_enhanceString_closure2
    //   90: dup
    //   91: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   94: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   97: aload_1
    //   98: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;Lgroovy/lang/Reference;)V
    //   101: dup
    //   102: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   105: aload_0
    //   106: ldc 9
    //   108: aaload
    //   109: invokestatic $get$$class$java$lang$String : ()Ljava/lang/Class;
    //   112: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   117: ldc 'asType'
    //   119: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   122: pop
    //   123: new net/sf/json/groovy/GJson$_enhanceString_closure3
    //   126: dup
    //   127: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   130: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   133: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   136: dup
    //   137: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   140: aload_0
    //   141: ldc 10
    //   143: aaload
    //   144: invokestatic $get$$class$java$lang$String : ()Ljava/lang/Class;
    //   147: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   152: ldc 'isJsonEnhanced'
    //   154: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   157: pop
    //   158: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   161: invokestatic $get$$class$java$lang$Boolean : ()Ljava/lang/Class;
    //   164: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   167: checkcast java/lang/Boolean
    //   170: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   173: ireturn
    //   174: goto -> 177
    //   177: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   180: invokestatic $get$$class$java$lang$Boolean : ()Ljava/lang/Class;
    //   183: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   186: checkcast java/lang/Boolean
    //   189: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   192: ireturn
    //   193: nop
    // Line number table:
    //   Java source line number -> byte code offset
    //   #40	-> 4
    //   #41	-> 61
    //   #42	-> 87
    //   #56	-> 123
    //   #57	-> 158
    //   #59	-> 177
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   87	87	1	asType	Ljava/lang/Object;
  }
  
  class GJson$_enhanceString_closure1 extends Closure implements GeneratedClosure {
    public GJson$_enhanceString_closure1(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure1;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object param1Object) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_3
      //   15: ldc 0
      //   17: aaload
      //   18: aload_2
      //   19: invokevirtual get : ()Ljava/lang/Object;
      //   22: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   27: ldc 'isJsonEnhanced'
      //   29: invokestatic compareEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   32: ifeq -> 41
      //   35: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   38: goto -> 44
      //   41: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
      //   44: areturn
      //   45: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #40	-> 14
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	45	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure1;
      //   0	45	2	it	Ljava/lang/Object;
    }
    
    public Object doCall() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_1
      //   5: ldc 1
      //   7: aaload
      //   8: aload_0
      //   9: aconst_null
      //   10: invokestatic $get$$class$java$lang$Object : ()Ljava/lang/Class;
      //   13: invokestatic createPojoWrapper : (Ljava/lang/Object;Ljava/lang/Class;)Lorg/codehaus/groovy/runtime/wrappers/Wrapper;
      //   16: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   21: areturn
      //   22: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure1;
    }
  }
  
  class GJson$_enhanceString_closure2 extends Closure implements GeneratedClosure {
    private Reference asType;
    
    public GJson$_enhanceString_closure2(Object _outerInstance, Object _thisObject, Reference asType) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore #4
      //   5: aload_0
      //   6: aload_1
      //   7: aload_2
      //   8: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   11: aload_3
      //   12: dup
      //   13: checkcast groovy/lang/Reference
      //   16: aload_0
      //   17: swap
      //   18: putfield asType : Lgroovy/lang/Reference;
      //   21: pop
      //   22: return
      //   23: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure2;
      //   0	22	1	_outerInstance	Ljava/lang/Object;
      //   0	22	2	_thisObject	Ljava/lang/Object;
      //   0	22	3	asType	Lgroovy/lang/Reference;
    }
    
    public Object doCall(Class param1Class) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_2
      //   15: invokevirtual get : ()Ljava/lang/Object;
      //   18: astore #4
      //   20: aload #4
      //   22: invokestatic $get$$class$net$sf$json$JSON : ()Ljava/lang/Class;
      //   25: invokestatic isCase : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   28: ifeq -> 57
      //   31: aload_3
      //   32: ldc 0
      //   34: aaload
      //   35: invokestatic $get$$class$net$sf$json$JSONSerializer : ()Ljava/lang/Class;
      //   38: aload_3
      //   39: ldc 1
      //   41: aaload
      //   42: aload_0
      //   43: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   48: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   53: areturn
      //   54: goto -> 68
      //   57: aload #4
      //   59: invokestatic $get$$class$net$sf$json$JSONArray : ()Ljava/lang/Class;
      //   62: invokestatic isCase : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   65: ifeq -> 94
      //   68: aload_3
      //   69: ldc 2
      //   71: aaload
      //   72: invokestatic $get$$class$net$sf$json$JSONArray : ()Ljava/lang/Class;
      //   75: aload_3
      //   76: ldc 3
      //   78: aaload
      //   79: aload_0
      //   80: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   85: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   90: areturn
      //   91: goto -> 105
      //   94: aload #4
      //   96: invokestatic $get$$class$net$sf$json$JSONObject : ()Ljava/lang/Class;
      //   99: invokestatic isCase : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   102: ifeq -> 131
      //   105: aload_3
      //   106: ldc 4
      //   108: aaload
      //   109: invokestatic $get$$class$net$sf$json$JSONObject : ()Ljava/lang/Class;
      //   112: aload_3
      //   113: ldc 5
      //   115: aaload
      //   116: aload_0
      //   117: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   122: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   127: areturn
      //   128: goto -> 142
      //   131: aload #4
      //   133: invokestatic $get$$class$net$sf$json$JSONFunction : ()Ljava/lang/Class;
      //   136: invokestatic isCase : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   139: ifeq -> 165
      //   142: aload_3
      //   143: ldc 6
      //   145: aaload
      //   146: invokestatic $get$$class$net$sf$json$JSONFunction : ()Ljava/lang/Class;
      //   149: aload_3
      //   150: ldc 7
      //   152: aaload
      //   153: aload_0
      //   154: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   159: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   164: areturn
      //   165: aload_3
      //   166: ldc 8
      //   168: aaload
      //   169: aload_0
      //   170: getfield asType : Lgroovy/lang/Reference;
      //   173: invokevirtual get : ()Ljava/lang/Object;
      //   176: aload_2
      //   177: invokevirtual get : ()Ljava/lang/Object;
      //   180: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   185: areturn
      //   186: aconst_null
      //   187: areturn
      //   188: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #43	-> 14
      //   #44	-> 20
      //   #45	-> 31
      //   #46	-> 57
      //   #47	-> 68
      //   #48	-> 94
      //   #49	-> 105
      //   #50	-> 131
      //   #51	-> 142
      //   #53	-> 165
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	188	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure2;
      //   0	188	2	clazz	Ljava/lang/Class;
    }
    
    public Object call(Class param1Class) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_3
      //   15: ldc 9
      //   17: aaload
      //   18: aload_0
      //   19: aload_2
      //   20: invokevirtual get : ()Ljava/lang/Object;
      //   23: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   28: areturn
      //   29: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	29	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure2;
      //   0	29	2	clazz	Ljava/lang/Class;
    }
    
    public Object getAsType() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_0
      //   5: getfield asType : Lgroovy/lang/Reference;
      //   8: invokevirtual get : ()Ljava/lang/Object;
      //   11: areturn
      //   12: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure2;
    }
  }
  
  class GJson$_enhanceString_closure3 extends Closure implements GeneratedClosure {
    public GJson$_enhanceString_closure3(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure3;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object it) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_2
      //   4: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   7: areturn
      //   8: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #56	-> 4
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	8	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure3;
      //   0	8	1	it	Ljava/lang/Object;
    }
    
    public Object doCall() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_1
      //   5: ldc 0
      //   7: aaload
      //   8: aload_0
      //   9: aconst_null
      //   10: invokestatic $get$$class$java$lang$Object : ()Ljava/lang/Class;
      //   13: invokestatic createPojoWrapper : (Ljava/lang/Object;Ljava/lang/Class;)Lorg/codehaus/groovy/runtime/wrappers/Wrapper;
      //   16: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   21: areturn
      //   22: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceString_closure3;
    }
  }
  
  private static boolean enhanceCollection() {
    // Byte code:
    //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
    //   3: astore_0
    //   4: aload_0
    //   5: ldc 11
    //   7: aaload
    //   8: aload_0
    //   9: ldc 12
    //   11: aaload
    //   12: aload_0
    //   13: ldc 13
    //   15: aaload
    //   16: invokestatic $get$$class$java$util$Collection : ()Ljava/lang/Class;
    //   19: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   24: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   29: new net/sf/json/groovy/GJson$_enhanceCollection_closure4
    //   32: dup
    //   33: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   36: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   39: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   42: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   47: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   50: ifne -> 57
    //   53: iconst_1
    //   54: goto -> 58
    //   57: iconst_0
    //   58: ifeq -> 202
    //   61: aload_0
    //   62: ldc 14
    //   64: aaload
    //   65: invokestatic $get$$class$java$util$Collection : ()Ljava/lang/Class;
    //   68: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   73: ldc 'asType'
    //   75: invokestatic getMethodPointer : (Ljava/lang/Object;Ljava/lang/String;)Lgroovy/lang/Closure;
    //   78: new groovy/lang/Reference
    //   81: dup_x1
    //   82: swap
    //   83: invokespecial <init> : (Ljava/lang/Object;)V
    //   86: astore_1
    //   87: new net/sf/json/groovy/GJson$_enhanceCollection_closure5
    //   90: dup
    //   91: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   94: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   97: aload_1
    //   98: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;Lgroovy/lang/Reference;)V
    //   101: astore_2
    //   102: aload_2
    //   103: dup
    //   104: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   107: aload_0
    //   108: ldc 15
    //   110: aaload
    //   111: invokestatic $get$$class$java$util$ArrayList : ()Ljava/lang/Class;
    //   114: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   119: ldc 'asType'
    //   121: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   124: pop
    //   125: aload_2
    //   126: dup
    //   127: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   130: aload_0
    //   131: ldc 16
    //   133: aaload
    //   134: invokestatic $get$$class$java$util$HashSet : ()Ljava/lang/Class;
    //   137: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   142: ldc 'asType'
    //   144: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   147: pop
    //   148: new net/sf/json/groovy/GJson$_enhanceCollection_closure6
    //   151: dup
    //   152: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   155: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   158: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   161: dup
    //   162: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   165: aload_0
    //   166: ldc 17
    //   168: aaload
    //   169: invokestatic $get$$class$java$util$Collection : ()Ljava/lang/Class;
    //   172: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   177: ldc 'isJsonEnhanced'
    //   179: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   182: pop
    //   183: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   186: invokestatic $get$$class$java$lang$Boolean : ()Ljava/lang/Class;
    //   189: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   192: checkcast java/lang/Boolean
    //   195: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   198: ireturn
    //   199: goto -> 202
    //   202: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   205: invokestatic $get$$class$java$lang$Boolean : ()Ljava/lang/Class;
    //   208: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   211: checkcast java/lang/Boolean
    //   214: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   217: ireturn
    //   218: nop
    // Line number table:
    //   Java source line number -> byte code offset
    //   #63	-> 4
    //   #64	-> 61
    //   #65	-> 87
    //   #74	-> 102
    //   #75	-> 125
    //   #76	-> 148
    //   #77	-> 183
    //   #79	-> 202
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   87	112	1	asType	Ljava/lang/Object;
    //   102	97	2	typeConverter	Ljava/lang/Object;
  }
  
  class GJson$_enhanceCollection_closure4 extends Closure implements GeneratedClosure {
    public GJson$_enhanceCollection_closure4(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure4;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object param1Object) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_3
      //   15: ldc 0
      //   17: aaload
      //   18: aload_2
      //   19: invokevirtual get : ()Ljava/lang/Object;
      //   22: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   27: ldc 'isJsonEnhanced'
      //   29: invokestatic compareEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   32: ifeq -> 41
      //   35: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   38: goto -> 44
      //   41: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
      //   44: areturn
      //   45: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #63	-> 14
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	45	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure4;
      //   0	45	2	it	Ljava/lang/Object;
    }
    
    public Object doCall() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_1
      //   5: ldc 1
      //   7: aaload
      //   8: aload_0
      //   9: aconst_null
      //   10: invokestatic $get$$class$java$lang$Object : ()Ljava/lang/Class;
      //   13: invokestatic createPojoWrapper : (Ljava/lang/Object;Ljava/lang/Class;)Lorg/codehaus/groovy/runtime/wrappers/Wrapper;
      //   16: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   21: areturn
      //   22: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure4;
    }
  }
  
  class GJson$_enhanceCollection_closure5 extends Closure implements GeneratedClosure {
    private Reference asType;
    
    public GJson$_enhanceCollection_closure5(Object _outerInstance, Object _thisObject, Reference asType) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore #4
      //   5: aload_0
      //   6: aload_1
      //   7: aload_2
      //   8: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   11: aload_3
      //   12: dup
      //   13: checkcast groovy/lang/Reference
      //   16: aload_0
      //   17: swap
      //   18: putfield asType : Lgroovy/lang/Reference;
      //   21: pop
      //   22: return
      //   23: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure5;
      //   0	22	1	_outerInstance	Ljava/lang/Object;
      //   0	22	2	_thisObject	Ljava/lang/Object;
      //   0	22	3	asType	Lgroovy/lang/Reference;
    }
    
    public Object doCall(Class param1Class) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_2
      //   15: invokevirtual get : ()Ljava/lang/Object;
      //   18: astore #4
      //   20: aload #4
      //   22: invokestatic $get$$class$net$sf$json$JSONArray : ()Ljava/lang/Class;
      //   25: invokestatic isCase : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   28: ifeq -> 54
      //   31: aload_3
      //   32: ldc 0
      //   34: aaload
      //   35: invokestatic $get$$class$net$sf$json$JSONArray : ()Ljava/lang/Class;
      //   38: aload_3
      //   39: ldc 1
      //   41: aaload
      //   42: aload_0
      //   43: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   48: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   53: areturn
      //   54: aload_3
      //   55: ldc 2
      //   57: aaload
      //   58: aload_0
      //   59: getfield asType : Lgroovy/lang/Reference;
      //   62: invokevirtual get : ()Ljava/lang/Object;
      //   65: aload_2
      //   66: invokevirtual get : ()Ljava/lang/Object;
      //   69: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   74: areturn
      //   75: aconst_null
      //   76: areturn
      //   77: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #66	-> 14
      //   #67	-> 20
      //   #68	-> 31
      //   #70	-> 54
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	77	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure5;
      //   0	77	2	clazz	Ljava/lang/Class;
    }
    
    public Object call(Class param1Class) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_3
      //   15: ldc 3
      //   17: aaload
      //   18: aload_0
      //   19: aload_2
      //   20: invokevirtual get : ()Ljava/lang/Object;
      //   23: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   28: areturn
      //   29: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	29	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure5;
      //   0	29	2	clazz	Ljava/lang/Class;
    }
    
    public Object getAsType() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_0
      //   5: getfield asType : Lgroovy/lang/Reference;
      //   8: invokevirtual get : ()Ljava/lang/Object;
      //   11: areturn
      //   12: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure5;
    }
  }
  
  class GJson$_enhanceCollection_closure6 extends Closure implements GeneratedClosure {
    public GJson$_enhanceCollection_closure6(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure6;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object it) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_2
      //   4: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   7: areturn
      //   8: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #76	-> 4
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	8	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure6;
      //   0	8	1	it	Ljava/lang/Object;
    }
    
    public Object doCall() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_1
      //   5: ldc 0
      //   7: aaload
      //   8: aload_0
      //   9: aconst_null
      //   10: invokestatic $get$$class$java$lang$Object : ()Ljava/lang/Class;
      //   13: invokestatic createPojoWrapper : (Ljava/lang/Object;Ljava/lang/Class;)Lorg/codehaus/groovy/runtime/wrappers/Wrapper;
      //   16: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   21: areturn
      //   22: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceCollection_closure6;
    }
  }
  
  private static boolean enhanceMap() {
    // Byte code:
    //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
    //   3: astore_0
    //   4: aload_0
    //   5: ldc 18
    //   7: aaload
    //   8: aload_0
    //   9: ldc 19
    //   11: aaload
    //   12: aload_0
    //   13: ldc 20
    //   15: aaload
    //   16: invokestatic $get$$class$java$util$Map : ()Ljava/lang/Class;
    //   19: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   24: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   29: new net/sf/json/groovy/GJson$_enhanceMap_closure7
    //   32: dup
    //   33: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   36: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   39: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   42: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   47: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   50: ifne -> 57
    //   53: iconst_1
    //   54: goto -> 58
    //   57: iconst_0
    //   58: ifeq -> 177
    //   61: aload_0
    //   62: ldc 21
    //   64: aaload
    //   65: invokestatic $get$$class$java$util$Map : ()Ljava/lang/Class;
    //   68: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   73: ldc 'asType'
    //   75: invokestatic getMethodPointer : (Ljava/lang/Object;Ljava/lang/String;)Lgroovy/lang/Closure;
    //   78: new groovy/lang/Reference
    //   81: dup_x1
    //   82: swap
    //   83: invokespecial <init> : (Ljava/lang/Object;)V
    //   86: astore_1
    //   87: new net/sf/json/groovy/GJson$_enhanceMap_closure8
    //   90: dup
    //   91: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   94: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   97: aload_1
    //   98: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;Lgroovy/lang/Reference;)V
    //   101: dup
    //   102: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   105: aload_0
    //   106: ldc 22
    //   108: aaload
    //   109: invokestatic $get$$class$java$util$Map : ()Ljava/lang/Class;
    //   112: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   117: ldc 'asType'
    //   119: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   122: pop
    //   123: new net/sf/json/groovy/GJson$_enhanceMap_closure9
    //   126: dup
    //   127: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   130: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   133: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   136: dup
    //   137: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   140: aload_0
    //   141: ldc 23
    //   143: aaload
    //   144: invokestatic $get$$class$java$util$Map : ()Ljava/lang/Class;
    //   147: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   152: ldc 'isJsonEnhanced'
    //   154: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   157: pop
    //   158: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   161: invokestatic $get$$class$java$lang$Boolean : ()Ljava/lang/Class;
    //   164: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   167: checkcast java/lang/Boolean
    //   170: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   173: ireturn
    //   174: goto -> 177
    //   177: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   180: invokestatic $get$$class$java$lang$Boolean : ()Ljava/lang/Class;
    //   183: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   186: checkcast java/lang/Boolean
    //   189: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   192: ireturn
    //   193: nop
    // Line number table:
    //   Java source line number -> byte code offset
    //   #83	-> 4
    //   #84	-> 61
    //   #85	-> 87
    //   #93	-> 123
    //   #94	-> 158
    //   #96	-> 177
    // Local variable table:
    //   start	length	slot	name	descriptor
    //   87	87	1	asType	Ljava/lang/Object;
  }
  
  class GJson$_enhanceMap_closure7 extends Closure implements GeneratedClosure {
    public GJson$_enhanceMap_closure7(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure7;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object param1Object) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_3
      //   15: ldc 0
      //   17: aaload
      //   18: aload_2
      //   19: invokevirtual get : ()Ljava/lang/Object;
      //   22: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   27: ldc 'isJsonEnhanced'
      //   29: invokestatic compareEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   32: ifeq -> 41
      //   35: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   38: goto -> 44
      //   41: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
      //   44: areturn
      //   45: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #83	-> 14
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	45	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure7;
      //   0	45	2	it	Ljava/lang/Object;
    }
    
    public Object doCall() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_1
      //   5: ldc 1
      //   7: aaload
      //   8: aload_0
      //   9: aconst_null
      //   10: invokestatic $get$$class$java$lang$Object : ()Ljava/lang/Class;
      //   13: invokestatic createPojoWrapper : (Ljava/lang/Object;Ljava/lang/Class;)Lorg/codehaus/groovy/runtime/wrappers/Wrapper;
      //   16: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   21: areturn
      //   22: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure7;
    }
  }
  
  class GJson$_enhanceMap_closure8 extends Closure implements GeneratedClosure {
    private Reference asType;
    
    public GJson$_enhanceMap_closure8(Object _outerInstance, Object _thisObject, Reference asType) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore #4
      //   5: aload_0
      //   6: aload_1
      //   7: aload_2
      //   8: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   11: aload_3
      //   12: dup
      //   13: checkcast groovy/lang/Reference
      //   16: aload_0
      //   17: swap
      //   18: putfield asType : Lgroovy/lang/Reference;
      //   21: pop
      //   22: return
      //   23: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure8;
      //   0	22	1	_outerInstance	Ljava/lang/Object;
      //   0	22	2	_thisObject	Ljava/lang/Object;
      //   0	22	3	asType	Lgroovy/lang/Reference;
    }
    
    public Object doCall(Class param1Class) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_2
      //   15: invokevirtual get : ()Ljava/lang/Object;
      //   18: astore #4
      //   20: aload #4
      //   22: invokestatic $get$$class$net$sf$json$JSONObject : ()Ljava/lang/Class;
      //   25: invokestatic isCase : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   28: ifeq -> 54
      //   31: aload_3
      //   32: ldc 0
      //   34: aaload
      //   35: invokestatic $get$$class$net$sf$json$JSONObject : ()Ljava/lang/Class;
      //   38: aload_3
      //   39: ldc 1
      //   41: aaload
      //   42: aload_0
      //   43: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   48: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   53: areturn
      //   54: aload_3
      //   55: ldc 2
      //   57: aaload
      //   58: aload_0
      //   59: getfield asType : Lgroovy/lang/Reference;
      //   62: invokevirtual get : ()Ljava/lang/Object;
      //   65: aload_2
      //   66: invokevirtual get : ()Ljava/lang/Object;
      //   69: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   74: areturn
      //   75: aconst_null
      //   76: areturn
      //   77: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #86	-> 14
      //   #87	-> 20
      //   #88	-> 31
      //   #90	-> 54
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	77	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure8;
      //   0	77	2	clazz	Ljava/lang/Class;
    }
    
    public Object call(Class param1Class) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_3
      //   15: ldc 3
      //   17: aaload
      //   18: aload_0
      //   19: aload_2
      //   20: invokevirtual get : ()Ljava/lang/Object;
      //   23: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   28: areturn
      //   29: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	29	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure8;
      //   0	29	2	clazz	Ljava/lang/Class;
    }
    
    public Object getAsType() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_0
      //   5: getfield asType : Lgroovy/lang/Reference;
      //   8: invokevirtual get : ()Ljava/lang/Object;
      //   11: areturn
      //   12: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	12	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure8;
    }
  }
  
  class GJson$_enhanceMap_closure9 extends Closure implements GeneratedClosure {
    public GJson$_enhanceMap_closure9(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure9;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object it) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_2
      //   4: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   7: areturn
      //   8: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #93	-> 4
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	8	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure9;
      //   0	8	1	it	Ljava/lang/Object;
    }
    
    public Object doCall() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_1
      //   5: ldc 0
      //   7: aaload
      //   8: aload_0
      //   9: aconst_null
      //   10: invokestatic $get$$class$java$lang$Object : ()Ljava/lang/Class;
      //   13: invokestatic createPojoWrapper : (Ljava/lang/Object;Ljava/lang/Class;)Lorg/codehaus/groovy/runtime/wrappers/Wrapper;
      //   16: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   21: areturn
      //   22: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceMap_closure9;
    }
  }
  
  private static boolean enhanceJSONObject() {
    // Byte code:
    //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
    //   3: astore_0
    //   4: aload_0
    //   5: ldc 24
    //   7: aaload
    //   8: aload_0
    //   9: ldc 25
    //   11: aaload
    //   12: aload_0
    //   13: ldc 26
    //   15: aaload
    //   16: invokestatic $get$$class$net$sf$json$JSONObject : ()Ljava/lang/Class;
    //   19: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   24: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   29: new net/sf/json/groovy/GJson$_enhanceJSONObject_closure10
    //   32: dup
    //   33: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   36: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   39: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   42: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   47: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   50: ifne -> 57
    //   53: iconst_1
    //   54: goto -> 58
    //   57: iconst_0
    //   58: ifeq -> 185
    //   61: new net/sf/json/groovy/GJson$_enhanceJSONObject_closure11
    //   64: dup
    //   65: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   68: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   71: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   74: dup
    //   75: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   78: aload_0
    //   79: ldc 27
    //   81: aaload
    //   82: invokestatic $get$$class$net$sf$json$JSONObject : ()Ljava/lang/Class;
    //   85: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   90: ldc 'leftShift'
    //   92: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   95: pop
    //   96: new net/sf/json/groovy/GJson$_enhanceJSONObject_closure12
    //   99: dup
    //   100: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   103: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   106: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   109: dup
    //   110: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   113: aload_0
    //   114: ldc 28
    //   116: aaload
    //   117: invokestatic $get$$class$net$sf$json$JSONObject : ()Ljava/lang/Class;
    //   120: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   125: ldc 'get'
    //   127: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   130: pop
    //   131: new net/sf/json/groovy/GJson$_enhanceJSONObject_closure13
    //   134: dup
    //   135: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   138: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   141: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   144: dup
    //   145: invokestatic $get$$class$net$sf$json$groovy$GJson : ()Ljava/lang/Class;
    //   148: aload_0
    //   149: ldc 29
    //   151: aaload
    //   152: invokestatic $get$$class$net$sf$json$JSONObject : ()Ljava/lang/Class;
    //   155: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
    //   160: ldc 'isJsonEnhanced'
    //   162: invokestatic setProperty : (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;)V
    //   165: pop
    //   166: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   169: invokestatic $get$$class$java$lang$Boolean : ()Ljava/lang/Class;
    //   172: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   175: checkcast java/lang/Boolean
    //   178: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   181: ireturn
    //   182: goto -> 185
    //   185: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   188: invokestatic $get$$class$java$lang$Boolean : ()Ljava/lang/Class;
    //   191: invokestatic castToType : (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;
    //   194: checkcast java/lang/Boolean
    //   197: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
    //   200: ireturn
    //   201: nop
    // Line number table:
    //   Java source line number -> byte code offset
    //   #100	-> 4
    //   #101	-> 61
    //   #114	-> 96
    //   #122	-> 131
    //   #123	-> 166
    //   #125	-> 185
  }
  
  static {
    // Byte code:
    //   0: ldc2_w 0
    //   3: invokestatic valueOf : (J)Ljava/lang/Long;
    //   6: dup
    //   7: checkcast java/lang/Long
    //   10: putstatic net/sf/json/groovy/GJson.__timeStamp__239_neverHappen1292322693142 : Ljava/lang/Long;
    //   13: pop
    //   14: ldc2_w 1292322693142
    //   17: invokestatic valueOf : (J)Ljava/lang/Long;
    //   20: dup
    //   21: checkcast java/lang/Long
    //   24: putstatic net/sf/json/groovy/GJson.__timeStamp : Ljava/lang/Long;
    //   27: pop
    //   28: return
    //   29: return
    //   30: nop
  }
  
  class GJson$_enhanceJSONObject_closure10 extends Closure implements GeneratedClosure {
    public GJson$_enhanceJSONObject_closure10(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure10;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object param1Object) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_3
      //   15: ldc 0
      //   17: aaload
      //   18: aload_2
      //   19: invokevirtual get : ()Ljava/lang/Object;
      //   22: invokeinterface callGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   27: ldc 'isJsonEnhanced'
      //   29: invokestatic compareEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   32: ifeq -> 41
      //   35: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   38: goto -> 44
      //   41: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
      //   44: areturn
      //   45: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #100	-> 14
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	45	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure10;
      //   0	45	2	it	Ljava/lang/Object;
    }
    
    public Object doCall() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_1
      //   5: ldc 1
      //   7: aaload
      //   8: aload_0
      //   9: aconst_null
      //   10: invokestatic $get$$class$java$lang$Object : ()Ljava/lang/Class;
      //   13: invokestatic createPojoWrapper : (Ljava/lang/Object;Ljava/lang/Class;)Lorg/codehaus/groovy/runtime/wrappers/Wrapper;
      //   16: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   21: areturn
      //   22: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure10;
    }
  }
  
  class GJson$_enhanceJSONObject_closure11 extends Closure implements GeneratedClosure {
    public GJson$_enhanceJSONObject_closure11(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure11;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object param1Object) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_2
      //   10: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   13: astore_3
      //   14: aload_2
      //   15: invokevirtual get : ()Ljava/lang/Object;
      //   18: instanceof java/util/Map
      //   21: ifeq -> 62
      //   24: aload_3
      //   25: ldc 0
      //   27: aaload
      //   28: aload_3
      //   29: ldc 1
      //   31: aaload
      //   32: aload_0
      //   33: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   38: aload_2
      //   39: invokevirtual get : ()Ljava/lang/Object;
      //   42: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   47: pop
      //   48: aload_3
      //   49: ldc 2
      //   51: aaload
      //   52: aload_0
      //   53: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   58: areturn
      //   59: goto -> 235
      //   62: aload_2
      //   63: invokevirtual get : ()Ljava/lang/Object;
      //   66: instanceof java/util/List
      //   69: ifeq -> 100
      //   72: aload_3
      //   73: ldc 3
      //   75: aaload
      //   76: aload_2
      //   77: invokevirtual get : ()Ljava/lang/Object;
      //   80: invokeinterface call : (Ljava/lang/Object;)Ljava/lang/Object;
      //   85: getstatic net/sf/json/groovy/GJson$_enhanceJSONObject_closure11.$const$0 : Ljava/lang/Integer;
      //   88: invokestatic compareGreaterThanEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   91: ifeq -> 100
      //   94: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   97: goto -> 103
      //   100: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
      //   103: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
      //   106: ifeq -> 233
      //   109: aload_3
      //   110: ldc 4
      //   112: aaload
      //   113: aload_2
      //   114: invokevirtual get : ()Ljava/lang/Object;
      //   117: getstatic net/sf/json/groovy/GJson$_enhanceJSONObject_closure11.$const$1 : Ljava/lang/Integer;
      //   120: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   125: new groovy/lang/Reference
      //   128: dup_x1
      //   129: swap
      //   130: invokespecial <init> : (Ljava/lang/Object;)V
      //   133: astore #4
      //   135: aload_3
      //   136: ldc 5
      //   138: aaload
      //   139: aload_2
      //   140: invokevirtual get : ()Ljava/lang/Object;
      //   143: invokeinterface call : (Ljava/lang/Object;)Ljava/lang/Object;
      //   148: getstatic net/sf/json/groovy/GJson$_enhanceJSONObject_closure11.$const$2 : Ljava/lang/Integer;
      //   151: invokestatic compareEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   154: ifeq -> 201
      //   157: aload_3
      //   158: ldc 6
      //   160: aaload
      //   161: aload_3
      //   162: ldc 7
      //   164: aaload
      //   165: aload_0
      //   166: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   171: aload #4
      //   173: invokevirtual get : ()Ljava/lang/Object;
      //   176: aload_3
      //   177: ldc 8
      //   179: aaload
      //   180: aload_2
      //   181: invokevirtual get : ()Ljava/lang/Object;
      //   184: getstatic net/sf/json/groovy/GJson$_enhanceJSONObject_closure11.$const$1 : Ljava/lang/Integer;
      //   187: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   192: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   197: areturn
      //   198: goto -> 230
      //   201: aload_3
      //   202: ldc 9
      //   204: aaload
      //   205: aload_3
      //   206: ldc 10
      //   208: aaload
      //   209: aload_0
      //   210: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   215: aload #4
      //   217: invokevirtual get : ()Ljava/lang/Object;
      //   220: aload_2
      //   221: invokevirtual get : ()Ljava/lang/Object;
      //   224: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   229: areturn
      //   230: goto -> 235
      //   233: aconst_null
      //   234: areturn
      //   235: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #102	-> 14
      //   #103	-> 24
      //   #104	-> 48
      //   #105	-> 62
      //   #106	-> 109
      //   #107	-> 135
      //   #108	-> 157
      //   #109	-> 201
      //   #110	-> 201
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	235	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure11;
      //   0	235	2	args	Ljava/lang/Object;
      //   135	95	4	key	Ljava/lang/Object;
    }
    
    static {
      // Byte code:
      //   0: ldc 1
      //   2: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   5: dup
      //   6: checkcast java/lang/Integer
      //   9: putstatic net/sf/json/groovy/GJson$_enhanceJSONObject_closure11.$const$2 : Ljava/lang/Integer;
      //   12: pop
      //   13: ldc 0
      //   15: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   18: dup
      //   19: checkcast java/lang/Integer
      //   22: putstatic net/sf/json/groovy/GJson$_enhanceJSONObject_closure11.$const$1 : Ljava/lang/Integer;
      //   25: pop
      //   26: ldc 2
      //   28: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   31: dup
      //   32: checkcast java/lang/Integer
      //   35: putstatic net/sf/json/groovy/GJson$_enhanceJSONObject_closure11.$const$0 : Ljava/lang/Integer;
      //   38: pop
      //   39: return
      //   40: return
      //   41: nop
    }
  }
  
  class GJson$_enhanceJSONObject_closure12 extends Closure implements GeneratedClosure {
    public GJson$_enhanceJSONObject_closure12(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure12;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(String param1String, Object param1Object) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_3
      //   10: aload_2
      //   11: new groovy/lang/Reference
      //   14: dup_x1
      //   15: swap
      //   16: invokespecial <init> : (Ljava/lang/Object;)V
      //   19: astore #4
      //   21: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   24: astore #5
      //   26: aload #5
      //   28: ldc 0
      //   30: aaload
      //   31: aload #5
      //   33: ldc 1
      //   35: aaload
      //   36: aload_0
      //   37: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   42: aload_3
      //   43: invokevirtual get : ()Ljava/lang/Object;
      //   46: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   51: new groovy/lang/Reference
      //   54: dup_x1
      //   55: swap
      //   56: invokespecial <init> : (Ljava/lang/Object;)V
      //   59: astore #6
      //   61: aload #6
      //   63: invokevirtual get : ()Ljava/lang/Object;
      //   66: invokestatic booleanUnbox : (Ljava/lang/Object;)Z
      //   69: ifne -> 76
      //   72: iconst_1
      //   73: goto -> 77
      //   76: iconst_0
      //   77: ifeq -> 147
      //   80: aload #5
      //   82: ldc 2
      //   84: aaload
      //   85: aload #5
      //   87: ldc 3
      //   89: aaload
      //   90: aload_0
      //   91: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   96: aload_3
      //   97: invokevirtual get : ()Ljava/lang/Object;
      //   100: aload #4
      //   102: invokevirtual get : ()Ljava/lang/Object;
      //   105: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   110: pop
      //   111: aload #5
      //   113: ldc 4
      //   115: aaload
      //   116: aload #5
      //   118: ldc 5
      //   120: aaload
      //   121: aload_0
      //   122: invokeinterface callGroovyObjectGetProperty : (Ljava/lang/Object;)Ljava/lang/Object;
      //   127: aload_3
      //   128: invokevirtual get : ()Ljava/lang/Object;
      //   131: invokeinterface call : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   136: dup
      //   137: aload #6
      //   139: swap
      //   140: invokevirtual set : (Ljava/lang/Object;)V
      //   143: pop
      //   144: goto -> 147
      //   147: aload #6
      //   149: invokevirtual get : ()Ljava/lang/Object;
      //   152: areturn
      //   153: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #115	-> 26
      //   #116	-> 61
      //   #117	-> 80
      //   #118	-> 111
      //   #120	-> 147
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	153	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure12;
      //   0	153	3	key	Ljava/lang/String;
      //   0	153	4	defaultValue	Ljava/lang/Object;
      //   61	92	6	previousValue	Ljava/lang/Object;
    }
    
    public Object call(String param1String, Object param1Object) {
      // Byte code:
      //   0: aload_1
      //   1: new groovy/lang/Reference
      //   4: dup_x1
      //   5: swap
      //   6: invokespecial <init> : (Ljava/lang/Object;)V
      //   9: astore_3
      //   10: aload_2
      //   11: new groovy/lang/Reference
      //   14: dup_x1
      //   15: swap
      //   16: invokespecial <init> : (Ljava/lang/Object;)V
      //   19: astore #4
      //   21: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   24: astore #5
      //   26: aload #5
      //   28: ldc 6
      //   30: aaload
      //   31: aload_0
      //   32: aload_3
      //   33: invokevirtual get : ()Ljava/lang/Object;
      //   36: aload #4
      //   38: invokevirtual get : ()Ljava/lang/Object;
      //   41: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   46: areturn
      //   47: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	47	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure12;
      //   0	47	3	key	Ljava/lang/String;
      //   0	47	4	defaultValue	Ljava/lang/Object;
    }
  }
  
  class GJson$_enhanceJSONObject_closure13 extends Closure implements GeneratedClosure {
    public GJson$_enhanceJSONObject_closure13(Object _outerInstance, Object _thisObject) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_3
      //   4: aload_0
      //   5: aload_1
      //   6: aload_2
      //   7: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   10: return
      //   11: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	10	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure13;
      //   0	10	1	_outerInstance	Ljava/lang/Object;
      //   0	10	2	_thisObject	Ljava/lang/Object;
    }
    
    public Object doCall(Object it) {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_2
      //   4: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   7: areturn
      //   8: nop
      // Line number table:
      //   Java source line number -> byte code offset
      //   #122	-> 4
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	8	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure13;
      //   0	8	1	it	Ljava/lang/Object;
    }
    
    public Object doCall() {
      // Byte code:
      //   0: invokestatic $getCallSiteArray : ()[Lorg/codehaus/groovy/runtime/callsite/CallSite;
      //   3: astore_1
      //   4: aload_1
      //   5: ldc 0
      //   7: aaload
      //   8: aload_0
      //   9: aconst_null
      //   10: invokestatic $get$$class$java$lang$Object : ()Ljava/lang/Class;
      //   13: invokestatic createPojoWrapper : (Ljava/lang/Object;Ljava/lang/Class;)Lorg/codehaus/groovy/runtime/wrappers/Wrapper;
      //   16: invokeinterface callCurrent : (Lgroovy/lang/GroovyObject;Ljava/lang/Object;)Ljava/lang/Object;
      //   21: areturn
      //   22: nop
      // Local variable table:
      //   start	length	slot	name	descriptor
      //   0	22	0	this	Lnet/sf/json/groovy/GJson$_enhanceJSONObject_closure13;
    }
  }
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\groovy\GJson.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */