/*     */ package net.sf.json;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import net.sf.json.util.JSONUtils;
/*     */ import net.sf.json.util.JsonEventListener;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractJSON
/*     */ {
/*     */   private static class CycleSet
/*     */     extends ThreadLocal
/*     */   {
/*     */     private CycleSet() {}
/*     */     
/*     */     protected Object initialValue() {
/*  38 */       return new SoftReference(new HashSet());
/*     */     }
/*     */     
/*     */     public Set getSet() {
/*  42 */       Set set = ((SoftReference)get()).get();
/*  43 */       if (set == null) {
/*  44 */         set = new HashSet();
/*  45 */         set((T)new SoftReference(set));
/*     */       } 
/*  47 */       return set;
/*     */     }
/*     */   }
/*     */   
/*  51 */   private static CycleSet cycleSet = new CycleSet();
/*     */   
/*  53 */   private static final Log log = LogFactory.getLog(AbstractJSON.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean addInstance(Object instance) {
/*  63 */     return getCycleSet().add(instance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void fireArrayEndEvent(JsonConfig jsonConfig) {
/*  70 */     if (jsonConfig.isEventTriggeringEnabled()) {
/*  71 */       Iterator listeners = jsonConfig.getJsonEventListeners().iterator();
/*  72 */       while (listeners.hasNext()) {
/*  73 */         JsonEventListener listener = listeners.next();
/*     */         try {
/*  75 */           listener.onArrayEnd();
/*  76 */         } catch (RuntimeException e) {
/*  77 */           log.warn(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void fireArrayStartEvent(JsonConfig jsonConfig) {
/*  87 */     if (jsonConfig.isEventTriggeringEnabled()) {
/*  88 */       Iterator listeners = jsonConfig.getJsonEventListeners().iterator();
/*  89 */       while (listeners.hasNext()) {
/*  90 */         JsonEventListener listener = listeners.next();
/*     */         try {
/*  92 */           listener.onArrayStart();
/*  93 */         } catch (RuntimeException e) {
/*  94 */           log.warn(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void fireElementAddedEvent(int index, Object element, JsonConfig jsonConfig) {
/* 107 */     if (jsonConfig.isEventTriggeringEnabled()) {
/* 108 */       Iterator listeners = jsonConfig.getJsonEventListeners().iterator();
/* 109 */       while (listeners.hasNext()) {
/* 110 */         JsonEventListener listener = listeners.next();
/*     */         try {
/* 112 */           listener.onElementAdded(index, element);
/* 113 */         } catch (RuntimeException e) {
/* 114 */           log.warn(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void fireErrorEvent(JSONException jsone, JsonConfig jsonConfig) {
/* 126 */     if (jsonConfig.isEventTriggeringEnabled()) {
/* 127 */       Iterator listeners = jsonConfig.getJsonEventListeners().iterator();
/* 128 */       while (listeners.hasNext()) {
/* 129 */         JsonEventListener listener = listeners.next();
/*     */         try {
/* 131 */           listener.onError(jsone);
/* 132 */         } catch (RuntimeException e) {
/* 133 */           log.warn(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void fireObjectEndEvent(JsonConfig jsonConfig) {
/* 143 */     if (jsonConfig.isEventTriggeringEnabled()) {
/* 144 */       Iterator listeners = jsonConfig.getJsonEventListeners().iterator();
/* 145 */       while (listeners.hasNext()) {
/* 146 */         JsonEventListener listener = listeners.next();
/*     */         try {
/* 148 */           listener.onObjectEnd();
/* 149 */         } catch (RuntimeException e) {
/* 150 */           log.warn(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void fireObjectStartEvent(JsonConfig jsonConfig) {
/* 160 */     if (jsonConfig.isEventTriggeringEnabled()) {
/* 161 */       Iterator listeners = jsonConfig.getJsonEventListeners().iterator();
/* 162 */       while (listeners.hasNext()) {
/* 163 */         JsonEventListener listener = listeners.next();
/*     */         try {
/* 165 */           listener.onObjectStart();
/* 166 */         } catch (RuntimeException e) {
/* 167 */           log.warn(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void firePropertySetEvent(String key, Object value, boolean accumulated, JsonConfig jsonConfig) {
/* 182 */     if (jsonConfig.isEventTriggeringEnabled()) {
/* 183 */       Iterator listeners = jsonConfig.getJsonEventListeners().iterator();
/* 184 */       while (listeners.hasNext()) {
/* 185 */         JsonEventListener listener = listeners.next();
/*     */         try {
/* 187 */           listener.onPropertySet(key, value, accumulated);
/* 188 */         } catch (RuntimeException e) {
/* 189 */           log.warn(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void fireWarnEvent(String warning, JsonConfig jsonConfig) {
/* 201 */     if (jsonConfig.isEventTriggeringEnabled()) {
/* 202 */       Iterator listeners = jsonConfig.getJsonEventListeners().iterator();
/* 203 */       while (listeners.hasNext()) {
/* 204 */         JsonEventListener listener = listeners.next();
/*     */         try {
/* 206 */           listener.onWarning(warning);
/* 207 */         } catch (RuntimeException e) {
/* 208 */           log.warn(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void removeInstance(Object instance) {
/* 218 */     Set set = getCycleSet();
/* 219 */     set.remove(instance);
/* 220 */     if (set.size() == 0) {
/* 221 */       cycleSet.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object _processValue(Object value, JsonConfig jsonConfig) {
/* 226 */     if (JSONNull.getInstance().equals(value))
/* 227 */       return JSONNull.getInstance(); 
/* 228 */     if (Class.class.isAssignableFrom(value.getClass()) || value instanceof Class)
/* 229 */       return ((Class)value).getName(); 
/* 230 */     if (JSONUtils.isFunction(value)) {
/* 231 */       if (value instanceof String) {
/* 232 */         value = JSONFunction.parse((String)value);
/*     */       }
/* 234 */       return value;
/* 235 */     }  if (value instanceof JSONString)
/* 236 */       return JSONSerializer.toJSON(value, jsonConfig); 
/* 237 */     if (value instanceof JSON)
/* 238 */       return JSONSerializer.toJSON(value, jsonConfig); 
/* 239 */     if (JSONUtils.isArray(value))
/* 240 */       return JSONArray.fromObject(value, jsonConfig); 
/* 241 */     if (JSONUtils.isString(value)) {
/* 242 */       String str = String.valueOf(value);
/* 243 */       if (JSONUtils.hasQuotes(str)) {
/* 244 */         String stripped = JSONUtils.stripQuotes(str);
/* 245 */         if (JSONUtils.isFunction(stripped)) {
/* 246 */           return "\"" + stripped + "\"";
/*     */         }
/* 248 */         if (stripped.startsWith("[") && stripped.endsWith("]")) {
/* 249 */           return stripped;
/*     */         }
/* 251 */         if (stripped.startsWith("{") && stripped.endsWith("}")) {
/* 252 */           return stripped;
/*     */         }
/* 254 */         return str;
/* 255 */       }  if (JSONUtils.isJsonKeyword(str, jsonConfig)) {
/* 256 */         if (jsonConfig.isJavascriptCompliant() && "undefined".equals(str)) {
/* 257 */           return JSONNull.getInstance();
/*     */         }
/* 259 */         return str;
/* 260 */       }  if (JSONUtils.mayBeJSON(str)) {
/*     */         try {
/* 262 */           return JSONSerializer.toJSON(str, jsonConfig);
/* 263 */         } catch (JSONException jsone) {
/* 264 */           return str;
/*     */         } 
/*     */       }
/* 267 */       return str;
/* 268 */     }  if (JSONUtils.isNumber(value)) {
/* 269 */       JSONUtils.testValidity(value);
/* 270 */       return JSONUtils.transformNumber((Number)value);
/* 271 */     }  if (JSONUtils.isBoolean(value)) {
/* 272 */       return value;
/*     */     }
/* 274 */     JSONObject jsonObject = JSONObject.fromObject(value, jsonConfig);
/* 275 */     if (jsonObject.isNullObject()) {
/* 276 */       return JSONNull.getInstance();
/*     */     }
/* 278 */     return jsonObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Set getCycleSet() {
/* 284 */     return cycleSet.getSet();
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\AbstractJSON.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */