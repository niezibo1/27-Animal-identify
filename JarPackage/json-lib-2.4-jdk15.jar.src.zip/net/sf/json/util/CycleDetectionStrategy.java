/*    */ package net.sf.json.util;
/*    */ 
/*    */ import net.sf.json.JSONArray;
/*    */ import net.sf.json.JSONException;
/*    */ import net.sf.json.JSONObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CycleDetectionStrategy
/*    */ {
/* 36 */   public static final JSONArray IGNORE_PROPERTY_ARR = new JSONArray();
/* 37 */   public static final JSONObject IGNORE_PROPERTY_OBJ = new JSONObject();
/*    */ 
/*    */   
/* 40 */   public static final CycleDetectionStrategy LENIENT = new LenientCycleDetectionStrategy();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public static final CycleDetectionStrategy NOPROP = new LenientNoRefCycleDetectionStrategy();
/*    */   
/* 47 */   public static final CycleDetectionStrategy STRICT = new StrictCycleDetectionStrategy();
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract JSONArray handleRepeatedReferenceAsArray(Object paramObject);
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract JSONObject handleRepeatedReferenceAsObject(Object paramObject);
/*    */ 
/*    */ 
/*    */   
/*    */   private static final class LenientCycleDetectionStrategy
/*    */     extends CycleDetectionStrategy
/*    */   {
/*    */     private LenientCycleDetectionStrategy() {}
/*    */ 
/*    */ 
/*    */     
/*    */     public JSONArray handleRepeatedReferenceAsArray(Object reference) {
/* 67 */       return new JSONArray();
/*    */     }
/*    */     
/*    */     public JSONObject handleRepeatedReferenceAsObject(Object reference) {
/* 71 */       return new JSONObject(true);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private static final class LenientNoRefCycleDetectionStrategy
/*    */     extends CycleDetectionStrategy
/*    */   {
/*    */     private LenientNoRefCycleDetectionStrategy() {}
/*    */ 
/*    */     
/*    */     public JSONArray handleRepeatedReferenceAsArray(Object reference) {
/* 83 */       return CycleDetectionStrategy.IGNORE_PROPERTY_ARR;
/*    */     }
/*    */     
/*    */     public JSONObject handleRepeatedReferenceAsObject(Object reference) {
/* 87 */       return CycleDetectionStrategy.IGNORE_PROPERTY_OBJ;
/*    */     }
/*    */   }
/*    */   
/*    */   private static final class StrictCycleDetectionStrategy extends CycleDetectionStrategy {
/*    */     public JSONArray handleRepeatedReferenceAsArray(Object reference) {
/* 93 */       throw new JSONException("There is a cycle in the hierarchy!");
/*    */     }
/*    */     
/*    */     public JSONObject handleRepeatedReferenceAsObject(Object reference) {
/* 97 */       throw new JSONException("There is a cycle in the hierarchy!");
/*    */     }
/*    */     
/*    */     private StrictCycleDetectionStrategy() {}
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\CycleDetectionStrategy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */