/*    */ package net.sf.json.util;
/*    */ 
/*    */ import net.sf.ezmorph.ObjectMorpher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumMorpher
/*    */   implements ObjectMorpher
/*    */ {
/*    */   private Class enumClass;
/*    */   
/*    */   public EnumMorpher(Class<?> enumClass) {
/* 30 */     if (enumClass == null) {
/* 31 */       throw new IllegalArgumentException("enumClass is null");
/*    */     }
/* 33 */     if (!Enum.class.isAssignableFrom(enumClass)) {
/* 34 */       throw new IllegalArgumentException("enumClass is not an Enum class");
/*    */     }
/* 36 */     this.enumClass = enumClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object morph(Object value) {
/* 41 */     if (value == null) {
/* 42 */       return this.enumClass.cast(null);
/*    */     }
/* 44 */     return Enum.valueOf(this.enumClass, String.valueOf(value));
/*    */   }
/*    */ 
/*    */   
/*    */   public Class morphsTo() {
/* 49 */     return this.enumClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 54 */     return String.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\EnumMorpher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */