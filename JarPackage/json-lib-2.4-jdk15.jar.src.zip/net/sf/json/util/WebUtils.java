/*     */ package net.sf.json.util;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.sf.json.JSON;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONNull;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebUtils
/*     */ {
/*  32 */   private static final WebHijackPreventionStrategy DEFAULT_WEB_HIJACK_PREVENTION_STRATEGY = WebHijackPreventionStrategy.INFINITE_LOOP;
/*  33 */   private static WebHijackPreventionStrategy webHijackPreventionStrategy = DEFAULT_WEB_HIJACK_PREVENTION_STRATEGY;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebHijackPreventionStrategy getWebHijackPreventionStrategy() {
/*  39 */     return webHijackPreventionStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String protect(JSON json) {
/*  50 */     return protect(json, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String protect(JSON json, boolean shrink) {
/*  62 */     String output = !shrink ? json.toString(0) : toString(json);
/*  63 */     return webHijackPreventionStrategy.protect(output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setWebHijackPreventionStrategy(WebHijackPreventionStrategy strategy) {
/*  72 */     webHijackPreventionStrategy = (strategy == null) ? DEFAULT_WEB_HIJACK_PREVENTION_STRATEGY : strategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(JSON json) {
/*  83 */     if (json instanceof JSONObject)
/*  84 */       return toString((JSONObject)json); 
/*  85 */     if (json instanceof JSONArray) {
/*  86 */       return toString((JSONArray)json);
/*     */     }
/*  88 */     return toString((JSONNull)json);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String join(JSONArray jsonArray) {
/*  93 */     int len = jsonArray.size();
/*  94 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  96 */     for (int i = 0; i < len; i++) {
/*  97 */       if (i > 0) {
/*  98 */         sb.append(",");
/*     */       }
/* 100 */       Object value = jsonArray.get(i);
/* 101 */       sb.append(toString(value));
/*     */     } 
/*     */     
/* 104 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String quote(String str) {
/* 108 */     if (str.indexOf(" ") > -1 || str.indexOf(":") > -1) {
/* 109 */       return JSONUtils.quote(str);
/*     */     }
/* 111 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toString(JSONArray jsonArray) {
/*     */     try {
/* 117 */       return '[' + join(jsonArray) + ']';
/* 118 */     } catch (Exception e) {
/* 119 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String toString(JSONNull jsonNull) {
/* 124 */     return jsonNull.toString();
/*     */   }
/*     */   
/*     */   private static String toString(JSONObject jsonObject) {
/* 128 */     if (jsonObject.isNullObject()) {
/* 129 */       return JSONNull.getInstance().toString();
/*     */     }
/*     */     
/* 132 */     Iterator keys = jsonObject.keys();
/* 133 */     StringBuffer sb = new StringBuffer("{");
/*     */     
/* 135 */     while (keys.hasNext()) {
/* 136 */       if (sb.length() > 1) {
/* 137 */         sb.append(',');
/*     */       }
/* 139 */       Object o = keys.next();
/* 140 */       sb.append(quote(o.toString()));
/* 141 */       sb.append(':');
/* 142 */       sb.append(toString(jsonObject.get(String.valueOf(o))));
/*     */     } 
/* 144 */     sb.append('}');
/* 145 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String toString(Object object) {
/* 149 */     if (object instanceof JSON) {
/* 150 */       return toString((JSON)object);
/*     */     }
/* 152 */     return JSONUtils.valueToString(object);
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\WebUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */