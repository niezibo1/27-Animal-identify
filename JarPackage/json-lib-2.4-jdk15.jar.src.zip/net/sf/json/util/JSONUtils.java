/*     */ package net.sf.json.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.sf.ezmorph.MorphUtils;
/*     */ import net.sf.ezmorph.MorpherRegistry;
/*     */ import net.sf.ezmorph.bean.MorphDynaBean;
/*     */ import net.sf.ezmorph.bean.MorphDynaClass;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONException;
/*     */ import net.sf.json.JSONFunction;
/*     */ import net.sf.json.JSONNull;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.JSONString;
/*     */ import net.sf.json.JsonConfig;
/*     */ import net.sf.json.regexp.RegexpUtils;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JSONUtils
/*     */ {
/*     */   public static final String DOUBLE_QUOTE = "\"";
/*     */   public static final String SINGLE_QUOTE = "'";
/*     */   private static final String FUNCTION_BODY_PATTERN = "^function[ ]?\\(.*?\\)[ \n\t]*\\{(.*?)\\}$";
/*     */   private static final String FUNCTION_HEADER_PATTERN = "^function[ ]?\\(.*?\\)$";
/*     */   private static final String FUNCTION_PARAMS_PATTERN = "^function[ ]?\\((.*?)\\).*";
/*     */   private static final String FUNCTION_PATTERN = "^function[ ]?\\(.*?\\)[ \n\t]*\\{.*?\\}$";
/*     */   private static final String FUNCTION_PREFIX = "function";
/*  61 */   private static final MorpherRegistry morpherRegistry = new MorpherRegistry();
/*     */ 
/*     */   
/*     */   static {
/*  65 */     MorphUtils.registerStandardMorphers(morpherRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertToJavaIdentifier(String key) {
/*  75 */     return convertToJavaIdentifier(key, new JsonConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertToJavaIdentifier(String key, JsonConfig jsonConfig) {
/*     */     try {
/*  86 */       return jsonConfig.getJavaIdentifierTransformer().transformToJavaIdentifier(key);
/*     */     }
/*  88 */     catch (JSONException jsone) {
/*  89 */       throw jsone;
/*  90 */     } catch (Exception e) {
/*  91 */       throw new JSONException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String doubleToString(double d) {
/* 103 */     if (Double.isInfinite(d) || Double.isNaN(d)) {
/* 104 */       return "null";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 109 */     String s = Double.toString(d);
/* 110 */     if (s.indexOf('.') > 0 && s.indexOf('e') < 0 && s.indexOf('E') < 0) {
/* 111 */       while (s.endsWith("0")) {
/* 112 */         s = s.substring(0, s.length() - 1);
/*     */       }
/* 114 */       if (s.endsWith(".")) {
/* 115 */         s = s.substring(0, s.length() - 1);
/*     */       }
/*     */     } 
/* 118 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFunctionBody(String function) {
/* 125 */     return RegexpUtils.getMatcher("^function[ ]?\\(.*?\\)[ \n\t]*\\{(.*?)\\}$", true).getGroupIfMatches(function, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFunctionParams(String function) {
/* 132 */     return RegexpUtils.getMatcher("^function[ ]?\\((.*?)\\).*", true).getGroupIfMatches(function, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class getInnerComponentType(Class type) {
/* 139 */     if (!type.isArray()) {
/* 140 */       return type;
/*     */     }
/* 142 */     return getInnerComponentType(type.getComponentType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MorpherRegistry getMorpherRegistry() {
/* 149 */     return morpherRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map getProperties(JSONObject jsonObject) {
/* 156 */     Map properties = new HashMap();
/* 157 */     for (Iterator keys = jsonObject.keys(); keys.hasNext(); ) {
/* 158 */       String key = keys.next();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 163 */       properties.put(key, getTypeClass(jsonObject.get(key)));
/*     */     } 
/* 165 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class getTypeClass(Object obj) {
/* 173 */     if (isNull(obj))
/* 174 */       return Object.class; 
/* 175 */     if (isArray(obj))
/* 176 */       return List.class; 
/* 177 */     if (isFunction(obj))
/* 178 */       return JSONFunction.class; 
/* 179 */     if (isBoolean(obj))
/* 180 */       return Boolean.class; 
/* 181 */     if (isNumber(obj)) {
/* 182 */       Number n = (Number)obj;
/* 183 */       if (isInteger(n))
/* 184 */         return Integer.class; 
/* 185 */       if (isLong(n))
/* 186 */         return Long.class; 
/* 187 */       if (isFloat(n))
/* 188 */         return Float.class; 
/* 189 */       if (isBigInteger(n))
/* 190 */         return BigInteger.class; 
/* 191 */       if (isBigDecimal(n))
/* 192 */         return BigDecimal.class; 
/* 193 */       if (isDouble(n)) {
/* 194 */         return Double.class;
/*     */       }
/* 196 */       throw new JSONException("Unsupported type");
/*     */     } 
/* 198 */     if (isString(obj))
/* 199 */       return String.class; 
/* 200 */     if (isObject(obj)) {
/* 201 */       return Object.class;
/*     */     }
/* 203 */     throw new JSONException("Unsupported type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hashCode(Object value) {
/* 215 */     if (value == null) {
/* 216 */       return JSONNull.getInstance().hashCode();
/*     */     }
/* 218 */     if (value instanceof net.sf.json.JSON || value instanceof String || value instanceof JSONFunction) {
/* 219 */       return value.hashCode();
/*     */     }
/* 221 */     return String.valueOf(value).hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isArray(Class clazz) {
/* 230 */     return (clazz != null && (clazz.isArray() || Collection.class.isAssignableFrom(clazz) || JSONArray.class.isAssignableFrom(clazz)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isArray(Object obj) {
/* 238 */     if ((obj != null && obj.getClass().isArray()) || obj instanceof Collection || obj instanceof JSONArray)
/*     */     {
/* 240 */       return true;
/*     */     }
/* 242 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBoolean(Class clazz) {
/* 249 */     return (clazz != null && (boolean.class.isAssignableFrom(clazz) || Boolean.class.isAssignableFrom(clazz)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBoolean(Object obj) {
/* 257 */     if (obj instanceof Boolean || (obj != null && obj.getClass() == boolean.class)) {
/* 258 */       return true;
/*     */     }
/* 260 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDouble(Class clazz) {
/* 267 */     return (clazz != null && (double.class.isAssignableFrom(clazz) || Double.class.isAssignableFrom(clazz)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFunction(Object obj) {
/* 277 */     if (obj instanceof String) {
/* 278 */       String str = (String)obj;
/* 279 */       return (str.startsWith("function") && RegexpUtils.getMatcher("^function[ ]?\\(.*?\\)[ \n\t]*\\{.*?\\}$", true).matches(str));
/*     */     } 
/* 281 */     if (obj instanceof JSONFunction) {
/* 282 */       return true;
/*     */     }
/* 284 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFunctionHeader(Object obj) {
/* 292 */     if (obj instanceof String) {
/* 293 */       String str = (String)obj;
/* 294 */       return (str.startsWith("function") && RegexpUtils.getMatcher("^function[ ]?\\(.*?\\)$", true).matches(str));
/*     */     } 
/* 296 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJavaIdentifier(String str) {
/* 303 */     if (str.length() == 0 || !Character.isJavaIdentifierStart(str.charAt(0))) {
/* 304 */       return false;
/*     */     }
/* 306 */     for (int i = 1; i < str.length(); i++) {
/* 307 */       if (!Character.isJavaIdentifierPart(str.charAt(i))) {
/* 308 */         return false;
/*     */       }
/*     */     } 
/* 311 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNull(Object obj) {
/* 318 */     if (obj instanceof JSONObject) {
/* 319 */       return ((JSONObject)obj).isNullObject();
/*     */     }
/* 321 */     return JSONNull.getInstance().equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNumber(Class clazz) {
/* 329 */     return (clazz != null && (byte.class.isAssignableFrom(clazz) || short.class.isAssignableFrom(clazz) || int.class.isAssignableFrom(clazz) || long.class.isAssignableFrom(clazz) || float.class.isAssignableFrom(clazz) || double.class.isAssignableFrom(clazz) || Number.class.isAssignableFrom(clazz)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNumber(Object obj) {
/* 339 */     if ((obj != null && obj.getClass() == byte.class) || (obj != null && obj.getClass() == short.class) || (obj != null && obj.getClass() == int.class) || (obj != null && obj.getClass() == long.class) || (obj != null && obj.getClass() == float.class) || (obj != null && obj.getClass() == double.class))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 345 */       return true;
/*     */     }
/*     */     
/* 348 */     return obj instanceof Number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isObject(Object obj) {
/* 355 */     return ((!isNumber(obj) && !isString(obj) && !isBoolean(obj) && !isArray(obj) && !isFunction(obj)) || isNull(obj));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isString(Class clazz) {
/* 363 */     return (clazz != null && (String.class.isAssignableFrom(clazz) || char.class.isAssignableFrom(clazz) || Character.class.isAssignableFrom(clazz)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isString(Object obj) {
/* 371 */     if (obj instanceof String || obj instanceof Character || (obj != null && (obj.getClass() == char.class || String.class.isAssignableFrom(obj.getClass()))))
/*     */     {
/*     */       
/* 374 */       return true;
/*     */     }
/* 376 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean mayBeJSON(String string) {
/* 389 */     return (string != null && ("null".equals(string) || (string.startsWith("[") && string.endsWith("]")) || (string.startsWith("{") && string.endsWith("}"))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DynaBean newDynaBean(JSONObject jsonObject) {
/* 400 */     return newDynaBean(jsonObject, new JsonConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DynaBean newDynaBean(JSONObject jsonObject, JsonConfig jsonConfig) {
/* 409 */     Map props = getProperties(jsonObject);
/* 410 */     Iterator entries = props.entrySet().iterator();
/* 411 */     while (entries.hasNext()) {
/* 412 */       Map.Entry entry = entries.next();
/* 413 */       String key = (String)entry.getKey();
/* 414 */       if (!isJavaIdentifier(key)) {
/* 415 */         String parsedKey = convertToJavaIdentifier(key, jsonConfig);
/* 416 */         if (parsedKey.compareTo(key) != 0) {
/* 417 */           props.put(parsedKey, props.remove(key));
/*     */         }
/*     */       } 
/*     */     } 
/* 421 */     MorphDynaClass dynaClass = new MorphDynaClass(props);
/* 422 */     MorphDynaBean dynaBean = null;
/*     */     try {
/* 424 */       dynaBean = (MorphDynaBean)dynaClass.newInstance();
/* 425 */       dynaBean.setDynaBeanClass(dynaClass);
/* 426 */     } catch (Exception e) {
/* 427 */       throw new JSONException(e);
/*     */     } 
/* 429 */     return (DynaBean)dynaBean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String numberToString(Number n) {
/* 440 */     if (n == null) {
/* 441 */       throw new JSONException("Null pointer");
/*     */     }
/* 443 */     testValidity(n);
/*     */ 
/*     */ 
/*     */     
/* 447 */     String s = n.toString();
/* 448 */     if (s.indexOf('.') > 0 && s.indexOf('e') < 0 && s.indexOf('E') < 0) {
/* 449 */       while (s.endsWith("0")) {
/* 450 */         s = s.substring(0, s.length() - 1);
/*     */       }
/* 452 */       if (s.endsWith(".")) {
/* 453 */         s = s.substring(0, s.length() - 1);
/*     */       }
/*     */     } 
/* 456 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quote(String string) {
/* 472 */     if (isFunction(string)) {
/* 473 */       return string;
/*     */     }
/* 475 */     if (string == null || string.length() == 0) {
/* 476 */       return "\"\"";
/*     */     }
/*     */ 
/*     */     
/* 480 */     char c = Character.MIN_VALUE;
/*     */     
/* 482 */     int len = string.length();
/* 483 */     StringBuffer sb = new StringBuffer(len * 2);
/*     */     
/* 485 */     char[] chars = string.toCharArray();
/* 486 */     char[] buffer = new char[1030];
/* 487 */     int bufferIndex = 0;
/* 488 */     sb.append('"');
/* 489 */     for (int i = 0; i < len; i++) {
/* 490 */       if (bufferIndex > 1024) {
/* 491 */         sb.append(buffer, 0, bufferIndex);
/* 492 */         bufferIndex = 0;
/*     */       } 
/* 494 */       char b = c;
/* 495 */       c = chars[i];
/* 496 */       switch (c) {
/*     */         case '"':
/*     */         case '\\':
/* 499 */           buffer[bufferIndex++] = '\\';
/* 500 */           buffer[bufferIndex++] = c;
/*     */           break;
/*     */         case '/':
/* 503 */           if (b == '<') {
/* 504 */             buffer[bufferIndex++] = '\\';
/*     */           }
/* 506 */           buffer[bufferIndex++] = c;
/*     */           break;
/*     */         default:
/* 509 */           if (c < ' ') {
/* 510 */             switch (c) {
/*     */               case '\b':
/* 512 */                 buffer[bufferIndex++] = '\\';
/* 513 */                 buffer[bufferIndex++] = 'b';
/*     */                 break;
/*     */               case '\t':
/* 516 */                 buffer[bufferIndex++] = '\\';
/* 517 */                 buffer[bufferIndex++] = 't';
/*     */                 break;
/*     */               case '\n':
/* 520 */                 buffer[bufferIndex++] = '\\';
/* 521 */                 buffer[bufferIndex++] = 'n';
/*     */                 break;
/*     */               case '\f':
/* 524 */                 buffer[bufferIndex++] = '\\';
/* 525 */                 buffer[bufferIndex++] = 'f';
/*     */                 break;
/*     */               case '\r':
/* 528 */                 buffer[bufferIndex++] = '\\';
/* 529 */                 buffer[bufferIndex++] = 'r';
/*     */                 break;
/*     */             } 
/* 532 */             String t = "000" + Integer.toHexString(c);
/* 533 */             int tLength = t.length();
/* 534 */             buffer[bufferIndex++] = '\\';
/* 535 */             buffer[bufferIndex++] = 'u';
/* 536 */             buffer[bufferIndex++] = t.charAt(tLength - 4);
/* 537 */             buffer[bufferIndex++] = t.charAt(tLength - 3);
/* 538 */             buffer[bufferIndex++] = t.charAt(tLength - 2);
/* 539 */             buffer[bufferIndex++] = t.charAt(tLength - 1);
/*     */             break;
/*     */           } 
/* 542 */           buffer[bufferIndex++] = c;
/*     */           break;
/*     */       } 
/*     */     } 
/* 546 */     sb.append(buffer, 0, bufferIndex);
/* 547 */     sb.append('"');
/* 548 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stripQuotes(String input) {
/* 555 */     if (input.length() < 2)
/* 556 */       return input; 
/* 557 */     if (input.startsWith("'") && input.endsWith("'"))
/* 558 */       return input.substring(1, input.length() - 1); 
/* 559 */     if (input.startsWith("\"") && input.endsWith("\"")) {
/* 560 */       return input.substring(1, input.length() - 1);
/*     */     }
/* 562 */     return input;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasQuotes(String input) {
/* 570 */     if (input == null || input.length() < 2) {
/* 571 */       return false;
/*     */     }
/* 573 */     return ((input.startsWith("'") && input.endsWith("'")) || (input.startsWith("\"") && input.endsWith("\"")));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isJsonKeyword(String input, JsonConfig jsonConfig) {
/* 578 */     if (input == null) {
/* 579 */       return false;
/*     */     }
/* 581 */     return ("null".equals(input) || "true".equals(input) || "false".equals(input) || (jsonConfig.isJavascriptCompliant() && "undefined".equals(input)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void testValidity(Object o) {
/* 594 */     if (o != null) {
/* 595 */       if (o instanceof Double) {
/* 596 */         if (((Double)o).isInfinite() || ((Double)o).isNaN()) {
/* 597 */           throw new JSONException("JSON does not allow non-finite numbers");
/*     */         }
/* 599 */       } else if (o instanceof Float) {
/* 600 */         if (((Float)o).isInfinite() || ((Float)o).isNaN()) {
/* 601 */           throw new JSONException("JSON does not allow non-finite numbers.");
/*     */         }
/* 603 */       } else if (o instanceof BigDecimal || o instanceof BigInteger) {
/*     */         return;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Number transformNumber(Number input) {
/* 617 */     if (input instanceof Float)
/* 618 */       return new Double(input.toString()); 
/* 619 */     if (input instanceof Short)
/* 620 */       return new Integer(input.intValue()); 
/* 621 */     if (input instanceof Byte)
/* 622 */       return new Integer(input.intValue()); 
/* 623 */     if (input instanceof Long) {
/* 624 */       Long max = new Long(2147483647L);
/* 625 */       if (input.longValue() <= max.longValue() && input.longValue() >= -2147483648L) {
/* 626 */         return new Integer(input.intValue());
/*     */       }
/*     */     } 
/*     */     
/* 630 */     return input;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String valueToString(Object value) {
/* 649 */     if (value == null || isNull(value)) {
/* 650 */       return "null";
/*     */     }
/* 652 */     if (value instanceof JSONFunction) {
/* 653 */       return ((JSONFunction)value).toString();
/*     */     }
/* 655 */     if (value instanceof JSONString) {
/*     */       Object o;
/*     */       try {
/* 658 */         o = ((JSONString)value).toJSONString();
/* 659 */       } catch (Exception e) {
/* 660 */         throw new JSONException(e);
/*     */       } 
/* 662 */       if (o instanceof String) {
/* 663 */         return (String)o;
/*     */       }
/* 665 */       throw new JSONException("Bad value from toJSONString: " + o);
/*     */     } 
/* 667 */     if (value instanceof Number) {
/* 668 */       return numberToString((Number)value);
/*     */     }
/* 670 */     if (value instanceof Boolean || value instanceof JSONObject || value instanceof JSONArray) {
/* 671 */       return value.toString();
/*     */     }
/* 673 */     return quote(value.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String valueToString(Object value, int indentFactor, int indent) {
/* 691 */     if (value == null || isNull(value)) {
/* 692 */       return "null";
/*     */     }
/* 694 */     if (value instanceof JSONFunction) {
/* 695 */       return ((JSONFunction)value).toString();
/*     */     }
/* 697 */     if (value instanceof JSONString) {
/* 698 */       return ((JSONString)value).toJSONString();
/*     */     }
/* 700 */     if (value instanceof Number) {
/* 701 */       return numberToString((Number)value);
/*     */     }
/* 703 */     if (value instanceof Boolean) {
/* 704 */       return value.toString();
/*     */     }
/* 706 */     if (value instanceof JSONObject) {
/* 707 */       return ((JSONObject)value).toString(indentFactor, indent);
/*     */     }
/* 709 */     if (value instanceof JSONArray) {
/* 710 */       return ((JSONArray)value).toString(indentFactor, indent);
/*     */     }
/* 712 */     return quote(value.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isBigDecimal(Number n) {
/* 722 */     if (n instanceof BigDecimal) {
/* 723 */       return true;
/*     */     }
/*     */     try {
/* 726 */       new BigDecimal(String.valueOf(n));
/* 727 */       return true;
/* 728 */     } catch (NumberFormatException e) {
/* 729 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isBigInteger(Number n) {
/* 740 */     if (n instanceof BigInteger) {
/* 741 */       return true;
/*     */     }
/*     */     try {
/* 744 */       new BigInteger(String.valueOf(n));
/* 745 */       return true;
/* 746 */     } catch (NumberFormatException e) {
/* 747 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isDouble(Number n) {
/* 758 */     if (n instanceof Double) {
/* 759 */       return true;
/*     */     }
/*     */     try {
/* 762 */       double d = Double.parseDouble(String.valueOf(n));
/* 763 */       return !Double.isInfinite(d);
/* 764 */     } catch (NumberFormatException e) {
/* 765 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isFloat(Number n) {
/* 776 */     if (n instanceof Float) {
/* 777 */       return true;
/*     */     }
/*     */     try {
/* 780 */       float f = Float.parseFloat(String.valueOf(n));
/* 781 */       return !Float.isInfinite(f);
/* 782 */     } catch (NumberFormatException e) {
/* 783 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isInteger(Number n) {
/* 794 */     if (n instanceof Integer) {
/* 795 */       return true;
/*     */     }
/*     */     try {
/* 798 */       Integer.parseInt(String.valueOf(n));
/* 799 */       return true;
/* 800 */     } catch (NumberFormatException e) {
/* 801 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isLong(Number n) {
/* 812 */     if (n instanceof Long) {
/* 813 */       return true;
/*     */     }
/*     */     try {
/* 816 */       Long.parseLong(String.valueOf(n));
/* 817 */       return true;
/* 818 */     } catch (NumberFormatException e) {
/* 819 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\JSONUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */