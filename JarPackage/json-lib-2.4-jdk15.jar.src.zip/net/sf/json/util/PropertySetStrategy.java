/*    */ package net.sf.json.util;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Map;
/*    */ import net.sf.json.JSONException;
/*    */ import net.sf.json.JsonConfig;
/*    */ import org.apache.commons.beanutils.PropertyUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PropertySetStrategy
/*    */ {
/* 35 */   public static final PropertySetStrategy DEFAULT = new DefaultPropertySetStrategy();
/*    */   
/*    */   public abstract void setProperty(Object paramObject1, String paramString, Object paramObject2) throws JSONException;
/*    */   
/*    */   public void setProperty(Object bean, String key, Object value, JsonConfig jsonConfig) throws JSONException {
/* 40 */     setProperty(bean, key, value);
/*    */   }
/*    */   
/*    */   private static final class DefaultPropertySetStrategy extends PropertySetStrategy {
/*    */     public void setProperty(Object bean, String key, Object value) throws JSONException {
/* 45 */       setProperty(bean, key, value, new JsonConfig());
/*    */     }
/*    */     private DefaultPropertySetStrategy() {}
/*    */     public void setProperty(Object bean, String key, Object value, JsonConfig jsonConfig) throws JSONException {
/* 49 */       if (bean instanceof Map) {
/* 50 */         ((Map)bean).put(key, value);
/*    */       }
/* 52 */       else if (!jsonConfig.isIgnorePublicFields()) {
/*    */         try {
/* 54 */           Field field = bean.getClass().getField(key);
/* 55 */           if (field != null) field.set(bean, value); 
/* 56 */         } catch (Exception e) {
/* 57 */           _setProperty(bean, key, value);
/*    */         } 
/*    */       } else {
/* 60 */         _setProperty(bean, key, value);
/*    */       } 
/*    */     }
/*    */ 
/*    */     
/*    */     private void _setProperty(Object bean, String key, Object value) {
/*    */       try {
/* 67 */         PropertyUtils.setSimpleProperty(bean, key, value);
/* 68 */       } catch (Exception e) {
/* 69 */         throw new JSONException(e);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\PropertySetStrategy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */