/*    */ package net.sf.json.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import net.sf.json.JSONObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NewBeanInstanceStrategy
/*    */ {
/* 34 */   public static final NewBeanInstanceStrategy DEFAULT = new DefaultNewBeanInstanceStrategy();
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract Object newInstance(Class paramClass, JSONObject paramJSONObject) throws InstantiationException, IllegalAccessException, SecurityException, NoSuchMethodException, InvocationTargetException;
/*    */ 
/*    */ 
/*    */   
/*    */   private static final class DefaultNewBeanInstanceStrategy
/*    */     extends NewBeanInstanceStrategy
/*    */   {
/*    */     private DefaultNewBeanInstanceStrategy() {}
/*    */ 
/*    */     
/* 48 */     private static final Object[] EMPTY_ARGS = new Object[0];
/* 49 */     private static final Class[] EMPTY_PARAM_TYPES = new Class[0];
/*    */ 
/*    */ 
/*    */     
/*    */     public Object newInstance(Class target, JSONObject source) throws InstantiationException, IllegalAccessException, SecurityException, NoSuchMethodException, InvocationTargetException {
/* 54 */       if (target != null) {
/* 55 */         Constructor c = target.getDeclaredConstructor(EMPTY_PARAM_TYPES);
/* 56 */         c.setAccessible(true);
/*    */         try {
/* 58 */           return c.newInstance(EMPTY_ARGS);
/* 59 */         } catch (InstantiationException e) {
/*    */           
/* 61 */           String cause = ""; try {
/* 62 */             cause = (e.getCause() != null) ? ("\n" + e.getCause().getMessage()) : "";
/* 63 */           } catch (Throwable t) {}
/* 64 */           throw new InstantiationException("Instantiation of \"" + target + "\" failed. " + "It's probably because class is an interface, " + "abstract class, array class, primitive type or void." + cause);
/*    */         } 
/*    */       } 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 71 */       return null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\NewBeanInstanceStrategy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */