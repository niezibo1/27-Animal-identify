package net.sf.json.util;

import net.sf.json.JSONException;

public interface JsonEventListener {
  void onArrayEnd();
  
  void onArrayStart();
  
  void onElementAdded(int paramInt, Object paramObject);
  
  void onError(JSONException paramJSONException);
  
  void onObjectEnd();
  
  void onObjectStart();
  
  void onPropertySet(String paramString, Object paramObject, boolean paramBoolean);
  
  void onWarning(String paramString);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\JsonEventListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */