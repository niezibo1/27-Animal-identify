/*     */ package net.sf.json.util;
/*     */ 
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONException;
/*     */ import net.sf.json.JSONNull;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.JsonConfig;
/*     */ import net.sf.json.regexp.RegexpUtils;
/*     */ import org.apache.commons.lang.math.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONTokener
/*     */ {
/*     */   private int myIndex;
/*     */   private String mySource;
/*     */   
/*     */   public static int dehexchar(char c) {
/*  44 */     if (c >= '0' && c <= '9') {
/*  45 */       return c - 48;
/*     */     }
/*  47 */     if (c >= 'A' && c <= 'F') {
/*  48 */       return c - 55;
/*     */     }
/*  50 */     if (c >= 'a' && c <= 'f') {
/*  51 */       return c - 87;
/*     */     }
/*  53 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONTokener(String s) {
/*  72 */     this.myIndex = 0;
/*  73 */     if (s != null) {
/*  74 */       s = s.trim();
/*     */     } else {
/*  76 */       s = "";
/*     */     } 
/*  78 */     if (s.length() > 0) {
/*  79 */       char first = s.charAt(0);
/*  80 */       char last = s.charAt(s.length() - 1);
/*  81 */       if (first == '[' && last != ']') {
/*  82 */         throw syntaxError("Found starting '[' but missing ']' at the end.");
/*     */       }
/*  84 */       if (first == '{' && last != '}') {
/*  85 */         throw syntaxError("Found starting '{' but missing '}' at the end.");
/*     */       }
/*     */     } 
/*  88 */     this.mySource = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void back() {
/*  97 */     if (this.myIndex > 0) {
/*  98 */       this.myIndex--;
/*     */     }
/*     */   }
/*     */   
/*     */   public int length() {
/* 103 */     if (this.mySource == null) {
/* 104 */       return 0;
/*     */     }
/* 106 */     return this.mySource.length();
/*     */   }
/*     */   
/*     */   public boolean matches(String pattern) {
/* 110 */     String str = this.mySource.substring(this.myIndex);
/* 111 */     return RegexpUtils.getMatcher(pattern).matches(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean more() {
/* 122 */     return (this.myIndex < this.mySource.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char next() {
/* 131 */     if (more()) {
/* 132 */       char c = this.mySource.charAt(this.myIndex);
/* 133 */       this.myIndex++;
/* 134 */       return c;
/*     */     } 
/* 136 */     return Character.MIN_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char next(char c) {
/* 148 */     char n = next();
/* 149 */     if (n != c) {
/* 150 */       throw syntaxError("Expected '" + c + "' and instead saw '" + n + "'.");
/*     */     }
/* 152 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String next(int n) {
/* 164 */     int i = this.myIndex;
/* 165 */     int j = i + n;
/* 166 */     if (j >= this.mySource.length()) {
/* 167 */       throw syntaxError("Substring bounds error");
/*     */     }
/* 169 */     this.myIndex += n;
/* 170 */     return this.mySource.substring(i, j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char nextClean() {
/*     */     char c;
/*     */     label38: 
/* 182 */     do { c = next();
/* 183 */       if (c == '/') {
/* 184 */         switch (next()) {
/*     */           case '/':
/*     */             while (true) {
/* 187 */               c = next();
/* 188 */               if (c != '\n') { if (c != '\r') { if (c == '\000')
/*     */                     continue label38;  continue; }  continue label38; }  continue label38;
/*     */             } 
/*     */           case '*':
/* 192 */             while (true) { c = next();
/* 193 */               if (c == '\000') {
/* 194 */                 throw syntaxError("Unclosed comment.");
/*     */               }
/* 196 */               if (c == '*') {
/* 197 */                 if (next() == '/') {
/*     */                   continue label38;
/*     */                 }
/* 200 */                 back();
/*     */               }  }
/*     */           
/*     */         } 
/*     */         
/* 205 */         back();
/* 206 */         return '/';
/*     */       } 
/* 208 */       if (c != '#')
/*     */         continue;  while (true)
/* 210 */       { c = next();
/* 211 */         if (c != '\n') { if (c != '\r') { if (c == '\000')
/* 212 */               continue label38;  continue; }  continue label38; }  continue label38; }  } while (c != '\000' && c <= ' ');
/* 213 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextString(char quote) {
/* 230 */     StringBuffer sb = new StringBuffer();
/*     */     while (true) {
/* 232 */       char c = next();
/* 233 */       switch (c) {
/*     */         case '\000':
/*     */         case '\n':
/*     */         case '\r':
/* 237 */           throw syntaxError("Unterminated string");
/*     */         case '\\':
/* 239 */           c = next();
/* 240 */           switch (c) {
/*     */             case 'b':
/* 242 */               sb.append('\b');
/*     */               continue;
/*     */             case 't':
/* 245 */               sb.append('\t');
/*     */               continue;
/*     */             case 'n':
/* 248 */               sb.append('\n');
/*     */               continue;
/*     */             case 'f':
/* 251 */               sb.append('\f');
/*     */               continue;
/*     */             case 'r':
/* 254 */               sb.append('\r');
/*     */               continue;
/*     */             case 'u':
/* 257 */               sb.append((char)Integer.parseInt(next(4), 16));
/*     */               continue;
/*     */             case 'x':
/* 260 */               sb.append((char)Integer.parseInt(next(2), 16));
/*     */               continue;
/*     */           } 
/* 263 */           sb.append(c);
/*     */           continue;
/*     */       } 
/*     */       
/* 267 */       if (c == quote) {
/* 268 */         return sb.toString();
/*     */       }
/* 270 */       sb.append(c);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextTo(char d) {
/* 283 */     StringBuffer sb = new StringBuffer();
/*     */     while (true) {
/* 285 */       char c = next();
/* 286 */       if (c == d || c == '\000' || c == '\n' || c == '\r') {
/* 287 */         if (c != '\000') {
/* 288 */           back();
/*     */         }
/* 290 */         return sb.toString().trim();
/*     */       } 
/*     */       
/* 293 */       sb.append(c);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextTo(String delimiters) {
/* 306 */     StringBuffer sb = new StringBuffer();
/*     */     while (true) {
/* 308 */       char c = next();
/* 309 */       if (delimiters.indexOf(c) >= 0 || c == '\000' || c == '\n' || c == '\r') {
/* 310 */         if (c != '\000') {
/* 311 */           back();
/*     */         }
/* 313 */         return sb.toString().trim();
/*     */       } 
/*     */       
/* 316 */       sb.append(c);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object nextValue() {
/* 328 */     return nextValue(new JsonConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object nextValue(JsonConfig jsonConfig) {
/* 339 */     char c = nextClean();
/*     */ 
/*     */     
/* 342 */     switch (c) {
/*     */       case '"':
/*     */       case '\'':
/* 345 */         return nextString(c);
/*     */       case '{':
/* 347 */         back();
/* 348 */         return JSONObject.fromObject(this, jsonConfig);
/*     */       case '[':
/* 350 */         back();
/* 351 */         return JSONArray.fromObject(this, jsonConfig);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 363 */     StringBuffer sb = new StringBuffer();
/* 364 */     char b = c;
/* 365 */     while (c >= ' ' && ",:]}/\\\"[{;=#".indexOf(c) < 0) {
/* 366 */       sb.append(c);
/* 367 */       c = next();
/*     */     } 
/* 369 */     back();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 375 */     String s = sb.toString().trim();
/*     */     
/* 377 */     if (s.equals("")) {
/* 378 */       throw syntaxError("Missing value.");
/*     */     }
/* 380 */     if (s.equalsIgnoreCase("true")) {
/* 381 */       return Boolean.TRUE;
/*     */     }
/* 383 */     if (s.equalsIgnoreCase("false")) {
/* 384 */       return Boolean.FALSE;
/*     */     }
/* 386 */     if (s.equals("null") || (jsonConfig.isJavascriptCompliant() && s.equals("undefined")))
/*     */     {
/* 388 */       return JSONNull.getInstance();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 399 */     if ((b >= '0' && b <= '9') || b == '.' || b == '-' || b == '+') {
/* 400 */       if (b == '0') {
/* 401 */         if (s.length() > 2 && (s.charAt(1) == 'x' || s.charAt(1) == 'X')) {
/*     */           try {
/* 403 */             return new Integer(Integer.parseInt(s.substring(2), 16));
/* 404 */           } catch (Exception e) {}
/*     */         } else {
/*     */ 
/*     */           
/*     */           try {
/* 409 */             return new Integer(Integer.parseInt(s, 8));
/* 410 */           } catch (Exception e) {}
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 417 */         return NumberUtils.createNumber(s);
/* 418 */       } catch (Exception e) {
/* 419 */         return s;
/*     */       } 
/*     */     } 
/*     */     
/* 423 */     if (JSONUtils.isFunctionHeader(s) || JSONUtils.isFunction(s)) {
/* 424 */       return s;
/*     */     }
/* 426 */     switch (peek()) {
/*     */       case ',':
/*     */       case '[':
/*     */       case ']':
/*     */       case '{':
/*     */       case '}':
/* 432 */         throw new JSONException("Unquotted string '" + s + "'");
/*     */     } 
/*     */     
/* 435 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char peek() {
/* 444 */     if (more()) {
/* 445 */       char c = this.mySource.charAt(this.myIndex);
/* 446 */       return c;
/*     */     } 
/* 448 */     return Character.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 452 */     this.myIndex = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipPast(String to) {
/* 462 */     this.myIndex = this.mySource.indexOf(to, this.myIndex);
/* 463 */     if (this.myIndex < 0) {
/* 464 */       this.myIndex = this.mySource.length();
/*     */     } else {
/* 466 */       this.myIndex += to.length();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char skipTo(char to) {
/* 480 */     int index = this.myIndex;
/*     */     while (true) {
/* 482 */       char c = next();
/* 483 */       if (c == '\000') {
/* 484 */         this.myIndex = index;
/* 485 */         return c;
/*     */       } 
/* 487 */       if (c == to) {
/* 488 */         back();
/* 489 */         return c;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONException syntaxError(String message) {
/* 499 */     return new JSONException(message + toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 508 */     return " at character " + this.myIndex + " of " + this.mySource;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\JSONTokener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */