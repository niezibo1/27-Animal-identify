package net.sf.json.util;

public interface PropertyFilter {
  boolean apply(Object paramObject1, String paramString, Object paramObject2);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\PropertyFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */