/*     */ package net.sf.json.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import net.sf.json.JSONException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONBuilder
/*     */ {
/*     */   private static final int MAXDEPTH = 20;
/*     */   private boolean comma;
/*     */   protected char mode;
/*     */   private char[] stack;
/*     */   private int top;
/*     */   protected Writer writer;
/*     */   
/*     */   public JSONBuilder(Writer w) {
/*  94 */     this.comma = false;
/*  95 */     this.mode = 'i';
/*  96 */     this.stack = new char[20];
/*  97 */     this.top = 0;
/*  98 */     this.writer = w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JSONBuilder append(String s) {
/* 109 */     if (s == null) {
/* 110 */       throw new JSONException("Null pointer");
/*     */     }
/* 112 */     if (this.mode == 'o' || this.mode == 'a') {
/*     */       try {
/* 114 */         if (this.comma && this.mode == 'a') {
/* 115 */           this.writer.write(44);
/*     */         }
/* 117 */         this.writer.write(s);
/* 118 */       } catch (IOException e) {
/* 119 */         throw new JSONException(e);
/*     */       } 
/* 121 */       if (this.mode == 'o') {
/* 122 */         this.mode = 'k';
/*     */       }
/* 124 */       this.comma = true;
/* 125 */       return this;
/*     */     } 
/* 127 */     throw new JSONException("Value out of sequence.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder array() {
/* 141 */     if (this.mode == 'i' || this.mode == 'o' || this.mode == 'a') {
/* 142 */       push('a');
/* 143 */       append("[");
/* 144 */       this.comma = false;
/* 145 */       return this;
/*     */     } 
/* 147 */     throw new JSONException("Misplaced array.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JSONBuilder end(char m, char c) {
/* 159 */     if (this.mode != m) {
/* 160 */       throw new JSONException((m == 'o') ? "Misplaced endObject." : "Misplaced endArray.");
/*     */     }
/* 162 */     pop(m);
/*     */     try {
/* 164 */       this.writer.write(c);
/* 165 */     } catch (IOException e) {
/* 166 */       throw new JSONException(e);
/*     */     } 
/* 168 */     this.comma = true;
/* 169 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder endArray() {
/* 180 */     return end('a', ']');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder endObject() {
/* 191 */     return end('k', '}');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder key(String s) {
/* 204 */     if (s == null) {
/* 205 */       throw new JSONException("Null key.");
/*     */     }
/* 207 */     if (this.mode == 'k') {
/*     */       try {
/* 209 */         if (this.comma) {
/* 210 */           this.writer.write(44);
/*     */         }
/* 212 */         this.writer.write(JSONUtils.quote(s));
/* 213 */         this.writer.write(58);
/* 214 */         this.comma = false;
/* 215 */         this.mode = 'o';
/* 216 */         return this;
/* 217 */       } catch (IOException e) {
/* 218 */         throw new JSONException(e);
/*     */       } 
/*     */     }
/* 221 */     throw new JSONException("Misplaced key.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder object() {
/* 235 */     if (this.mode == 'i') {
/* 236 */       this.mode = 'o';
/*     */     }
/* 238 */     if (this.mode == 'o' || this.mode == 'a') {
/* 239 */       append("{");
/* 240 */       push('k');
/* 241 */       this.comma = false;
/* 242 */       return this;
/*     */     } 
/* 244 */     throw new JSONException("Misplaced object.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void pop(char c) {
/* 255 */     if (this.top <= 0 || this.stack[this.top - 1] != c) {
/* 256 */       throw new JSONException("Nesting error.");
/*     */     }
/* 258 */     this.top--;
/* 259 */     this.mode = (this.top == 0) ? 'd' : this.stack[this.top - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void push(char c) {
/* 269 */     if (this.top >= 20) {
/* 270 */       throw new JSONException("Nesting too deep.");
/*     */     }
/* 272 */     this.stack[this.top] = c;
/* 273 */     this.mode = c;
/* 274 */     this.top++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder value(boolean b) {
/* 286 */     return append(b ? "true" : "false");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder value(double d) {
/* 297 */     return value(new Double(d));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder value(long l) {
/* 308 */     return append(Long.toString(l));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONBuilder value(Object o) {
/* 321 */     return append(JSONUtils.valueToString(o));
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\JSONBuilder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */