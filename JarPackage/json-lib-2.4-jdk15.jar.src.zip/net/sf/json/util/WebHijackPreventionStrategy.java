/*    */ package net.sf.json.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WebHijackPreventionStrategy
/*    */ {
/* 31 */   public static final WebHijackPreventionStrategy COMMENTS = new CommentWebHijackPreventionStrategy();
/*    */   
/* 33 */   public static final WebHijackPreventionStrategy INFINITE_LOOP = new InfiniteLoopWebHijackPreventionStrategy();
/*    */ 
/*    */   
/*    */   public abstract String protect(String paramString);
/*    */ 
/*    */   
/*    */   private static final class CommentWebHijackPreventionStrategy
/*    */     extends WebHijackPreventionStrategy
/*    */   {
/*    */     private CommentWebHijackPreventionStrategy() {}
/*    */ 
/*    */     
/*    */     public String protect(String str) {
/* 46 */       return "/*" + str + "*/";
/*    */     } }
/*    */   
/*    */   private static final class InfiniteLoopWebHijackPreventionStrategy extends WebHijackPreventionStrategy {
/*    */     private InfiniteLoopWebHijackPreventionStrategy() {}
/*    */     
/*    */     public String protect(String str) {
/* 53 */       return "while(1);" + str;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\WebHijackPreventionStrategy.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */