/*     */ package net.sf.json.util;
/*     */ 
/*     */ import net.sf.json.JSONException;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaIdentifierTransformer
/*     */ {
/*  40 */   public static final JavaIdentifierTransformer CAMEL_CASE = new CamelCaseJavaIdentifierTransformer();
/*     */   
/*  42 */   public static final JavaIdentifierTransformer NOOP = new NoopJavaIdentifierTransformer();
/*     */   
/*  44 */   public static final JavaIdentifierTransformer STRICT = new StrictJavaIdentifierTransformer();
/*     */   
/*  46 */   public static final JavaIdentifierTransformer UNDERSCORE = new UnderscoreJavaIdentifierTransformer();
/*     */   
/*  48 */   public static final JavaIdentifierTransformer WHITESPACE = new WhiteSpaceJavaIdentifierTransformer();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String transformToJavaIdentifier(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String shaveOffNonJavaIdentifierStartChars(String str) {
/*  58 */     String str2 = str;
/*     */     
/*  60 */     boolean ready = false;
/*  61 */     while (!ready) {
/*  62 */       if (!Character.isJavaIdentifierStart(str2.charAt(0))) {
/*  63 */         str2 = str2.substring(1);
/*  64 */         if (str2.length() == 0)
/*  65 */           throw new JSONException("Can't convert '" + str + "' to a valid Java identifier"); 
/*     */         continue;
/*     */       } 
/*  68 */       ready = true;
/*     */     } 
/*     */     
/*  71 */     return str2;
/*     */   }
/*     */   private static final class CamelCaseJavaIdentifierTransformer extends JavaIdentifierTransformer { private CamelCaseJavaIdentifierTransformer() {}
/*     */     
/*     */     public String transformToJavaIdentifier(String str) {
/*  76 */       if (str == null) {
/*  77 */         return null;
/*     */       }
/*     */       
/*  80 */       String str2 = shaveOffNonJavaIdentifierStartChars(str);
/*     */       
/*  82 */       char[] chars = str2.toCharArray();
/*  83 */       int pos = 0;
/*  84 */       StringBuffer buf = new StringBuffer();
/*  85 */       boolean toUpperCaseNextChar = false;
/*  86 */       while (pos < chars.length) {
/*  87 */         if (!Character.isJavaIdentifierPart(chars[pos]) || Character.isWhitespace(chars[pos])) {
/*     */           
/*  89 */           toUpperCaseNextChar = true;
/*     */         }
/*  91 */         else if (toUpperCaseNextChar) {
/*  92 */           buf.append(Character.toUpperCase(chars[pos]));
/*  93 */           toUpperCaseNextChar = false;
/*     */         } else {
/*  95 */           buf.append(chars[pos]);
/*     */         } 
/*     */         
/*  98 */         pos++;
/*     */       } 
/* 100 */       return buf.toString();
/*     */     } }
/*     */   
/*     */   private static final class NoopJavaIdentifierTransformer extends JavaIdentifierTransformer { private NoopJavaIdentifierTransformer() {}
/*     */     
/*     */     public String transformToJavaIdentifier(String str) {
/* 106 */       return str;
/*     */     } }
/*     */   
/*     */   private static final class StrictJavaIdentifierTransformer extends JavaIdentifierTransformer { private StrictJavaIdentifierTransformer() {}
/*     */     
/*     */     public String transformToJavaIdentifier(String str) {
/* 112 */       throw new JSONException("'" + str + "' is not a valid Java identifier.");
/*     */     } }
/*     */ 
/*     */   
/*     */   private static final class UnderscoreJavaIdentifierTransformer extends JavaIdentifierTransformer { public String transformToJavaIdentifier(String str) {
/* 117 */       if (str == null) {
/* 118 */         return null;
/*     */       }
/* 120 */       String str2 = shaveOffNonJavaIdentifierStartChars(str);
/*     */       
/* 122 */       char[] chars = str2.toCharArray();
/* 123 */       int pos = 0;
/* 124 */       StringBuffer buf = new StringBuffer();
/* 125 */       boolean toUnderScorePreviousChar = false;
/* 126 */       while (pos < chars.length) {
/* 127 */         if (!Character.isJavaIdentifierPart(chars[pos]) || Character.isWhitespace(chars[pos])) {
/*     */           
/* 129 */           toUnderScorePreviousChar = true;
/*     */         } else {
/* 131 */           if (toUnderScorePreviousChar) {
/* 132 */             buf.append("_");
/* 133 */             toUnderScorePreviousChar = false;
/*     */           } 
/* 135 */           buf.append(chars[pos]);
/*     */         } 
/* 137 */         pos++;
/*     */       } 
/* 139 */       if (buf.charAt(buf.length() - 1) == '_') {
/* 140 */         buf.deleteCharAt(buf.length() - 1);
/*     */       }
/* 142 */       return buf.toString();
/*     */     }
/*     */     private UnderscoreJavaIdentifierTransformer() {} }
/*     */   private static final class WhiteSpaceJavaIdentifierTransformer extends JavaIdentifierTransformer { private WhiteSpaceJavaIdentifierTransformer() {}
/*     */     public String transformToJavaIdentifier(String str) {
/* 147 */       if (str == null) {
/* 148 */         return null;
/*     */       }
/* 150 */       String str2 = shaveOffNonJavaIdentifierStartChars(str);
/* 151 */       str2 = StringUtils.deleteWhitespace(str2);
/* 152 */       char[] chars = str2.toCharArray();
/* 153 */       int pos = 0;
/* 154 */       StringBuffer buf = new StringBuffer();
/* 155 */       while (pos < chars.length) {
/* 156 */         if (Character.isJavaIdentifierPart(chars[pos])) {
/* 157 */           buf.append(chars[pos]);
/*     */         }
/* 159 */         pos++;
/*     */       } 
/* 161 */       return buf.toString();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\jso\\util\JavaIdentifierTransformer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */