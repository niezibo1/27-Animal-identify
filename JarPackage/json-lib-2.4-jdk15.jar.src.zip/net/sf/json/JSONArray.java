/*      */ package net.sf.json;
/*      */ 
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import net.sf.ezmorph.Morpher;
/*      */ import net.sf.ezmorph.object.IdentityObjectMorpher;
/*      */ import net.sf.json.processors.JsonValueProcessor;
/*      */ import net.sf.json.processors.JsonVerifier;
/*      */ import net.sf.json.util.JSONTokener;
/*      */ import net.sf.json.util.JSONUtils;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class JSONArray
/*      */   extends AbstractJSON
/*      */   implements JSON, List, Comparable
/*      */ {
/*      */   private List elements;
/*      */   private boolean expandElements;
/*      */   
/*      */   public static JSONArray fromObject(Object object) {
/*  105 */     return fromObject(object, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JSONArray fromObject(Object object, JsonConfig jsonConfig) {
/*  118 */     if (object instanceof JSONString)
/*  119 */       return _fromJSONString((JSONString)object, jsonConfig); 
/*  120 */     if (object instanceof JSONArray)
/*  121 */       return _fromJSONArray((JSONArray)object, jsonConfig); 
/*  122 */     if (object instanceof Collection)
/*  123 */       return _fromCollection((Collection)object, jsonConfig); 
/*  124 */     if (object instanceof JSONTokener)
/*  125 */       return _fromJSONTokener((JSONTokener)object, jsonConfig); 
/*  126 */     if (object instanceof String)
/*  127 */       return _fromString((String)object, jsonConfig); 
/*  128 */     if (object != null && object.getClass().isArray()) {
/*      */       
/*  130 */       Class<?> type = object.getClass().getComponentType();
/*      */       
/*  132 */       if (!type.isPrimitive()) {
/*  133 */         return _fromArray((Object[])object, jsonConfig);
/*      */       }
/*  135 */       if (type == boolean.class)
/*  136 */         return _fromArray((boolean[])object, jsonConfig); 
/*  137 */       if (type == byte.class)
/*  138 */         return _fromArray((byte[])object, jsonConfig); 
/*  139 */       if (type == short.class)
/*  140 */         return _fromArray((short[])object, jsonConfig); 
/*  141 */       if (type == int.class)
/*  142 */         return _fromArray((int[])object, jsonConfig); 
/*  143 */       if (type == long.class)
/*  144 */         return _fromArray((long[])object, jsonConfig); 
/*  145 */       if (type == float.class)
/*  146 */         return _fromArray((float[])object, jsonConfig); 
/*  147 */       if (type == double.class)
/*  148 */         return _fromArray((double[])object, jsonConfig); 
/*  149 */       if (type == char.class) {
/*  150 */         return _fromArray((char[])object, jsonConfig);
/*      */       }
/*  152 */       throw new JSONException("Unsupported type");
/*      */     } 
/*      */     
/*  155 */     if (JSONUtils.isBoolean(object) || JSONUtils.isFunction(object) || JSONUtils.isNumber(object) || JSONUtils.isNull(object) || JSONUtils.isString(object) || object instanceof JSON) {
/*      */ 
/*      */       
/*  158 */       fireArrayStartEvent(jsonConfig);
/*  159 */       JSONArray jsonArray = (new JSONArray()).element(object, jsonConfig);
/*  160 */       fireElementAddedEvent(0, jsonArray.get(0), jsonConfig);
/*  161 */       fireArrayStartEvent(jsonConfig);
/*  162 */       return jsonArray;
/*  163 */     }  if (object instanceof Enum)
/*  164 */       return _fromArray((Enum)object, jsonConfig); 
/*  165 */     if (object instanceof java.lang.annotation.Annotation || (object != null && object.getClass().isAnnotation()))
/*      */     {
/*  167 */       throw new JSONException("Unsupported type"); } 
/*  168 */     if (JSONUtils.isObject(object)) {
/*  169 */       fireArrayStartEvent(jsonConfig);
/*  170 */       JSONArray jsonArray = (new JSONArray()).element(JSONObject.fromObject(object, jsonConfig));
/*  171 */       fireElementAddedEvent(0, jsonArray.get(0), jsonConfig);
/*  172 */       fireArrayStartEvent(jsonConfig);
/*  173 */       return jsonArray;
/*      */     } 
/*  175 */     throw new JSONException("Unsupported type");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class[] getCollectionType(PropertyDescriptor pd, boolean useGetter) throws JSONException {
/*      */     Type type;
/*  188 */     if (useGetter) {
/*  189 */       Method m = pd.getReadMethod();
/*  190 */       type = m.getGenericReturnType();
/*      */     } else {
/*  192 */       Method m = pd.getWriteMethod();
/*  193 */       Type[] gpts = m.getGenericParameterTypes();
/*      */       
/*  195 */       if (1 != gpts.length) {
/*  196 */         throw new JSONException("method " + m + " is not a standard setter");
/*      */       }
/*  198 */       type = gpts[0];
/*      */     } 
/*      */     
/*  201 */     if (!(type instanceof ParameterizedType)) {
/*  202 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  207 */     ParameterizedType pType = (ParameterizedType)type;
/*  208 */     Type[] actualTypes = pType.getActualTypeArguments();
/*      */     
/*  210 */     Class[] ret = new Class[actualTypes.length];
/*  211 */     for (int i = 0; i < ret.length; i++) {
/*  212 */       ret[i] = (Class)actualTypes[i];
/*      */     }
/*      */     
/*  215 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] getDimensions(JSONArray jsonArray) {
/*  223 */     if (jsonArray == null || jsonArray.isEmpty()) {
/*  224 */       return new int[] { 0 };
/*      */     }
/*      */     
/*  227 */     List dims = new ArrayList();
/*  228 */     processArrayDimensions(jsonArray, dims, 0);
/*  229 */     int[] dimensions = new int[dims.size()];
/*  230 */     int j = 0;
/*  231 */     for (Iterator i = dims.iterator(); i.hasNext();) {
/*  232 */       dimensions[j++] = ((Integer)i.next()).intValue();
/*      */     }
/*  234 */     return dimensions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toArray(JSONArray jsonArray) {
/*  241 */     return toArray(jsonArray, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toArray(JSONArray jsonArray, Class objectClass) {
/*  248 */     JsonConfig jsonConfig = new JsonConfig();
/*  249 */     jsonConfig.setRootClass(objectClass);
/*  250 */     return toArray(jsonArray, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toArray(JSONArray jsonArray, Class objectClass, Map classMap) {
/*  265 */     JsonConfig jsonConfig = new JsonConfig();
/*  266 */     jsonConfig.setRootClass(objectClass);
/*  267 */     jsonConfig.setClassMap(classMap);
/*  268 */     return toArray(jsonArray, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toArray(JSONArray jsonArray, JsonConfig jsonConfig) {
/*  275 */     Class<?> objectClass = jsonConfig.getRootClass();
/*  276 */     Map classMap = jsonConfig.getClassMap();
/*      */     
/*  278 */     if (jsonArray.size() == 0) {
/*  279 */       return Array.newInstance((objectClass == null) ? Object.class : objectClass, 0);
/*      */     }
/*      */     
/*  282 */     int[] dimensions = getDimensions(jsonArray);
/*  283 */     Object array = Array.newInstance((objectClass == null) ? Object.class : objectClass, dimensions);
/*      */     
/*  285 */     int size = jsonArray.size();
/*  286 */     for (int i = 0; i < size; i++) {
/*  287 */       Object value = jsonArray.get(i);
/*  288 */       if (JSONUtils.isNull(value)) {
/*  289 */         Array.set(array, i, null);
/*      */       } else {
/*  291 */         Class<?> type = value.getClass();
/*  292 */         if (JSONArray.class.isAssignableFrom(type)) {
/*  293 */           Array.set(array, i, toArray((JSONArray)value, objectClass, classMap));
/*  294 */         } else if (String.class.isAssignableFrom(type) || Boolean.class.isAssignableFrom(type) || Character.class.isAssignableFrom(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */ 
/*      */           
/*  298 */           if (objectClass != null && !objectClass.isAssignableFrom(type)) {
/*  299 */             value = JSONUtils.getMorpherRegistry().morph(objectClass, value);
/*      */           }
/*      */           
/*  302 */           Array.set(array, i, value);
/*  303 */         } else if (JSONUtils.isNumber(type)) {
/*  304 */           if (objectClass != null && (Byte.class.isAssignableFrom(objectClass) || byte.class.isAssignableFrom(objectClass))) {
/*      */             
/*  306 */             Array.set(array, i, Byte.valueOf(String.valueOf(value)));
/*  307 */           } else if (objectClass != null && (Short.class.isAssignableFrom(objectClass) || short.class.isAssignableFrom(objectClass))) {
/*      */             
/*  309 */             Array.set(array, i, Short.valueOf(String.valueOf(value)));
/*      */           } else {
/*  311 */             Array.set(array, i, value);
/*      */           }
/*      */         
/*  314 */         } else if (objectClass != null) {
/*  315 */           JsonConfig jsc = jsonConfig.copy();
/*  316 */           jsc.setRootClass(objectClass);
/*  317 */           jsc.setClassMap(classMap);
/*  318 */           Array.set(array, i, JSONObject.toBean((JSONObject)value, jsc));
/*      */         } else {
/*  320 */           Array.set(array, i, JSONObject.toBean((JSONObject)value));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  325 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toArray(JSONArray jsonArray, Object root, JsonConfig jsonConfig) {
/*  332 */     Class<?> objectClass = root.getClass();
/*  333 */     if (jsonArray.size() == 0) {
/*  334 */       return Array.newInstance(objectClass, 0);
/*      */     }
/*      */     
/*  337 */     int[] dimensions = getDimensions(jsonArray);
/*  338 */     Object array = Array.newInstance((objectClass == null) ? Object.class : objectClass, dimensions);
/*      */     
/*  340 */     int size = jsonArray.size();
/*  341 */     for (int i = 0; i < size; i++) {
/*  342 */       Object value = jsonArray.get(i);
/*  343 */       if (JSONUtils.isNull(value)) {
/*  344 */         Array.set(array, i, null);
/*      */       } else {
/*  346 */         Class<?> type = value.getClass();
/*  347 */         if (JSONArray.class.isAssignableFrom(type)) {
/*  348 */           Array.set(array, i, toArray((JSONArray)value, root, jsonConfig));
/*  349 */         } else if (String.class.isAssignableFrom(type) || Boolean.class.isAssignableFrom(type) || JSONUtils.isNumber(type) || Character.class.isAssignableFrom(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */ 
/*      */           
/*  353 */           if (objectClass != null && !objectClass.isAssignableFrom(type)) {
/*  354 */             value = JSONUtils.getMorpherRegistry().morph(objectClass, value);
/*      */           }
/*      */           
/*  357 */           Array.set(array, i, value);
/*      */         } else {
/*      */           try {
/*  360 */             Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(root.getClass(), null);
/*      */             
/*  362 */             Array.set(array, i, JSONObject.toBean((JSONObject)value, newRoot, jsonConfig));
/*  363 */           } catch (JSONException jsone) {
/*  364 */             throw jsone;
/*  365 */           } catch (Exception e) {
/*  366 */             throw new JSONException(e);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  371 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection toCollection(JSONArray jsonArray) {
/*  378 */     return toCollection(jsonArray, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection toCollection(JSONArray jsonArray, Class objectClass) {
/*  385 */     JsonConfig jsonConfig = new JsonConfig();
/*  386 */     jsonConfig.setRootClass(objectClass);
/*  387 */     return toCollection(jsonArray, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Collection toCollection(JSONArray jsonArray, JsonConfig jsonConfig) {
/*  395 */     Collection<Collection> collection = null;
/*  396 */     Class<Collection> collectionType = jsonConfig.getCollectionType();
/*      */     
/*  398 */     if (collectionType.isInterface()) {
/*  399 */       if (collectionType.equals(List.class)) {
/*  400 */         collection = new ArrayList();
/*  401 */       } else if (collectionType.equals(Set.class)) {
/*  402 */         collection = new HashSet();
/*      */       } else {
/*  404 */         throw new JSONException("unknown interface: " + collectionType);
/*      */       } 
/*      */     } else {
/*      */       try {
/*  408 */         collection = collectionType.newInstance();
/*  409 */       } catch (InstantiationException e) {
/*  410 */         throw new JSONException(e);
/*  411 */       } catch (IllegalAccessException e) {
/*  412 */         throw new JSONException(e);
/*      */       } 
/*      */     } 
/*      */     
/*  416 */     Class objectClass = jsonConfig.getRootClass();
/*  417 */     Map classMap = jsonConfig.getClassMap();
/*      */     
/*  419 */     int size = jsonArray.size();
/*  420 */     for (int i = 0; i < size; i++) {
/*  421 */       Object value = jsonArray.get(i);
/*      */       
/*  423 */       if (JSONUtils.isNull(value)) {
/*  424 */         collection.add(null);
/*      */       } else {
/*  426 */         Class<?> type = value.getClass();
/*  427 */         if (JSONArray.class.isAssignableFrom(value.getClass())) {
/*  428 */           collection.add(toCollection((JSONArray)value, jsonConfig));
/*  429 */         } else if (String.class.isAssignableFrom(type) || Boolean.class.isAssignableFrom(type) || JSONUtils.isNumber(type) || Character.class.isAssignableFrom(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  434 */           if (objectClass != null && !objectClass.isAssignableFrom(type)) {
/*  435 */             value = JSONUtils.getMorpherRegistry().morph(objectClass, value);
/*      */           }
/*      */           
/*  438 */           collection.add(value);
/*      */         }
/*  440 */         else if (objectClass != null) {
/*  441 */           JsonConfig jsc = jsonConfig.copy();
/*  442 */           jsc.setRootClass(objectClass);
/*  443 */           jsc.setClassMap(classMap);
/*  444 */           collection.add(JSONObject.toBean((JSONObject)value, jsc));
/*      */         } else {
/*  446 */           collection.add(JSONObject.toBean((JSONObject)value));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  452 */     return collection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List toList(JSONArray jsonArray) {
/*  544 */     return toList(jsonArray, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List toList(JSONArray jsonArray, Class objectClass) {
/*  554 */     JsonConfig jsonConfig = new JsonConfig();
/*  555 */     jsonConfig.setRootClass(objectClass);
/*  556 */     return toList(jsonArray, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List toList(JSONArray jsonArray, Class objectClass, Map classMap) {
/*  574 */     JsonConfig jsonConfig = new JsonConfig();
/*  575 */     jsonConfig.setRootClass(objectClass);
/*  576 */     jsonConfig.setClassMap(classMap);
/*  577 */     return toList(jsonArray, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List toList(JSONArray jsonArray, JsonConfig jsonConfig) {
/*  587 */     if (jsonArray.size() == 0) {
/*  588 */       return new ArrayList();
/*      */     }
/*      */     
/*  591 */     Class objectClass = jsonConfig.getRootClass();
/*  592 */     Map classMap = jsonConfig.getClassMap();
/*      */     
/*  594 */     List<List> list = new ArrayList();
/*  595 */     int size = jsonArray.size();
/*  596 */     for (int i = 0; i < size; i++) {
/*  597 */       Object value = jsonArray.get(i);
/*  598 */       if (JSONUtils.isNull(value)) {
/*  599 */         list.add(null);
/*      */       } else {
/*  601 */         Class<?> type = value.getClass();
/*  602 */         if (JSONArray.class.isAssignableFrom(type)) {
/*  603 */           list.add(toList((JSONArray)value, objectClass, classMap));
/*  604 */         } else if (String.class.isAssignableFrom(type) || Boolean.class.isAssignableFrom(type) || JSONUtils.isNumber(type) || Character.class.isAssignableFrom(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */ 
/*      */           
/*  608 */           if (objectClass != null && !objectClass.isAssignableFrom(type)) {
/*  609 */             value = JSONUtils.getMorpherRegistry().morph(objectClass, value);
/*      */           }
/*      */           
/*  612 */           list.add(value);
/*      */         }
/*  614 */         else if (objectClass != null) {
/*  615 */           JsonConfig jsc = jsonConfig.copy();
/*  616 */           jsc.setRootClass(objectClass);
/*  617 */           jsc.setClassMap(classMap);
/*  618 */           list.add(JSONObject.toBean((JSONObject)value, jsc));
/*      */         } else {
/*  620 */           list.add(JSONObject.toBean((JSONObject)value));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  625 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List toList(JSONArray jsonArray, Object root, JsonConfig jsonConfig) {
/*  632 */     if (jsonArray.size() == 0 || root == null) {
/*  633 */       return new ArrayList();
/*      */     }
/*      */     
/*  636 */     List<List> list = new ArrayList();
/*  637 */     int size = jsonArray.size();
/*  638 */     for (int i = 0; i < size; i++) {
/*  639 */       Object value = jsonArray.get(i);
/*  640 */       if (JSONUtils.isNull(value)) {
/*  641 */         list.add(null);
/*      */       } else {
/*  643 */         Class<?> type = value.getClass();
/*  644 */         if (JSONArray.class.isAssignableFrom(type)) {
/*  645 */           list.add(toList((JSONArray)value, root, jsonConfig));
/*  646 */         } else if (String.class.isAssignableFrom(type) || Boolean.class.isAssignableFrom(type) || JSONUtils.isNumber(type) || Character.class.isAssignableFrom(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */ 
/*      */           
/*  650 */           list.add(value);
/*      */         } else {
/*      */           try {
/*  653 */             Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(root.getClass(), null);
/*      */             
/*  655 */             list.add(JSONObject.toBean((JSONObject)value, newRoot, jsonConfig));
/*  656 */           } catch (JSONException jsone) {
/*  657 */             throw jsone;
/*  658 */           } catch (Exception e) {
/*  659 */             throw new JSONException(e);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  664 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(boolean[] array, JsonConfig jsonConfig) {
/*  673 */     if (!addInstance(array)) {
/*      */       try {
/*  675 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/*  677 */       catch (JSONException jsone) {
/*  678 */         removeInstance(array);
/*  679 */         fireErrorEvent(jsone, jsonConfig);
/*  680 */         throw jsone;
/*  681 */       } catch (RuntimeException e) {
/*  682 */         removeInstance(array);
/*  683 */         JSONException jsone = new JSONException(e);
/*  684 */         fireErrorEvent(jsone, jsonConfig);
/*  685 */         throw jsone;
/*      */       } 
/*      */     }
/*  688 */     fireArrayStartEvent(jsonConfig);
/*  689 */     JSONArray jsonArray = new JSONArray();
/*  690 */     for (int i = 0; i < array.length; i++) {
/*  691 */       Boolean b = array[i] ? Boolean.TRUE : Boolean.FALSE;
/*  692 */       jsonArray.addValue(b, jsonConfig);
/*  693 */       fireElementAddedEvent(i, b, jsonConfig);
/*      */     } 
/*      */     
/*  696 */     removeInstance(array);
/*  697 */     fireArrayEndEvent(jsonConfig);
/*  698 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(byte[] array, JsonConfig jsonConfig) {
/*  707 */     if (!addInstance(array)) {
/*      */       try {
/*  709 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/*  711 */       catch (JSONException jsone) {
/*  712 */         removeInstance(array);
/*  713 */         fireErrorEvent(jsone, jsonConfig);
/*  714 */         throw jsone;
/*  715 */       } catch (RuntimeException e) {
/*  716 */         removeInstance(array);
/*  717 */         JSONException jsone = new JSONException(e);
/*  718 */         fireErrorEvent(jsone, jsonConfig);
/*  719 */         throw jsone;
/*      */       } 
/*      */     }
/*  722 */     fireArrayStartEvent(jsonConfig);
/*  723 */     JSONArray jsonArray = new JSONArray();
/*  724 */     for (int i = 0; i < array.length; i++) {
/*  725 */       Number n = JSONUtils.transformNumber(new Byte(array[i]));
/*  726 */       jsonArray.addValue(n, jsonConfig);
/*  727 */       fireElementAddedEvent(i, n, jsonConfig);
/*      */     } 
/*      */     
/*  730 */     removeInstance(array);
/*  731 */     fireArrayEndEvent(jsonConfig);
/*  732 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(char[] array, JsonConfig jsonConfig) {
/*  741 */     if (!addInstance(array)) {
/*      */       try {
/*  743 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/*  745 */       catch (JSONException jsone) {
/*  746 */         removeInstance(array);
/*  747 */         fireErrorEvent(jsone, jsonConfig);
/*  748 */         throw jsone;
/*  749 */       } catch (RuntimeException e) {
/*  750 */         removeInstance(array);
/*  751 */         JSONException jsone = new JSONException(e);
/*  752 */         fireErrorEvent(jsone, jsonConfig);
/*  753 */         throw jsone;
/*      */       } 
/*      */     }
/*  756 */     fireArrayStartEvent(jsonConfig);
/*  757 */     JSONArray jsonArray = new JSONArray();
/*  758 */     for (int i = 0; i < array.length; i++) {
/*  759 */       Character c = new Character(array[i]);
/*  760 */       jsonArray.addValue(c, jsonConfig);
/*  761 */       fireElementAddedEvent(i, c, jsonConfig);
/*      */     } 
/*      */     
/*  764 */     removeInstance(array);
/*  765 */     fireArrayEndEvent(jsonConfig);
/*  766 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(double[] array, JsonConfig jsonConfig) {
/*  775 */     if (!addInstance(array)) {
/*      */       try {
/*  777 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/*  779 */       catch (JSONException jsone) {
/*  780 */         removeInstance(array);
/*  781 */         fireErrorEvent(jsone, jsonConfig);
/*  782 */         throw jsone;
/*  783 */       } catch (RuntimeException e) {
/*  784 */         removeInstance(array);
/*  785 */         JSONException jsone = new JSONException(e);
/*  786 */         fireErrorEvent(jsone, jsonConfig);
/*  787 */         throw jsone;
/*      */       } 
/*      */     }
/*  790 */     fireArrayStartEvent(jsonConfig);
/*  791 */     JSONArray jsonArray = new JSONArray();
/*      */     try {
/*  793 */       for (int i = 0; i < array.length; i++) {
/*  794 */         Double d = new Double(array[i]);
/*  795 */         JSONUtils.testValidity(d);
/*  796 */         jsonArray.addValue(d, jsonConfig);
/*  797 */         fireElementAddedEvent(i, d, jsonConfig);
/*      */       } 
/*  799 */     } catch (JSONException jsone) {
/*  800 */       removeInstance(array);
/*  801 */       fireErrorEvent(jsone, jsonConfig);
/*  802 */       throw jsone;
/*      */     } 
/*      */     
/*  805 */     removeInstance(array);
/*  806 */     fireArrayEndEvent(jsonConfig);
/*  807 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(Enum e, JsonConfig jsonConfig) {
/*  817 */     if (!addInstance(e)) {
/*      */       try {
/*  819 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(e);
/*      */       }
/*  821 */       catch (JSONException jsone) {
/*  822 */         removeInstance(e);
/*  823 */         fireErrorEvent(jsone, jsonConfig);
/*  824 */         throw jsone;
/*  825 */       } catch (RuntimeException re) {
/*  826 */         removeInstance(e);
/*  827 */         JSONException jsone = new JSONException(re);
/*  828 */         fireErrorEvent(jsone, jsonConfig);
/*  829 */         throw jsone;
/*      */       } 
/*      */     }
/*  832 */     fireArrayStartEvent(jsonConfig);
/*  833 */     JSONArray jsonArray = new JSONArray();
/*  834 */     if (e != null) {
/*  835 */       jsonArray.addValue(e, jsonConfig);
/*  836 */       fireElementAddedEvent(0, jsonArray.get(0), jsonConfig);
/*      */     } else {
/*  838 */       JSONException jsone = new JSONException("enum value is null");
/*  839 */       removeInstance(e);
/*  840 */       fireErrorEvent(jsone, jsonConfig);
/*  841 */       throw jsone;
/*      */     } 
/*      */     
/*  844 */     removeInstance(e);
/*  845 */     fireArrayEndEvent(jsonConfig);
/*  846 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(float[] array, JsonConfig jsonConfig) {
/*  855 */     if (!addInstance(array)) {
/*      */       try {
/*  857 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/*  859 */       catch (JSONException jsone) {
/*  860 */         removeInstance(array);
/*  861 */         fireErrorEvent(jsone, jsonConfig);
/*  862 */         throw jsone;
/*  863 */       } catch (RuntimeException e) {
/*  864 */         removeInstance(array);
/*  865 */         JSONException jsone = new JSONException(e);
/*  866 */         fireErrorEvent(jsone, jsonConfig);
/*  867 */         throw jsone;
/*      */       } 
/*      */     }
/*  870 */     fireArrayStartEvent(jsonConfig);
/*  871 */     JSONArray jsonArray = new JSONArray();
/*      */     try {
/*  873 */       for (int i = 0; i < array.length; i++) {
/*  874 */         Float f = new Float(array[i]);
/*  875 */         JSONUtils.testValidity(f);
/*  876 */         jsonArray.addValue(f, jsonConfig);
/*  877 */         fireElementAddedEvent(i, f, jsonConfig);
/*      */       } 
/*  879 */     } catch (JSONException jsone) {
/*  880 */       removeInstance(array);
/*  881 */       fireErrorEvent(jsone, jsonConfig);
/*  882 */       throw jsone;
/*      */     } 
/*      */     
/*  885 */     removeInstance(array);
/*  886 */     fireArrayEndEvent(jsonConfig);
/*  887 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(int[] array, JsonConfig jsonConfig) {
/*  896 */     if (!addInstance(array)) {
/*      */       try {
/*  898 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/*  900 */       catch (JSONException jsone) {
/*  901 */         removeInstance(array);
/*  902 */         fireErrorEvent(jsone, jsonConfig);
/*  903 */         throw jsone;
/*  904 */       } catch (RuntimeException e) {
/*  905 */         removeInstance(array);
/*  906 */         JSONException jsone = new JSONException(e);
/*  907 */         fireErrorEvent(jsone, jsonConfig);
/*  908 */         throw jsone;
/*      */       } 
/*      */     }
/*  911 */     fireArrayStartEvent(jsonConfig);
/*  912 */     JSONArray jsonArray = new JSONArray();
/*  913 */     for (int i = 0; i < array.length; i++) {
/*  914 */       Number n = new Integer(array[i]);
/*  915 */       jsonArray.addValue(n, jsonConfig);
/*  916 */       fireElementAddedEvent(i, n, jsonConfig);
/*      */     } 
/*      */     
/*  919 */     removeInstance(array);
/*  920 */     fireArrayEndEvent(jsonConfig);
/*  921 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(long[] array, JsonConfig jsonConfig) {
/*  930 */     if (!addInstance(array)) {
/*      */       try {
/*  932 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/*  934 */       catch (JSONException jsone) {
/*  935 */         removeInstance(array);
/*  936 */         fireErrorEvent(jsone, jsonConfig);
/*  937 */         throw jsone;
/*  938 */       } catch (RuntimeException e) {
/*  939 */         removeInstance(array);
/*  940 */         JSONException jsone = new JSONException(e);
/*  941 */         fireErrorEvent(jsone, jsonConfig);
/*  942 */         throw jsone;
/*      */       } 
/*      */     }
/*  945 */     fireArrayStartEvent(jsonConfig);
/*  946 */     JSONArray jsonArray = new JSONArray();
/*  947 */     for (int i = 0; i < array.length; i++) {
/*  948 */       Number n = JSONUtils.transformNumber(new Long(array[i]));
/*  949 */       jsonArray.addValue(n, jsonConfig);
/*  950 */       fireElementAddedEvent(i, n, jsonConfig);
/*      */     } 
/*      */     
/*  953 */     removeInstance(array);
/*  954 */     fireArrayEndEvent(jsonConfig);
/*  955 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(Object[] array, JsonConfig jsonConfig) {
/*  961 */     if (!addInstance(array)) {
/*      */       try {
/*  963 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/*  965 */       catch (JSONException jsone) {
/*  966 */         removeInstance(array);
/*  967 */         fireErrorEvent(jsone, jsonConfig);
/*  968 */         throw jsone;
/*  969 */       } catch (RuntimeException e) {
/*  970 */         removeInstance(array);
/*  971 */         JSONException jsone = new JSONException(e);
/*  972 */         fireErrorEvent(jsone, jsonConfig);
/*  973 */         throw jsone;
/*      */       } 
/*      */     }
/*  976 */     fireArrayStartEvent(jsonConfig);
/*  977 */     JSONArray jsonArray = new JSONArray();
/*      */     try {
/*  979 */       for (int i = 0; i < array.length; i++) {
/*  980 */         Object element = array[i];
/*  981 */         jsonArray.addValue(element, jsonConfig);
/*  982 */         fireElementAddedEvent(i, jsonArray.get(i), jsonConfig);
/*      */       } 
/*  984 */     } catch (JSONException jsone) {
/*  985 */       removeInstance(array);
/*  986 */       fireErrorEvent(jsone, jsonConfig);
/*  987 */       throw jsone;
/*  988 */     } catch (RuntimeException e) {
/*  989 */       removeInstance(array);
/*  990 */       JSONException jsone = new JSONException(e);
/*  991 */       fireErrorEvent(jsone, jsonConfig);
/*  992 */       throw jsone;
/*      */     } 
/*      */     
/*  995 */     removeInstance(array);
/*  996 */     fireArrayEndEvent(jsonConfig);
/*  997 */     return jsonArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONArray _fromArray(short[] array, JsonConfig jsonConfig) {
/* 1006 */     if (!addInstance(array)) {
/*      */       try {
/* 1008 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/* 1010 */       catch (JSONException jsone) {
/* 1011 */         removeInstance(array);
/* 1012 */         fireErrorEvent(jsone, jsonConfig);
/* 1013 */         throw jsone;
/* 1014 */       } catch (RuntimeException e) {
/* 1015 */         removeInstance(array);
/* 1016 */         JSONException jsone = new JSONException(e);
/* 1017 */         fireErrorEvent(jsone, jsonConfig);
/* 1018 */         throw jsone;
/*      */       } 
/*      */     }
/* 1021 */     fireArrayStartEvent(jsonConfig);
/* 1022 */     JSONArray jsonArray = new JSONArray();
/* 1023 */     for (int i = 0; i < array.length; i++) {
/* 1024 */       Number n = JSONUtils.transformNumber(new Short(array[i]));
/* 1025 */       jsonArray.addValue(n, jsonConfig);
/* 1026 */       fireElementAddedEvent(i, n, jsonConfig);
/*      */     } 
/*      */     
/* 1029 */     removeInstance(array);
/* 1030 */     fireArrayEndEvent(jsonConfig);
/* 1031 */     return jsonArray;
/*      */   }
/*      */   
/*      */   private static JSONArray _fromCollection(Collection collection, JsonConfig jsonConfig) {
/* 1035 */     if (!addInstance(collection)) {
/*      */       try {
/* 1037 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(collection);
/*      */       }
/* 1039 */       catch (JSONException jsone) {
/* 1040 */         removeInstance(collection);
/* 1041 */         fireErrorEvent(jsone, jsonConfig);
/* 1042 */         throw jsone;
/* 1043 */       } catch (RuntimeException e) {
/* 1044 */         removeInstance(collection);
/* 1045 */         JSONException jsone = new JSONException(e);
/* 1046 */         fireErrorEvent(jsone, jsonConfig);
/* 1047 */         throw jsone;
/*      */       } 
/*      */     }
/* 1050 */     fireArrayStartEvent(jsonConfig);
/* 1051 */     JSONArray jsonArray = new JSONArray();
/*      */     try {
/* 1053 */       int i = 0;
/* 1054 */       for (Iterator elements = collection.iterator(); elements.hasNext(); ) {
/* 1055 */         Object element = elements.next();
/* 1056 */         jsonArray.addValue(element, jsonConfig);
/* 1057 */         fireElementAddedEvent(i, jsonArray.get(i++), jsonConfig);
/*      */       } 
/* 1059 */     } catch (JSONException jsone) {
/* 1060 */       removeInstance(collection);
/* 1061 */       fireErrorEvent(jsone, jsonConfig);
/* 1062 */       throw jsone;
/* 1063 */     } catch (RuntimeException e) {
/* 1064 */       removeInstance(collection);
/* 1065 */       JSONException jsone = new JSONException(e);
/* 1066 */       fireErrorEvent(jsone, jsonConfig);
/* 1067 */       throw jsone;
/*      */     } 
/*      */     
/* 1070 */     removeInstance(collection);
/* 1071 */     fireArrayEndEvent(jsonConfig);
/* 1072 */     return jsonArray;
/*      */   }
/*      */   
/*      */   private static JSONArray _fromJSONArray(JSONArray array, JsonConfig jsonConfig) {
/* 1076 */     if (!addInstance(array)) {
/*      */       try {
/* 1078 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsArray(array);
/*      */       }
/* 1080 */       catch (JSONException jsone) {
/* 1081 */         removeInstance(array);
/* 1082 */         fireErrorEvent(jsone, jsonConfig);
/* 1083 */         throw jsone;
/* 1084 */       } catch (RuntimeException e) {
/* 1085 */         removeInstance(array);
/* 1086 */         JSONException jsone = new JSONException(e);
/* 1087 */         fireErrorEvent(jsone, jsonConfig);
/* 1088 */         throw jsone;
/*      */       } 
/*      */     }
/* 1091 */     fireArrayStartEvent(jsonConfig);
/* 1092 */     JSONArray jsonArray = new JSONArray();
/* 1093 */     int index = 0;
/* 1094 */     for (Iterator elements = array.iterator(); elements.hasNext(); ) {
/* 1095 */       Object element = elements.next();
/* 1096 */       jsonArray.addValue(element, jsonConfig);
/* 1097 */       fireElementAddedEvent(index++, element, jsonConfig);
/*      */     } 
/*      */     
/* 1100 */     removeInstance(array);
/* 1101 */     fireArrayEndEvent(jsonConfig);
/* 1102 */     return jsonArray;
/*      */   }
/*      */   
/*      */   private static JSONArray _fromJSONString(JSONString string, JsonConfig jsonConfig) {
/* 1106 */     return _fromJSONTokener(new JSONTokener(string.toJSONString()), jsonConfig);
/*      */   }
/*      */ 
/*      */   
/*      */   private static JSONArray _fromJSONTokener(JSONTokener tokener, JsonConfig jsonConfig) {
/* 1111 */     JSONArray jsonArray = new JSONArray();
/* 1112 */     int index = 0;
/*      */     
/*      */     try {
/* 1115 */       if (tokener.nextClean() != '[') {
/* 1116 */         throw tokener.syntaxError("A JSONArray text must start with '['");
/*      */       }
/* 1118 */       fireArrayStartEvent(jsonConfig);
/* 1119 */       if (tokener.nextClean() == ']') {
/* 1120 */         fireArrayEndEvent(jsonConfig);
/* 1121 */         return jsonArray;
/*      */       } 
/* 1123 */       tokener.back();
/*      */       while (true) {
/* 1125 */         if (tokener.nextClean() == ',') {
/* 1126 */           tokener.back();
/* 1127 */           jsonArray.elements.add(JSONNull.getInstance());
/* 1128 */           fireElementAddedEvent(index, jsonArray.get(index++), jsonConfig);
/*      */         } else {
/* 1130 */           tokener.back();
/* 1131 */           Object v = tokener.nextValue(jsonConfig);
/* 1132 */           if (!JSONUtils.isFunctionHeader(v)) {
/* 1133 */             if (v instanceof String && JSONUtils.mayBeJSON((String)v)) {
/* 1134 */               jsonArray.addValue("\"" + v + "\"", jsonConfig);
/*      */             } else {
/*      */               
/* 1137 */               jsonArray.addValue(v, jsonConfig);
/*      */             } 
/* 1139 */             fireElementAddedEvent(index, jsonArray.get(index++), jsonConfig);
/*      */           } else {
/*      */             
/* 1142 */             String params = JSONUtils.getFunctionParams((String)v);
/*      */             
/* 1144 */             int i = 0;
/* 1145 */             StringBuffer sb = new StringBuffer();
/*      */             do {
/* 1147 */               char ch = tokener.next();
/* 1148 */               if (ch == '\000') {
/*      */                 break;
/*      */               }
/* 1151 */               if (ch == '{') {
/* 1152 */                 i++;
/*      */               }
/* 1154 */               if (ch == '}') {
/* 1155 */                 i--;
/*      */               }
/* 1157 */               sb.append(ch);
/* 1158 */             } while (i != 0);
/*      */ 
/*      */ 
/*      */             
/* 1162 */             if (i != 0) {
/* 1163 */               throw tokener.syntaxError("Unbalanced '{' or '}' on prop: " + v);
/*      */             }
/*      */             
/* 1166 */             String text = sb.toString();
/* 1167 */             text = text.substring(1, text.length() - 1).trim();
/*      */             
/* 1169 */             jsonArray.addValue(new JSONFunction((params != null) ? StringUtils.split(params, ",") : null, text), jsonConfig);
/*      */             
/* 1171 */             fireElementAddedEvent(index, jsonArray.get(index++), jsonConfig);
/*      */           } 
/*      */         } 
/* 1174 */         switch (tokener.nextClean()) {
/*      */           case ',':
/*      */           case ';':
/* 1177 */             if (tokener.nextClean() == ']') {
/* 1178 */               fireArrayEndEvent(jsonConfig);
/* 1179 */               return jsonArray;
/*      */             } 
/* 1181 */             tokener.back();
/*      */             continue;
/*      */           case ']':
/* 1184 */             fireArrayEndEvent(jsonConfig);
/* 1185 */             return jsonArray;
/*      */         }  break;
/* 1187 */       }  throw tokener.syntaxError("Expected a ',' or ']'");
/*      */     
/*      */     }
/* 1190 */     catch (JSONException jsone) {
/* 1191 */       fireErrorEvent(jsone, jsonConfig);
/* 1192 */       throw jsone;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static JSONArray _fromString(String string, JsonConfig jsonConfig) {
/* 1197 */     return _fromJSONTokener(new JSONTokener(string), jsonConfig);
/*      */   }
/*      */   
/*      */   private static void processArrayDimensions(JSONArray jsonArray, List<Integer> dims, int index) {
/* 1201 */     if (dims.size() <= index) {
/* 1202 */       dims.add(new Integer(jsonArray.size()));
/*      */     } else {
/* 1204 */       int j = ((Integer)dims.get(index)).intValue();
/* 1205 */       if (jsonArray.size() > j) {
/* 1206 */         dims.set(index, new Integer(jsonArray.size()));
/*      */       }
/*      */     } 
/* 1209 */     for (Iterator i = jsonArray.iterator(); i.hasNext(); ) {
/* 1210 */       Object item = i.next();
/* 1211 */       if (item instanceof JSONArray) {
/* 1212 */         processArrayDimensions((JSONArray)item, dims, index + 1);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray() {
/* 1233 */     this.elements = new ArrayList();
/*      */   }
/*      */   
/*      */   public void add(int index, Object value) {
/* 1237 */     add(index, value, new JsonConfig());
/*      */   }
/*      */   
/*      */   public void add(int index, Object value, JsonConfig jsonConfig) {
/* 1241 */     this.elements.add(index, processValue(value, jsonConfig));
/*      */   }
/*      */   
/*      */   public boolean add(Object value) {
/* 1245 */     return add(value, new JsonConfig());
/*      */   }
/*      */   
/*      */   public boolean add(Object value, JsonConfig jsonConfig) {
/* 1249 */     element(value, jsonConfig);
/* 1250 */     return true;
/*      */   }
/*      */   
/*      */   public boolean addAll(Collection collection) {
/* 1254 */     return addAll(collection, new JsonConfig());
/*      */   }
/*      */   
/*      */   public boolean addAll(Collection collection, JsonConfig jsonConfig) {
/* 1258 */     if (collection == null || collection.size() == 0) {
/* 1259 */       return false;
/*      */     }
/* 1261 */     for (Iterator i = collection.iterator(); i.hasNext();) {
/* 1262 */       element(i.next(), jsonConfig);
/*      */     }
/* 1264 */     return true;
/*      */   }
/*      */   
/*      */   public boolean addAll(int index, Collection collection) {
/* 1268 */     return addAll(index, collection, new JsonConfig());
/*      */   }
/*      */   
/*      */   public boolean addAll(int index, Collection collection, JsonConfig jsonConfig) {
/* 1272 */     if (collection == null || collection.size() == 0) {
/* 1273 */       return false;
/*      */     }
/* 1275 */     int offset = 0;
/* 1276 */     for (Iterator i = collection.iterator(); i.hasNext();) {
/* 1277 */       this.elements.add(index + offset++, processValue(i.next(), jsonConfig));
/*      */     }
/* 1279 */     return true;
/*      */   }
/*      */   
/*      */   public void clear() {
/* 1283 */     this.elements.clear();
/*      */   }
/*      */   
/*      */   public int compareTo(Object obj) {
/* 1287 */     if (obj != null && obj instanceof JSONArray) {
/* 1288 */       JSONArray other = (JSONArray)obj;
/* 1289 */       int size1 = size();
/* 1290 */       int size2 = other.size();
/* 1291 */       if (size1 < size2)
/* 1292 */         return -1; 
/* 1293 */       if (size1 > size2)
/* 1294 */         return 1; 
/* 1295 */       if (equals(other)) {
/* 1296 */         return 0;
/*      */       }
/*      */     } 
/* 1299 */     return -1;
/*      */   }
/*      */   
/*      */   public boolean contains(Object o) {
/* 1303 */     return contains(o, new JsonConfig());
/*      */   }
/*      */   
/*      */   public boolean contains(Object o, JsonConfig jsonConfig) {
/* 1307 */     return this.elements.contains(processValue(o, jsonConfig));
/*      */   }
/*      */   
/*      */   public boolean containsAll(Collection collection) {
/* 1311 */     return containsAll(collection, new JsonConfig());
/*      */   }
/*      */   
/*      */   public boolean containsAll(Collection collection, JsonConfig jsonConfig) {
/* 1315 */     return this.elements.containsAll(fromObject(collection, jsonConfig));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray discard(int index) {
/* 1325 */     this.elements.remove(index);
/* 1326 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray discard(Object o) {
/* 1336 */     this.elements.remove(o);
/* 1337 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(boolean value) {
/* 1347 */     return element(value ? Boolean.TRUE : Boolean.FALSE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(Collection value) {
/* 1358 */     return element(value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(Collection value, JsonConfig jsonConfig) {
/* 1369 */     if (value instanceof JSONArray) {
/* 1370 */       this.elements.add(value);
/* 1371 */       return this;
/*      */     } 
/* 1373 */     return element(_fromCollection(value, jsonConfig));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(double value) {
/* 1385 */     Double d = new Double(value);
/* 1386 */     JSONUtils.testValidity(d);
/* 1387 */     return element(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int value) {
/* 1397 */     return element(new Integer(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, boolean value) {
/* 1411 */     return element(index, value ? Boolean.TRUE : Boolean.FALSE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, Collection value) {
/* 1425 */     return element(index, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, Collection value, JsonConfig jsonConfig) {
/* 1439 */     if (value instanceof JSONArray) {
/* 1440 */       if (index < 0) {
/* 1441 */         throw new JSONException("JSONArray[" + index + "] not found.");
/*      */       }
/* 1443 */       if (index < size()) {
/* 1444 */         this.elements.set(index, value);
/*      */       } else {
/* 1446 */         while (index != size()) {
/* 1447 */           element(JSONNull.getInstance());
/*      */         }
/* 1449 */         element(value, jsonConfig);
/*      */       } 
/* 1451 */       return this;
/*      */     } 
/* 1453 */     return element(index, _fromCollection(value, jsonConfig));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, double value) {
/* 1469 */     return element(index, new Double(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, int value) {
/* 1483 */     return element(index, new Integer(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, long value) {
/* 1497 */     return element(index, new Long(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, Map value) {
/* 1511 */     return element(index, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, Map value, JsonConfig jsonConfig) {
/* 1525 */     if (value instanceof JSONObject) {
/* 1526 */       if (index < 0) {
/* 1527 */         throw new JSONException("JSONArray[" + index + "] not found.");
/*      */       }
/* 1529 */       if (index < size()) {
/* 1530 */         this.elements.set(index, value);
/*      */       } else {
/* 1532 */         while (index != size()) {
/* 1533 */           element(JSONNull.getInstance());
/*      */         }
/* 1535 */         element(value, jsonConfig);
/*      */       } 
/* 1537 */       return this;
/*      */     } 
/* 1539 */     return element(index, JSONObject.fromObject(value, jsonConfig));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, Object value) {
/* 1557 */     return element(index, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, Object value, JsonConfig jsonConfig) {
/* 1574 */     JSONUtils.testValidity(value);
/* 1575 */     if (index < 0) {
/* 1576 */       throw new JSONException("JSONArray[" + index + "] not found.");
/*      */     }
/* 1578 */     if (index < size()) {
/* 1579 */       this.elements.set(index, processValue(value, jsonConfig));
/*      */     } else {
/* 1581 */       while (index != size()) {
/* 1582 */         element(JSONNull.getInstance());
/*      */       }
/* 1584 */       element(value, jsonConfig);
/*      */     } 
/* 1586 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, String value) {
/* 1603 */     return element(index, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(int index, String value, JsonConfig jsonConfig) {
/* 1620 */     if (index < 0) {
/* 1621 */       throw new JSONException("JSONArray[" + index + "] not found.");
/*      */     }
/* 1623 */     if (index < size()) {
/* 1624 */       if (value == null) {
/* 1625 */         this.elements.set(index, "");
/* 1626 */       } else if (JSONUtils.mayBeJSON(value)) {
/*      */         try {
/* 1628 */           this.elements.set(index, JSONSerializer.toJSON(value, jsonConfig));
/* 1629 */         } catch (JSONException jsone) {
/* 1630 */           this.elements.set(index, JSONUtils.stripQuotes(value));
/*      */         } 
/*      */       } else {
/* 1633 */         this.elements.set(index, JSONUtils.stripQuotes(value));
/*      */       } 
/*      */     } else {
/* 1636 */       while (index != size()) {
/* 1637 */         element(JSONNull.getInstance());
/*      */       }
/* 1639 */       element(value, jsonConfig);
/*      */     } 
/* 1641 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(JSONNull value) {
/* 1651 */     this.elements.add(value);
/* 1652 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(JSONObject value) {
/* 1662 */     this.elements.add(value);
/* 1663 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(long value) {
/* 1673 */     return element(JSONUtils.transformNumber(new Long(value)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(Map value) {
/* 1684 */     return element(value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(Map value, JsonConfig jsonConfig) {
/* 1695 */     if (value instanceof JSONObject) {
/* 1696 */       this.elements.add(value);
/* 1697 */       return this;
/*      */     } 
/* 1699 */     return element(JSONObject.fromObject(value, jsonConfig));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(Object value) {
/* 1712 */     return element(value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(Object value, JsonConfig jsonConfig) {
/* 1724 */     return addValue(value, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(String value) {
/* 1736 */     return element(value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray element(String value, JsonConfig jsonConfig) {
/* 1748 */     if (value == null) {
/* 1749 */       this.elements.add("");
/* 1750 */     } else if (JSONUtils.hasQuotes(value)) {
/* 1751 */       this.elements.add(value);
/* 1752 */     } else if (JSONNull.getInstance().equals(value)) {
/* 1753 */       this.elements.add(JSONNull.getInstance());
/* 1754 */     } else if (JSONUtils.isJsonKeyword(value, jsonConfig)) {
/* 1755 */       if (jsonConfig.isJavascriptCompliant() && "undefined".equals(value)) {
/* 1756 */         this.elements.add(JSONNull.getInstance());
/*      */       } else {
/* 1758 */         this.elements.add(value);
/*      */       } 
/* 1760 */     } else if (JSONUtils.mayBeJSON(value)) {
/*      */       try {
/* 1762 */         this.elements.add(JSONSerializer.toJSON(value, jsonConfig));
/* 1763 */       } catch (JSONException jsone) {
/* 1764 */         this.elements.add(value);
/*      */       } 
/*      */     } else {
/* 1767 */       this.elements.add(value);
/*      */     } 
/* 1769 */     return this;
/*      */   }
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1773 */     if (obj == this) {
/* 1774 */       return true;
/*      */     }
/* 1776 */     if (obj == null) {
/* 1777 */       return false;
/*      */     }
/*      */     
/* 1780 */     if (!(obj instanceof JSONArray)) {
/* 1781 */       return false;
/*      */     }
/*      */     
/* 1784 */     JSONArray other = (JSONArray)obj;
/*      */     
/* 1786 */     if (other.size() != size()) {
/* 1787 */       return false;
/*      */     }
/*      */     
/* 1790 */     int max = size();
/* 1791 */     for (int i = 0; i < max; i++) {
/* 1792 */       Object o1 = get(i);
/* 1793 */       Object o2 = other.get(i);
/*      */ 
/*      */       
/* 1796 */       if (JSONNull.getInstance().equals(o1)) {
/*      */         
/* 1798 */         if (!JSONNull.getInstance().equals(o2))
/*      */         {
/*      */ 
/*      */           
/* 1802 */           return false;
/*      */         }
/*      */       } else {
/* 1805 */         if (JSONNull.getInstance().equals(o2))
/*      */         {
/* 1807 */           return false;
/*      */         }
/*      */ 
/*      */         
/* 1811 */         if (o1 instanceof JSONArray && o2 instanceof JSONArray) {
/* 1812 */           JSONArray e = (JSONArray)o1;
/* 1813 */           JSONArray a = (JSONArray)o2;
/* 1814 */           if (!a.equals(e)) {
/* 1815 */             return false;
/*      */           }
/*      */         }
/* 1818 */         else if (o1 instanceof String && o2 instanceof JSONFunction) {
/* 1819 */           if (!o1.equals(String.valueOf(o2))) {
/* 1820 */             return false;
/*      */           }
/* 1822 */         } else if (o1 instanceof JSONFunction && o2 instanceof String) {
/* 1823 */           if (!o2.equals(String.valueOf(o1))) {
/* 1824 */             return false;
/*      */           }
/* 1826 */         } else if (o1 instanceof JSONObject && o2 instanceof JSONObject) {
/* 1827 */           if (!o1.equals(o2)) {
/* 1828 */             return false;
/*      */           }
/* 1830 */         } else if (o1 instanceof JSONArray && o2 instanceof JSONArray) {
/* 1831 */           if (!o1.equals(o2)) {
/* 1832 */             return false;
/*      */           }
/* 1834 */         } else if (o1 instanceof JSONFunction && o2 instanceof JSONFunction) {
/* 1835 */           if (!o1.equals(o2)) {
/* 1836 */             return false;
/*      */           }
/*      */         }
/* 1839 */         else if (o1 instanceof String) {
/* 1840 */           if (!o1.equals(String.valueOf(o2))) {
/* 1841 */             return false;
/*      */           }
/* 1843 */         } else if (o2 instanceof String) {
/* 1844 */           if (!o2.equals(String.valueOf(o1))) {
/* 1845 */             return false;
/*      */           }
/*      */         } else {
/* 1848 */           Morpher m1 = JSONUtils.getMorpherRegistry().getMorpherFor(o1.getClass());
/*      */           
/* 1850 */           Morpher m2 = JSONUtils.getMorpherRegistry().getMorpherFor(o2.getClass());
/*      */           
/* 1852 */           if (m1 != null && m1 != IdentityObjectMorpher.getInstance()) {
/* 1853 */             if (!o1.equals(JSONUtils.getMorpherRegistry().morph(o1.getClass(), o2)))
/*      */             {
/* 1855 */               return false;
/*      */             }
/* 1857 */           } else if (m2 != null && m2 != IdentityObjectMorpher.getInstance()) {
/* 1858 */             if (!JSONUtils.getMorpherRegistry().morph(o1.getClass(), o1).equals(o2))
/*      */             {
/*      */               
/* 1861 */               return false;
/*      */             }
/*      */           }
/* 1864 */           else if (!o1.equals(o2)) {
/* 1865 */             return false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1872 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(int index) {
/* 1886 */     return this.elements.get(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int index) {
/* 1899 */     Object o = get(index);
/* 1900 */     if (o != null) {
/* 1901 */       if (o.equals(Boolean.FALSE) || (o instanceof String && ((String)o).equalsIgnoreCase("false")))
/*      */       {
/* 1903 */         return false; } 
/* 1904 */       if (o.equals(Boolean.TRUE) || (o instanceof String && ((String)o).equalsIgnoreCase("true")))
/*      */       {
/* 1906 */         return true;
/*      */       }
/*      */     } 
/* 1909 */     throw new JSONException("JSONArray[" + index + "] is not a Boolean.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int index) {
/* 1921 */     Object o = get(index);
/* 1922 */     if (o != null) {
/*      */       try {
/* 1924 */         return (o instanceof Number) ? ((Number)o).doubleValue() : Double.parseDouble((String)o);
/*      */       }
/* 1926 */       catch (Exception e) {
/* 1927 */         throw new JSONException("JSONArray[" + index + "] is not a number.");
/*      */       } 
/*      */     }
/* 1930 */     throw new JSONException("JSONArray[" + index + "] is not a number.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int index) {
/* 1943 */     Object o = get(index);
/* 1944 */     if (o != null) {
/* 1945 */       return (o instanceof Number) ? ((Number)o).intValue() : (int)getDouble(index);
/*      */     }
/* 1947 */     throw new JSONException("JSONArray[" + index + "] is not a number.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray getJSONArray(int index) {
/* 1959 */     Object o = get(index);
/* 1960 */     if (o != null && o instanceof JSONArray) {
/* 1961 */       return (JSONArray)o;
/*      */     }
/* 1963 */     throw new JSONException("JSONArray[" + index + "] is not a JSONArray.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject getJSONObject(int index) {
/* 1975 */     Object o = get(index);
/* 1976 */     if (JSONNull.getInstance().equals(o))
/*      */     {
/* 1978 */       return new JSONObject(true); } 
/* 1979 */     if (o instanceof JSONObject) {
/* 1980 */       return (JSONObject)o;
/*      */     }
/* 1982 */     throw new JSONException("JSONArray[" + index + "] is not a JSONObject.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int index) {
/* 1994 */     Object o = get(index);
/* 1995 */     if (o != null) {
/* 1996 */       return (o instanceof Number) ? ((Number)o).longValue() : (long)getDouble(index);
/*      */     }
/* 1998 */     throw new JSONException("JSONArray[" + index + "] is not a number.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int index) {
/* 2009 */     Object o = get(index);
/* 2010 */     if (o != null) {
/* 2011 */       return o.toString();
/*      */     }
/* 2013 */     throw new JSONException("JSONArray[" + index + "] not found.");
/*      */   }
/*      */   
/*      */   public int hashCode() {
/* 2017 */     int hashcode = 29;
/*      */     
/* 2019 */     for (Iterator e = this.elements.iterator(); e.hasNext(); ) {
/* 2020 */       Object element = e.next();
/* 2021 */       hashcode += JSONUtils.hashCode(element);
/*      */     } 
/* 2023 */     return hashcode;
/*      */   }
/*      */   
/*      */   public int indexOf(Object o) {
/* 2027 */     return this.elements.indexOf(o);
/*      */   }
/*      */   
/*      */   public boolean isArray() {
/* 2031 */     return true;
/*      */   }
/*      */   
/*      */   public boolean isEmpty() {
/* 2035 */     return this.elements.isEmpty();
/*      */   }
/*      */   
/*      */   public boolean isExpandElements() {
/* 2039 */     return this.expandElements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator iterator() {
/* 2046 */     return new JSONArrayListIterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String join(String separator) {
/* 2059 */     return join(separator, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String join(String separator, boolean stripQuotes) {
/* 2072 */     int len = size();
/* 2073 */     StringBuffer sb = new StringBuffer();
/*      */     
/* 2075 */     for (int i = 0; i < len; i++) {
/* 2076 */       if (i > 0) {
/* 2077 */         sb.append(separator);
/*      */       }
/* 2079 */       String value = JSONUtils.valueToString(this.elements.get(i));
/* 2080 */       sb.append(stripQuotes ? JSONUtils.stripQuotes(value) : value);
/*      */     } 
/* 2082 */     return sb.toString();
/*      */   }
/*      */   
/*      */   public int lastIndexOf(Object o) {
/* 2086 */     return this.elements.lastIndexOf(o);
/*      */   }
/*      */   
/*      */   public ListIterator listIterator() {
/* 2090 */     return listIterator(0);
/*      */   }
/*      */   
/*      */   public ListIterator listIterator(int index) {
/* 2094 */     if (index < 0 || index > size()) {
/* 2095 */       throw new IndexOutOfBoundsException("Index: " + index);
/*      */     }
/* 2097 */     return new JSONArrayListIterator(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object opt(int index) {
/* 2107 */     return (index < 0 || index >= size()) ? null : this.elements.get(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean optBoolean(int index) {
/* 2119 */     return optBoolean(index, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean optBoolean(int index, boolean defaultValue) {
/*      */     try {
/* 2133 */       return getBoolean(index);
/* 2134 */     } catch (Exception e) {
/* 2135 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double optDouble(int index) {
/* 2148 */     return optDouble(index, Double.NaN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double optDouble(int index, double defaultValue) {
/*      */     try {
/* 2162 */       return getDouble(index);
/* 2163 */     } catch (Exception e) {
/* 2164 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int optInt(int index) {
/* 2177 */     return optInt(index, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int optInt(int index, int defaultValue) {
/*      */     try {
/* 2191 */       return getInt(index);
/* 2192 */     } catch (Exception e) {
/* 2193 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray optJSONArray(int index) {
/* 2205 */     Object o = opt(index);
/* 2206 */     return (o instanceof JSONArray) ? (JSONArray)o : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject optJSONObject(int index) {
/* 2218 */     Object o = opt(index);
/* 2219 */     return (o instanceof JSONObject) ? (JSONObject)o : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long optLong(int index) {
/* 2231 */     return optLong(index, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long optLong(int index, long defaultValue) {
/*      */     try {
/* 2245 */       return getLong(index);
/* 2246 */     } catch (Exception e) {
/* 2247 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String optString(int index) {
/* 2260 */     return optString(index, "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String optString(int index, String defaultValue) {
/* 2272 */     Object o = opt(index);
/* 2273 */     return (o != null) ? o.toString() : defaultValue;
/*      */   }
/*      */   
/*      */   public Object remove(int index) {
/* 2277 */     return this.elements.remove(index);
/*      */   }
/*      */   
/*      */   public boolean remove(Object o) {
/* 2281 */     return this.elements.remove(o);
/*      */   }
/*      */   
/*      */   public boolean removeAll(Collection collection) {
/* 2285 */     return removeAll(collection, new JsonConfig());
/*      */   }
/*      */   
/*      */   public boolean removeAll(Collection collection, JsonConfig jsonConfig) {
/* 2289 */     return this.elements.removeAll(fromObject(collection, jsonConfig));
/*      */   }
/*      */   
/*      */   public boolean retainAll(Collection collection) {
/* 2293 */     return retainAll(collection, new JsonConfig());
/*      */   }
/*      */   
/*      */   public boolean retainAll(Collection collection, JsonConfig jsonConfig) {
/* 2297 */     return this.elements.retainAll(fromObject(collection, jsonConfig));
/*      */   }
/*      */   
/*      */   public Object set(int index, Object value) {
/* 2301 */     return set(index, value, new JsonConfig());
/*      */   }
/*      */   
/*      */   public Object set(int index, Object value, JsonConfig jsonConfig) {
/* 2305 */     Object previous = get(index);
/* 2306 */     element(index, value, jsonConfig);
/* 2307 */     return previous;
/*      */   }
/*      */   
/*      */   public void setExpandElements(boolean expandElements) {
/* 2311 */     this.expandElements = expandElements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/* 2320 */     return this.elements.size();
/*      */   }
/*      */   
/*      */   public List subList(int fromIndex, int toIndex) {
/* 2324 */     return this.elements.subList(fromIndex, toIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] toArray() {
/* 2331 */     return this.elements.toArray();
/*      */   }
/*      */   
/*      */   public Object[] toArray(Object[] array) {
/* 2335 */     return this.elements.toArray(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject toJSONObject(JSONArray names) {
/* 2349 */     if (names == null || names.size() == 0 || size() == 0) {
/* 2350 */       return null;
/*      */     }
/* 2352 */     JSONObject jo = new JSONObject();
/* 2353 */     for (int i = 0; i < names.size(); i++) {
/* 2354 */       jo.element(names.getString(i), opt(i));
/*      */     }
/* 2356 */     return jo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*      */     try {
/* 2372 */       return '[' + join(",") + ']';
/* 2373 */     } catch (Exception e) {
/* 2374 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(int indentFactor) {
/* 2391 */     if (indentFactor == 0) {
/* 2392 */       return toString();
/*      */     }
/* 2394 */     return toString(indentFactor, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(int indentFactor, int indent) {
/* 2409 */     int len = size();
/* 2410 */     if (len == 0) {
/* 2411 */       return "[]";
/*      */     }
/* 2413 */     if (indentFactor == 0) {
/* 2414 */       return toString();
/*      */     }
/*      */     
/* 2417 */     StringBuffer sb = new StringBuffer("[");
/* 2418 */     if (len == 1) {
/* 2419 */       sb.append(JSONUtils.valueToString(this.elements.get(0), indentFactor, indent));
/*      */     } else {
/* 2421 */       int newindent = indent + indentFactor;
/* 2422 */       sb.append('\n'); int i;
/* 2423 */       for (i = 0; i < len; i++) {
/* 2424 */         if (i > 0) {
/* 2425 */           sb.append(",\n");
/*      */         }
/* 2427 */         for (int j = 0; j < newindent; j++) {
/* 2428 */           sb.append(' ');
/*      */         }
/* 2430 */         sb.append(JSONUtils.valueToString(this.elements.get(i), indentFactor, newindent));
/*      */       } 
/* 2432 */       sb.append('\n');
/* 2433 */       for (i = 0; i < indent; i++) {
/* 2434 */         sb.append(' ');
/*      */       }
/* 2436 */       for (i = 0; i < indent; i++) {
/* 2437 */         sb.insert(0, ' ');
/*      */       }
/*      */     } 
/* 2440 */     sb.append(']');
/* 2441 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer write(Writer writer) {
/*      */     try {
/* 2455 */       boolean b = false;
/* 2456 */       int len = size();
/*      */       
/* 2458 */       writer.write(91);
/*      */       
/* 2460 */       for (int i = 0; i < len; i++) {
/* 2461 */         if (b) {
/* 2462 */           writer.write(44);
/*      */         }
/* 2464 */         Object v = this.elements.get(i);
/* 2465 */         if (v instanceof JSONObject) {
/* 2466 */           ((JSONObject)v).write(writer);
/* 2467 */         } else if (v instanceof JSONArray) {
/* 2468 */           ((JSONArray)v).write(writer);
/*      */         } else {
/* 2470 */           writer.write(JSONUtils.valueToString(v));
/*      */         } 
/* 2472 */         b = true;
/*      */       } 
/* 2474 */       writer.write(93);
/* 2475 */       return writer;
/* 2476 */     } catch (IOException e) {
/* 2477 */       throw new JSONException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JSONArray addString(String str) {
/* 2485 */     if (str != null) {
/* 2486 */       this.elements.add(str);
/*      */     }
/* 2488 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JSONArray _addValue(Object value, JsonConfig jsonConfig) {
/* 2500 */     this.elements.add(value);
/* 2501 */     return this;
/*      */   }
/*      */   
/*      */   protected Object _processValue(Object value, JsonConfig jsonConfig) {
/* 2505 */     if (value instanceof JSONTokener)
/* 2506 */       return _fromJSONTokener((JSONTokener)value, jsonConfig); 
/* 2507 */     if (value != null && Enum.class.isAssignableFrom(value.getClass()))
/* 2508 */       return ((Enum)value).name(); 
/* 2509 */     if (value instanceof java.lang.annotation.Annotation || (value != null && value.getClass().isAnnotation()))
/*      */     {
/* 2511 */       throw new JSONException("Unsupported type");
/*      */     }
/* 2513 */     return super._processValue(value, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JSONArray addValue(Object value, JsonConfig jsonConfig) {
/* 2525 */     return _addValue(processValue(value, jsonConfig), jsonConfig);
/*      */   }
/*      */   
/*      */   private Object processValue(Object value, JsonConfig jsonConfig) {
/* 2529 */     if (value != null) {
/* 2530 */       JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(value.getClass());
/* 2531 */       if (jsonValueProcessor != null) {
/* 2532 */         value = jsonValueProcessor.processArrayValue(value, jsonConfig);
/* 2533 */         if (!JsonVerifier.isValidJsonValue(value)) {
/* 2534 */           throw new JSONException("Value is not a valid JSON value. " + value);
/*      */         }
/*      */       } 
/*      */     } 
/* 2538 */     return _processValue(value, jsonConfig);
/*      */   }
/*      */   
/*      */   private class JSONArrayListIterator implements ListIterator {
/* 2542 */     int currentIndex = 0;
/* 2543 */     int lastIndex = -1;
/*      */ 
/*      */     
/*      */     JSONArrayListIterator() {}
/*      */ 
/*      */     
/*      */     JSONArrayListIterator(int index) {
/* 2550 */       this.currentIndex = index;
/*      */     }
/*      */     
/*      */     public boolean hasNext() {
/* 2554 */       return (this.currentIndex != JSONArray.this.size());
/*      */     }
/*      */     
/*      */     public Object next() {
/*      */       try {
/* 2559 */         Object next = JSONArray.this.get(this.currentIndex);
/* 2560 */         this.lastIndex = this.currentIndex++;
/* 2561 */         return next;
/* 2562 */       } catch (IndexOutOfBoundsException e) {
/* 2563 */         throw new NoSuchElementException();
/*      */       } 
/*      */     }
/*      */     
/*      */     public void remove() {
/* 2568 */       if (this.lastIndex == -1)
/* 2569 */         throw new IllegalStateException(); 
/*      */       try {
/* 2571 */         JSONArray.this.remove(this.lastIndex);
/* 2572 */         if (this.lastIndex < this.currentIndex) {
/* 2573 */           this.currentIndex--;
/*      */         }
/* 2575 */         this.lastIndex = -1;
/* 2576 */       } catch (IndexOutOfBoundsException e) {
/* 2577 */         throw new ConcurrentModificationException();
/*      */       } 
/*      */     }
/*      */     
/*      */     public boolean hasPrevious() {
/* 2582 */       return (this.currentIndex != 0);
/*      */     }
/*      */     
/*      */     public Object previous() {
/*      */       try {
/* 2587 */         int index = this.currentIndex - 1;
/* 2588 */         Object previous = JSONArray.this.get(index);
/* 2589 */         this.lastIndex = this.currentIndex = index;
/* 2590 */         return previous;
/* 2591 */       } catch (IndexOutOfBoundsException e) {
/* 2592 */         throw new NoSuchElementException();
/*      */       } 
/*      */     }
/*      */     
/*      */     public int nextIndex() {
/* 2597 */       return this.currentIndex;
/*      */     }
/*      */     
/*      */     public int previousIndex() {
/* 2601 */       return this.currentIndex - 1;
/*      */     }
/*      */     
/*      */     public void set(Object obj) {
/* 2605 */       if (this.lastIndex == -1) {
/* 2606 */         throw new IllegalStateException();
/*      */       }
/*      */       
/*      */       try {
/* 2610 */         JSONArray.this.set(this.lastIndex, obj);
/* 2611 */       } catch (IndexOutOfBoundsException ex) {
/* 2612 */         throw new ConcurrentModificationException();
/*      */       } 
/*      */     }
/*      */     
/*      */     public void add(Object obj) {
/*      */       try {
/* 2618 */         JSONArray.this.add(this.currentIndex++, obj);
/* 2619 */         this.lastIndex = -1;
/* 2620 */       } catch (IndexOutOfBoundsException ex) {
/* 2621 */         throw new ConcurrentModificationException();
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\JSONArray.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */