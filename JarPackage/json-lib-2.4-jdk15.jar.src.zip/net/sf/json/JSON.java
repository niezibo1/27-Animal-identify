package net.sf.json;

import java.io.Serializable;
import java.io.Writer;

public interface JSON extends Serializable {
  boolean isArray();
  
  boolean isEmpty();
  
  int size();
  
  String toString(int paramInt);
  
  String toString(int paramInt1, int paramInt2);
  
  Writer write(Writer paramWriter);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\JSON.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */