/*      */ package net.sf.json;
/*      */ 
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import net.sf.ezmorph.Morpher;
/*      */ import net.sf.ezmorph.array.ObjectArrayMorpher;
/*      */ import net.sf.ezmorph.bean.BeanMorpher;
/*      */ import net.sf.ezmorph.object.IdentityObjectMorpher;
/*      */ import net.sf.json.processors.JsonBeanProcessor;
/*      */ import net.sf.json.processors.JsonValueProcessor;
/*      */ import net.sf.json.processors.JsonVerifier;
/*      */ import net.sf.json.processors.PropertyNameProcessor;
/*      */ import net.sf.json.regexp.RegexpUtils;
/*      */ import net.sf.json.util.CycleDetectionStrategy;
/*      */ import net.sf.json.util.EnumMorpher;
/*      */ import net.sf.json.util.JSONTokener;
/*      */ import net.sf.json.util.JSONUtils;
/*      */ import net.sf.json.util.PropertyFilter;
/*      */ import net.sf.json.util.PropertySetStrategy;
/*      */ import org.apache.commons.beanutils.DynaBean;
/*      */ import org.apache.commons.beanutils.DynaProperty;
/*      */ import org.apache.commons.beanutils.PropertyUtils;
/*      */ import org.apache.commons.collections.map.ListOrderedMap;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class JSONObject
/*      */   extends AbstractJSON
/*      */   implements JSON, Map, Comparable
/*      */ {
/*  121 */   private static final Log log = LogFactory.getLog(JSONObject.class);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean nullObject;
/*      */ 
/*      */ 
/*      */   
/*      */   private Map properties;
/*      */ 
/*      */ 
/*      */   
/*      */   public static JSONObject fromObject(Object object) {
/*  134 */     return fromObject(object, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JSONObject fromObject(Object object, JsonConfig jsonConfig) {
/*  147 */     if (object == null || JSONUtils.isNull(object))
/*  148 */       return new JSONObject(true); 
/*  149 */     if (object instanceof Enum)
/*  150 */       throw new JSONException("'object' is an Enum. Use JSONArray instead"); 
/*  151 */     if (object instanceof java.lang.annotation.Annotation || (object != null && object.getClass().isAnnotation()))
/*      */     {
/*  153 */       throw new JSONException("'object' is an Annotation."); } 
/*  154 */     if (object instanceof JSONObject)
/*  155 */       return _fromJSONObject((JSONObject)object, jsonConfig); 
/*  156 */     if (object instanceof DynaBean)
/*  157 */       return _fromDynaBean((DynaBean)object, jsonConfig); 
/*  158 */     if (object instanceof JSONTokener)
/*  159 */       return _fromJSONTokener((JSONTokener)object, jsonConfig); 
/*  160 */     if (object instanceof JSONString)
/*  161 */       return _fromJSONString((JSONString)object, jsonConfig); 
/*  162 */     if (object instanceof Map)
/*  163 */       return _fromMap((Map)object, jsonConfig); 
/*  164 */     if (object instanceof String)
/*  165 */       return _fromString((String)object, jsonConfig); 
/*  166 */     if (JSONUtils.isNumber(object) || JSONUtils.isBoolean(object) || JSONUtils.isString(object))
/*      */     {
/*  168 */       return new JSONObject(); } 
/*  169 */     if (JSONUtils.isArray(object)) {
/*  170 */       throw new JSONException("'object' is an array. Use JSONArray instead");
/*      */     }
/*  172 */     return _fromBean(object, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toBean(JSONObject jsonObject) {
/*  180 */     if (jsonObject == null || jsonObject.isNullObject()) {
/*  181 */       return null;
/*      */     }
/*      */     
/*  184 */     DynaBean dynaBean = null;
/*      */     
/*  186 */     JsonConfig jsonConfig = new JsonConfig();
/*  187 */     Map props = JSONUtils.getProperties(jsonObject);
/*  188 */     dynaBean = JSONUtils.newDynaBean(jsonObject, jsonConfig);
/*  189 */     Iterator<String> entries = jsonObject.names(jsonConfig).iterator();
/*  190 */     while (entries.hasNext()) {
/*  191 */       String name = entries.next();
/*  192 */       String key = JSONUtils.convertToJavaIdentifier(name, jsonConfig);
/*  193 */       Class<?> type = (Class)props.get(name);
/*  194 */       Object value = jsonObject.get(name);
/*      */       try {
/*  196 */         if (!JSONUtils.isNull(value)) {
/*  197 */           if (value instanceof JSONArray) {
/*  198 */             dynaBean.set(key, JSONArray.toCollection((JSONArray)value)); continue;
/*  199 */           }  if (String.class.isAssignableFrom(type) || Boolean.class.isAssignableFrom(type) || JSONUtils.isNumber(type) || Character.class.isAssignableFrom(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */ 
/*      */             
/*  203 */             dynaBean.set(key, value); continue;
/*      */           } 
/*  205 */           dynaBean.set(key, toBean((JSONObject)value));
/*      */           continue;
/*      */         } 
/*  208 */         if (type.isPrimitive()) {
/*      */           
/*  210 */           log.warn("Tried to assign null value to " + key + ":" + type.getName());
/*  211 */           dynaBean.set(key, JSONUtils.getMorpherRegistry().morph(type, null));
/*      */           continue;
/*      */         } 
/*  214 */         dynaBean.set(key, null);
/*      */       
/*      */       }
/*  217 */       catch (JSONException jsone) {
/*  218 */         throw jsone;
/*  219 */       } catch (Exception e) {
/*  220 */         throw new JSONException("Error while setting property=" + name + " type" + type, e);
/*      */       } 
/*      */     } 
/*      */     
/*  224 */     return dynaBean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toBean(JSONObject jsonObject, Class beanClass) {
/*  231 */     JsonConfig jsonConfig = new JsonConfig();
/*  232 */     jsonConfig.setRootClass(beanClass);
/*  233 */     return toBean(jsonObject, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toBean(JSONObject jsonObject, Class beanClass, Map classMap) {
/*  249 */     JsonConfig jsonConfig = new JsonConfig();
/*  250 */     jsonConfig.setRootClass(beanClass);
/*  251 */     jsonConfig.setClassMap(classMap);
/*  252 */     return toBean(jsonObject, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toBean(JSONObject jsonObject, JsonConfig jsonConfig) {
/*  259 */     if (jsonObject == null || jsonObject.isNullObject()) {
/*  260 */       return null;
/*      */     }
/*      */     
/*  263 */     Class<?> beanClass = jsonConfig.getRootClass();
/*  264 */     Map classMap = jsonConfig.getClassMap();
/*      */     
/*  266 */     if (beanClass == null) {
/*  267 */       return toBean(jsonObject);
/*      */     }
/*  269 */     if (classMap == null) {
/*  270 */       classMap = Collections.EMPTY_MAP;
/*      */     }
/*      */     
/*  273 */     Object<Object, Object> bean = null;
/*      */     try {
/*  275 */       if (beanClass.isInterface()) {
/*  276 */         if (!Map.class.isAssignableFrom(beanClass)) {
/*  277 */           throw new JSONException("beanClass is an interface. " + beanClass);
/*      */         }
/*  279 */         bean = (Object<Object, Object>)new HashMap<Object, Object>();
/*      */       } else {
/*      */         
/*  282 */         bean = (Object<Object, Object>)jsonConfig.getNewBeanInstanceStrategy().newInstance(beanClass, jsonObject);
/*      */       }
/*      */     
/*  285 */     } catch (JSONException jsone) {
/*  286 */       throw jsone;
/*  287 */     } catch (Exception e) {
/*  288 */       throw new JSONException(e);
/*      */     } 
/*      */     
/*  291 */     Map props = JSONUtils.getProperties(jsonObject);
/*  292 */     PropertyFilter javaPropertyFilter = jsonConfig.getJavaPropertyFilter();
/*  293 */     Iterator<String> entries = jsonObject.names(jsonConfig).iterator();
/*  294 */     while (entries.hasNext()) {
/*  295 */       String name = entries.next();
/*  296 */       Class<?> type = (Class)props.get(name);
/*  297 */       Object value = jsonObject.get(name);
/*  298 */       if (javaPropertyFilter != null && javaPropertyFilter.apply(bean, name, value)) {
/*      */         continue;
/*      */       }
/*  301 */       String key = (Map.class.isAssignableFrom(beanClass) && jsonConfig.isSkipJavaIdentifierTransformationInMapKeys()) ? name : JSONUtils.convertToJavaIdentifier(name, jsonConfig);
/*      */ 
/*      */       
/*  304 */       PropertyNameProcessor propertyNameProcessor = jsonConfig.findJavaPropertyNameProcessor(beanClass);
/*  305 */       if (propertyNameProcessor != null) {
/*  306 */         key = propertyNameProcessor.processPropertyName(beanClass, key);
/*      */       }
/*      */       try {
/*  309 */         if (Map.class.isAssignableFrom(beanClass)) {
/*      */           
/*  311 */           if (JSONUtils.isNull(value)) {
/*  312 */             setProperty(bean, key, value, jsonConfig); continue;
/*  313 */           }  if (value instanceof JSONArray) {
/*  314 */             setProperty(bean, key, convertPropertyValueToCollection(key, value, jsonConfig, name, classMap, List.class), jsonConfig); continue;
/*      */           } 
/*  316 */           if (String.class.isAssignableFrom(type) || JSONUtils.isBoolean(type) || JSONUtils.isNumber(type) || JSONUtils.isString(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */             
/*  319 */             if (jsonConfig.isHandleJettisonEmptyElement() && "".equals(value)) {
/*  320 */               setProperty(bean, key, (Object)null, jsonConfig); continue;
/*      */             } 
/*  322 */             setProperty(bean, key, value, jsonConfig);
/*      */             continue;
/*      */           } 
/*  325 */           Class targetClass = resolveClass(classMap, key, name, type);
/*  326 */           JsonConfig jsc = jsonConfig.copy();
/*  327 */           jsc.setRootClass(targetClass);
/*  328 */           jsc.setClassMap(classMap);
/*  329 */           if (targetClass != null) {
/*  330 */             setProperty(bean, key, toBean((JSONObject)value, jsc), jsonConfig); continue;
/*      */           } 
/*  332 */           setProperty(bean, key, toBean((JSONObject)value), jsonConfig);
/*      */           
/*      */           continue;
/*      */         } 
/*  336 */         PropertyDescriptor pd = PropertyUtils.getPropertyDescriptor(bean, key);
/*  337 */         if (pd != null && pd.getWriteMethod() == null) {
/*  338 */           log.info("Property '" + key + "' of " + bean.getClass() + " has no write method. SKIPPED.");
/*      */           
/*      */           continue;
/*      */         } 
/*  342 */         if (pd != null) {
/*  343 */           Class<?> targetType = pd.getPropertyType();
/*  344 */           if (!JSONUtils.isNull(value)) {
/*  345 */             if (value instanceof JSONArray) {
/*  346 */               if (List.class.isAssignableFrom(pd.getPropertyType())) {
/*  347 */                 setProperty(bean, key, convertPropertyValueToCollection(key, value, jsonConfig, name, classMap, pd.getPropertyType()), jsonConfig); continue;
/*      */               } 
/*  349 */               if (Set.class.isAssignableFrom(pd.getPropertyType())) {
/*  350 */                 setProperty(bean, key, convertPropertyValueToCollection(key, value, jsonConfig, name, classMap, pd.getPropertyType()), jsonConfig);
/*      */                 continue;
/*      */               } 
/*  353 */               setProperty(bean, key, convertPropertyValueToArray(key, value, targetType, jsonConfig, classMap), jsonConfig);
/*      */               continue;
/*      */             } 
/*  356 */             if (String.class.isAssignableFrom(type) || JSONUtils.isBoolean(type) || JSONUtils.isNumber(type) || JSONUtils.isString(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */               
/*  359 */               if (pd != null) {
/*  360 */                 if (jsonConfig.isHandleJettisonEmptyElement() && "".equals(value)) {
/*  361 */                   setProperty(bean, key, (Object)null, jsonConfig); continue;
/*  362 */                 }  if (!targetType.isInstance(value)) {
/*  363 */                   setProperty(bean, key, morphPropertyValue(key, value, type, targetType), jsonConfig);
/*      */                   continue;
/*      */                 } 
/*  366 */                 setProperty(bean, key, value, jsonConfig); continue;
/*      */               } 
/*  368 */               if (beanClass == null || bean instanceof Map) {
/*  369 */                 setProperty(bean, key, value, jsonConfig); continue;
/*      */               } 
/*  371 */               log.warn("Tried to assign property " + key + ":" + type.getName() + " to bean of class " + bean.getClass().getName());
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/*  376 */             if (jsonConfig.isHandleJettisonSingleElementArray()) {
/*  377 */               JSONArray array = (new JSONArray()).element(value, jsonConfig);
/*  378 */               Class newTargetClass = resolveClass(classMap, key, name, type);
/*  379 */               JsonConfig jsonConfig1 = jsonConfig.copy();
/*  380 */               jsonConfig1.setRootClass(newTargetClass);
/*  381 */               jsonConfig1.setClassMap(classMap);
/*  382 */               if (targetType.isArray()) {
/*  383 */                 setProperty(bean, key, JSONArray.toArray(array, jsonConfig1), jsonConfig); continue;
/*  384 */               }  if (JSONArray.class.isAssignableFrom(targetType)) {
/*  385 */                 setProperty(bean, key, array, jsonConfig); continue;
/*  386 */               }  if (List.class.isAssignableFrom(targetType) || Set.class.isAssignableFrom(targetType)) {
/*      */                 
/*  388 */                 jsonConfig1.setCollectionType(targetType);
/*  389 */                 setProperty(bean, key, JSONArray.toCollection(array, jsonConfig1), jsonConfig);
/*      */                 continue;
/*      */               } 
/*  392 */               setProperty(bean, key, toBean((JSONObject)value, jsonConfig1), jsonConfig);
/*      */               continue;
/*      */             } 
/*  395 */             if (targetType == Object.class || targetType.isInterface()) {
/*  396 */               Class<?> targetTypeCopy = targetType;
/*  397 */               targetType = findTargetClass(key, classMap);
/*  398 */               targetType = (targetType == null) ? findTargetClass(name, classMap) : targetType;
/*      */               
/*  400 */               targetType = (targetType == null && targetTypeCopy.isInterface()) ? targetTypeCopy : targetType;
/*      */             } 
/*      */             
/*  403 */             JsonConfig jsc = jsonConfig.copy();
/*  404 */             jsc.setRootClass(targetType);
/*  405 */             jsc.setClassMap(classMap);
/*  406 */             setProperty(bean, key, toBean((JSONObject)value, jsc), jsonConfig);
/*      */             
/*      */             continue;
/*      */           } 
/*  410 */           if (type.isPrimitive()) {
/*      */             
/*  412 */             log.warn("Tried to assign null value to " + key + ":" + type.getName());
/*  413 */             setProperty(bean, key, JSONUtils.getMorpherRegistry().morph(type, null), jsonConfig);
/*      */             continue;
/*      */           } 
/*  416 */           setProperty(bean, key, (Object)null, jsonConfig);
/*      */           
/*      */           continue;
/*      */         } 
/*  420 */         if (!JSONUtils.isNull(value)) {
/*  421 */           if (value instanceof JSONArray) {
/*  422 */             setProperty(bean, key, convertPropertyValueToCollection(key, value, jsonConfig, name, classMap, List.class), jsonConfig); continue;
/*      */           } 
/*  424 */           if (String.class.isAssignableFrom(type) || JSONUtils.isBoolean(type) || JSONUtils.isNumber(type) || JSONUtils.isString(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */             
/*  427 */             if (beanClass == null || bean instanceof Map || jsonConfig.getPropertySetStrategy() != null || !jsonConfig.isIgnorePublicFields()) {
/*      */               
/*  429 */               setProperty(bean, key, value, jsonConfig); continue;
/*      */             } 
/*  431 */             log.warn("Tried to assign property " + key + ":" + type.getName() + " to bean of class " + bean.getClass().getName());
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  436 */           if (jsonConfig.isHandleJettisonSingleElementArray()) {
/*  437 */             Class newTargetClass = resolveClass(classMap, key, name, type);
/*  438 */             JsonConfig jsc = jsonConfig.copy();
/*  439 */             jsc.setRootClass(newTargetClass);
/*  440 */             jsc.setClassMap(classMap);
/*  441 */             setProperty(bean, key, toBean((JSONObject)value, jsc), jsonConfig); continue;
/*      */           } 
/*  443 */           setProperty(bean, key, value, jsonConfig);
/*      */           
/*      */           continue;
/*      */         } 
/*  447 */         if (type.isPrimitive()) {
/*      */           
/*  449 */           log.warn("Tried to assign null value to " + key + ":" + type.getName());
/*  450 */           setProperty(bean, key, JSONUtils.getMorpherRegistry().morph(type, null), jsonConfig);
/*      */           continue;
/*      */         } 
/*  453 */         setProperty(bean, key, (Object)null, jsonConfig);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  458 */       catch (JSONException jsone) {
/*  459 */         throw jsone;
/*  460 */       } catch (Exception e) {
/*  461 */         throw new JSONException("Error while setting property=" + name + " type " + type, e);
/*      */       } 
/*      */     } 
/*      */     
/*  465 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object toBean(JSONObject jsonObject, Object root, JsonConfig jsonConfig) {
/*  472 */     if (jsonObject == null || jsonObject.isNullObject() || root == null) {
/*  473 */       return root;
/*      */     }
/*      */     
/*  476 */     Class<?> rootClass = root.getClass();
/*  477 */     if (rootClass.isInterface()) {
/*  478 */       throw new JSONException("Root bean is an interface. " + rootClass);
/*      */     }
/*      */     
/*  481 */     Map classMap = jsonConfig.getClassMap();
/*  482 */     if (classMap == null) {
/*  483 */       classMap = Collections.EMPTY_MAP;
/*      */     }
/*      */     
/*  486 */     Map props = JSONUtils.getProperties(jsonObject);
/*  487 */     PropertyFilter javaPropertyFilter = jsonConfig.getJavaPropertyFilter();
/*  488 */     Iterator<String> entries = jsonObject.names(jsonConfig).iterator();
/*  489 */     while (entries.hasNext()) {
/*  490 */       String name = entries.next();
/*  491 */       Class<?> type = (Class)props.get(name);
/*  492 */       Object value = jsonObject.get(name);
/*  493 */       if (javaPropertyFilter != null && javaPropertyFilter.apply(root, name, value)) {
/*      */         continue;
/*      */       }
/*  496 */       String key = JSONUtils.convertToJavaIdentifier(name, jsonConfig);
/*      */       try {
/*  498 */         PropertyDescriptor pd = PropertyUtils.getPropertyDescriptor(root, key);
/*  499 */         if (pd != null && pd.getWriteMethod() == null) {
/*  500 */           log.info("Property '" + key + "' of " + root.getClass() + " has no write method. SKIPPED.");
/*      */           
/*      */           continue;
/*      */         } 
/*  504 */         if (!JSONUtils.isNull(value)) {
/*  505 */           if (value instanceof JSONArray) {
/*  506 */             if (pd == null || List.class.isAssignableFrom(pd.getPropertyType())) {
/*  507 */               Class targetClass = resolveClass(classMap, key, name, type);
/*  508 */               Object object = jsonConfig.getNewBeanInstanceStrategy().newInstance(targetClass, null);
/*      */               
/*  510 */               List list = JSONArray.toList((JSONArray)value, object, jsonConfig);
/*  511 */               setProperty(root, key, list, jsonConfig); continue;
/*      */             } 
/*  513 */             Class<?> innerType = JSONUtils.getInnerComponentType(pd.getPropertyType());
/*  514 */             Class<?> targetInnerType = findTargetClass(key, classMap);
/*  515 */             if (innerType.equals(Object.class) && targetInnerType != null && !targetInnerType.equals(Object.class))
/*      */             {
/*  517 */               innerType = targetInnerType;
/*      */             }
/*  519 */             Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(innerType, null);
/*      */             
/*  521 */             Object array = JSONArray.toArray((JSONArray)value, newRoot, jsonConfig);
/*  522 */             if (innerType.isPrimitive() || JSONUtils.isNumber(innerType) || Boolean.class.isAssignableFrom(innerType) || JSONUtils.isString(innerType)) {
/*      */ 
/*      */               
/*  525 */               array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(innerType, 0).getClass(), array);
/*      */             
/*      */             }
/*  528 */             else if (!array.getClass().equals(pd.getPropertyType())) {
/*      */               
/*  530 */               if (!pd.getPropertyType().equals(Object.class)) {
/*      */                 
/*  532 */                 Morpher morpher = JSONUtils.getMorpherRegistry().getMorpherFor(Array.newInstance(innerType, 0).getClass());
/*      */ 
/*      */                 
/*  535 */                 if (IdentityObjectMorpher.getInstance().equals(morpher)) {
/*      */                   
/*  537 */                   ObjectArrayMorpher beanMorpher = new ObjectArrayMorpher((Morpher)new BeanMorpher(innerType, JSONUtils.getMorpherRegistry()));
/*      */                   
/*  539 */                   JSONUtils.getMorpherRegistry().registerMorpher((Morpher)beanMorpher);
/*      */                 } 
/*      */                 
/*  542 */                 array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(innerType, 0).getClass(), array);
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/*  547 */             setProperty(root, key, array, jsonConfig); continue;
/*      */           } 
/*  549 */           if (String.class.isAssignableFrom(type) || JSONUtils.isBoolean(type) || JSONUtils.isNumber(type) || JSONUtils.isString(type) || JSONFunction.class.isAssignableFrom(type)) {
/*      */ 
/*      */             
/*  552 */             if (pd != null) {
/*  553 */               if (jsonConfig.isHandleJettisonEmptyElement() && "".equals(value)) {
/*  554 */                 setProperty(root, key, (Object)null, jsonConfig); continue;
/*  555 */               }  if (!pd.getPropertyType().isInstance(value)) {
/*      */                 
/*  557 */                 Morpher morpher = JSONUtils.getMorpherRegistry().getMorpherFor(pd.getPropertyType());
/*      */                 
/*  559 */                 if (IdentityObjectMorpher.getInstance().equals(morpher)) {
/*      */                   
/*  561 */                   log.warn("Can't transform property '" + key + "' from " + type.getName() + " into " + pd.getPropertyType().getName() + ". Will register a default BeanMorpher");
/*      */ 
/*      */                   
/*  564 */                   JSONUtils.getMorpherRegistry().registerMorpher((Morpher)new BeanMorpher(pd.getPropertyType(), JSONUtils.getMorpherRegistry()));
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/*  569 */                 setProperty(root, key, JSONUtils.getMorpherRegistry().morph(pd.getPropertyType(), value), jsonConfig);
/*      */                 continue;
/*      */               } 
/*  572 */               setProperty(root, key, value, jsonConfig); continue;
/*      */             } 
/*  574 */             if (root instanceof Map) {
/*  575 */               setProperty(root, key, value, jsonConfig); continue;
/*      */             } 
/*  577 */             log.warn("Tried to assign property " + key + ":" + type.getName() + " to bean of class " + root.getClass().getName());
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  582 */           if (pd != null) {
/*  583 */             Class<?> targetClass = pd.getPropertyType();
/*  584 */             if (jsonConfig.isHandleJettisonSingleElementArray()) {
/*  585 */               JSONArray array = (new JSONArray()).element(value, jsonConfig);
/*  586 */               Class newTargetClass = resolveClass(classMap, key, name, type);
/*  587 */               Object object = jsonConfig.getNewBeanInstanceStrategy().newInstance(newTargetClass, (JSONObject)value);
/*      */               
/*  589 */               if (targetClass.isArray()) {
/*  590 */                 setProperty(root, key, JSONArray.toArray(array, object, jsonConfig), jsonConfig); continue;
/*      */               } 
/*  592 */               if (Collection.class.isAssignableFrom(targetClass)) {
/*  593 */                 setProperty(root, key, JSONArray.toList(array, object, jsonConfig), jsonConfig); continue;
/*      */               } 
/*  595 */               if (JSONArray.class.isAssignableFrom(targetClass)) {
/*  596 */                 setProperty(root, key, array, jsonConfig); continue;
/*      */               } 
/*  598 */               setProperty(root, key, toBean((JSONObject)value, object, jsonConfig), jsonConfig);
/*      */               
/*      */               continue;
/*      */             } 
/*  602 */             if (targetClass == Object.class) {
/*  603 */               targetClass = resolveClass(classMap, key, name, type);
/*  604 */               if (targetClass == null) {
/*  605 */                 targetClass = Object.class;
/*      */               }
/*      */             } 
/*  608 */             Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(targetClass, (JSONObject)value);
/*      */             
/*  610 */             setProperty(root, key, toBean((JSONObject)value, newRoot, jsonConfig), jsonConfig);
/*      */             continue;
/*      */           } 
/*  613 */           if (root instanceof Map) {
/*  614 */             Class targetClass = findTargetClass(key, classMap);
/*  615 */             targetClass = (targetClass == null) ? findTargetClass(name, classMap) : targetClass;
/*      */             
/*  617 */             Object newRoot = jsonConfig.getNewBeanInstanceStrategy().newInstance(targetClass, null);
/*      */             
/*  619 */             setProperty(root, key, toBean((JSONObject)value, newRoot, jsonConfig), jsonConfig);
/*      */             continue;
/*      */           } 
/*  622 */           log.warn("Tried to assign property " + key + ":" + type.getName() + " to bean of class " + rootClass.getName());
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  627 */         if (type.isPrimitive()) {
/*      */           
/*  629 */           log.warn("Tried to assign null value to " + key + ":" + type.getName());
/*  630 */           setProperty(root, key, JSONUtils.getMorpherRegistry().morph(type, null), jsonConfig);
/*      */           continue;
/*      */         } 
/*  633 */         setProperty(root, key, (Object)null, jsonConfig);
/*      */       
/*      */       }
/*  636 */       catch (JSONException jsone) {
/*  637 */         throw jsone;
/*  638 */       } catch (Exception e) {
/*  639 */         throw new JSONException("Error while setting property=" + name + " type " + type, e);
/*      */       } 
/*      */     } 
/*      */     
/*  643 */     return root;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONObject _fromBean(Object bean, JsonConfig jsonConfig) {
/*  655 */     if (!addInstance(bean)) {
/*      */       try {
/*  657 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(bean);
/*      */       }
/*  659 */       catch (JSONException jsone) {
/*  660 */         removeInstance(bean);
/*  661 */         fireErrorEvent(jsone, jsonConfig);
/*  662 */         throw jsone;
/*  663 */       } catch (RuntimeException e) {
/*  664 */         removeInstance(bean);
/*  665 */         JSONException jsone = new JSONException(e);
/*  666 */         fireErrorEvent(jsone, jsonConfig);
/*  667 */         throw jsone;
/*      */       } 
/*      */     }
/*  670 */     fireObjectStartEvent(jsonConfig);
/*      */     
/*  672 */     JsonBeanProcessor processor = jsonConfig.findJsonBeanProcessor(bean.getClass());
/*  673 */     if (processor != null) {
/*  674 */       JSONObject json = null;
/*      */       try {
/*  676 */         json = processor.processBean(bean, jsonConfig);
/*  677 */         if (json == null) {
/*  678 */           json = (JSONObject)jsonConfig.findDefaultValueProcessor(bean.getClass()).getDefaultValue(bean.getClass());
/*      */           
/*  680 */           if (json == null) {
/*  681 */             json = new JSONObject(true);
/*      */           }
/*      */         } 
/*  684 */         removeInstance(bean);
/*  685 */         fireObjectEndEvent(jsonConfig);
/*  686 */       } catch (JSONException jsone) {
/*  687 */         removeInstance(bean);
/*  688 */         fireErrorEvent(jsone, jsonConfig);
/*  689 */         throw jsone;
/*  690 */       } catch (RuntimeException e) {
/*  691 */         removeInstance(bean);
/*  692 */         JSONException jsone = new JSONException(e);
/*  693 */         fireErrorEvent(jsone, jsonConfig);
/*  694 */         throw jsone;
/*      */       } 
/*  696 */       return json;
/*      */     } 
/*      */     
/*  699 */     JSONObject jsonObject = defaultBeanProcessing(bean, jsonConfig);
/*  700 */     removeInstance(bean);
/*  701 */     fireObjectEndEvent(jsonConfig);
/*  702 */     return jsonObject;
/*      */   }
/*      */   
/*      */   private static JSONObject defaultBeanProcessing(Object bean, JsonConfig jsonConfig) {
/*  706 */     Class<?> beanClass = bean.getClass();
/*  707 */     PropertyNameProcessor propertyNameProcessor = jsonConfig.findJsonPropertyNameProcessor(beanClass);
/*  708 */     Collection exclusions = jsonConfig.getMergedExcludes(beanClass);
/*  709 */     JSONObject jsonObject = new JSONObject();
/*      */     try {
/*  711 */       PropertyDescriptor[] pds = PropertyUtils.getPropertyDescriptors(bean);
/*  712 */       PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
/*  713 */       for (int i = 0; i < pds.length; i++) {
/*  714 */         boolean bypass = false;
/*  715 */         String key = pds[i].getName();
/*  716 */         if (!exclusions.contains(key))
/*      */         {
/*      */ 
/*      */           
/*  720 */           if (!jsonConfig.isIgnoreTransientFields() || !isTransientField(key, beanClass, jsonConfig)) {
/*      */ 
/*      */ 
/*      */             
/*  724 */             Class<?> type = pds[i].getPropertyType(); try {
/*  725 */               pds[i].getReadMethod();
/*  726 */             } catch (Exception e) {
/*      */               
/*  728 */               String warning = "Property '" + key + "' of " + beanClass + " has no read method. SKIPPED";
/*  729 */               fireWarnEvent(warning, jsonConfig);
/*  730 */               log.info(warning);
/*      */             } 
/*      */             
/*  733 */             if (pds[i].getReadMethod() != null)
/*      */             
/*      */             { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  747 */               if (!isTransient(pds[i].getReadMethod(), jsonConfig)) {
/*      */                 
/*  749 */                 Object value = PropertyUtils.getProperty(bean, key);
/*  750 */                 if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(bean, key, value))
/*      */                 
/*      */                 { 
/*  753 */                   JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(beanClass, type, key);
/*      */                   
/*  755 */                   if (jsonValueProcessor != null) {
/*  756 */                     value = jsonValueProcessor.processObjectValue(key, value, jsonConfig);
/*  757 */                     bypass = true;
/*  758 */                     if (!JsonVerifier.isValidJsonValue(value)) {
/*  759 */                       throw new JSONException("Value is not a valid JSON value. " + value);
/*      */                     }
/*      */                   } 
/*  762 */                   if (propertyNameProcessor != null) {
/*  763 */                     key = propertyNameProcessor.processPropertyName(beanClass, key);
/*      */                   }
/*  765 */                   setValue(jsonObject, key, value, type, jsonConfig, bypass); } 
/*      */               }  }
/*  767 */             else { String warning = "Property '" + key + "' of " + beanClass + " has no read method. SKIPPED";
/*  768 */               fireWarnEvent(warning, jsonConfig);
/*  769 */               log.info(warning); }
/*      */           
/*      */           } 
/*      */         }
/*      */       } 
/*      */       try {
/*  775 */         if (!jsonConfig.isIgnorePublicFields()) {
/*  776 */           Field[] fields = beanClass.getFields();
/*  777 */           for (int j = 0; j < fields.length; j++) {
/*  778 */             boolean bypass = false;
/*  779 */             Field field = fields[j];
/*  780 */             String key = field.getName();
/*  781 */             if (!exclusions.contains(key))
/*      */             {
/*      */ 
/*      */               
/*  785 */               if (!jsonConfig.isIgnoreTransientFields() || !isTransient(field, jsonConfig)) {
/*      */ 
/*      */ 
/*      */                 
/*  789 */                 Class<?> type = field.getType();
/*  790 */                 Object value = field.get(bean);
/*  791 */                 if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(bean, key, value))
/*      */                 
/*      */                 { 
/*  794 */                   JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(beanClass, type, key);
/*  795 */                   if (jsonValueProcessor != null) {
/*  796 */                     value = jsonValueProcessor.processObjectValue(key, value, jsonConfig);
/*  797 */                     bypass = true;
/*  798 */                     if (!JsonVerifier.isValidJsonValue(value)) {
/*  799 */                       throw new JSONException("Value is not a valid JSON value. " + value);
/*      */                     }
/*      */                   } 
/*  802 */                   if (propertyNameProcessor != null) {
/*  803 */                     key = propertyNameProcessor.processPropertyName(beanClass, key);
/*      */                   }
/*  805 */                   setValue(jsonObject, key, value, type, jsonConfig, bypass); } 
/*      */               }  } 
/*      */           } 
/*      */         } 
/*  809 */       } catch (Exception e) {
/*  810 */         log.trace("Couldn't read public fields.", e);
/*      */       } 
/*  812 */     } catch (JSONException jsone) {
/*  813 */       removeInstance(bean);
/*  814 */       fireErrorEvent(jsone, jsonConfig);
/*  815 */       throw jsone;
/*  816 */     } catch (Exception e) {
/*  817 */       removeInstance(bean);
/*  818 */       JSONException jsone = new JSONException(e);
/*  819 */       fireErrorEvent(jsone, jsonConfig);
/*  820 */       throw jsone;
/*      */     } 
/*  822 */     return jsonObject;
/*      */   }
/*      */   
/*      */   private static JSONObject _fromDynaBean(DynaBean bean, JsonConfig jsonConfig) {
/*  826 */     if (bean == null) {
/*  827 */       fireObjectStartEvent(jsonConfig);
/*  828 */       fireObjectEndEvent(jsonConfig);
/*  829 */       return new JSONObject(true);
/*      */     } 
/*      */     
/*  832 */     if (!addInstance(bean)) {
/*      */       try {
/*  834 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(bean);
/*      */       }
/*  836 */       catch (JSONException jsone) {
/*  837 */         removeInstance(bean);
/*  838 */         fireErrorEvent(jsone, jsonConfig);
/*  839 */         throw jsone;
/*  840 */       } catch (RuntimeException e) {
/*  841 */         removeInstance(bean);
/*  842 */         JSONException jsone = new JSONException(e);
/*  843 */         fireErrorEvent(jsone, jsonConfig);
/*  844 */         throw jsone;
/*      */       } 
/*      */     }
/*  847 */     fireObjectStartEvent(jsonConfig);
/*      */     
/*  849 */     JSONObject jsonObject = new JSONObject();
/*      */     try {
/*  851 */       DynaProperty[] props = bean.getDynaClass().getDynaProperties();
/*      */       
/*  853 */       Collection exclusions = jsonConfig.getMergedExcludes();
/*  854 */       PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
/*  855 */       for (int i = 0; i < props.length; i++) {
/*  856 */         boolean bypass = false;
/*  857 */         DynaProperty dynaProperty = props[i];
/*  858 */         String key = dynaProperty.getName();
/*  859 */         if (!exclusions.contains(key))
/*      */         
/*      */         { 
/*  862 */           Class type = dynaProperty.getType();
/*  863 */           Object value = bean.get(dynaProperty.getName());
/*  864 */           if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(bean, key, value))
/*      */           
/*      */           { 
/*  867 */             JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(type, key);
/*  868 */             if (jsonValueProcessor != null) {
/*  869 */               value = jsonValueProcessor.processObjectValue(key, value, jsonConfig);
/*  870 */               bypass = true;
/*  871 */               if (!JsonVerifier.isValidJsonValue(value)) {
/*  872 */                 throw new JSONException("Value is not a valid JSON value. " + value);
/*      */               }
/*      */             } 
/*  875 */             setValue(jsonObject, key, value, type, jsonConfig, bypass); }  } 
/*      */       } 
/*  877 */     } catch (JSONException jsone) {
/*  878 */       removeInstance(bean);
/*  879 */       fireErrorEvent(jsone, jsonConfig);
/*  880 */       throw jsone;
/*  881 */     } catch (RuntimeException e) {
/*  882 */       removeInstance(bean);
/*  883 */       JSONException jsone = new JSONException(e);
/*  884 */       fireErrorEvent(jsone, jsonConfig);
/*  885 */       throw jsone;
/*      */     } 
/*      */     
/*  888 */     removeInstance(bean);
/*  889 */     fireObjectEndEvent(jsonConfig);
/*  890 */     return jsonObject;
/*      */   }
/*      */   
/*      */   private static JSONObject _fromJSONObject(JSONObject object, JsonConfig jsonConfig) {
/*  894 */     if (object == null || object.isNullObject()) {
/*  895 */       fireObjectStartEvent(jsonConfig);
/*  896 */       fireObjectEndEvent(jsonConfig);
/*  897 */       return new JSONObject(true);
/*      */     } 
/*      */     
/*  900 */     if (!addInstance(object)) {
/*      */       try {
/*  902 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(object);
/*      */       }
/*  904 */       catch (JSONException jsone) {
/*  905 */         removeInstance(object);
/*  906 */         fireErrorEvent(jsone, jsonConfig);
/*  907 */         throw jsone;
/*  908 */       } catch (RuntimeException e) {
/*  909 */         removeInstance(object);
/*  910 */         JSONException jsone = new JSONException(e);
/*  911 */         fireErrorEvent(jsone, jsonConfig);
/*  912 */         throw jsone;
/*      */       } 
/*      */     }
/*  915 */     fireObjectStartEvent(jsonConfig);
/*      */     
/*  917 */     JSONArray sa = object.names(jsonConfig);
/*  918 */     Collection exclusions = jsonConfig.getMergedExcludes();
/*  919 */     JSONObject jsonObject = new JSONObject();
/*  920 */     PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
/*  921 */     for (Iterator i = sa.iterator(); i.hasNext(); ) {
/*  922 */       Object k = i.next();
/*  923 */       if (k == null) {
/*  924 */         throw new JSONException("JSON keys cannot be null.");
/*      */       }
/*  926 */       if (!(k instanceof String) && !jsonConfig.isAllowNonStringKeys()) {
/*  927 */         throw new ClassCastException("JSON keys must be strings.");
/*      */       }
/*  929 */       String key = String.valueOf(k);
/*  930 */       if ("null".equals(key)) {
/*  931 */         throw new NullPointerException("JSON keys must not be null nor the 'null' string.");
/*      */       }
/*  933 */       if (exclusions.contains(key)) {
/*      */         continue;
/*      */       }
/*  936 */       Object value = object.opt(key);
/*  937 */       if (jsonPropertyFilter != null && jsonPropertyFilter.apply(object, key, value)) {
/*      */         continue;
/*      */       }
/*  940 */       if (jsonObject.properties.containsKey(key)) {
/*  941 */         jsonObject.accumulate(key, value, jsonConfig);
/*  942 */         firePropertySetEvent(key, value, true, jsonConfig); continue;
/*      */       } 
/*  944 */       jsonObject.setInternal(key, value, jsonConfig);
/*  945 */       firePropertySetEvent(key, value, false, jsonConfig);
/*      */     } 
/*      */ 
/*      */     
/*  949 */     removeInstance(object);
/*  950 */     fireObjectEndEvent(jsonConfig);
/*  951 */     return jsonObject;
/*      */   }
/*      */   
/*      */   private static JSONObject _fromJSONString(JSONString string, JsonConfig jsonConfig) {
/*  955 */     return _fromJSONTokener(new JSONTokener(string.toJSONString()), jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONObject _fromJSONTokener(JSONTokener tokener, JsonConfig jsonConfig) {
/*      */     try {
/*  965 */       if (tokener.matches("null.*")) {
/*  966 */         fireObjectStartEvent(jsonConfig);
/*  967 */         fireObjectEndEvent(jsonConfig);
/*  968 */         return new JSONObject(true);
/*      */       } 
/*      */       
/*  971 */       if (tokener.nextClean() != '{') {
/*  972 */         throw tokener.syntaxError("A JSONObject text must begin with '{'");
/*      */       }
/*  974 */       fireObjectStartEvent(jsonConfig);
/*      */       
/*  976 */       Collection exclusions = jsonConfig.getMergedExcludes();
/*  977 */       PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
/*  978 */       JSONObject jsonObject = new JSONObject();
/*      */       while (true) {
/*  980 */         char c = tokener.nextClean();
/*  981 */         switch (c) {
/*      */           case '\000':
/*  983 */             throw tokener.syntaxError("A JSONObject text must end with '}'");
/*      */           case '}':
/*  985 */             fireObjectEndEvent(jsonConfig);
/*  986 */             return jsonObject;
/*      */         } 
/*  988 */         tokener.back();
/*  989 */         String key = tokener.nextValue(jsonConfig).toString();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  997 */         c = tokener.nextClean();
/*  998 */         if (c == '=') {
/*  999 */           if (tokener.next() != '>') {
/* 1000 */             tokener.back();
/*      */           }
/* 1002 */         } else if (c != ':') {
/* 1003 */           throw tokener.syntaxError("Expected a ':' after a key");
/*      */         } 
/*      */         
/* 1006 */         char peek = tokener.peek();
/* 1007 */         boolean quoted = (peek == '"' || peek == '\'');
/* 1008 */         Object v = tokener.nextValue(jsonConfig);
/* 1009 */         if (quoted || !JSONUtils.isFunctionHeader(v)) {
/* 1010 */           if (exclusions.contains(key)) {
/* 1011 */             switch (tokener.nextClean()) {
/*      */               case ',':
/*      */               case ';':
/* 1014 */                 if (tokener.nextClean() == '}') {
/* 1015 */                   fireObjectEndEvent(jsonConfig);
/* 1016 */                   return jsonObject;
/*      */                 } 
/* 1018 */                 tokener.back();
/*      */                 continue;
/*      */               case '}':
/* 1021 */                 fireObjectEndEvent(jsonConfig);
/* 1022 */                 return jsonObject;
/*      */             } 
/* 1024 */             throw tokener.syntaxError("Expected a ',' or '}'");
/*      */           } 
/*      */ 
/*      */           
/* 1028 */           if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(tokener, key, v)) {
/* 1029 */             if (quoted && v instanceof String && (JSONUtils.mayBeJSON((String)v) || JSONUtils.isFunction(v))) {
/* 1030 */               v = "\"" + v + "\"";
/*      */             }
/* 1032 */             if (jsonObject.properties.containsKey(key)) {
/* 1033 */               jsonObject.accumulate(key, v, jsonConfig);
/* 1034 */               firePropertySetEvent(key, v, true, jsonConfig);
/*      */             } else {
/* 1036 */               jsonObject.element(key, v, jsonConfig);
/* 1037 */               firePropertySetEvent(key, v, false, jsonConfig);
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/* 1042 */           String params = JSONUtils.getFunctionParams((String)v);
/*      */           
/* 1044 */           int i = 0;
/* 1045 */           StringBuffer sb = new StringBuffer();
/*      */           do {
/* 1047 */             char ch = tokener.next();
/* 1048 */             if (ch == '\000') {
/*      */               break;
/*      */             }
/* 1051 */             if (ch == '{') {
/* 1052 */               i++;
/*      */             }
/* 1054 */             if (ch == '}') {
/* 1055 */               i--;
/*      */             }
/* 1057 */             sb.append(ch);
/* 1058 */           } while (i != 0);
/*      */ 
/*      */ 
/*      */           
/* 1062 */           if (i != 0) {
/* 1063 */             throw tokener.syntaxError("Unbalanced '{' or '}' on prop: " + v);
/*      */           }
/*      */           
/* 1066 */           String text = sb.toString();
/* 1067 */           text = text.substring(1, text.length() - 1).trim();
/*      */           
/* 1069 */           Object value = new JSONFunction((params != null) ? StringUtils.split(params, ",") : null, text);
/*      */           
/* 1071 */           if (jsonPropertyFilter == null || !jsonPropertyFilter.apply(tokener, key, value)) {
/* 1072 */             if (jsonObject.properties.containsKey(key)) {
/* 1073 */               jsonObject.accumulate(key, value, jsonConfig);
/* 1074 */               firePropertySetEvent(key, value, true, jsonConfig);
/*      */             } else {
/* 1076 */               jsonObject.element(key, value, jsonConfig);
/* 1077 */               firePropertySetEvent(key, value, false, jsonConfig);
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1086 */         switch (tokener.nextClean()) {
/*      */           case ',':
/*      */           case ';':
/* 1089 */             if (tokener.nextClean() == '}') {
/* 1090 */               fireObjectEndEvent(jsonConfig);
/* 1091 */               return jsonObject;
/*      */             } 
/* 1093 */             tokener.back();
/*      */             continue;
/*      */           case '}':
/* 1096 */             fireObjectEndEvent(jsonConfig);
/* 1097 */             return jsonObject;
/*      */         }  break;
/* 1099 */       }  throw tokener.syntaxError("Expected a ',' or '}'");
/*      */     
/*      */     }
/* 1102 */     catch (JSONException jsone) {
/* 1103 */       fireErrorEvent(jsone, jsonConfig);
/* 1104 */       throw jsone;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static JSONObject _fromMap(Map map, JsonConfig jsonConfig) {
/* 1109 */     if (map == null) {
/* 1110 */       fireObjectStartEvent(jsonConfig);
/* 1111 */       fireObjectEndEvent(jsonConfig);
/* 1112 */       return new JSONObject(true);
/*      */     } 
/*      */     
/* 1115 */     if (!addInstance(map)) {
/*      */       try {
/* 1117 */         return jsonConfig.getCycleDetectionStrategy().handleRepeatedReferenceAsObject(map);
/*      */       }
/* 1119 */       catch (JSONException jsone) {
/* 1120 */         removeInstance(map);
/* 1121 */         fireErrorEvent(jsone, jsonConfig);
/* 1122 */         throw jsone;
/* 1123 */       } catch (RuntimeException e) {
/* 1124 */         removeInstance(map);
/* 1125 */         JSONException jsone = new JSONException(e);
/* 1126 */         fireErrorEvent(jsone, jsonConfig);
/* 1127 */         throw jsone;
/*      */       } 
/*      */     }
/* 1130 */     fireObjectStartEvent(jsonConfig);
/*      */     
/* 1132 */     Collection exclusions = jsonConfig.getMergedExcludes();
/* 1133 */     JSONObject jsonObject = new JSONObject();
/* 1134 */     PropertyFilter jsonPropertyFilter = jsonConfig.getJsonPropertyFilter();
/*      */     try {
/* 1136 */       Iterator<Map.Entry> entries = map.entrySet().iterator();
/* 1137 */       while (entries.hasNext()) {
/* 1138 */         boolean bypass = false;
/* 1139 */         Map.Entry entry = entries.next();
/* 1140 */         Object k = entry.getKey();
/* 1141 */         if (k == null) {
/* 1142 */           throw new JSONException("JSON keys cannot be null.");
/*      */         }
/* 1144 */         if (!(k instanceof String) && !jsonConfig.isAllowNonStringKeys()) {
/* 1145 */           throw new ClassCastException("JSON keys must be strings.");
/*      */         }
/* 1147 */         String key = String.valueOf(k);
/* 1148 */         if ("null".equals(key)) {
/* 1149 */           throw new NullPointerException("JSON keys must not be null nor the 'null' string.");
/*      */         }
/* 1151 */         if (exclusions.contains(key)) {
/*      */           continue;
/*      */         }
/* 1154 */         Object value = entry.getValue();
/* 1155 */         if (jsonPropertyFilter != null && jsonPropertyFilter.apply(map, key, value)) {
/*      */           continue;
/*      */         }
/* 1158 */         if (value != null) {
/* 1159 */           JsonValueProcessor jsonValueProcessor = jsonConfig.findJsonValueProcessor(value.getClass(), key);
/*      */           
/* 1161 */           if (jsonValueProcessor != null) {
/* 1162 */             value = jsonValueProcessor.processObjectValue(key, value, jsonConfig);
/* 1163 */             bypass = true;
/* 1164 */             if (!JsonVerifier.isValidJsonValue(value)) {
/* 1165 */               throw new JSONException("Value is not a valid JSON value. " + value);
/*      */             }
/*      */           } 
/* 1168 */           setValue(jsonObject, key, value, value.getClass(), jsonConfig, bypass); continue;
/*      */         } 
/* 1170 */         if (jsonObject.properties.containsKey(key)) {
/* 1171 */           jsonObject.accumulate(key, JSONNull.getInstance());
/* 1172 */           firePropertySetEvent(key, JSONNull.getInstance(), true, jsonConfig); continue;
/*      */         } 
/* 1174 */         jsonObject.element(key, JSONNull.getInstance());
/* 1175 */         firePropertySetEvent(key, JSONNull.getInstance(), false, jsonConfig);
/*      */       }
/*      */     
/*      */     }
/* 1179 */     catch (JSONException jsone) {
/* 1180 */       removeInstance(map);
/* 1181 */       fireErrorEvent(jsone, jsonConfig);
/* 1182 */       throw jsone;
/* 1183 */     } catch (RuntimeException e) {
/* 1184 */       removeInstance(map);
/* 1185 */       JSONException jsone = new JSONException(e);
/* 1186 */       fireErrorEvent(jsone, jsonConfig);
/* 1187 */       throw jsone;
/*      */     } 
/*      */     
/* 1190 */     removeInstance(map);
/* 1191 */     fireObjectEndEvent(jsonConfig);
/* 1192 */     return jsonObject;
/*      */   }
/*      */   
/*      */   private static JSONObject _fromString(String str, JsonConfig jsonConfig) {
/* 1196 */     if (str == null || "null".equals(str)) {
/* 1197 */       fireObjectStartEvent(jsonConfig);
/* 1198 */       fireObjectEndEvent(jsonConfig);
/* 1199 */       return new JSONObject(true);
/*      */     } 
/* 1201 */     return _fromJSONTokener(new JSONTokener(str), jsonConfig);
/*      */   }
/*      */ 
/*      */   
/*      */   private static Object convertPropertyValueToArray(String key, Object value, Class targetType, JsonConfig jsonConfig, Map classMap) {
/* 1206 */     Class<?> innerType = JSONUtils.getInnerComponentType(targetType);
/* 1207 */     Class<?> targetInnerType = findTargetClass(key, classMap);
/* 1208 */     if (innerType.equals(Object.class) && targetInnerType != null && !targetInnerType.equals(Object.class))
/*      */     {
/* 1210 */       innerType = targetInnerType;
/*      */     }
/* 1212 */     JsonConfig jsc = jsonConfig.copy();
/* 1213 */     jsc.setRootClass(innerType);
/* 1214 */     jsc.setClassMap(classMap);
/* 1215 */     Object array = JSONArray.toArray((JSONArray)value, jsc);
/* 1216 */     if (innerType.isPrimitive() || JSONUtils.isNumber(innerType) || Boolean.class.isAssignableFrom(innerType) || JSONUtils.isString(innerType)) {
/*      */       
/* 1218 */       array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(innerType, 0).getClass(), array);
/*      */     
/*      */     }
/* 1221 */     else if (!array.getClass().equals(targetType)) {
/*      */       
/* 1223 */       if (!targetType.equals(Object.class)) {
/* 1224 */         Morpher morpher = JSONUtils.getMorpherRegistry().getMorpherFor(Array.newInstance(innerType, 0).getClass());
/*      */ 
/*      */         
/* 1227 */         if (IdentityObjectMorpher.getInstance().equals(morpher)) {
/*      */           
/* 1229 */           ObjectArrayMorpher beanMorpher = new ObjectArrayMorpher((Morpher)new BeanMorpher(innerType, JSONUtils.getMorpherRegistry()));
/*      */           
/* 1231 */           JSONUtils.getMorpherRegistry().registerMorpher((Morpher)beanMorpher);
/*      */         } 
/*      */         
/* 1234 */         array = JSONUtils.getMorpherRegistry().morph(Array.newInstance(innerType, 0).getClass(), array);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1239 */     return array;
/*      */   }
/*      */ 
/*      */   
/*      */   private static List convertPropertyValueToList(String key, Object value, JsonConfig jsonConfig, String name, Map classMap) {
/* 1244 */     Class targetClass = findTargetClass(key, classMap);
/* 1245 */     targetClass = (targetClass == null) ? findTargetClass(name, classMap) : targetClass;
/* 1246 */     JsonConfig jsc = jsonConfig.copy();
/* 1247 */     jsc.setRootClass(targetClass);
/* 1248 */     jsc.setClassMap(classMap);
/* 1249 */     List list = (List)JSONArray.toCollection((JSONArray)value, jsc);
/* 1250 */     return list;
/*      */   }
/*      */ 
/*      */   
/*      */   private static Collection convertPropertyValueToCollection(String key, Object value, JsonConfig jsonConfig, String name, Map classMap, Class collectionType) {
/* 1255 */     Class targetClass = findTargetClass(key, classMap);
/* 1256 */     targetClass = (targetClass == null) ? findTargetClass(name, classMap) : targetClass;
/* 1257 */     JsonConfig jsc = jsonConfig.copy();
/* 1258 */     jsc.setRootClass(targetClass);
/* 1259 */     jsc.setClassMap(classMap);
/* 1260 */     jsc.setCollectionType(collectionType);
/* 1261 */     return JSONArray.toCollection((JSONArray)value, jsc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Class resolveClass(Map classMap, String key, String name, Class<ArrayList> type) {
/* 1299 */     Class<ArrayList> targetClass = findTargetClass(key, classMap);
/* 1300 */     if (targetClass == null) {
/* 1301 */       targetClass = findTargetClass(name, classMap);
/*      */     }
/* 1303 */     if (targetClass == null && type != null) {
/* 1304 */       if (List.class.equals(type)) {
/* 1305 */         targetClass = ArrayList.class;
/* 1306 */       } else if (Map.class.equals(type)) {
/* 1307 */         Class<LinkedHashMap> clazz = LinkedHashMap.class;
/* 1308 */       } else if (Set.class.equals(type)) {
/* 1309 */         Class<LinkedHashSet> clazz = LinkedHashSet.class;
/* 1310 */       } else if (!type.isInterface() && !Object.class.equals(type)) {
/* 1311 */         targetClass = type;
/*      */       } 
/*      */     }
/* 1314 */     return targetClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Class findTargetClass(String key, Map classMap) {
/* 1323 */     Class targetClass = (Class)classMap.get(key);
/* 1324 */     if (targetClass == null) {
/*      */ 
/*      */ 
/*      */       
/* 1328 */       Iterator<Map.Entry> i = classMap.entrySet().iterator();
/* 1329 */       while (i.hasNext()) {
/* 1330 */         Map.Entry entry = i.next();
/* 1331 */         if (RegexpUtils.getMatcher((String)entry.getKey()).matches(key)) {
/*      */           
/* 1333 */           targetClass = (Class)entry.getValue();
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1339 */     return targetClass;
/*      */   }
/*      */   
/*      */   private static boolean isTransientField(String name, Class beanClass, JsonConfig jsonConfig) {
/*      */     try {
/* 1344 */       Field field = beanClass.getDeclaredField(name);
/* 1345 */       if ((field.getModifiers() & 0x80) == 128) return true; 
/* 1346 */       return isTransient(field, jsonConfig);
/* 1347 */     } catch (Exception e) {
/* 1348 */       log.info("Error while inspecting field " + beanClass + "." + name + " for transient status.", e);
/*      */       
/* 1350 */       return false;
/*      */     } 
/*      */   }
/*      */   private static boolean isTransient(AnnotatedElement element, JsonConfig jsonConfig) {
/* 1354 */     for (Iterator<String> annotations = jsonConfig.getIgnoreFieldAnnotations().iterator(); annotations.hasNext();) {
/*      */       try {
/* 1356 */         String annotationClassName = annotations.next();
/* 1357 */         if (element.getAnnotation(Class.forName(annotationClassName)) != null) return true; 
/* 1358 */       } catch (Exception e) {
/* 1359 */         log.info("Error while inspecting " + element + " for transient status.", e);
/*      */       } 
/*      */     } 
/* 1362 */     return false;
/*      */   }
/*      */   
/*      */   private static Object morphPropertyValue(String key, Object value, Class type, Class<?> targetType) {
/* 1366 */     Morpher morpher = JSONUtils.getMorpherRegistry().getMorpherFor(targetType);
/*      */     
/* 1368 */     if (IdentityObjectMorpher.getInstance().equals(morpher)) {
/*      */       
/* 1370 */       log.warn("Can't transform property '" + key + "' from " + type.getName() + " into " + targetType.getName() + ". Will register a default Morpher");
/*      */       
/* 1372 */       if (Enum.class.isAssignableFrom(targetType)) {
/* 1373 */         JSONUtils.getMorpherRegistry().registerMorpher((Morpher)new EnumMorpher(targetType));
/*      */       } else {
/*      */         
/* 1376 */         JSONUtils.getMorpherRegistry().registerMorpher((Morpher)new BeanMorpher(targetType, JSONUtils.getMorpherRegistry()));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1381 */     value = JSONUtils.getMorpherRegistry().morph(targetType, value);
/*      */     
/* 1383 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void setProperty(Object bean, String key, Object value, JsonConfig jsonConfig) throws Exception {
/* 1392 */     PropertySetStrategy propertySetStrategy = (jsonConfig.getPropertySetStrategy() != null) ? jsonConfig.getPropertySetStrategy() : PropertySetStrategy.DEFAULT;
/*      */     
/* 1394 */     propertySetStrategy.setProperty(bean, key, value, jsonConfig);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void setValue(JSONObject jsonObject, String key, Object value, Class<?> type, JsonConfig jsonConfig, boolean bypass) {
/* 1399 */     boolean accumulated = false;
/* 1400 */     if (value == null) {
/* 1401 */       value = jsonConfig.findDefaultValueProcessor(type).getDefaultValue(type);
/*      */       
/* 1403 */       if (!JsonVerifier.isValidJsonValue(value)) {
/* 1404 */         throw new JSONException("Value is not a valid JSON value. " + value);
/*      */       }
/*      */     } 
/* 1407 */     if (jsonObject.properties.containsKey(key)) {
/* 1408 */       if (String.class.isAssignableFrom(type)) {
/* 1409 */         Object o = jsonObject.opt(key);
/* 1410 */         if (o instanceof JSONArray) {
/* 1411 */           ((JSONArray)o).addString((String)value);
/*      */         } else {
/* 1413 */           jsonObject.properties.put(key, (new JSONArray()).element(o).addString((String)value));
/*      */         } 
/*      */       } else {
/*      */         
/* 1417 */         jsonObject.accumulate(key, value, jsonConfig);
/*      */       } 
/* 1419 */       accumulated = true;
/*      */     }
/* 1421 */     else if (bypass || String.class.isAssignableFrom(type)) {
/* 1422 */       jsonObject.properties.put(key, value);
/*      */     } else {
/* 1424 */       jsonObject.setInternal(key, value, jsonConfig);
/*      */     } 
/*      */ 
/*      */     
/* 1428 */     value = jsonObject.opt(key);
/* 1429 */     if (accumulated) {
/* 1430 */       JSONArray array = (JSONArray)value;
/* 1431 */       value = array.get(array.size() - 1);
/*      */     } 
/* 1433 */     firePropertySetEvent(key, value, accumulated, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject() {
/* 1450 */     this.properties = (Map)new ListOrderedMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject(boolean isNull) {
/* 1457 */     this();
/* 1458 */     this.nullObject = isNull;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject accumulate(String key, boolean value) {
/* 1475 */     return _accumulate(key, value ? Boolean.TRUE : Boolean.FALSE, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject accumulate(String key, double value) {
/* 1492 */     return _accumulate(key, Double.valueOf(value), new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject accumulate(String key, int value) {
/* 1509 */     return _accumulate(key, Integer.valueOf(value), new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject accumulate(String key, long value) {
/* 1526 */     return _accumulate(key, Long.valueOf(value), new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject accumulate(String key, Object value) {
/* 1543 */     return _accumulate(key, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject accumulate(String key, Object value, JsonConfig jsonConfig) {
/* 1560 */     return _accumulate(key, value, jsonConfig);
/*      */   }
/*      */   
/*      */   public void accumulateAll(Map map) {
/* 1564 */     accumulateAll(map, new JsonConfig());
/*      */   }
/*      */   
/*      */   public void accumulateAll(Map map, JsonConfig jsonConfig) {
/* 1568 */     if (map instanceof JSONObject) {
/* 1569 */       Iterator<Map.Entry> entries = map.entrySet().iterator();
/* 1570 */       while (entries.hasNext()) {
/* 1571 */         Map.Entry entry = entries.next();
/* 1572 */         String key = (String)entry.getKey();
/* 1573 */         Object value = entry.getValue();
/* 1574 */         accumulate(key, value, jsonConfig);
/*      */       } 
/*      */     } else {
/* 1577 */       Iterator<Map.Entry> entries = map.entrySet().iterator();
/* 1578 */       while (entries.hasNext()) {
/* 1579 */         Map.Entry entry = entries.next();
/* 1580 */         String key = String.valueOf(entry.getKey());
/* 1581 */         Object value = entry.getValue();
/* 1582 */         accumulate(key, value, jsonConfig);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void clear() {
/* 1588 */     this.properties.clear();
/*      */   }
/*      */   
/*      */   public int compareTo(Object obj) {
/* 1592 */     if (obj != null && obj instanceof JSONObject) {
/* 1593 */       JSONObject other = (JSONObject)obj;
/* 1594 */       int size1 = size();
/* 1595 */       int size2 = other.size();
/* 1596 */       if (size1 < size2)
/* 1597 */         return -1; 
/* 1598 */       if (size1 > size2)
/* 1599 */         return 1; 
/* 1600 */       if (equals(other)) {
/* 1601 */         return 0;
/*      */       }
/*      */     } 
/* 1604 */     return -1;
/*      */   }
/*      */   
/*      */   public boolean containsKey(Object key) {
/* 1608 */     return this.properties.containsKey(key);
/*      */   }
/*      */   
/*      */   public boolean containsValue(Object value) {
/* 1612 */     return containsValue(value, new JsonConfig());
/*      */   }
/*      */   
/*      */   public boolean containsValue(Object value, JsonConfig jsonConfig) {
/*      */     try {
/* 1617 */       value = processValue(value, jsonConfig);
/* 1618 */     } catch (JSONException e) {
/* 1619 */       return false;
/*      */     } 
/* 1621 */     return this.properties.containsValue(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject discard(String key) {
/* 1631 */     verifyIsNull();
/* 1632 */     this.properties.remove(key);
/* 1633 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, boolean value) {
/* 1645 */     verifyIsNull();
/* 1646 */     return element(key, value ? Boolean.TRUE : Boolean.FALSE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, Collection value) {
/* 1659 */     return element(key, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, Collection value, JsonConfig jsonConfig) {
/* 1672 */     if (!(value instanceof JSONArray)) {
/* 1673 */       value = JSONArray.fromObject(value, jsonConfig);
/*      */     }
/* 1675 */     return setInternal(key, value, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, double value) {
/* 1687 */     verifyIsNull();
/* 1688 */     Double d = new Double(value);
/* 1689 */     JSONUtils.testValidity(d);
/* 1690 */     return element(key, d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, int value) {
/* 1702 */     verifyIsNull();
/* 1703 */     return element(key, new Integer(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, long value) {
/* 1715 */     verifyIsNull();
/* 1716 */     return element(key, new Long(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, Map value) {
/* 1729 */     return element(key, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, Map value, JsonConfig jsonConfig) {
/* 1742 */     verifyIsNull();
/* 1743 */     if (value instanceof JSONObject) {
/* 1744 */       return setInternal(key, value, jsonConfig);
/*      */     }
/* 1746 */     return element(key, fromObject(value, jsonConfig), jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, Object value) {
/* 1764 */     return element(key, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject element(String key, Object value, JsonConfig jsonConfig) {
/* 1781 */     verifyIsNull();
/* 1782 */     if (key == null) {
/* 1783 */       throw new JSONException("Null key.");
/*      */     }
/* 1785 */     if (value != null) {
/* 1786 */       value = processValue(key, value, jsonConfig);
/* 1787 */       _setInternal(key, value, jsonConfig);
/*      */     } else {
/* 1789 */       remove(key);
/*      */     } 
/* 1791 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject elementOpt(String key, Object value) {
/* 1806 */     return elementOpt(key, value, new JsonConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject elementOpt(String key, Object value, JsonConfig jsonConfig) {
/* 1821 */     verifyIsNull();
/* 1822 */     if (key != null && value != null) {
/* 1823 */       element(key, value, jsonConfig);
/*      */     }
/* 1825 */     return this;
/*      */   }
/*      */   
/*      */   public Set entrySet() {
/* 1829 */     return Collections.unmodifiableSet(this.properties.entrySet());
/*      */   }
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1833 */     if (obj == this) {
/* 1834 */       return true;
/*      */     }
/* 1836 */     if (obj == null) {
/* 1837 */       return false;
/*      */     }
/*      */     
/* 1840 */     if (!(obj instanceof JSONObject)) {
/* 1841 */       return false;
/*      */     }
/*      */     
/* 1844 */     JSONObject other = (JSONObject)obj;
/*      */     
/* 1846 */     if (isNullObject()) {
/* 1847 */       if (other.isNullObject()) {
/* 1848 */         return true;
/*      */       }
/* 1850 */       return false;
/*      */     } 
/*      */     
/* 1853 */     if (other.isNullObject()) {
/* 1854 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1858 */     if (other.size() != size()) {
/* 1859 */       return false;
/*      */     }
/*      */     
/* 1862 */     Iterator<String> keys = this.properties.keySet().iterator();
/* 1863 */     while (keys.hasNext()) {
/* 1864 */       String key = keys.next();
/* 1865 */       if (!other.properties.containsKey(key)) {
/* 1866 */         return false;
/*      */       }
/* 1868 */       Object o1 = this.properties.get(key);
/* 1869 */       Object o2 = other.properties.get(key);
/*      */       
/* 1871 */       if (JSONNull.getInstance().equals(o1)) {
/*      */         
/* 1873 */         if (JSONNull.getInstance().equals(o2)) {
/*      */           continue;
/*      */         }
/*      */         
/* 1877 */         return false;
/*      */       } 
/*      */       
/* 1880 */       if (JSONNull.getInstance().equals(o2))
/*      */       {
/* 1882 */         return false;
/*      */       }
/*      */ 
/*      */       
/* 1886 */       if (o1 instanceof String && o2 instanceof JSONFunction) {
/* 1887 */         if (!o1.equals(String.valueOf(o2)))
/* 1888 */           return false;  continue;
/*      */       } 
/* 1890 */       if (o1 instanceof JSONFunction && o2 instanceof String) {
/* 1891 */         if (!o2.equals(String.valueOf(o1)))
/* 1892 */           return false;  continue;
/*      */       } 
/* 1894 */       if (o1 instanceof JSONObject && o2 instanceof JSONObject) {
/* 1895 */         if (!o1.equals(o2))
/* 1896 */           return false;  continue;
/*      */       } 
/* 1898 */       if (o1 instanceof JSONArray && o2 instanceof JSONArray) {
/* 1899 */         if (!o1.equals(o2))
/* 1900 */           return false;  continue;
/*      */       } 
/* 1902 */       if (o1 instanceof JSONFunction && o2 instanceof JSONFunction) {
/* 1903 */         if (!o1.equals(o2))
/* 1904 */           return false; 
/*      */         continue;
/*      */       } 
/* 1907 */       if (o1 instanceof String) {
/* 1908 */         if (!o1.equals(String.valueOf(o2)))
/* 1909 */           return false;  continue;
/*      */       } 
/* 1911 */       if (o2 instanceof String) {
/* 1912 */         if (!o2.equals(String.valueOf(o1)))
/* 1913 */           return false; 
/*      */         continue;
/*      */       } 
/* 1916 */       Morpher m1 = JSONUtils.getMorpherRegistry().getMorpherFor(o1.getClass());
/*      */       
/* 1918 */       Morpher m2 = JSONUtils.getMorpherRegistry().getMorpherFor(o2.getClass());
/*      */       
/* 1920 */       if (m1 != null && m1 != IdentityObjectMorpher.getInstance()) {
/* 1921 */         if (!o1.equals(JSONUtils.getMorpherRegistry().morph(o1.getClass(), o2)))
/*      */         {
/* 1923 */           return false; }  continue;
/*      */       } 
/* 1925 */       if (m2 != null && m2 != IdentityObjectMorpher.getInstance()) {
/* 1926 */         if (!JSONUtils.getMorpherRegistry().morph(o1.getClass(), o1).equals(o2))
/*      */         {
/*      */           
/* 1929 */           return false; } 
/*      */         continue;
/*      */       } 
/* 1932 */       if (!o1.equals(o2)) {
/* 1933 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1939 */     return true;
/*      */   }
/*      */   
/*      */   public Object get(Object key) {
/* 1943 */     if (key instanceof String) {
/* 1944 */       return get((String)key);
/*      */     }
/* 1946 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(String key) {
/* 1957 */     verifyIsNull();
/* 1958 */     return this.properties.get(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String key) {
/* 1970 */     verifyIsNull();
/* 1971 */     Object o = get(key);
/* 1972 */     if (o != null) {
/* 1973 */       if (o.equals(Boolean.FALSE) || (o instanceof String && ((String)o).equalsIgnoreCase("false")))
/*      */       {
/* 1975 */         return false; } 
/* 1976 */       if (o.equals(Boolean.TRUE) || (o instanceof String && ((String)o).equalsIgnoreCase("true")))
/*      */       {
/* 1978 */         return true;
/*      */       }
/*      */     } 
/* 1981 */     throw new JSONException("JSONObject[" + JSONUtils.quote(key) + "] is not a Boolean.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String key) {
/* 1993 */     verifyIsNull();
/* 1994 */     Object o = get(key);
/* 1995 */     if (o != null) {
/*      */       try {
/* 1997 */         return (o instanceof Number) ? ((Number)o).doubleValue() : Double.parseDouble((String)o);
/*      */       }
/* 1999 */       catch (Exception e) {
/* 2000 */         throw new JSONException("JSONObject[" + JSONUtils.quote(key) + "] is not a number.");
/*      */       } 
/*      */     }
/* 2003 */     throw new JSONException("JSONObject[" + JSONUtils.quote(key) + "] is not a number.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String key) {
/* 2016 */     verifyIsNull();
/* 2017 */     Object o = get(key);
/* 2018 */     if (o != null) {
/* 2019 */       return (o instanceof Number) ? ((Number)o).intValue() : (int)getDouble(key);
/*      */     }
/* 2021 */     throw new JSONException("JSONObject[" + JSONUtils.quote(key) + "] is not a number.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray getJSONArray(String key) {
/* 2033 */     verifyIsNull();
/* 2034 */     Object o = get(key);
/* 2035 */     if (o != null && o instanceof JSONArray) {
/* 2036 */       return (JSONArray)o;
/*      */     }
/* 2038 */     throw new JSONException("JSONObject[" + JSONUtils.quote(key) + "] is not a JSONArray.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject getJSONObject(String key) {
/* 2050 */     verifyIsNull();
/* 2051 */     Object o = get(key);
/* 2052 */     if (JSONNull.getInstance().equals(o))
/*      */     {
/* 2054 */       return new JSONObject(true); } 
/* 2055 */     if (o instanceof JSONObject) {
/* 2056 */       return (JSONObject)o;
/*      */     }
/* 2058 */     throw new JSONException("JSONObject[" + JSONUtils.quote(key) + "] is not a JSONObject.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String key) {
/* 2071 */     verifyIsNull();
/* 2072 */     Object o = get(key);
/* 2073 */     if (o != null) {
/* 2074 */       return (o instanceof Number) ? ((Number)o).longValue() : (long)getDouble(key);
/*      */     }
/* 2076 */     throw new JSONException("JSONObject[" + JSONUtils.quote(key) + "] is not a number.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String key) {
/* 2087 */     verifyIsNull();
/* 2088 */     Object o = get(key);
/* 2089 */     if (o != null) {
/* 2090 */       return o.toString();
/*      */     }
/* 2092 */     throw new JSONException("JSONObject[" + JSONUtils.quote(key) + "] not found.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean has(String key) {
/* 2102 */     verifyIsNull();
/* 2103 */     return this.properties.containsKey(key);
/*      */   }
/*      */   
/*      */   public int hashCode() {
/* 2107 */     int hashcode = 19;
/* 2108 */     if (isNullObject()) {
/* 2109 */       return hashcode + JSONNull.getInstance().hashCode();
/*      */     }
/*      */     
/* 2112 */     Iterator<Map.Entry> entries = this.properties.entrySet().iterator();
/* 2113 */     while (entries.hasNext()) {
/* 2114 */       Map.Entry entry = entries.next();
/* 2115 */       Object key = entry.getKey();
/* 2116 */       Object value = entry.getValue();
/* 2117 */       hashcode += key.hashCode() + JSONUtils.hashCode(value);
/*      */     } 
/* 2119 */     return hashcode;
/*      */   }
/*      */   
/*      */   public boolean isArray() {
/* 2123 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/* 2128 */     return this.properties.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNullObject() {
/* 2135 */     return this.nullObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator keys() {
/* 2144 */     verifyIsNull();
/* 2145 */     return keySet().iterator();
/*      */   }
/*      */   
/*      */   public Set keySet() {
/* 2149 */     return Collections.unmodifiableSet(this.properties.keySet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray names() {
/* 2160 */     verifyIsNull();
/* 2161 */     JSONArray ja = new JSONArray();
/* 2162 */     Iterator keys = keys();
/* 2163 */     while (keys.hasNext()) {
/* 2164 */       ja.element(keys.next());
/*      */     }
/* 2166 */     return ja;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray names(JsonConfig jsonConfig) {
/* 2177 */     verifyIsNull();
/* 2178 */     JSONArray ja = new JSONArray();
/* 2179 */     Iterator keys = keys();
/* 2180 */     while (keys.hasNext()) {
/* 2181 */       ja.element(keys.next(), jsonConfig);
/*      */     }
/* 2183 */     return ja;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object opt(String key) {
/* 2193 */     verifyIsNull();
/* 2194 */     return (key == null) ? null : this.properties.get(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean optBoolean(String key) {
/* 2205 */     verifyIsNull();
/* 2206 */     return optBoolean(key, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean optBoolean(String key, boolean defaultValue) {
/* 2219 */     verifyIsNull();
/*      */     try {
/* 2221 */       return getBoolean(key);
/* 2222 */     } catch (Exception e) {
/* 2223 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double optDouble(String key) {
/* 2236 */     verifyIsNull();
/* 2237 */     return optDouble(key, Double.NaN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double optDouble(String key, double defaultValue) {
/* 2250 */     verifyIsNull();
/*      */     try {
/* 2252 */       Object o = opt(key);
/* 2253 */       return (o instanceof Number) ? ((Number)o).doubleValue() : (new Double((String)o)).doubleValue();
/*      */     }
/* 2255 */     catch (Exception e) {
/* 2256 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int optInt(String key) {
/* 2269 */     verifyIsNull();
/* 2270 */     return optInt(key, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int optInt(String key, int defaultValue) {
/* 2283 */     verifyIsNull();
/*      */     try {
/* 2285 */       return getInt(key);
/* 2286 */     } catch (Exception e) {
/* 2287 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray optJSONArray(String key) {
/* 2299 */     verifyIsNull();
/* 2300 */     Object o = opt(key);
/* 2301 */     return (o instanceof JSONArray) ? (JSONArray)o : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject optJSONObject(String key) {
/* 2312 */     verifyIsNull();
/* 2313 */     Object o = opt(key);
/* 2314 */     return (o instanceof JSONObject) ? (JSONObject)o : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long optLong(String key) {
/* 2326 */     verifyIsNull();
/* 2327 */     return optLong(key, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long optLong(String key, long defaultValue) {
/* 2340 */     verifyIsNull();
/*      */     try {
/* 2342 */       return getLong(key);
/* 2343 */     } catch (Exception e) {
/* 2344 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String optString(String key) {
/* 2357 */     verifyIsNull();
/* 2358 */     return optString(key, "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String optString(String key, String defaultValue) {
/* 2370 */     verifyIsNull();
/* 2371 */     Object o = opt(key);
/* 2372 */     return (o != null) ? o.toString() : defaultValue;
/*      */   }
/*      */   
/*      */   public Object put(Object key, Object value) {
/* 2376 */     if (key == null) {
/* 2377 */       throw new IllegalArgumentException("key is null.");
/*      */     }
/* 2379 */     Object previous = this.properties.get(key);
/* 2380 */     element(String.valueOf(key), value);
/* 2381 */     return previous;
/*      */   }
/*      */   
/*      */   public void putAll(Map map) {
/* 2385 */     putAll(map, new JsonConfig());
/*      */   }
/*      */   
/*      */   public void putAll(Map map, JsonConfig jsonConfig) {
/* 2389 */     if (map instanceof JSONObject) {
/* 2390 */       Iterator<Map.Entry> entries = map.entrySet().iterator();
/* 2391 */       while (entries.hasNext()) {
/* 2392 */         Map.Entry entry = entries.next();
/* 2393 */         String key = (String)entry.getKey();
/* 2394 */         Object value = entry.getValue();
/* 2395 */         this.properties.put(key, value);
/*      */       } 
/*      */     } else {
/* 2398 */       Iterator<Map.Entry> entries = map.entrySet().iterator();
/* 2399 */       while (entries.hasNext()) {
/* 2400 */         Map.Entry entry = entries.next();
/* 2401 */         String key = String.valueOf(entry.getKey());
/* 2402 */         Object value = entry.getValue();
/* 2403 */         element(key, value, jsonConfig);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public Object remove(Object key) {
/* 2409 */     return this.properties.remove(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object remove(String key) {
/* 2420 */     verifyIsNull();
/* 2421 */     return this.properties.remove(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/* 2431 */     return this.properties.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray toJSONArray(JSONArray names) {
/* 2444 */     verifyIsNull();
/* 2445 */     if (names == null || names.size() == 0) {
/* 2446 */       return null;
/*      */     }
/* 2448 */     JSONArray ja = new JSONArray();
/* 2449 */     for (int i = 0; i < names.size(); i++) {
/* 2450 */       ja.element(opt(names.getString(i)));
/*      */     }
/* 2452 */     return ja;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2468 */     if (isNullObject()) {
/* 2469 */       return JSONNull.getInstance().toString();
/*      */     }
/*      */     
/*      */     try {
/* 2473 */       Iterator keys = keys();
/* 2474 */       StringBuffer sb = new StringBuffer("{");
/*      */       
/* 2476 */       while (keys.hasNext()) {
/* 2477 */         if (sb.length() > 1) {
/* 2478 */           sb.append(',');
/*      */         }
/* 2480 */         Object o = keys.next();
/* 2481 */         sb.append(JSONUtils.quote(o.toString()));
/* 2482 */         sb.append(':');
/* 2483 */         sb.append(JSONUtils.valueToString(this.properties.get(o)));
/*      */       } 
/* 2485 */       sb.append('}');
/* 2486 */       return sb.toString();
/* 2487 */     } catch (Exception e) {
/* 2488 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(int indentFactor) {
/* 2506 */     if (isNullObject()) {
/* 2507 */       return JSONNull.getInstance().toString();
/*      */     }
/*      */     
/* 2510 */     if (indentFactor == 0) {
/* 2511 */       return toString();
/*      */     }
/* 2513 */     return toString(indentFactor, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(int indentFactor, int indent) {
/* 2530 */     if (isNullObject()) {
/* 2531 */       return JSONNull.getInstance().toString();
/*      */     }
/*      */ 
/*      */     
/* 2535 */     int n = size();
/* 2536 */     if (n == 0) {
/* 2537 */       return "{}";
/*      */     }
/* 2539 */     if (indentFactor == 0) {
/* 2540 */       return toString();
/*      */     }
/* 2542 */     Iterator keys = keys();
/* 2543 */     StringBuffer sb = new StringBuffer("{");
/* 2544 */     int newindent = indent + indentFactor;
/*      */     
/* 2546 */     if (n == 1) {
/* 2547 */       Object o = keys.next();
/* 2548 */       sb.append(JSONUtils.quote(o.toString()));
/* 2549 */       sb.append(": ");
/* 2550 */       sb.append(JSONUtils.valueToString(this.properties.get(o), indentFactor, indent));
/*      */     } else {
/* 2552 */       while (keys.hasNext()) {
/* 2553 */         Object o = keys.next();
/* 2554 */         if (sb.length() > 1) {
/* 2555 */           sb.append(",\n");
/*      */         } else {
/* 2557 */           sb.append('\n');
/*      */         } 
/* 2559 */         for (int j = 0; j < newindent; j++) {
/* 2560 */           sb.append(' ');
/*      */         }
/* 2562 */         sb.append(JSONUtils.quote(o.toString()));
/* 2563 */         sb.append(": ");
/* 2564 */         sb.append(JSONUtils.valueToString(this.properties.get(o), indentFactor, newindent));
/*      */       } 
/* 2566 */       if (sb.length() > 1) {
/* 2567 */         sb.append('\n');
/* 2568 */         for (int j = 0; j < indent; j++) {
/* 2569 */           sb.append(' ');
/*      */         }
/*      */       } 
/* 2572 */       for (int i = 0; i < indent; i++) {
/* 2573 */         sb.insert(0, ' ');
/*      */       }
/*      */     } 
/* 2576 */     sb.append('}');
/* 2577 */     return sb.toString();
/*      */   }
/*      */   
/*      */   public Collection values() {
/* 2581 */     return Collections.unmodifiableCollection(this.properties.values());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer write(Writer writer) {
/*      */     try {
/* 2595 */       if (isNullObject()) {
/* 2596 */         writer.write(JSONNull.getInstance().toString());
/*      */         
/* 2598 */         return writer;
/*      */       } 
/*      */       
/* 2601 */       boolean b = false;
/* 2602 */       Iterator keys = keys();
/* 2603 */       writer.write(123);
/*      */       
/* 2605 */       while (keys.hasNext()) {
/* 2606 */         if (b) {
/* 2607 */           writer.write(44);
/*      */         }
/* 2609 */         Object k = keys.next();
/* 2610 */         writer.write(JSONUtils.quote(k.toString()));
/* 2611 */         writer.write(58);
/* 2612 */         Object v = this.properties.get(k);
/* 2613 */         if (v instanceof JSONObject) {
/* 2614 */           ((JSONObject)v).write(writer);
/* 2615 */         } else if (v instanceof JSONArray) {
/* 2616 */           ((JSONArray)v).write(writer);
/*      */         } else {
/* 2618 */           writer.write(JSONUtils.valueToString(v));
/*      */         } 
/* 2620 */         b = true;
/*      */       } 
/* 2622 */       writer.write(125);
/* 2623 */       return writer;
/* 2624 */     } catch (IOException e) {
/* 2625 */       throw new JSONException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private JSONObject _accumulate(String key, Object value, JsonConfig jsonConfig) {
/* 2630 */     if (isNullObject()) {
/* 2631 */       throw new JSONException("Can't accumulate on null object");
/*      */     }
/*      */     
/* 2634 */     if (!has(key)) {
/* 2635 */       setInternal(key, value, jsonConfig);
/*      */     } else {
/* 2637 */       Object o = opt(key);
/* 2638 */       if (o instanceof JSONArray) {
/* 2639 */         ((JSONArray)o).element(value, jsonConfig);
/*      */       } else {
/* 2641 */         setInternal(key, (new JSONArray()).element(o).element(value, jsonConfig), jsonConfig);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2646 */     return this;
/*      */   }
/*      */   
/*      */   protected Object _processValue(Object value, JsonConfig jsonConfig) {
/* 2650 */     if (value instanceof JSONTokener)
/* 2651 */       return _fromJSONTokener((JSONTokener)value, jsonConfig); 
/* 2652 */     if (value != null && Enum.class.isAssignableFrom(value.getClass())) {
/* 2653 */       return ((Enum)value).name();
/*      */     }
/* 2655 */     return super._processValue(value, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JSONObject _setInternal(String key, Object value, JsonConfig jsonConfig) {
/* 2670 */     verifyIsNull();
/* 2671 */     if (key == null) {
/* 2672 */       throw new JSONException("Null key.");
/*      */     }
/*      */     
/* 2675 */     if (JSONUtils.isString(value) && JSONUtils.mayBeJSON(String.valueOf(value))) {
/* 2676 */       this.properties.put(key, value);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2687 */     else if (CycleDetectionStrategy.IGNORE_PROPERTY_OBJ != value && CycleDetectionStrategy.IGNORE_PROPERTY_ARR != value) {
/*      */ 
/*      */ 
/*      */       
/* 2691 */       this.properties.put(key, value);
/*      */     } 
/*      */ 
/*      */     
/* 2695 */     return this;
/*      */   }
/*      */   
/*      */   private Object processValue(Object value, JsonConfig jsonConfig) {
/* 2699 */     if (value != null) {
/* 2700 */       JsonValueProcessor processor = jsonConfig.findJsonValueProcessor(value.getClass());
/* 2701 */       if (processor != null) {
/* 2702 */         value = processor.processObjectValue(null, value, jsonConfig);
/* 2703 */         if (!JsonVerifier.isValidJsonValue(value)) {
/* 2704 */           throw new JSONException("Value is not a valid JSON value. " + value);
/*      */         }
/*      */       } 
/*      */     } 
/* 2708 */     return _processValue(value, jsonConfig);
/*      */   }
/*      */   
/*      */   private Object processValue(String key, Object value, JsonConfig jsonConfig) {
/* 2712 */     if (value != null) {
/* 2713 */       JsonValueProcessor processor = jsonConfig.findJsonValueProcessor(value.getClass(), key);
/* 2714 */       if (processor != null) {
/* 2715 */         value = processor.processObjectValue(null, value, jsonConfig);
/* 2716 */         if (!JsonVerifier.isValidJsonValue(value)) {
/* 2717 */           throw new JSONException("Value is not a valid JSON value. " + value);
/*      */         }
/*      */       } 
/*      */     } 
/* 2721 */     return _processValue(value, jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JSONObject setInternal(String key, Object value, JsonConfig jsonConfig) {
/* 2736 */     return _setInternal(key, processValue(key, value, jsonConfig), jsonConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyIsNull() {
/* 2743 */     if (isNullObject())
/* 2744 */       throw new JSONException("null object"); 
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\json-lib-2.4-jdk15.jar!\net\sf\json\JSONObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */