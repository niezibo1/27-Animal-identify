package org.apache.commons.lang.mutable;

public interface Mutable {
  Object getValue();
  
  void setValue(Object paramObject);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\mutable\Mutable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */