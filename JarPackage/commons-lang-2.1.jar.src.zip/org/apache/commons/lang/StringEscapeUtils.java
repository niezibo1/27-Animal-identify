/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.commons.lang.exception.NestableRuntimeException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringEscapeUtils
/*     */ {
/*     */   public static String escapeJava(String str) {
/*  80 */     return escapeJavaStyleString(str, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void escapeJava(Writer out, String str) throws IOException {
/*  96 */     escapeJavaStyleString(out, str, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeJavaScript(String str) {
/* 121 */     return escapeJavaStyleString(str, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void escapeJavaScript(Writer out, String str) throws IOException {
/* 137 */     escapeJavaStyleString(out, str, true);
/*     */   }
/*     */   
/*     */   private static String escapeJavaStyleString(String str, boolean escapeSingleQuotes) {
/* 141 */     if (str == null) {
/* 142 */       return null;
/*     */     }
/*     */     try {
/* 145 */       StringPrintWriter writer = new StringPrintWriter(str.length() * 2);
/* 146 */       escapeJavaStyleString(writer, str, escapeSingleQuotes);
/* 147 */       return writer.getString();
/* 148 */     } catch (IOException ioe) {
/*     */       
/* 150 */       ioe.printStackTrace();
/* 151 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void escapeJavaStyleString(Writer out, String str, boolean escapeSingleQuote) throws IOException {
/* 156 */     if (out == null) {
/* 157 */       throw new IllegalArgumentException("The Writer must not be null");
/*     */     }
/* 159 */     if (str == null) {
/*     */       return;
/*     */     }
/*     */     
/* 163 */     int sz = str.length();
/* 164 */     for (int i = 0; i < sz; i++) {
/* 165 */       char ch = str.charAt(i);
/*     */ 
/*     */       
/* 168 */       if (ch > '࿿') {
/* 169 */         out.write("\\u" + hex(ch));
/* 170 */       } else if (ch > 'ÿ') {
/* 171 */         out.write("\\u0" + hex(ch));
/* 172 */       } else if (ch > '') {
/* 173 */         out.write("\\u00" + hex(ch));
/* 174 */       } else if (ch < ' ') {
/* 175 */         switch (ch) {
/*     */           case '\b':
/* 177 */             out.write(92);
/* 178 */             out.write(98);
/*     */             break;
/*     */           case '\n':
/* 181 */             out.write(92);
/* 182 */             out.write(110);
/*     */             break;
/*     */           case '\t':
/* 185 */             out.write(92);
/* 186 */             out.write(116);
/*     */             break;
/*     */           case '\f':
/* 189 */             out.write(92);
/* 190 */             out.write(102);
/*     */             break;
/*     */           case '\r':
/* 193 */             out.write(92);
/* 194 */             out.write(114);
/*     */             break;
/*     */           default:
/* 197 */             if (ch > '\017') {
/* 198 */               out.write("\\u00" + hex(ch)); break;
/*     */             } 
/* 200 */             out.write("\\u000" + hex(ch));
/*     */             break;
/*     */         } 
/*     */       
/*     */       } else {
/* 205 */         switch (ch) {
/*     */           case '\'':
/* 207 */             if (escapeSingleQuote) {
/* 208 */               out.write(92);
/*     */             }
/* 210 */             out.write(39);
/*     */             break;
/*     */           case '"':
/* 213 */             out.write(92);
/* 214 */             out.write(34);
/*     */             break;
/*     */           case '\\':
/* 217 */             out.write(92);
/* 218 */             out.write(92);
/*     */             break;
/*     */           default:
/* 221 */             out.write(ch);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String hex(char ch) {
/* 236 */     return Integer.toHexString(ch).toUpperCase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescapeJava(String str) {
/* 249 */     if (str == null) {
/* 250 */       return null;
/*     */     }
/*     */     try {
/* 253 */       StringPrintWriter writer = new StringPrintWriter(str.length());
/* 254 */       unescapeJava(writer, str);
/* 255 */       return writer.getString();
/* 256 */     } catch (IOException ioe) {
/*     */       
/* 258 */       ioe.printStackTrace();
/* 259 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unescapeJava(Writer out, String str) throws IOException {
/* 279 */     if (out == null) {
/* 280 */       throw new IllegalArgumentException("The Writer must not be null");
/*     */     }
/* 282 */     if (str == null) {
/*     */       return;
/*     */     }
/* 285 */     int sz = str.length();
/* 286 */     StringBuffer unicode = new StringBuffer(4);
/* 287 */     boolean hadSlash = false;
/* 288 */     boolean inUnicode = false;
/* 289 */     for (int i = 0; i < sz; i++) {
/* 290 */       char ch = str.charAt(i);
/* 291 */       if (inUnicode) {
/*     */ 
/*     */         
/* 294 */         unicode.append(ch);
/* 295 */         if (unicode.length() == 4) {
/*     */           
/*     */           try {
/*     */             
/* 299 */             int value = Integer.parseInt(unicode.toString(), 16);
/* 300 */             out.write((char)value);
/* 301 */             unicode.setLength(0);
/* 302 */             inUnicode = false;
/* 303 */             hadSlash = false;
/* 304 */           } catch (NumberFormatException nfe) {
/* 305 */             throw new NestableRuntimeException("Unable to parse unicode value: " + unicode, nfe);
/*     */           }
/*     */         
/*     */         }
/*     */       }
/* 310 */       else if (hadSlash) {
/*     */         
/* 312 */         hadSlash = false;
/* 313 */         switch (ch) {
/*     */           case '\\':
/* 315 */             out.write(92);
/*     */             break;
/*     */           case '\'':
/* 318 */             out.write(39);
/*     */             break;
/*     */           case '"':
/* 321 */             out.write(34);
/*     */             break;
/*     */           case 'r':
/* 324 */             out.write(13);
/*     */             break;
/*     */           case 'f':
/* 327 */             out.write(12);
/*     */             break;
/*     */           case 't':
/* 330 */             out.write(9);
/*     */             break;
/*     */           case 'n':
/* 333 */             out.write(10);
/*     */             break;
/*     */           case 'b':
/* 336 */             out.write(8);
/*     */             break;
/*     */ 
/*     */           
/*     */           case 'u':
/* 341 */             inUnicode = true;
/*     */             break;
/*     */           
/*     */           default:
/* 345 */             out.write(ch);
/*     */             break;
/*     */         } 
/*     */       
/* 349 */       } else if (ch == '\\') {
/* 350 */         hadSlash = true;
/*     */       } else {
/*     */         
/* 353 */         out.write(ch);
/*     */       } 
/* 355 */     }  if (hadSlash)
/*     */     {
/*     */       
/* 358 */       out.write(92);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescapeJavaScript(String str) {
/* 374 */     return unescapeJava(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unescapeJavaScript(Writer out, String str) throws IOException {
/* 394 */     unescapeJava(out, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeHtml(String str) {
/* 424 */     if (str == null) {
/* 425 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 429 */     return Entities.HTML40.escape(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescapeHtml(String str) {
/* 449 */     if (str == null) {
/* 450 */       return null;
/*     */     }
/* 452 */     return Entities.HTML40.unescape(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeXml(String str) {
/* 470 */     if (str == null) {
/* 471 */       return null;
/*     */     }
/* 473 */     return Entities.XML.escape(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unescapeXml(String str) {
/* 489 */     if (str == null) {
/* 490 */       return null;
/*     */     }
/* 492 */     return Entities.XML.unescape(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeSql(String str) {
/* 514 */     if (str == null) {
/* 515 */       return null;
/*     */     }
/* 517 */     return StringUtils.replace(str, "'", "''");
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\StringEscapeUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */