/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharSetUtils
/*     */ {
/*     */   public static CharSet evaluateSet(String[] set) {
/*  69 */     if (set == null) {
/*  70 */       return null;
/*     */     }
/*  72 */     return new CharSet(set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String squeeze(String str, String set) {
/*  96 */     if (StringUtils.isEmpty(str) || StringUtils.isEmpty(set)) {
/*  97 */       return str;
/*     */     }
/*  99 */     String[] strs = new String[1];
/* 100 */     strs[0] = set;
/* 101 */     return squeeze(str, strs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String squeeze(String str, String[] set) {
/* 119 */     if (StringUtils.isEmpty(str) || ArrayUtils.isEmpty((Object[])set)) {
/* 120 */       return str;
/*     */     }
/* 122 */     CharSet chars = evaluateSet(set);
/* 123 */     StringBuffer buffer = new StringBuffer(str.length());
/* 124 */     char[] chrs = str.toCharArray();
/* 125 */     int sz = chrs.length;
/* 126 */     char lastChar = ' ';
/* 127 */     char ch = ' ';
/* 128 */     for (int i = 0; i < sz; i++) {
/* 129 */       ch = chrs[i];
/* 130 */       if (!chars.contains(ch) || 
/* 131 */         ch != lastChar || i == 0) {
/*     */ 
/*     */ 
/*     */         
/* 135 */         buffer.append(ch);
/* 136 */         lastChar = ch;
/*     */       } 
/* 138 */     }  return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int count(String str, String set) {
/* 162 */     if (StringUtils.isEmpty(str) || StringUtils.isEmpty(set)) {
/* 163 */       return 0;
/*     */     }
/* 165 */     String[] strs = new String[1];
/* 166 */     strs[0] = set;
/* 167 */     return count(str, strs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int count(String str, String[] set) {
/* 185 */     if (StringUtils.isEmpty(str) || ArrayUtils.isEmpty((Object[])set)) {
/* 186 */       return 0;
/*     */     }
/* 188 */     CharSet chars = evaluateSet(set);
/* 189 */     int count = 0;
/* 190 */     char[] chrs = str.toCharArray();
/* 191 */     int sz = chrs.length;
/* 192 */     for (int i = 0; i < sz; i++) {
/* 193 */       if (chars.contains(chrs[i])) {
/* 194 */         count++;
/*     */       }
/*     */     } 
/* 197 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String keep(String str, String set) {
/* 222 */     if (str == null) {
/* 223 */       return null;
/*     */     }
/* 225 */     if (str.length() == 0 || StringUtils.isEmpty(set)) {
/* 226 */       return "";
/*     */     }
/* 228 */     String[] strs = new String[1];
/* 229 */     strs[0] = set;
/* 230 */     return keep(str, strs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String keep(String str, String[] set) {
/* 250 */     if (str == null) {
/* 251 */       return null;
/*     */     }
/* 253 */     if (str.length() == 0 || ArrayUtils.isEmpty((Object[])set)) {
/* 254 */       return "";
/*     */     }
/* 256 */     return modify(str, set, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delete(String str, String set) {
/* 280 */     if (StringUtils.isEmpty(str) || StringUtils.isEmpty(set)) {
/* 281 */       return str;
/*     */     }
/* 283 */     String[] strs = new String[1];
/* 284 */     strs[0] = set;
/* 285 */     return delete(str, strs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String delete(String str, String[] set) {
/* 304 */     if (StringUtils.isEmpty(str) || ArrayUtils.isEmpty((Object[])set)) {
/* 305 */       return str;
/*     */     }
/* 307 */     return modify(str, set, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String modify(String str, String[] set, boolean expect) {
/* 320 */     CharSet chars = evaluateSet(set);
/* 321 */     StringBuffer buffer = new StringBuffer(str.length());
/* 322 */     char[] chrs = str.toCharArray();
/* 323 */     int sz = chrs.length;
/* 324 */     for (int i = 0; i < sz; i++) {
/* 325 */       if (chars.contains(chrs[i]) == expect) {
/* 326 */         buffer.append(chrs[i]);
/*     */       }
/*     */     } 
/* 329 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String translate(String str, String searchChars, String replaceChars) {
/* 367 */     if (StringUtils.isEmpty(str)) {
/* 368 */       return str;
/*     */     }
/* 370 */     StringBuffer buffer = new StringBuffer(str.length());
/* 371 */     char[] chrs = str.toCharArray();
/* 372 */     char[] withChrs = replaceChars.toCharArray();
/* 373 */     int sz = chrs.length;
/* 374 */     int withMax = replaceChars.length() - 1;
/* 375 */     for (int i = 0; i < sz; i++) {
/* 376 */       int idx = searchChars.indexOf(chrs[i]);
/* 377 */       if (idx != -1) {
/* 378 */         if (idx > withMax) {
/* 379 */           idx = withMax;
/*     */         }
/* 381 */         buffer.append(withChrs[idx]);
/*     */       } else {
/* 383 */         buffer.append(chrs[i]);
/*     */       } 
/*     */     } 
/* 386 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\CharSetUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */