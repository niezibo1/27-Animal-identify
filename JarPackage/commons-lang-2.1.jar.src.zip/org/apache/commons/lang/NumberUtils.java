/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberUtils
/*     */ {
/*     */   public static int stringToInt(String str) {
/*  60 */     return stringToInt(str, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int stringToInt(String str, int defaultValue) {
/*     */     try {
/*  73 */       return Integer.parseInt(str);
/*  74 */     } catch (NumberFormatException numberFormatException) {
/*  75 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Number createNumber(String val) throws NumberFormatException {
/*     */     String mant, dec, exp;
/* 138 */     if (val == null) {
/* 139 */       return null;
/*     */     }
/* 141 */     if (val.length() == 0) {
/* 142 */       throw new NumberFormatException("\"\" is not a valid number.");
/*     */     }
/* 144 */     if (val.startsWith("--"))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 149 */       return null;
/*     */     }
/* 151 */     if (val.startsWith("0x") || val.startsWith("-0x")) {
/* 152 */       return createInteger(val);
/*     */     }
/* 154 */     char lastChar = val.charAt(val.length() - 1);
/*     */ 
/*     */ 
/*     */     
/* 158 */     int decPos = val.indexOf('.');
/* 159 */     int expPos = val.indexOf('e') + val.indexOf('E') + 1;
/*     */     
/* 161 */     if (decPos > -1) {
/*     */       
/* 163 */       if (expPos > -1) {
/* 164 */         if (expPos < decPos) {
/* 165 */           throw new NumberFormatException(String.valueOf(val) + " is not a valid number.");
/*     */         }
/* 167 */         dec = val.substring(decPos + 1, expPos);
/*     */       } else {
/* 169 */         dec = val.substring(decPos + 1);
/*     */       } 
/* 171 */       mant = val.substring(0, decPos);
/*     */     } else {
/* 173 */       if (expPos > -1) {
/* 174 */         mant = val.substring(0, expPos);
/*     */       } else {
/* 176 */         mant = val;
/*     */       } 
/* 178 */       dec = null;
/*     */     } 
/* 180 */     if (!Character.isDigit(lastChar)) {
/* 181 */       if (expPos > -1 && expPos < val.length() - 1) {
/* 182 */         exp = val.substring(expPos + 1, val.length() - 1);
/*     */       } else {
/* 184 */         exp = null;
/*     */       } 
/*     */       
/* 187 */       String numeric = val.substring(0, val.length() - 1);
/* 188 */       boolean bool = !(!isAllZeros(mant) || !isAllZeros(exp));
/* 189 */       switch (lastChar) {
/*     */         case 'L':
/*     */         case 'l':
/* 192 */           if (dec == null && 
/* 193 */             exp == null && 
/* 194 */             isDigits(numeric.substring(1)) && (
/* 195 */             numeric.charAt(0) == '-' || Character.isDigit(numeric.charAt(0)))) {
/*     */             try {
/* 197 */               return createLong(numeric);
/* 198 */             } catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */               
/* 201 */               return createBigInteger(numeric);
/*     */             } 
/*     */           }
/* 204 */           throw new NumberFormatException(String.valueOf(val) + " is not a valid number.");
/*     */         case 'F':
/*     */         case 'f':
/*     */           try {
/* 208 */             Float f = createFloat(numeric);
/* 209 */             if (!f.isInfinite() && (f.floatValue() != 0.0F || bool))
/*     */             {
/*     */               
/* 212 */               return f;
/*     */             }
/*     */           }
/* 215 */           catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */         
/*     */         case 'D':
/*     */         case 'd':
/*     */           try {
/* 221 */             Double d = createDouble(numeric);
/* 222 */             if (!d.isInfinite() && (d.floatValue() != 0.0D || bool)) {
/* 223 */               return d;
/*     */             }
/* 225 */           } catch (NumberFormatException numberFormatException) {}
/*     */           
/*     */           try {
/* 228 */             return createBigDecimal(numeric);
/* 229 */           } catch (NumberFormatException numberFormatException) {
/*     */             break;
/*     */           } 
/*     */       } 
/* 233 */       throw new NumberFormatException(String.valueOf(val) + " is not a valid number.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (expPos > -1 && expPos < val.length() - 1) {
/* 240 */       exp = val.substring(expPos + 1, val.length());
/*     */     } else {
/* 242 */       exp = null;
/*     */     } 
/* 244 */     if (dec == null && exp == null) {
/*     */       
/*     */       try {
/* 247 */         return createInteger(val);
/* 248 */       } catch (NumberFormatException numberFormatException) {
/*     */         
/*     */         try {
/* 251 */           return createLong(val);
/* 252 */         } catch (NumberFormatException numberFormatException1) {
/*     */           
/* 254 */           return createBigInteger(val);
/*     */         } 
/*     */       } 
/*     */     }
/* 258 */     boolean allZeros = !(!isAllZeros(mant) || !isAllZeros(exp));
/*     */     try {
/* 260 */       Float f = createFloat(val);
/* 261 */       if (!f.isInfinite() && (f.floatValue() != 0.0F || allZeros)) {
/* 262 */         return f;
/*     */       }
/* 264 */     } catch (NumberFormatException numberFormatException) {}
/*     */     
/*     */     try {
/* 267 */       Double d = createDouble(val);
/* 268 */       if (!d.isInfinite() && (d.doubleValue() != 0.0D || allZeros)) {
/* 269 */         return d;
/*     */       }
/* 271 */     } catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */     
/* 274 */     return createBigDecimal(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isAllZeros(String s) {
/* 290 */     if (s == null) {
/* 291 */       return true;
/*     */     }
/* 293 */     for (int i = s.length() - 1; i >= 0; i--) {
/* 294 */       if (s.charAt(i) != '0') {
/* 295 */         return false;
/*     */       }
/*     */     } 
/* 298 */     return !(s.length() <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Float createFloat(String val) {
/* 311 */     return Float.valueOf(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Double createDouble(String val) {
/* 322 */     return Double.valueOf(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer createInteger(String val) {
/* 335 */     return Integer.decode(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Long createLong(String val) {
/* 346 */     return Long.valueOf(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger createBigInteger(String val) {
/* 357 */     BigInteger bi = new BigInteger(val);
/* 358 */     return bi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal createBigDecimal(String val) {
/* 369 */     BigDecimal bd = new BigDecimal(val);
/* 370 */     return bd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long minimum(long a, long b, long c) {
/* 384 */     if (b < a) {
/* 385 */       a = b;
/*     */     }
/* 387 */     if (c < a) {
/* 388 */       a = c;
/*     */     }
/* 390 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int minimum(int a, int b, int c) {
/* 402 */     if (b < a) {
/* 403 */       a = b;
/*     */     }
/* 405 */     if (c < a) {
/* 406 */       a = c;
/*     */     }
/* 408 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long maximum(long a, long b, long c) {
/* 420 */     if (b > a) {
/* 421 */       a = b;
/*     */     }
/* 423 */     if (c > a) {
/* 424 */       a = c;
/*     */     }
/* 426 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int maximum(int a, int b, int c) {
/* 438 */     if (b > a) {
/* 439 */       a = b;
/*     */     }
/* 441 */     if (c > a) {
/* 442 */       a = c;
/*     */     }
/* 444 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compare(double lhs, double rhs) {
/* 484 */     if (lhs < rhs) {
/* 485 */       return -1;
/*     */     }
/* 487 */     if (lhs > rhs) {
/* 488 */       return 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 494 */     long lhsBits = Double.doubleToLongBits(lhs);
/* 495 */     long rhsBits = Double.doubleToLongBits(rhs);
/* 496 */     if (lhsBits == rhsBits) {
/* 497 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 505 */     if (lhsBits < rhsBits) {
/* 506 */       return -1;
/*     */     }
/* 508 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compare(float lhs, float rhs) {
/* 545 */     if (lhs < rhs) {
/* 546 */       return -1;
/*     */     }
/* 548 */     if (lhs > rhs) {
/* 549 */       return 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 555 */     int lhsBits = Float.floatToIntBits(lhs);
/* 556 */     int rhsBits = Float.floatToIntBits(rhs);
/* 557 */     if (lhsBits == rhsBits) {
/* 558 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 566 */     if (lhsBits < rhsBits) {
/* 567 */       return -1;
/*     */     }
/* 569 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDigits(String str) {
/* 586 */     if (str == null || str.length() == 0) {
/* 587 */       return false;
/*     */     }
/* 589 */     for (int i = 0; i < str.length(); i++) {
/* 590 */       if (!Character.isDigit(str.charAt(i))) {
/* 591 */         return false;
/*     */       }
/*     */     } 
/* 594 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNumber(String str) {
/* 611 */     if (StringUtils.isEmpty(str)) {
/* 612 */       return false;
/*     */     }
/* 614 */     char[] chars = str.toCharArray();
/* 615 */     int sz = chars.length;
/* 616 */     boolean hasExp = false;
/* 617 */     boolean hasDecPoint = false;
/* 618 */     boolean allowSigns = false;
/* 619 */     boolean foundDigit = false;
/*     */     
/* 621 */     int start = (chars[0] == '-') ? 1 : 0;
/* 622 */     if (sz > start + 1 && 
/* 623 */       chars[start] == '0' && chars[start + 1] == 'x') {
/* 624 */       int j = start + 2;
/* 625 */       if (j == sz) {
/* 626 */         return false;
/*     */       }
/*     */       
/* 629 */       for (; j < chars.length; j++) {
/* 630 */         if ((chars[j] < '0' || chars[j] > '9') && (
/* 631 */           chars[j] < 'a' || chars[j] > 'f') && (
/* 632 */           chars[j] < 'A' || chars[j] > 'F')) {
/* 633 */           return false;
/*     */         }
/*     */       } 
/* 636 */       return true;
/*     */     } 
/*     */     
/* 639 */     sz--;
/*     */     
/* 641 */     int i = start;
/*     */ 
/*     */     
/* 644 */     while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
/* 645 */       if (chars[i] >= '0' && chars[i] <= '9') {
/* 646 */         foundDigit = true;
/* 647 */         allowSigns = false;
/*     */       }
/* 649 */       else if (chars[i] == '.') {
/* 650 */         if (hasDecPoint || hasExp)
/*     */         {
/* 652 */           return false;
/*     */         }
/* 654 */         hasDecPoint = true;
/* 655 */       } else if (chars[i] == 'e' || chars[i] == 'E') {
/*     */         
/* 657 */         if (hasExp)
/*     */         {
/* 659 */           return false;
/*     */         }
/* 661 */         if (!foundDigit) {
/* 662 */           return false;
/*     */         }
/* 664 */         hasExp = true;
/* 665 */         allowSigns = true;
/* 666 */       } else if (chars[i] == '+' || chars[i] == '-') {
/* 667 */         if (!allowSigns) {
/* 668 */           return false;
/*     */         }
/* 670 */         allowSigns = false;
/* 671 */         foundDigit = false;
/*     */       } else {
/* 673 */         return false;
/*     */       } 
/* 675 */       i++;
/*     */     } 
/* 677 */     if (i < chars.length) {
/* 678 */       if (chars[i] >= '0' && chars[i] <= '9')
/*     */       {
/* 680 */         return true;
/*     */       }
/* 682 */       if (chars[i] == 'e' || chars[i] == 'E')
/*     */       {
/* 684 */         return false;
/*     */       }
/* 686 */       if (!allowSigns && (
/* 687 */         chars[i] == 'd' || 
/* 688 */         chars[i] == 'D' || 
/* 689 */         chars[i] == 'f' || 
/* 690 */         chars[i] == 'F')) {
/* 691 */         return foundDigit;
/*     */       }
/* 693 */       if (chars[i] == 'l' || 
/* 694 */         chars[i] == 'L')
/*     */       {
/* 696 */         return !(!foundDigit || hasExp);
/*     */       }
/*     */       
/* 699 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 703 */     return !(allowSigns || !foundDigit);
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\NumberUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */