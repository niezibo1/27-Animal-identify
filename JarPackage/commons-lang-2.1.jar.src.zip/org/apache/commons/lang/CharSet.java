/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharSet
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5947847346149275958L;
/*  47 */   public static final CharSet EMPTY = new CharSet(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final CharSet ASCII_ALPHA = new CharSet("a-zA-Z");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final CharSet ASCII_ALPHA_LOWER = new CharSet("a-z");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final CharSet ASCII_ALPHA_UPPER = new CharSet("A-Z");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final CharSet ASCII_NUMERIC = new CharSet("0-9");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   protected static final Map COMMON = new HashMap();
/*     */   
/*     */   static {
/*  81 */     COMMON.put(null, EMPTY);
/*  82 */     COMMON.put("", EMPTY);
/*  83 */     COMMON.put("a-zA-Z", ASCII_ALPHA);
/*  84 */     COMMON.put("A-Za-z", ASCII_ALPHA);
/*  85 */     COMMON.put("a-z", ASCII_ALPHA_LOWER);
/*  86 */     COMMON.put("A-Z", ASCII_ALPHA_UPPER);
/*  87 */     COMMON.put("0-9", ASCII_NUMERIC);
/*     */   }
/*     */ 
/*     */   
/*  91 */   private Set set = new HashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharSet getInstance(String setStr) {
/* 138 */     Object set = COMMON.get(setStr);
/* 139 */     if (set != null) {
/* 140 */       return (CharSet)set;
/*     */     }
/* 142 */     return new CharSet(setStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CharSet(String setStr) {
/* 154 */     add(setStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CharSet(String[] set) {
/* 166 */     int sz = set.length;
/* 167 */     for (int i = 0; i < sz; i++) {
/* 168 */       add(set[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void add(String str) {
/* 179 */     if (str == null) {
/*     */       return;
/*     */     }
/*     */     
/* 183 */     int len = str.length();
/* 184 */     int pos = 0;
/* 185 */     while (pos < len) {
/* 186 */       int remainder = len - pos;
/* 187 */       if (remainder >= 4 && str.charAt(pos) == '^' && str.charAt(pos + 2) == '-') {
/*     */         
/* 189 */         this.set.add(new CharRange(str.charAt(pos + 1), str.charAt(pos + 3), true));
/* 190 */         pos += 4; continue;
/* 191 */       }  if (remainder >= 3 && str.charAt(pos + 1) == '-') {
/*     */         
/* 193 */         this.set.add(new CharRange(str.charAt(pos), str.charAt(pos + 2)));
/* 194 */         pos += 3; continue;
/* 195 */       }  if (remainder >= 2 && str.charAt(pos) == '^') {
/*     */         
/* 197 */         this.set.add(new CharRange(str.charAt(pos + 1), true));
/* 198 */         pos += 2;
/*     */         continue;
/*     */       } 
/* 201 */       this.set.add(new CharRange(str.charAt(pos)));
/* 202 */       pos++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharRange[] getCharRanges() {
/* 215 */     return (CharRange[])this.set.toArray((Object[])new CharRange[this.set.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(char ch) {
/* 227 */     for (Iterator it = this.set.iterator(); it.hasNext(); ) {
/* 228 */       CharRange range = it.next();
/* 229 */       if (range.contains(ch)) {
/* 230 */         return true;
/*     */       }
/*     */     } 
/* 233 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 250 */     if (obj == this) {
/* 251 */       return true;
/*     */     }
/* 253 */     if (obj instanceof CharSet == false) {
/* 254 */       return false;
/*     */     }
/* 256 */     CharSet other = (CharSet)obj;
/* 257 */     return this.set.equals(other.set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 267 */     return 89 + this.set.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 276 */     return this.set.toString();
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\CharSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */