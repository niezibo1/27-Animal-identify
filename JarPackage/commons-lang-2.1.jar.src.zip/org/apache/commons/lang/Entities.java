/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Entities
/*     */ {
/*  38 */   private static final String[][] BASIC_ARRAY = new String[][] {
/*  39 */       { "quot", "34"
/*  40 */       }, { "amp", "38"
/*  41 */       }, { "lt", "60"
/*  42 */       }, { "gt", "62" }
/*     */     };
/*     */   
/*  45 */   private static final String[][] APOS_ARRAY = new String[][] {
/*  46 */       { "apos", "39" }
/*     */     };
/*     */ 
/*     */   
/*  50 */   static final String[][] ISO8859_1_ARRAY = new String[][] { 
/*  51 */       { "nbsp", "160"
/*  52 */       }, { "iexcl", "161"
/*  53 */       }, { "cent", "162"
/*  54 */       }, { "pound", "163"
/*  55 */       }, { "curren", "164"
/*  56 */       }, { "yen", "165"
/*  57 */       }, { "brvbar", "166"
/*  58 */       }, { "sect", "167"
/*  59 */       }, { "uml", "168"
/*  60 */       }, { "copy", "169" }, 
/*  61 */       { "ordf", "170"
/*  62 */       }, { "laquo", "171"
/*  63 */       }, { "not", "172"
/*  64 */       }, { "shy", "173"
/*  65 */       }, { "reg", "174"
/*  66 */       }, { "macr", "175"
/*  67 */       }, { "deg", "176"
/*  68 */       }, { "plusmn", "177"
/*  69 */       }, { "sup2", "178"
/*  70 */       }, { "sup3", "179" }, 
/*  71 */       { "acute", "180"
/*  72 */       }, { "micro", "181"
/*  73 */       }, { "para", "182"
/*  74 */       }, { "middot", "183"
/*  75 */       }, { "cedil", "184"
/*  76 */       }, { "sup1", "185"
/*  77 */       }, { "ordm", "186"
/*  78 */       }, { "raquo", "187"
/*  79 */       }, { "frac14", "188"
/*  80 */       }, { "frac12", "189" }, 
/*  81 */       { "frac34", "190"
/*  82 */       }, { "iquest", "191"
/*  83 */       }, { "Agrave", "192"
/*  84 */       }, { "Aacute", "193"
/*  85 */       }, { "Acirc", "194"
/*  86 */       }, { "Atilde", "195"
/*  87 */       }, { "Auml", "196"
/*  88 */       }, { "Aring", "197"
/*  89 */       }, { "AElig", "198"
/*  90 */       }, { "Ccedil", "199" }, 
/*  91 */       { "Egrave", "200"
/*  92 */       }, { "Eacute", "201"
/*  93 */       }, { "Ecirc", "202"
/*  94 */       }, { "Euml", "203"
/*  95 */       }, { "Igrave", "204"
/*  96 */       }, { "Iacute", "205"
/*  97 */       }, { "Icirc", "206"
/*  98 */       }, { "Iuml", "207"
/*  99 */       }, { "ETH", "208"
/* 100 */       }, { "Ntilde", "209" }, 
/* 101 */       { "Ograve", "210"
/* 102 */       }, { "Oacute", "211"
/* 103 */       }, { "Ocirc", "212"
/* 104 */       }, { "Otilde", "213"
/* 105 */       }, { "Ouml", "214"
/* 106 */       }, { "times", "215"
/* 107 */       }, { "Oslash", "216"
/* 108 */       }, { "Ugrave", "217"
/* 109 */       }, { "Uacute", "218"
/* 110 */       }, { "Ucirc", "219" }, 
/* 111 */       { "Uuml", "220"
/* 112 */       }, { "Yacute", "221"
/* 113 */       }, { "THORN", "222"
/* 114 */       }, { "szlig", "223"
/* 115 */       }, { "agrave", "224"
/* 116 */       }, { "aacute", "225"
/* 117 */       }, { "acirc", "226"
/* 118 */       }, { "atilde", "227"
/* 119 */       }, { "auml", "228"
/* 120 */       }, { "aring", "229" }, 
/* 121 */       { "aelig", "230"
/* 122 */       }, { "ccedil", "231"
/* 123 */       }, { "egrave", "232"
/* 124 */       }, { "eacute", "233"
/* 125 */       }, { "ecirc", "234"
/* 126 */       }, { "euml", "235"
/* 127 */       }, { "igrave", "236"
/* 128 */       }, { "iacute", "237"
/* 129 */       }, { "icirc", "238"
/* 130 */       }, { "iuml", "239" }, 
/* 131 */       { "eth", "240"
/* 132 */       }, { "ntilde", "241"
/* 133 */       }, { "ograve", "242"
/* 134 */       }, { "oacute", "243"
/* 135 */       }, { "ocirc", "244"
/* 136 */       }, { "otilde", "245"
/* 137 */       }, { "ouml", "246"
/* 138 */       }, { "divide", "247"
/* 139 */       }, { "oslash", "248"
/* 140 */       }, { "ugrave", "249" }, 
/* 141 */       { "uacute", "250"
/* 142 */       }, { "ucirc", "251"
/* 143 */       }, { "uuml", "252"
/* 144 */       }, { "yacute", "253"
/* 145 */       }, { "thorn", "254"
/* 146 */       }, { "yuml", "255" } };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   static final String[][] HTML40_ARRAY = new String[][] {
/*     */       
/* 153 */       { "fnof", "402"
/*     */       },
/* 155 */       { "Alpha", "913"
/* 156 */       }, { "Beta", "914"
/* 157 */       }, { "Gamma", "915"
/* 158 */       }, { "Delta", "916"
/* 159 */       }, { "Epsilon", "917"
/* 160 */       }, { "Zeta", "918"
/* 161 */       }, { "Eta", "919"
/* 162 */       }, { "Theta", "920"
/* 163 */       }, { "Iota", "921" }, 
/* 164 */       { "Kappa", "922"
/* 165 */       }, { "Lambda", "923"
/* 166 */       }, { "Mu", "924"
/* 167 */       }, { "Nu", "925"
/* 168 */       }, { "Xi", "926"
/* 169 */       }, { "Omicron", "927"
/* 170 */       }, { "Pi", "928"
/* 171 */       }, { "Rho", "929"
/*     */       },
/* 173 */       { "Sigma", "931"
/* 174 */       }, { "Tau", "932" }, 
/* 175 */       { "Upsilon", "933"
/* 176 */       }, { "Phi", "934"
/* 177 */       }, { "Chi", "935"
/* 178 */       }, { "Psi", "936"
/* 179 */       }, { "Omega", "937"
/* 180 */       }, { "alpha", "945"
/* 181 */       }, { "beta", "946"
/* 182 */       }, { "gamma", "947"
/* 183 */       }, { "delta", "948"
/* 184 */       }, { "epsilon", "949" }, 
/* 185 */       { "zeta", "950"
/* 186 */       }, { "eta", "951"
/* 187 */       }, { "theta", "952"
/* 188 */       }, { "iota", "953"
/* 189 */       }, { "kappa", "954"
/* 190 */       }, { "lambda", "955"
/* 191 */       }, { "mu", "956"
/* 192 */       }, { "nu", "957"
/* 193 */       }, { "xi", "958"
/* 194 */       }, { "omicron", "959" }, 
/* 195 */       { "pi", "960"
/* 196 */       }, { "rho", "961"
/* 197 */       }, { "sigmaf", "962"
/* 198 */       }, { "sigma", "963"
/* 199 */       }, { "tau", "964"
/* 200 */       }, { "upsilon", "965"
/* 201 */       }, { "phi", "966"
/* 202 */       }, { "chi", "967"
/* 203 */       }, { "psi", "968"
/* 204 */       }, { "omega", "969" }, 
/* 205 */       { "thetasym", "977"
/* 206 */       }, { "upsih", "978"
/* 207 */       }, { "piv", "982"
/*     */       },
/* 209 */       { "bull", "8226"
/*     */       },
/* 211 */       { "hellip", "8230"
/* 212 */       }, { "prime", "8242"
/* 213 */       }, { "Prime", "8243"
/* 214 */       }, { "oline", "8254"
/* 215 */       }, { "frasl", "8260"
/*     */       },
/* 217 */       { "weierp", "8472" }, 
/* 218 */       { "image", "8465"
/* 219 */       }, { "real", "8476"
/* 220 */       }, { "trade", "8482"
/* 221 */       }, { "alefsym", "8501"
/*     */       },
/*     */       {
/* 224 */         "larr", "8592"
/* 225 */       }, { "uarr", "8593"
/* 226 */       }, { "rarr", "8594"
/* 227 */       }, { "darr", "8595"
/* 228 */       }, { "harr", "8596"
/* 229 */       }, { "crarr", "8629" }, 
/* 230 */       { "lArr", "8656"
/*     */       },
/* 232 */       { "uArr", "8657"
/* 233 */       }, { "rArr", "8658"
/*     */       },
/* 235 */       { "dArr", "8659"
/* 236 */       }, { "hArr", "8660"
/*     */       },
/* 238 */       { "forall", "8704"
/* 239 */       }, { "part", "8706"
/* 240 */       }, { "exist", "8707"
/* 241 */       }, { "empty", "8709"
/* 242 */       }, { "nabla", "8711" }, 
/* 243 */       { "isin", "8712"
/* 244 */       }, { "notin", "8713"
/* 245 */       }, { "ni", "8715"
/*     */       },
/* 247 */       { "prod", "8719"
/*     */       },
/* 249 */       { "sum", "8721"
/*     */       },
/* 251 */       { "minus", "8722"
/* 252 */       }, { "lowast", "8727"
/* 253 */       }, { "radic", "8730"
/* 254 */       }, { "prop", "8733"
/* 255 */       }, { "infin", "8734" }, 
/* 256 */       { "ang", "8736"
/* 257 */       }, { "and", "8743"
/* 258 */       }, { "or", "8744"
/* 259 */       }, { "cap", "8745"
/* 260 */       }, { "cup", "8746"
/* 261 */       }, { "int", "8747"
/* 262 */       }, { "there4", "8756"
/* 263 */       }, { "sim", "8764"
/*     */       },
/* 265 */       { "cong", "8773"
/* 266 */       }, { "asymp", "8776" }, 
/* 267 */       { "ne", "8800"
/* 268 */       }, { "equiv", "8801"
/* 269 */       }, { "le", "8804"
/* 270 */       }, { "ge", "8805"
/* 271 */       }, { "sub", "8834"
/* 272 */       }, { "sup", "8835"
/*     */       },
/* 274 */       { "sube", "8838"
/* 275 */       }, { "supe", "8839"
/* 276 */       }, { "oplus", "8853"
/* 277 */       }, { "otimes", "8855" }, 
/* 278 */       { "perp", "8869"
/* 279 */       }, { "sdot", "8901"
/*     */       },
/*     */       {
/* 282 */         "lceil", "8968"
/* 283 */       }, { "rceil", "8969"
/* 284 */       }, { "lfloor", "8970"
/* 285 */       }, { "rfloor", "8971"
/* 286 */       }, { "lang", "9001"
/*     */       },
/* 288 */       { "rang", "9002"
/*     */       },
/*     */       {
/* 291 */         "loz", "9674"
/*     */       
/* 293 */       }, { "spades", "9824"
/*     */       }, 
/* 295 */       { "clubs", "9827"
/* 296 */       }, { "hearts", "9829"
/* 297 */       }, { "diams", "9830"
/*     */       },
/*     */       {
/* 300 */         "OElig", "338"
/* 301 */       }, { "oelig", "339"
/*     */       },
/* 303 */       { "Scaron", "352"
/* 304 */       }, { "scaron", "353"
/* 305 */       }, { "Yuml", "376"
/*     */       },
/* 307 */       { "circ", "710"
/* 308 */       }, { "tilde", "732"
/*     */       }, 
/* 310 */       { "ensp", "8194"
/* 311 */       }, { "emsp", "8195"
/* 312 */       }, { "thinsp", "8201"
/* 313 */       }, { "zwnj", "8204"
/* 314 */       }, { "zwj", "8205"
/* 315 */       }, { "lrm", "8206"
/* 316 */       }, { "rlm", "8207"
/* 317 */       }, { "ndash", "8211"
/* 318 */       }, { "mdash", "8212"
/* 319 */       }, { "lsquo", "8216" }, 
/* 320 */       { "rsquo", "8217"
/* 321 */       }, { "sbquo", "8218"
/* 322 */       }, { "ldquo", "8220"
/* 323 */       }, { "rdquo", "8221"
/* 324 */       }, { "bdquo", "8222"
/* 325 */       }, { "dagger", "8224"
/* 326 */       }, { "Dagger", "8225"
/* 327 */       }, { "permil", "8240"
/* 328 */       }, { "lsaquo", "8249"
/*     */       },
/* 330 */       { "rsaquo", "8250"
/*     */       }, 
/* 332 */       { "euro", "8364" }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 351 */   public static final Entities XML = new Entities(); static {
/* 352 */     XML.addEntities(BASIC_ARRAY);
/* 353 */     XML.addEntities(APOS_ARRAY);
/*     */   }
/*     */ 
/*     */   
/* 357 */   public static final Entities HTML32 = new Entities(); static {
/* 358 */     HTML32.addEntities(BASIC_ARRAY);
/* 359 */     HTML32.addEntities(ISO8859_1_ARRAY);
/*     */   }
/*     */ 
/*     */   
/* 363 */   public static final Entities HTML40 = new Entities(); static {
/* 364 */     fillWithHtml40Entities(HTML40);
/*     */   }
/*     */   
/*     */   static void fillWithHtml40Entities(Entities entities) {
/* 368 */     entities.addEntities(BASIC_ARRAY);
/* 369 */     entities.addEntities(ISO8859_1_ARRAY);
/* 370 */     entities.addEntities(HTML40_ARRAY);
/*     */   }
/*     */   
/*     */   static interface EntityMap {
/*     */     void add(String param1String, int param1Int);
/*     */     
/*     */     String name(int param1Int);
/*     */     
/*     */     int value(String param1String);
/*     */   }
/*     */   
/*     */   static class PrimitiveEntityMap implements EntityMap {
/* 382 */     private Map mapNameToValue = new HashMap();
/* 383 */     private IntHashMap mapValueToName = new IntHashMap();
/*     */     
/*     */     public void add(String name, int value) {
/* 386 */       this.mapNameToValue.put(name, new Integer(value));
/* 387 */       this.mapValueToName.put(value, name);
/*     */     }
/*     */     
/*     */     public String name(int value) {
/* 391 */       return (String)this.mapValueToName.get(value);
/*     */     }
/*     */     
/*     */     public int value(String name) {
/* 395 */       Object value = this.mapNameToValue.get(name);
/* 396 */       if (value == null) {
/* 397 */         return -1;
/*     */       }
/* 399 */       return ((Integer)value).intValue();
/*     */     }
/*     */   }
/*     */   
/*     */   static abstract class MapIntMap
/*     */     implements EntityMap {
/*     */     protected Map mapNameToValue;
/*     */     protected Map mapValueToName;
/*     */     
/*     */     public void add(String name, int value) {
/* 409 */       this.mapNameToValue.put(name, new Integer(value));
/* 410 */       this.mapValueToName.put(new Integer(value), name);
/*     */     }
/*     */     
/*     */     public String name(int value) {
/* 414 */       return (String)this.mapValueToName.get(new Integer(value));
/*     */     }
/*     */     
/*     */     public int value(String name) {
/* 418 */       Object value = this.mapNameToValue.get(name);
/* 419 */       if (value == null) {
/* 420 */         return -1;
/*     */       }
/* 422 */       return ((Integer)value).intValue();
/*     */     }
/*     */   }
/*     */   
/*     */   static class HashEntityMap extends MapIntMap {
/*     */     public HashEntityMap() {
/* 428 */       this.mapNameToValue = new HashMap();
/* 429 */       this.mapValueToName = new HashMap();
/*     */     }
/*     */   }
/*     */   
/*     */   static class TreeEntityMap extends MapIntMap {
/*     */     public TreeEntityMap() {
/* 435 */       this.mapNameToValue = new TreeMap();
/* 436 */       this.mapValueToName = new TreeMap();
/*     */     } }
/*     */   
/*     */   static class LookupEntityMap extends PrimitiveEntityMap { private String[] lookupTable;
/*     */     
/*     */     LookupEntityMap() {
/* 442 */       this.LOOKUP_TABLE_SIZE = 256;
/*     */     } private int LOOKUP_TABLE_SIZE;
/*     */     public String name(int value) {
/* 445 */       if (value < this.LOOKUP_TABLE_SIZE) {
/* 446 */         return lookupTable()[value];
/*     */       }
/* 448 */       return super.name(value);
/*     */     }
/*     */     
/*     */     private String[] lookupTable() {
/* 452 */       if (this.lookupTable == null) {
/* 453 */         createLookupTable();
/*     */       }
/* 455 */       return this.lookupTable;
/*     */     }
/*     */     
/*     */     private void createLookupTable() {
/* 459 */       this.lookupTable = new String[this.LOOKUP_TABLE_SIZE];
/* 460 */       for (int i = 0; i < this.LOOKUP_TABLE_SIZE; i++)
/* 461 */         this.lookupTable[i] = super.name(i); 
/*     */     } }
/*     */ 
/*     */   
/*     */   static class ArrayEntityMap
/*     */     implements EntityMap {
/* 467 */     protected int growBy = 100;
/* 468 */     protected int size = 0;
/*     */     protected String[] names;
/*     */     protected int[] values;
/*     */     
/*     */     public ArrayEntityMap() {
/* 473 */       this.names = new String[this.growBy];
/* 474 */       this.values = new int[this.growBy];
/*     */     }
/*     */     
/*     */     public ArrayEntityMap(int growBy) {
/* 478 */       this.growBy = growBy;
/* 479 */       this.names = new String[growBy];
/* 480 */       this.values = new int[growBy];
/*     */     }
/*     */     
/*     */     public void add(String name, int value) {
/* 484 */       ensureCapacity(this.size + 1);
/* 485 */       this.names[this.size] = name;
/* 486 */       this.values[this.size] = value;
/* 487 */       this.size++;
/*     */     }
/*     */     
/*     */     protected void ensureCapacity(int capacity) {
/* 491 */       if (capacity > this.names.length) {
/* 492 */         int newSize = Math.max(capacity, this.size + this.growBy);
/* 493 */         String[] newNames = new String[newSize];
/* 494 */         System.arraycopy(this.names, 0, newNames, 0, this.size);
/* 495 */         this.names = newNames;
/* 496 */         int[] newValues = new int[newSize];
/* 497 */         System.arraycopy(this.values, 0, newValues, 0, this.size);
/* 498 */         this.values = newValues;
/*     */       } 
/*     */     }
/*     */     
/*     */     public String name(int value) {
/* 503 */       for (int i = 0; i < this.size; i++) {
/* 504 */         if (this.values[i] == value) {
/* 505 */           return this.names[i];
/*     */         }
/*     */       } 
/* 508 */       return null;
/*     */     }
/*     */     
/*     */     public int value(String name) {
/* 512 */       for (int i = 0; i < this.size; i++) {
/* 513 */         if (this.names[i].equals(name)) {
/* 514 */           return this.values[i];
/*     */         }
/*     */       } 
/* 517 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   static class BinaryEntityMap
/*     */     extends ArrayEntityMap
/*     */   {
/*     */     public BinaryEntityMap() {}
/*     */     
/*     */     public BinaryEntityMap(int growBy) {
/* 527 */       super(growBy);
/*     */     }
/*     */ 
/*     */     
/*     */     private int binarySearch(int key) {
/* 532 */       int low = 0;
/* 533 */       int high = this.size - 1;
/*     */       
/* 535 */       while (low <= high) {
/* 536 */         int mid = low + high >> 1;
/* 537 */         int midVal = this.values[mid];
/*     */         
/* 539 */         if (midVal < key) {
/* 540 */           low = mid + 1; continue;
/* 541 */         }  if (midVal > key) {
/* 542 */           high = mid - 1; continue;
/*     */         } 
/* 544 */         return mid;
/*     */       } 
/*     */       
/* 547 */       return -(low + 1);
/*     */     }
/*     */     
/*     */     public void add(String name, int value) {
/* 551 */       ensureCapacity(this.size + 1);
/* 552 */       int insertAt = binarySearch(value);
/* 553 */       if (insertAt > 0) {
/*     */         return;
/*     */       }
/* 556 */       insertAt = -(insertAt + 1);
/* 557 */       System.arraycopy(this.values, insertAt, this.values, insertAt + 1, this.size - insertAt);
/* 558 */       this.values[insertAt] = value;
/* 559 */       System.arraycopy(this.names, insertAt, this.names, insertAt + 1, this.size - insertAt);
/* 560 */       this.names[insertAt] = name;
/* 561 */       this.size++;
/*     */     }
/*     */     
/*     */     public String name(int value) {
/* 565 */       int index = binarySearch(value);
/* 566 */       if (index < 0) {
/* 567 */         return null;
/*     */       }
/* 569 */       return this.names[index];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 574 */   EntityMap map = new LookupEntityMap();
/*     */   
/*     */   public void addEntities(String[][] entityArray) {
/* 577 */     for (int i = 0; i < entityArray.length; i++) {
/* 578 */       addEntity(entityArray[i][0], Integer.parseInt(entityArray[i][1]));
/*     */     }
/*     */   }
/*     */   
/*     */   public void addEntity(String name, int value) {
/* 583 */     this.map.add(name, value);
/*     */   }
/*     */   
/*     */   public String entityName(int value) {
/* 587 */     return this.map.name(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int entityValue(String name) {
/* 592 */     return this.map.value(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String escape(String str) {
/* 606 */     StringBuffer buf = new StringBuffer(str.length() * 2);
/*     */     
/* 608 */     for (int i = 0; i < str.length(); i++) {
/* 609 */       char ch = str.charAt(i);
/* 610 */       String entityName = entityName(ch);
/* 611 */       if (entityName == null) {
/* 612 */         if (ch > '') {
/* 613 */           int intValue = ch;
/* 614 */           buf.append("&#");
/* 615 */           buf.append(intValue);
/* 616 */           buf.append(';');
/*     */         } else {
/* 618 */           buf.append(ch);
/*     */         } 
/*     */       } else {
/* 621 */         buf.append('&');
/* 622 */         buf.append(entityName);
/* 623 */         buf.append(';');
/*     */       } 
/*     */     } 
/* 626 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String unescape(String str) {
/* 639 */     StringBuffer buf = new StringBuffer(str.length());
/*     */     
/* 641 */     for (int i = 0; i < str.length(); i++) {
/* 642 */       char ch = str.charAt(i);
/* 643 */       if (ch == '&')
/* 644 */       { int semi = str.indexOf(';', i + 1);
/* 645 */         if (semi == -1) {
/* 646 */           buf.append(ch);
/*     */         } else {
/*     */           int entityValue;
/* 649 */           String entityName = str.substring(i + 1, semi);
/*     */           
/* 651 */           if (entityName.length() == 0) {
/* 652 */             entityValue = -1;
/* 653 */           } else if (entityName.charAt(0) == '#') {
/* 654 */             if (entityName.length() == 1) {
/* 655 */               entityValue = -1;
/*     */             } else {
/* 657 */               char charAt1 = entityName.charAt(1);
/*     */               try {
/* 659 */                 if (charAt1 == 'x' || charAt1 == 'X') {
/* 660 */                   entityValue = Integer.valueOf(entityName.substring(2), 16).intValue();
/*     */                 } else {
/* 662 */                   entityValue = Integer.parseInt(entityName.substring(1));
/*     */                 } 
/* 664 */               } catch (NumberFormatException numberFormatException) {
/* 665 */                 entityValue = -1;
/*     */               } 
/*     */             } 
/*     */           } else {
/* 669 */             entityValue = entityValue(entityName);
/*     */           } 
/* 671 */           if (entityValue == -1) {
/* 672 */             buf.append('&');
/* 673 */             buf.append(entityName);
/* 674 */             buf.append(';');
/*     */           } else {
/* 676 */             buf.append((char)entityValue);
/*     */           } 
/* 678 */           i = semi;
/*     */         }  }
/* 680 */       else { buf.append(ch); }
/*     */     
/*     */     } 
/* 683 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\Entities.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */