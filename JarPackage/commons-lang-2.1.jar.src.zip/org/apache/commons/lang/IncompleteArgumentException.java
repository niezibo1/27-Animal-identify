/*    */ package org.apache.commons.lang;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncompleteArgumentException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   public IncompleteArgumentException(String argName) {
/* 55 */     super(String.valueOf(argName) + " is incomplete.");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IncompleteArgumentException(String argName, String[] items) {
/* 65 */     super(
/* 66 */         String.valueOf(argName) + 
/* 67 */         " is missing the following items: " + 
/* 68 */         safeArrayToString((Object[])items));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final String safeArrayToString(Object[] array) {
/* 78 */     return (array == null) ? null : Arrays.<Object>asList(array).toString();
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\IncompleteArgumentException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */