/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WordUtils
/*     */ {
/*     */   public static String wrap(String str, int wrapLength) {
/* 141 */     return wrap(str, wrapLength, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String wrap(String str, int wrapLength, String newLineStr, boolean wrapLongWords) {
/* 163 */     if (str == null) {
/* 164 */       return null;
/*     */     }
/* 166 */     if (newLineStr == null) {
/* 167 */       newLineStr = SystemUtils.LINE_SEPARATOR;
/*     */     }
/* 169 */     if (wrapLength < 1) {
/* 170 */       wrapLength = 1;
/*     */     }
/* 172 */     int inputLineLength = str.length();
/* 173 */     int offset = 0;
/* 174 */     StringBuffer wrappedLine = new StringBuffer(inputLineLength + 32);
/*     */     
/* 176 */     while (inputLineLength - offset > wrapLength) {
/* 177 */       if (str.charAt(offset) == ' ') {
/* 178 */         offset++;
/*     */         continue;
/*     */       } 
/* 181 */       int spaceToWrapAt = str.lastIndexOf(' ', wrapLength + offset);
/*     */       
/* 183 */       if (spaceToWrapAt >= offset) {
/*     */         
/* 185 */         wrappedLine.append(str.substring(offset, spaceToWrapAt));
/* 186 */         wrappedLine.append(newLineStr);
/* 187 */         offset = spaceToWrapAt + 1;
/*     */         
/*     */         continue;
/*     */       } 
/* 191 */       if (wrapLongWords) {
/*     */         
/* 193 */         wrappedLine.append(str.substring(offset, wrapLength + offset));
/* 194 */         wrappedLine.append(newLineStr);
/* 195 */         offset += wrapLength;
/*     */         continue;
/*     */       } 
/* 198 */       spaceToWrapAt = str.indexOf(' ', wrapLength + offset);
/* 199 */       if (spaceToWrapAt >= 0) {
/* 200 */         wrappedLine.append(str.substring(offset, spaceToWrapAt));
/* 201 */         wrappedLine.append(newLineStr);
/* 202 */         offset = spaceToWrapAt + 1; continue;
/*     */       } 
/* 204 */       wrappedLine.append(str.substring(offset));
/* 205 */       offset = inputLineLength;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     wrappedLine.append(str.substring(offset));
/*     */     
/* 214 */     return wrappedLine.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String capitalize(String str) {
/* 242 */     return capitalize(str, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String capitalize(String str, char[] delimiters) {
/* 275 */     if (str == null || str.length() == 0) {
/* 276 */       return str;
/*     */     }
/* 278 */     int strLen = str.length();
/* 279 */     StringBuffer buffer = new StringBuffer(strLen);
/*     */     
/* 281 */     int delimitersLen = 0;
/* 282 */     if (delimiters != null) {
/* 283 */       delimitersLen = delimiters.length;
/*     */     }
/*     */     
/* 286 */     boolean capitalizeNext = true;
/* 287 */     for (int i = 0; i < strLen; i++) {
/* 288 */       char ch = str.charAt(i);
/*     */       
/* 290 */       boolean isDelimiter = false;
/* 291 */       if (delimiters == null) {
/* 292 */         isDelimiter = Character.isWhitespace(ch);
/*     */       } else {
/* 294 */         for (int j = 0; j < delimitersLen; j++) {
/* 295 */           if (ch == delimiters[j]) {
/* 296 */             isDelimiter = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 302 */       if (isDelimiter) {
/* 303 */         buffer.append(ch);
/* 304 */         capitalizeNext = true;
/* 305 */       } else if (capitalizeNext) {
/* 306 */         buffer.append(Character.toTitleCase(ch));
/* 307 */         capitalizeNext = false;
/*     */       } else {
/* 309 */         buffer.append(ch);
/*     */       } 
/*     */     } 
/* 312 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String capitalizeFully(String str) {
/* 335 */     return capitalizeFully(str, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String capitalizeFully(String str, char[] delimiters) {
/* 365 */     if (str == null || str.length() == 0) {
/* 366 */       return str;
/*     */     }
/* 368 */     str = str.toLowerCase();
/* 369 */     return capitalize(str, delimiters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String uncapitalize(String str) {
/* 390 */     return uncapitalize(str, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String uncapitalize(String str, char[] delimiters) {
/* 419 */     if (str == null || str.length() == 0) {
/* 420 */       return str;
/*     */     }
/* 422 */     int strLen = str.length();
/*     */     
/* 424 */     int delimitersLen = 0;
/* 425 */     if (delimiters != null) {
/* 426 */       delimitersLen = delimiters.length;
/*     */     }
/*     */     
/* 429 */     StringBuffer buffer = new StringBuffer(strLen);
/* 430 */     boolean uncapitalizeNext = true;
/* 431 */     for (int i = 0; i < strLen; i++) {
/* 432 */       char ch = str.charAt(i);
/*     */       
/* 434 */       boolean isDelimiter = false;
/* 435 */       if (delimiters == null) {
/* 436 */         isDelimiter = Character.isWhitespace(ch);
/*     */       } else {
/* 438 */         for (int j = 0; j < delimitersLen; j++) {
/* 439 */           if (ch == delimiters[j]) {
/* 440 */             isDelimiter = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 446 */       if (isDelimiter) {
/* 447 */         buffer.append(ch);
/* 448 */         uncapitalizeNext = true;
/* 449 */       } else if (uncapitalizeNext) {
/* 450 */         buffer.append(Character.toLowerCase(ch));
/* 451 */         uncapitalizeNext = false;
/*     */       } else {
/* 453 */         buffer.append(ch);
/*     */       } 
/*     */     } 
/* 456 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String swapCase(String str) {
/*     */     int strLen;
/* 483 */     if (str == null || (strLen = str.length()) == 0) {
/* 484 */       return str;
/*     */     }
/* 486 */     StringBuffer buffer = new StringBuffer(strLen);
/*     */     
/* 488 */     boolean whitespace = true;
/* 489 */     char ch = Character.MIN_VALUE;
/* 490 */     char tmp = Character.MIN_VALUE;
/*     */     
/* 492 */     for (int i = 0; i < strLen; i++) {
/* 493 */       ch = str.charAt(i);
/* 494 */       if (Character.isUpperCase(ch)) {
/* 495 */         tmp = Character.toLowerCase(ch);
/* 496 */       } else if (Character.isTitleCase(ch)) {
/* 497 */         tmp = Character.toLowerCase(ch);
/* 498 */       } else if (Character.isLowerCase(ch)) {
/* 499 */         if (whitespace) {
/* 500 */           tmp = Character.toTitleCase(ch);
/*     */         } else {
/* 502 */           tmp = Character.toUpperCase(ch);
/*     */         } 
/*     */       } else {
/* 505 */         tmp = ch;
/*     */       } 
/* 507 */       buffer.append(tmp);
/* 508 */       whitespace = Character.isWhitespace(ch);
/*     */     } 
/* 510 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\WordUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */