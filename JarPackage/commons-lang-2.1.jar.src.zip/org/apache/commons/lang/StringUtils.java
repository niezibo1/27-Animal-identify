/*      */ package org.apache.commons.lang;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   public static final String EMPTY = "";
/*      */   public static final int INDEX_NOT_FOUND = -1;
/*      */   private static final int PAD_LIMIT = 8192;
/*  155 */   private static final String[] PADDING = new String[65535];
/*      */ 
/*      */   
/*      */   static {
/*  159 */     PADDING[32] = "                                                                ";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(String str) {
/*  195 */     return !(str != null && str.length() != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotEmpty(String str) {
/*  213 */     return !(str == null || str.length() <= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isBlank(String str) {
/*      */     int strLen;
/*  233 */     if (str == null || (strLen = str.length()) == 0) {
/*  234 */       return true;
/*      */     }
/*  236 */     for (int i = 0; i < strLen; i++) {
/*  237 */       if (Character.isWhitespace(str.charAt(i)) == false) {
/*  238 */         return false;
/*      */       }
/*      */     } 
/*  241 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNotBlank(String str) {
/*      */     int strLen;
/*  262 */     if (str == null || (strLen = str.length()) == 0) {
/*  263 */       return false;
/*      */     }
/*  265 */     for (int i = 0; i < strLen; i++) {
/*  266 */       if (Character.isWhitespace(str.charAt(i)) == false) {
/*  267 */         return true;
/*      */       }
/*      */     } 
/*  270 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String clean(String str) {
/*  295 */     return (str == null) ? "" : str.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trim(String str) {
/*  322 */     return (str == null) ? null : str.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trimToNull(String str) {
/*  348 */     String ts = trim(str);
/*  349 */     return isEmpty(ts) ? null : ts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trimToEmpty(String str) {
/*  374 */     return (str == null) ? "" : str.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String strip(String str) {
/*  402 */     return strip(str, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripToNull(String str) {
/*  429 */     if (str == null) {
/*  430 */       return null;
/*      */     }
/*  432 */     str = strip(str, null);
/*  433 */     return (str.length() == 0) ? null : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripToEmpty(String str) {
/*  459 */     return (str == null) ? "" : strip(str, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String strip(String str, String stripChars) {
/*  489 */     if (isEmpty(str)) {
/*  490 */       return str;
/*      */     }
/*  492 */     str = stripStart(str, stripChars);
/*  493 */     return stripEnd(str, stripChars);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripStart(String str, String stripChars) {
/*      */     int strLen;
/*  522 */     if (str == null || (strLen = str.length()) == 0) {
/*  523 */       return str;
/*      */     }
/*  525 */     int start = 0;
/*  526 */     if (stripChars == null) {
/*  527 */       while (start != strLen && Character.isWhitespace(str.charAt(start)))
/*  528 */         start++; 
/*      */     } else {
/*  530 */       if (stripChars.length() == 0) {
/*  531 */         return str;
/*      */       }
/*  533 */       while (start != strLen && stripChars.indexOf(str.charAt(start)) != -1) {
/*  534 */         start++;
/*      */       }
/*      */     } 
/*  537 */     return str.substring(start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripEnd(String str, String stripChars) {
/*      */     int end;
/*  566 */     if (str == null || (end = str.length()) == 0) {
/*  567 */       return str;
/*      */     }
/*      */     
/*  570 */     if (stripChars == null) {
/*  571 */       while (end != 0 && Character.isWhitespace(str.charAt(end - 1)))
/*  572 */         end--; 
/*      */     } else {
/*  574 */       if (stripChars.length() == 0) {
/*  575 */         return str;
/*      */       }
/*  577 */       while (end != 0 && stripChars.indexOf(str.charAt(end - 1)) != -1) {
/*  578 */         end--;
/*      */       }
/*      */     } 
/*  581 */     return str.substring(0, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] stripAll(String[] strs) {
/*  606 */     return stripAll(strs, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] stripAll(String[] strs, String stripChars) {
/*      */     int strsLen;
/*  636 */     if (strs == null || (strsLen = strs.length) == 0) {
/*  637 */       return strs;
/*      */     }
/*  639 */     String[] newArr = new String[strsLen];
/*  640 */     for (int i = 0; i < strsLen; i++) {
/*  641 */       newArr[i] = strip(strs[i], stripChars);
/*      */     }
/*  643 */     return newArr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equals(String str1, String str2) {
/*  669 */     return (str1 == null) ? (!(str2 != null)) : str1.equals(str2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equalsIgnoreCase(String str1, String str2) {
/*  694 */     return (str1 == null) ? (!(str2 != null)) : str1.equalsIgnoreCase(str2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(String str, char searchChar) {
/*  719 */     if (isEmpty(str)) {
/*  720 */       return -1;
/*      */     }
/*  722 */     return str.indexOf(searchChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(String str, char searchChar, int startPos) {
/*  751 */     if (isEmpty(str)) {
/*  752 */       return -1;
/*      */     }
/*  754 */     return str.indexOf(searchChar, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(String str, String searchStr) {
/*  780 */     if (str == null || searchStr == null) {
/*  781 */       return -1;
/*      */     }
/*  783 */     return str.indexOf(searchStr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int ordinalIndexOf(String str, String searchStr, int ordinal) {
/*  814 */     if (str == null || searchStr == null || ordinal <= 0) {
/*  815 */       return -1;
/*      */     }
/*  817 */     if (searchStr.length() == 0) {
/*  818 */       return 0;
/*      */     }
/*  820 */     int found = 0;
/*  821 */     int index = -1;
/*      */     while (true) {
/*  823 */       index = str.indexOf(searchStr, index + 1);
/*  824 */       if (index < 0) {
/*  825 */         return index;
/*      */       }
/*  827 */       found++;
/*  828 */       if (found >= ordinal) {
/*  829 */         return index;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(String str, String searchStr, int startPos) {
/*  864 */     if (str == null || searchStr == null) {
/*  865 */       return -1;
/*      */     }
/*      */     
/*  868 */     if (searchStr.length() == 0 && startPos >= str.length()) {
/*  869 */       return str.length();
/*      */     }
/*  871 */     return str.indexOf(searchStr, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(String str, char searchChar) {
/*  896 */     if (isEmpty(str)) {
/*  897 */       return -1;
/*      */     }
/*  899 */     return str.lastIndexOf(searchChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(String str, char searchChar, int startPos) {
/*  930 */     if (isEmpty(str)) {
/*  931 */       return -1;
/*      */     }
/*  933 */     return str.lastIndexOf(searchChar, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(String str, String searchStr) {
/*  959 */     if (str == null || searchStr == null) {
/*  960 */       return -1;
/*      */     }
/*  962 */     return str.lastIndexOf(searchStr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(String str, String searchStr, int startPos) {
/*  994 */     if (str == null || searchStr == null) {
/*  995 */       return -1;
/*      */     }
/*  997 */     return str.lastIndexOf(searchStr, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(String str, char searchChar) {
/* 1022 */     if (isEmpty(str)) {
/* 1023 */       return false;
/*      */     }
/* 1025 */     return !(str.indexOf(searchChar) < 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(String str, String searchStr) {
/* 1050 */     if (str == null || searchStr == null) {
/* 1051 */       return false;
/*      */     }
/* 1053 */     return !(str.indexOf(searchStr) < 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(String str, char[] searchChars) {
/* 1081 */     if (isEmpty(str) || ArrayUtils.isEmpty(searchChars)) {
/* 1082 */       return -1;
/*      */     }
/* 1084 */     for (int i = 0; i < str.length(); i++) {
/* 1085 */       char ch = str.charAt(i);
/* 1086 */       for (int j = 0; j < searchChars.length; j++) {
/* 1087 */         if (searchChars[j] == ch) {
/* 1088 */           return i;
/*      */         }
/*      */       } 
/*      */     } 
/* 1092 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(String str, String searchChars) {
/* 1118 */     if (isEmpty(str) || isEmpty(searchChars)) {
/* 1119 */       return -1;
/*      */     }
/* 1121 */     return indexOfAny(str, searchChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAnyBut(String str, char[] searchChars) {
/* 1149 */     if (isEmpty(str) || ArrayUtils.isEmpty(searchChars)) {
/* 1150 */       return -1;
/*      */     }
/* 1152 */     for (int i = 0; i < str.length(); i++) {
/* 1153 */       char ch = str.charAt(i);
/* 1154 */       int j = 0; while (true) { if (j >= searchChars.length)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1159 */           return i; }  if (searchChars[j] == ch)
/*      */           break;  j++; } 
/* 1161 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAnyBut(String str, String searchChars) {
/* 1187 */     if (isEmpty(str) || isEmpty(searchChars)) {
/* 1188 */       return -1;
/*      */     }
/* 1190 */     for (int i = 0; i < str.length(); i++) {
/* 1191 */       if (searchChars.indexOf(str.charAt(i)) < 0) {
/* 1192 */         return i;
/*      */       }
/*      */     } 
/* 1195 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsOnly(String str, char[] valid) {
/* 1223 */     if (valid == null || str == null) {
/* 1224 */       return false;
/*      */     }
/* 1226 */     if (str.length() == 0) {
/* 1227 */       return true;
/*      */     }
/* 1229 */     if (valid.length == 0) {
/* 1230 */       return false;
/*      */     }
/* 1232 */     return !(indexOfAnyBut(str, valid) != -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsOnly(String str, String validChars) {
/* 1258 */     if (str == null || validChars == null) {
/* 1259 */       return false;
/*      */     }
/* 1261 */     return containsOnly(str, validChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsNone(String str, char[] invalidChars) {
/* 1289 */     if (str == null || invalidChars == null) {
/* 1290 */       return true;
/*      */     }
/* 1292 */     int strSize = str.length();
/* 1293 */     int validSize = invalidChars.length;
/* 1294 */     for (int i = 0; i < strSize; i++) {
/* 1295 */       char ch = str.charAt(i);
/* 1296 */       for (int j = 0; j < validSize; j++) {
/* 1297 */         if (invalidChars[j] == ch) {
/* 1298 */           return false;
/*      */         }
/*      */       } 
/*      */     } 
/* 1302 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsNone(String str, String invalidChars) {
/* 1328 */     if (str == null || invalidChars == null) {
/* 1329 */       return true;
/*      */     }
/* 1331 */     return containsNone(str, invalidChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(String str, String[] searchStrs) {
/* 1363 */     if (str == null || searchStrs == null) {
/* 1364 */       return -1;
/*      */     }
/* 1366 */     int sz = searchStrs.length;
/*      */ 
/*      */     
/* 1369 */     int ret = Integer.MAX_VALUE;
/*      */     
/* 1371 */     int tmp = 0;
/* 1372 */     for (int i = 0; i < sz; i++) {
/* 1373 */       String search = searchStrs[i];
/* 1374 */       if (search != null) {
/*      */ 
/*      */         
/* 1377 */         tmp = str.indexOf(search);
/* 1378 */         if (tmp != -1)
/*      */         {
/*      */ 
/*      */           
/* 1382 */           if (tmp < ret)
/* 1383 */             ret = tmp; 
/*      */         }
/*      */       } 
/*      */     } 
/* 1387 */     return (ret == Integer.MAX_VALUE) ? -1 : ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOfAny(String str, String[] searchStrs) {
/* 1416 */     if (str == null || searchStrs == null) {
/* 1417 */       return -1;
/*      */     }
/* 1419 */     int sz = searchStrs.length;
/* 1420 */     int ret = -1;
/* 1421 */     int tmp = 0;
/* 1422 */     for (int i = 0; i < sz; i++) {
/* 1423 */       String search = searchStrs[i];
/* 1424 */       if (search != null) {
/*      */ 
/*      */         
/* 1427 */         tmp = str.lastIndexOf(search);
/* 1428 */         if (tmp > ret)
/* 1429 */           ret = tmp; 
/*      */       } 
/*      */     } 
/* 1432 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substring(String str, int start) {
/* 1462 */     if (str == null) {
/* 1463 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1467 */     if (start < 0) {
/* 1468 */       start = str.length() + start;
/*      */     }
/*      */     
/* 1471 */     if (start < 0) {
/* 1472 */       start = 0;
/*      */     }
/* 1474 */     if (start > str.length()) {
/* 1475 */       return "";
/*      */     }
/*      */     
/* 1478 */     return str.substring(start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substring(String str, int start, int end) {
/* 1517 */     if (str == null) {
/* 1518 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1522 */     if (end < 0) {
/* 1523 */       end = str.length() + end;
/*      */     }
/* 1525 */     if (start < 0) {
/* 1526 */       start = str.length() + start;
/*      */     }
/*      */ 
/*      */     
/* 1530 */     if (end > str.length()) {
/* 1531 */       end = str.length();
/*      */     }
/*      */ 
/*      */     
/* 1535 */     if (start > end) {
/* 1536 */       return "";
/*      */     }
/*      */     
/* 1539 */     if (start < 0) {
/* 1540 */       start = 0;
/*      */     }
/* 1542 */     if (end < 0) {
/* 1543 */       end = 0;
/*      */     }
/*      */     
/* 1546 */     return str.substring(start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String left(String str, int len) {
/* 1572 */     if (str == null) {
/* 1573 */       return null;
/*      */     }
/* 1575 */     if (len < 0) {
/* 1576 */       return "";
/*      */     }
/* 1578 */     if (str.length() <= len) {
/* 1579 */       return str;
/*      */     }
/* 1581 */     return str.substring(0, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String right(String str, int len) {
/* 1606 */     if (str == null) {
/* 1607 */       return null;
/*      */     }
/* 1609 */     if (len < 0) {
/* 1610 */       return "";
/*      */     }
/* 1612 */     if (str.length() <= len) {
/* 1613 */       return str;
/*      */     }
/* 1615 */     return str.substring(str.length() - len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mid(String str, int pos, int len) {
/* 1644 */     if (str == null) {
/* 1645 */       return null;
/*      */     }
/* 1647 */     if (len < 0 || pos > str.length()) {
/* 1648 */       return "";
/*      */     }
/* 1650 */     if (pos < 0) {
/* 1651 */       pos = 0;
/*      */     }
/* 1653 */     if (str.length() <= pos + len) {
/* 1654 */       return str.substring(pos);
/*      */     }
/* 1656 */     return str.substring(pos, pos + len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBefore(String str, String separator) {
/* 1688 */     if (isEmpty(str) || separator == null) {
/* 1689 */       return str;
/*      */     }
/* 1691 */     if (separator.length() == 0) {
/* 1692 */       return "";
/*      */     }
/* 1694 */     int pos = str.indexOf(separator);
/* 1695 */     if (pos == -1) {
/* 1696 */       return str;
/*      */     }
/* 1698 */     return str.substring(0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringAfter(String str, String separator) {
/* 1728 */     if (isEmpty(str)) {
/* 1729 */       return str;
/*      */     }
/* 1731 */     if (separator == null) {
/* 1732 */       return "";
/*      */     }
/* 1734 */     int pos = str.indexOf(separator);
/* 1735 */     if (pos == -1) {
/* 1736 */       return "";
/*      */     }
/* 1738 */     return str.substring(pos + separator.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBeforeLast(String str, String separator) {
/* 1767 */     if (isEmpty(str) || isEmpty(separator)) {
/* 1768 */       return str;
/*      */     }
/* 1770 */     int pos = str.lastIndexOf(separator);
/* 1771 */     if (pos == -1) {
/* 1772 */       return str;
/*      */     }
/* 1774 */     return str.substring(0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringAfterLast(String str, String separator) {
/* 1805 */     if (isEmpty(str)) {
/* 1806 */       return str;
/*      */     }
/* 1808 */     if (isEmpty(separator)) {
/* 1809 */       return "";
/*      */     }
/* 1811 */     int pos = str.lastIndexOf(separator);
/* 1812 */     if (pos == -1 || pos == str.length() - separator.length()) {
/* 1813 */       return "";
/*      */     }
/* 1815 */     return str.substring(pos + separator.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBetween(String str, String tag) {
/* 1842 */     return substringBetween(str, tag, tag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBetween(String str, String open, String close) {
/* 1871 */     if (str == null || open == null || close == null) {
/* 1872 */       return null;
/*      */     }
/* 1874 */     int start = str.indexOf(open);
/* 1875 */     if (start != -1) {
/* 1876 */       int end = str.indexOf(close, start + open.length());
/* 1877 */       if (end != -1) {
/* 1878 */         return str.substring(start + open.length(), end);
/*      */       }
/*      */     } 
/* 1881 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getNestedString(String str, String tag) {
/* 1909 */     return substringBetween(str, tag, tag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getNestedString(String str, String open, String close) {
/* 1939 */     return substringBetween(str, open, close);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String str) {
/* 1967 */     return split(str, null, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String str, char separatorChar) {
/* 1997 */     return splitWorker(str, separatorChar, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String str, String separatorChars) {
/* 2026 */     return splitWorker(str, separatorChars, -1, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String str, String separatorChars, int max) {
/* 2060 */     return splitWorker(str, separatorChars, max, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitByWholeSeparator(String str, String separator) {
/* 2088 */     return splitByWholeSeparator(str, separator, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitByWholeSeparator(String str, String separator, int max) {
/* 2119 */     if (str == null) {
/* 2120 */       return null;
/*      */     }
/*      */     
/* 2123 */     int len = str.length();
/*      */     
/* 2125 */     if (len == 0) {
/* 2126 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/*      */     
/* 2129 */     if (separator == null || "".equals(separator))
/*      */     {
/* 2131 */       return split(str, null, max);
/*      */     }
/*      */ 
/*      */     
/* 2135 */     int separatorLength = separator.length();
/*      */     
/* 2137 */     ArrayList substrings = new ArrayList();
/* 2138 */     int numberOfSubstrings = 0;
/* 2139 */     int beg = 0;
/* 2140 */     int end = 0;
/* 2141 */     while (end < len) {
/* 2142 */       end = str.indexOf(separator, beg);
/*      */       
/* 2144 */       if (end > -1) {
/* 2145 */         if (end > beg) {
/* 2146 */           numberOfSubstrings++;
/*      */           
/* 2148 */           if (numberOfSubstrings == max) {
/* 2149 */             end = len;
/* 2150 */             substrings.add(str.substring(beg));
/*      */             
/*      */             continue;
/*      */           } 
/* 2154 */           substrings.add(str.substring(beg, end));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2159 */           beg = end + separatorLength;
/*      */           
/*      */           continue;
/*      */         } 
/* 2163 */         beg = end + separatorLength;
/*      */         
/*      */         continue;
/*      */       } 
/* 2167 */       substrings.add(str.substring(beg));
/* 2168 */       end = len;
/*      */     } 
/*      */ 
/*      */     
/* 2172 */     return substrings.<String>toArray(new String[substrings.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitPreserveAllTokens(String str) {
/* 2202 */     return splitWorker(str, null, -1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitPreserveAllTokens(String str, char separatorChar) {
/* 2238 */     return splitWorker(str, separatorChar, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitWorker(String str, char separatorChar, boolean preserveAllTokens) {
/* 2256 */     if (str == null) {
/* 2257 */       return null;
/*      */     }
/* 2259 */     int len = str.length();
/* 2260 */     if (len == 0) {
/* 2261 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2263 */     List list = new ArrayList();
/* 2264 */     int i = 0, start = 0;
/* 2265 */     boolean match = false;
/* 2266 */     boolean lastMatch = false;
/* 2267 */     while (i < len) {
/* 2268 */       if (str.charAt(i) == separatorChar) {
/* 2269 */         if (match || preserveAllTokens) {
/* 2270 */           list.add(str.substring(start, i));
/* 2271 */           match = false;
/* 2272 */           lastMatch = true;
/*      */         } 
/* 2274 */         start = ++i;
/*      */         continue;
/*      */       } 
/* 2277 */       lastMatch = false;
/*      */       
/* 2279 */       match = true;
/* 2280 */       i++;
/*      */     } 
/* 2282 */     if (match || (preserveAllTokens && lastMatch)) {
/* 2283 */       list.add(str.substring(start, i));
/*      */     }
/* 2285 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitPreserveAllTokens(String str, String separatorChars) {
/* 2322 */     return splitWorker(str, separatorChars, -1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitPreserveAllTokens(String str, String separatorChars, int max) {
/* 2362 */     return splitWorker(str, separatorChars, max, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitWorker(String str, String separatorChars, int max, boolean preserveAllTokens) {
/* 2384 */     if (str == null) {
/* 2385 */       return null;
/*      */     }
/* 2387 */     int len = str.length();
/* 2388 */     if (len == 0) {
/* 2389 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2391 */     List list = new ArrayList();
/* 2392 */     int sizePlus1 = 1;
/* 2393 */     int i = 0, start = 0;
/* 2394 */     boolean match = false;
/* 2395 */     boolean lastMatch = false;
/* 2396 */     if (separatorChars == null) {
/*      */       
/* 2398 */       while (i < len) {
/* 2399 */         if (Character.isWhitespace(str.charAt(i))) {
/* 2400 */           if (match || preserveAllTokens) {
/* 2401 */             lastMatch = true;
/* 2402 */             if (sizePlus1++ == max) {
/* 2403 */               i = len;
/* 2404 */               lastMatch = false;
/*      */             } 
/* 2406 */             list.add(str.substring(start, i));
/* 2407 */             match = false;
/*      */           } 
/* 2409 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 2412 */         lastMatch = false;
/*      */         
/* 2414 */         match = true;
/* 2415 */         i++;
/*      */       } 
/* 2417 */     } else if (separatorChars.length() == 1) {
/*      */       
/* 2419 */       char sep = separatorChars.charAt(0);
/* 2420 */       while (i < len) {
/* 2421 */         if (str.charAt(i) == sep) {
/* 2422 */           if (match || preserveAllTokens) {
/* 2423 */             lastMatch = true;
/* 2424 */             if (sizePlus1++ == max) {
/* 2425 */               i = len;
/* 2426 */               lastMatch = false;
/*      */             } 
/* 2428 */             list.add(str.substring(start, i));
/* 2429 */             match = false;
/*      */           } 
/* 2431 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 2434 */         lastMatch = false;
/*      */         
/* 2436 */         match = true;
/* 2437 */         i++;
/*      */       } 
/*      */     } else {
/*      */       
/* 2441 */       while (i < len) {
/* 2442 */         if (separatorChars.indexOf(str.charAt(i)) >= 0) {
/* 2443 */           if (match || preserveAllTokens) {
/* 2444 */             lastMatch = true;
/* 2445 */             if (sizePlus1++ == max) {
/* 2446 */               i = len;
/* 2447 */               lastMatch = false;
/*      */             } 
/* 2449 */             list.add(str.substring(start, i));
/* 2450 */             match = false;
/*      */           } 
/* 2452 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 2455 */         lastMatch = false;
/*      */         
/* 2457 */         match = true;
/* 2458 */         i++;
/*      */       } 
/*      */     } 
/* 2461 */     if (match || (preserveAllTokens && lastMatch)) {
/* 2462 */       list.add(str.substring(start, i));
/*      */     }
/* 2464 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String concatenate(Object[] array) {
/* 2488 */     return join(array, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array) {
/* 2512 */     return join(array, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, char separator) {
/* 2538 */     if (array == null) {
/* 2539 */       return null;
/*      */     }
/* 2541 */     int arraySize = array.length;
/* 2542 */     int bufSize = (arraySize == 0) ? 0 : ((((array[0] == null) ? 16 : array[0].toString().length()) + 1) * arraySize);
/* 2543 */     StringBuffer buf = new StringBuffer(bufSize);
/*      */     
/* 2545 */     for (int i = 0; i < arraySize; i++) {
/* 2546 */       if (i > 0) {
/* 2547 */         buf.append(separator);
/*      */       }
/* 2549 */       if (array[i] != null) {
/* 2550 */         buf.append(array[i]);
/*      */       }
/*      */     } 
/* 2553 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, String separator) {
/* 2580 */     if (array == null) {
/* 2581 */       return null;
/*      */     }
/* 2583 */     if (separator == null) {
/* 2584 */       separator = "";
/*      */     }
/* 2586 */     int arraySize = array.length;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2591 */     int bufSize = 
/* 2592 */       (arraySize == 0) ? 
/* 2593 */       0 : (
/* 2594 */       arraySize * ((
/* 2595 */       (array[0] == null) ? 16 : array[0].toString().length()) + 
/* 2596 */       separator.length()));
/*      */     
/* 2598 */     StringBuffer buf = new StringBuffer(bufSize);
/*      */     
/* 2600 */     for (int i = 0; i < arraySize; i++) {
/* 2601 */       if (i > 0) {
/* 2602 */         buf.append(separator);
/*      */       }
/* 2604 */       if (array[i] != null) {
/* 2605 */         buf.append(array[i]);
/*      */       }
/*      */     } 
/* 2608 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterator iterator, char separator) {
/* 2626 */     if (iterator == null) {
/* 2627 */       return null;
/*      */     }
/* 2629 */     StringBuffer buf = new StringBuffer(256);
/* 2630 */     while (iterator.hasNext()) {
/* 2631 */       Object obj = iterator.next();
/* 2632 */       if (obj != null) {
/* 2633 */         buf.append(obj);
/*      */       }
/* 2635 */       if (iterator.hasNext()) {
/* 2636 */         buf.append(separator);
/*      */       }
/*      */     } 
/* 2639 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterator iterator, String separator) {
/* 2656 */     if (iterator == null) {
/* 2657 */       return null;
/*      */     }
/* 2659 */     StringBuffer buf = new StringBuffer(256);
/* 2660 */     while (iterator.hasNext()) {
/* 2661 */       Object obj = iterator.next();
/* 2662 */       if (obj != null) {
/* 2663 */         buf.append(obj);
/*      */       }
/* 2665 */       if (separator != null && iterator.hasNext()) {
/* 2666 */         buf.append(separator);
/*      */       }
/*      */     } 
/* 2669 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String deleteSpaces(String str) {
/* 2701 */     if (str == null) {
/* 2702 */       return null;
/*      */     }
/* 2704 */     return CharSetUtils.delete(str, " \t\r\n\b");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String deleteWhitespace(String str) {
/* 2722 */     if (isEmpty(str)) {
/* 2723 */       return str;
/*      */     }
/* 2725 */     int sz = str.length();
/* 2726 */     char[] chs = new char[sz];
/* 2727 */     int count = 0;
/* 2728 */     for (int i = 0; i < sz; i++) {
/* 2729 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 2730 */         chs[count++] = str.charAt(i);
/*      */       }
/*      */     } 
/* 2733 */     if (count == sz) {
/* 2734 */       return str;
/*      */     }
/* 2736 */     return new String(chs, 0, count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeStart(String str, String remove) {
/* 2766 */     if (isEmpty(str) || isEmpty(remove)) {
/* 2767 */       return str;
/*      */     }
/* 2769 */     if (str.startsWith(remove)) {
/* 2770 */       return str.substring(remove.length());
/*      */     }
/* 2772 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeEnd(String str, String remove) {
/* 2800 */     if (isEmpty(str) || isEmpty(remove)) {
/* 2801 */       return str;
/*      */     }
/* 2803 */     if (str.endsWith(remove)) {
/* 2804 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 2806 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String remove(String str, String remove) {
/* 2833 */     if (isEmpty(str) || isEmpty(remove)) {
/* 2834 */       return str;
/*      */     }
/* 2836 */     return replace(str, remove, "", -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String remove(String str, char remove) {
/* 2859 */     if (isEmpty(str) || str.indexOf(remove) == -1) {
/* 2860 */       return str;
/*      */     }
/* 2862 */     char[] chars = str.toCharArray();
/* 2863 */     int pos = 0;
/* 2864 */     for (int i = 0; i < chars.length; i++) {
/* 2865 */       if (chars[i] != remove) {
/* 2866 */         chars[pos++] = chars[i];
/*      */       }
/*      */     } 
/* 2869 */     return new String(chars, 0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceOnce(String text, String repl, String with) {
/* 2898 */     return replace(text, repl, with, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replace(String text, String repl, String with) {
/* 2925 */     return replace(text, repl, with, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replace(String text, String repl, String with, int max) {
/* 2957 */     if (text == null || isEmpty(repl) || with == null || max == 0) {
/* 2958 */       return text;
/*      */     }
/*      */     
/* 2961 */     StringBuffer buf = new StringBuffer(text.length());
/* 2962 */     int start = 0, end = 0;
/* 2963 */     while ((end = text.indexOf(repl, start)) != -1) {
/* 2964 */       buf.append(text.substring(start, end)).append(with);
/* 2965 */       start = end + repl.length();
/*      */       
/* 2967 */       if (--max == 0) {
/*      */         break;
/*      */       }
/*      */     } 
/* 2971 */     buf.append(text.substring(start));
/* 2972 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceChars(String str, char searchChar, char replaceChar) {
/* 2998 */     if (str == null) {
/* 2999 */       return null;
/*      */     }
/* 3001 */     return str.replace(searchChar, replaceChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceChars(String str, String searchChars, String replaceChars) {
/* 3041 */     if (isEmpty(str) || isEmpty(searchChars)) {
/* 3042 */       return str;
/*      */     }
/* 3044 */     if (replaceChars == null) {
/* 3045 */       replaceChars = "";
/*      */     }
/* 3047 */     boolean modified = false;
/* 3048 */     StringBuffer buf = new StringBuffer(str.length());
/* 3049 */     for (int i = 0; i < str.length(); i++) {
/* 3050 */       char ch = str.charAt(i);
/* 3051 */       int index = searchChars.indexOf(ch);
/* 3052 */       if (index >= 0) {
/* 3053 */         modified = true;
/* 3054 */         if (index < replaceChars.length()) {
/* 3055 */           buf.append(replaceChars.charAt(index));
/*      */         }
/*      */       } else {
/* 3058 */         buf.append(ch);
/*      */       } 
/*      */     } 
/* 3061 */     if (modified) {
/* 3062 */       return buf.toString();
/*      */     }
/* 3064 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String overlayString(String text, String overlay, int start, int end) {
/* 3096 */     return (new StringBuffer(start + overlay.length() + text.length() - end + 1))
/* 3097 */       .append(text.substring(0, start))
/* 3098 */       .append(overlay)
/* 3099 */       .append(text.substring(end))
/* 3100 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String overlay(String str, String overlay, int start, int end) {
/* 3133 */     if (str == null) {
/* 3134 */       return null;
/*      */     }
/* 3136 */     if (overlay == null) {
/* 3137 */       overlay = "";
/*      */     }
/* 3139 */     int len = str.length();
/* 3140 */     if (start < 0) {
/* 3141 */       start = 0;
/*      */     }
/* 3143 */     if (start > len) {
/* 3144 */       start = len;
/*      */     }
/* 3146 */     if (end < 0) {
/* 3147 */       end = 0;
/*      */     }
/* 3149 */     if (end > len) {
/* 3150 */       end = len;
/*      */     }
/* 3152 */     if (start > end) {
/* 3153 */       int temp = start;
/* 3154 */       start = end;
/* 3155 */       end = temp;
/*      */     } 
/* 3157 */     return (new StringBuffer(len + start - end + overlay.length() + 1))
/* 3158 */       .append(str.substring(0, start))
/* 3159 */       .append(overlay)
/* 3160 */       .append(str.substring(end))
/* 3161 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chomp(String str) {
/* 3192 */     if (isEmpty(str)) {
/* 3193 */       return str;
/*      */     }
/*      */     
/* 3196 */     if (str.length() == 1) {
/* 3197 */       char ch = str.charAt(0);
/* 3198 */       if (ch == '\r' || ch == '\n') {
/* 3199 */         return "";
/*      */       }
/* 3201 */       return str;
/*      */     } 
/*      */ 
/*      */     
/* 3205 */     int lastIdx = str.length() - 1;
/* 3206 */     char last = str.charAt(lastIdx);
/*      */     
/* 3208 */     if (last == '\n') {
/* 3209 */       if (str.charAt(lastIdx - 1) == '\r') {
/* 3210 */         lastIdx--;
/*      */       }
/* 3212 */     } else if (last != '\r') {
/*      */ 
/*      */ 
/*      */       
/* 3216 */       lastIdx++;
/*      */     } 
/* 3218 */     return str.substring(0, lastIdx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chomp(String str, String separator) {
/* 3248 */     if (isEmpty(str) || separator == null) {
/* 3249 */       return str;
/*      */     }
/* 3251 */     if (str.endsWith(separator)) {
/* 3252 */       return str.substring(0, str.length() - separator.length());
/*      */     }
/* 3254 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chompLast(String str) {
/* 3268 */     return chompLast(str, "\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chompLast(String str, String sep) {
/* 3282 */     if (str.length() == 0) {
/* 3283 */       return str;
/*      */     }
/* 3285 */     String sub = str.substring(str.length() - sep.length());
/* 3286 */     if (sep.equals(sub)) {
/* 3287 */       return str.substring(0, str.length() - sep.length());
/*      */     }
/* 3289 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getChomp(String str, String sep) {
/* 3306 */     int idx = str.lastIndexOf(sep);
/* 3307 */     if (idx == str.length() - sep.length())
/* 3308 */       return sep; 
/* 3309 */     if (idx != -1) {
/* 3310 */       return str.substring(idx);
/*      */     }
/* 3312 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String prechomp(String str, String sep) {
/* 3328 */     int idx = str.indexOf(sep);
/* 3329 */     if (idx != -1) {
/* 3330 */       return str.substring(idx + sep.length());
/*      */     }
/* 3332 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPrechomp(String str, String sep) {
/* 3349 */     int idx = str.indexOf(sep);
/* 3350 */     if (idx != -1) {
/* 3351 */       return str.substring(0, idx + sep.length());
/*      */     }
/* 3353 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chop(String str) {
/* 3383 */     if (str == null) {
/* 3384 */       return null;
/*      */     }
/* 3386 */     int strLen = str.length();
/* 3387 */     if (strLen < 2) {
/* 3388 */       return "";
/*      */     }
/* 3390 */     int lastIdx = strLen - 1;
/* 3391 */     String ret = str.substring(0, lastIdx);
/* 3392 */     char last = str.charAt(lastIdx);
/* 3393 */     if (last == '\n' && 
/* 3394 */       ret.charAt(lastIdx - 1) == '\r') {
/* 3395 */       return ret.substring(0, lastIdx - 1);
/*      */     }
/*      */     
/* 3398 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chopNewline(String str) {
/* 3412 */     int lastIdx = str.length() - 1;
/* 3413 */     if (lastIdx <= 0) {
/* 3414 */       return "";
/*      */     }
/* 3416 */     char last = str.charAt(lastIdx);
/* 3417 */     if (last == '\n') {
/* 3418 */       if (str.charAt(lastIdx - 1) == '\r') {
/* 3419 */         lastIdx--;
/*      */       }
/*      */     } else {
/* 3422 */       lastIdx++;
/*      */     } 
/* 3424 */     return str.substring(0, lastIdx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String escape(String str) {
/* 3446 */     return StringEscapeUtils.escapeJava(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String repeat(String str, int repeat) {
/*      */     char ch, output1[];
/*      */     int i;
/*      */     char ch0, ch1, output2[];
/*      */     int j;
/* 3472 */     if (str == null) {
/* 3473 */       return null;
/*      */     }
/* 3475 */     if (repeat <= 0) {
/* 3476 */       return "";
/*      */     }
/* 3478 */     int inputLength = str.length();
/* 3479 */     if (repeat == 1 || inputLength == 0) {
/* 3480 */       return str;
/*      */     }
/* 3482 */     if (inputLength == 1 && repeat <= 8192) {
/* 3483 */       return padding(repeat, str.charAt(0));
/*      */     }
/*      */     
/* 3486 */     int outputLength = inputLength * repeat;
/* 3487 */     switch (inputLength) {
/*      */       case 1:
/* 3489 */         ch = str.charAt(0);
/* 3490 */         output1 = new char[outputLength];
/* 3491 */         for (i = repeat - 1; i >= 0; i--) {
/* 3492 */           output1[i] = ch;
/*      */         }
/* 3494 */         return new String(output1);
/*      */       case 2:
/* 3496 */         ch0 = str.charAt(0);
/* 3497 */         ch1 = str.charAt(1);
/* 3498 */         output2 = new char[outputLength];
/* 3499 */         for (j = repeat * 2 - 2; j >= 0; j--, j--) {
/* 3500 */           output2[j] = ch0;
/* 3501 */           output2[j + 1] = ch1;
/*      */         } 
/* 3503 */         return new String(output2);
/*      */     } 
/* 3505 */     StringBuffer buf = new StringBuffer(outputLength);
/* 3506 */     for (int k = 0; k < repeat; k++) {
/* 3507 */       buf.append(str);
/*      */     }
/* 3509 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String padding(int repeat, char padChar) {
/* 3531 */     String pad = PADDING[padChar];
/* 3532 */     if (pad == null) {
/* 3533 */       pad = String.valueOf(padChar);
/*      */     }
/* 3535 */     while (pad.length() < repeat) {
/* 3536 */       pad = pad.concat(pad);
/*      */     }
/* 3538 */     PADDING[padChar] = pad;
/* 3539 */     return pad.substring(0, repeat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size) {
/* 3562 */     return rightPad(str, size, ' ');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size, char padChar) {
/* 3587 */     if (str == null) {
/* 3588 */       return null;
/*      */     }
/* 3590 */     int pads = size - str.length();
/* 3591 */     if (pads <= 0) {
/* 3592 */       return str;
/*      */     }
/* 3594 */     if (pads > 8192) {
/* 3595 */       return rightPad(str, size, String.valueOf(padChar));
/*      */     }
/* 3597 */     return str.concat(padding(pads, padChar));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size, String padStr) {
/* 3624 */     if (str == null) {
/* 3625 */       return null;
/*      */     }
/* 3627 */     if (isEmpty(padStr)) {
/* 3628 */       padStr = " ";
/*      */     }
/* 3630 */     int padLen = padStr.length();
/* 3631 */     int strLen = str.length();
/* 3632 */     int pads = size - strLen;
/* 3633 */     if (pads <= 0) {
/* 3634 */       return str;
/*      */     }
/* 3636 */     if (padLen == 1 && pads <= 8192) {
/* 3637 */       return rightPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 3640 */     if (pads == padLen)
/* 3641 */       return str.concat(padStr); 
/* 3642 */     if (pads < padLen) {
/* 3643 */       return str.concat(padStr.substring(0, pads));
/*      */     }
/* 3645 */     char[] padding = new char[pads];
/* 3646 */     char[] padChars = padStr.toCharArray();
/* 3647 */     for (int i = 0; i < pads; i++) {
/* 3648 */       padding[i] = padChars[i % padLen];
/*      */     }
/* 3650 */     return str.concat(new String(padding));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String leftPad(String str, int size) {
/* 3674 */     return leftPad(str, size, ' ');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String leftPad(String str, int size, char padChar) {
/* 3699 */     if (str == null) {
/* 3700 */       return null;
/*      */     }
/* 3702 */     int pads = size - str.length();
/* 3703 */     if (pads <= 0) {
/* 3704 */       return str;
/*      */     }
/* 3706 */     if (pads > 8192) {
/* 3707 */       return leftPad(str, size, String.valueOf(padChar));
/*      */     }
/* 3709 */     return padding(pads, padChar).concat(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String leftPad(String str, int size, String padStr) {
/* 3736 */     if (str == null) {
/* 3737 */       return null;
/*      */     }
/* 3739 */     if (isEmpty(padStr)) {
/* 3740 */       padStr = " ";
/*      */     }
/* 3742 */     int padLen = padStr.length();
/* 3743 */     int strLen = str.length();
/* 3744 */     int pads = size - strLen;
/* 3745 */     if (pads <= 0) {
/* 3746 */       return str;
/*      */     }
/* 3748 */     if (padLen == 1 && pads <= 8192) {
/* 3749 */       return leftPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 3752 */     if (pads == padLen)
/* 3753 */       return padStr.concat(str); 
/* 3754 */     if (pads < padLen) {
/* 3755 */       return padStr.substring(0, pads).concat(str);
/*      */     }
/* 3757 */     char[] padding = new char[pads];
/* 3758 */     char[] padChars = padStr.toCharArray();
/* 3759 */     for (int i = 0; i < pads; i++) {
/* 3760 */       padding[i] = padChars[i % padLen];
/*      */     }
/* 3762 */     return (new String(padding)).concat(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String center(String str, int size) {
/* 3792 */     return center(str, size, ' ');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String center(String str, int size, char padChar) {
/* 3820 */     if (str == null || size <= 0) {
/* 3821 */       return str;
/*      */     }
/* 3823 */     int strLen = str.length();
/* 3824 */     int pads = size - strLen;
/* 3825 */     if (pads <= 0) {
/* 3826 */       return str;
/*      */     }
/* 3828 */     str = leftPad(str, strLen + pads / 2, padChar);
/* 3829 */     str = rightPad(str, size, padChar);
/* 3830 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String center(String str, int size, String padStr) {
/* 3860 */     if (str == null || size <= 0) {
/* 3861 */       return str;
/*      */     }
/* 3863 */     if (isEmpty(padStr)) {
/* 3864 */       padStr = " ";
/*      */     }
/* 3866 */     int strLen = str.length();
/* 3867 */     int pads = size - strLen;
/* 3868 */     if (pads <= 0) {
/* 3869 */       return str;
/*      */     }
/* 3871 */     str = leftPad(str, strLen + pads / 2, padStr);
/* 3872 */     str = rightPad(str, size, padStr);
/* 3873 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String upperCase(String str) {
/* 3893 */     if (str == null) {
/* 3894 */       return null;
/*      */     }
/* 3896 */     return str.toUpperCase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String lowerCase(String str) {
/* 3914 */     if (str == null) {
/* 3915 */       return null;
/*      */     }
/* 3917 */     return str.toLowerCase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String capitalize(String str) {
/*      */     int strLen;
/* 3942 */     if (str == null || (strLen = str.length()) == 0) {
/* 3943 */       return str;
/*      */     }
/* 3945 */     return (new StringBuffer(strLen))
/* 3946 */       .append(Character.toTitleCase(str.charAt(0)))
/* 3947 */       .append(str.substring(1))
/* 3948 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String capitalise(String str) {
/* 3961 */     return capitalize(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String uncapitalize(String str) {
/*      */     int strLen;
/* 3986 */     if (str == null || (strLen = str.length()) == 0) {
/* 3987 */       return str;
/*      */     }
/* 3989 */     return (new StringBuffer(strLen))
/* 3990 */       .append(Character.toLowerCase(str.charAt(0)))
/* 3991 */       .append(str.substring(1))
/* 3992 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String uncapitalise(String str) {
/* 4005 */     return uncapitalize(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String swapCase(String str) {
/*      */     int strLen;
/* 4037 */     if (str == null || (strLen = str.length()) == 0) {
/* 4038 */       return str;
/*      */     }
/* 4040 */     StringBuffer buffer = new StringBuffer(strLen);
/*      */     
/* 4042 */     char ch = Character.MIN_VALUE;
/* 4043 */     for (int i = 0; i < strLen; i++) {
/* 4044 */       ch = str.charAt(i);
/* 4045 */       if (Character.isUpperCase(ch)) {
/* 4046 */         ch = Character.toLowerCase(ch);
/* 4047 */       } else if (Character.isTitleCase(ch)) {
/* 4048 */         ch = Character.toLowerCase(ch);
/* 4049 */       } else if (Character.isLowerCase(ch)) {
/* 4050 */         ch = Character.toUpperCase(ch);
/*      */       } 
/* 4052 */       buffer.append(ch);
/*      */     } 
/* 4054 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String capitaliseAllWords(String str) {
/* 4070 */     return WordUtils.capitalize(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int countMatches(String str, String sub) {
/* 4095 */     if (isEmpty(str) || isEmpty(sub)) {
/* 4096 */       return 0;
/*      */     }
/* 4098 */     int count = 0;
/* 4099 */     int idx = 0;
/* 4100 */     while ((idx = str.indexOf(sub, idx)) != -1) {
/* 4101 */       count++;
/* 4102 */       idx += sub.length();
/*      */     } 
/* 4104 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlpha(String str) {
/* 4128 */     if (str == null) {
/* 4129 */       return false;
/*      */     }
/* 4131 */     int sz = str.length();
/* 4132 */     for (int i = 0; i < sz; i++) {
/* 4133 */       if (Character.isLetter(str.charAt(i)) == false) {
/* 4134 */         return false;
/*      */       }
/*      */     } 
/* 4137 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphaSpace(String str) {
/* 4162 */     if (str == null) {
/* 4163 */       return false;
/*      */     }
/* 4165 */     int sz = str.length();
/* 4166 */     for (int i = 0; i < sz; i++) {
/* 4167 */       if (Character.isLetter(str.charAt(i)) == false && str.charAt(i) != ' ') {
/* 4168 */         return false;
/*      */       }
/*      */     } 
/* 4171 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphanumeric(String str) {
/* 4195 */     if (str == null) {
/* 4196 */       return false;
/*      */     }
/* 4198 */     int sz = str.length();
/* 4199 */     for (int i = 0; i < sz; i++) {
/* 4200 */       if (Character.isLetterOrDigit(str.charAt(i)) == false) {
/* 4201 */         return false;
/*      */       }
/*      */     } 
/* 4204 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphanumericSpace(String str) {
/* 4229 */     if (str == null) {
/* 4230 */       return false;
/*      */     }
/* 4232 */     int sz = str.length();
/* 4233 */     for (int i = 0; i < sz; i++) {
/* 4234 */       if (Character.isLetterOrDigit(str.charAt(i)) == false && str.charAt(i) != ' ') {
/* 4235 */         return false;
/*      */       }
/*      */     } 
/* 4238 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAsciiPrintable(String str) {
/* 4267 */     if (str == null) {
/* 4268 */       return false;
/*      */     }
/* 4270 */     int sz = str.length();
/* 4271 */     for (int i = 0; i < sz; i++) {
/* 4272 */       if (CharUtils.isAsciiPrintable(str.charAt(i)) == false) {
/* 4273 */         return false;
/*      */       }
/*      */     } 
/* 4276 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumeric(String str) {
/* 4301 */     if (str == null) {
/* 4302 */       return false;
/*      */     }
/* 4304 */     int sz = str.length();
/* 4305 */     for (int i = 0; i < sz; i++) {
/* 4306 */       if (Character.isDigit(str.charAt(i)) == false) {
/* 4307 */         return false;
/*      */       }
/*      */     } 
/* 4310 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumericSpace(String str) {
/* 4337 */     if (str == null) {
/* 4338 */       return false;
/*      */     }
/* 4340 */     int sz = str.length();
/* 4341 */     for (int i = 0; i < sz; i++) {
/* 4342 */       if (Character.isDigit(str.charAt(i)) == false && str.charAt(i) != ' ') {
/* 4343 */         return false;
/*      */       }
/*      */     } 
/* 4346 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWhitespace(String str) {
/* 4369 */     if (str == null) {
/* 4370 */       return false;
/*      */     }
/* 4372 */     int sz = str.length();
/* 4373 */     for (int i = 0; i < sz; i++) {
/* 4374 */       if (Character.isWhitespace(str.charAt(i)) == false) {
/* 4375 */         return false;
/*      */       }
/*      */     } 
/* 4378 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String defaultString(String str) {
/* 4400 */     return (str == null) ? "" : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String defaultString(String str, String defaultStr) {
/* 4421 */     return (str == null) ? defaultStr : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String defaultIfEmpty(String str, String defaultStr) {
/* 4441 */     return isEmpty(str) ? defaultStr : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String reverse(String str) {
/* 4461 */     if (str == null) {
/* 4462 */       return null;
/*      */     }
/* 4464 */     return (new StringBuffer(str)).reverse().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String reverseDelimited(String str, char separatorChar) {
/* 4487 */     if (str == null) {
/* 4488 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 4492 */     String[] strs = split(str, separatorChar);
/* 4493 */     ArrayUtils.reverse((Object[])strs);
/* 4494 */     return join((Object[])strs, separatorChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String reverseDelimitedString(String str, String separatorChars) {
/* 4520 */     if (str == null) {
/* 4521 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 4525 */     String[] strs = split(str, separatorChars);
/* 4526 */     ArrayUtils.reverse((Object[])strs);
/* 4527 */     if (separatorChars == null) {
/* 4528 */       return join((Object[])strs, ' ');
/*      */     }
/* 4530 */     return join((Object[])strs, separatorChars);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviate(String str, int maxWidth) {
/* 4568 */     return abbreviate(str, 0, maxWidth);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviate(String str, int offset, int maxWidth) {
/* 4607 */     if (str == null) {
/* 4608 */       return null;
/*      */     }
/* 4610 */     if (maxWidth < 4) {
/* 4611 */       throw new IllegalArgumentException("Minimum abbreviation width is 4");
/*      */     }
/* 4613 */     if (str.length() <= maxWidth) {
/* 4614 */       return str;
/*      */     }
/* 4616 */     if (offset > str.length()) {
/* 4617 */       offset = str.length();
/*      */     }
/* 4619 */     if (str.length() - offset < maxWidth - 3) {
/* 4620 */       offset = str.length() - maxWidth - 3;
/*      */     }
/* 4622 */     if (offset <= 4) {
/* 4623 */       return String.valueOf(str.substring(0, maxWidth - 3)) + "...";
/*      */     }
/* 4625 */     if (maxWidth < 7) {
/* 4626 */       throw new IllegalArgumentException("Minimum abbreviation width with offset is 7");
/*      */     }
/* 4628 */     if (offset + maxWidth - 3 < str.length()) {
/* 4629 */       return "..." + abbreviate(str.substring(offset), maxWidth - 3);
/*      */     }
/* 4631 */     return "..." + str.substring(str.length() - maxWidth - 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String difference(String str1, String str2) {
/* 4662 */     if (str1 == null) {
/* 4663 */       return str2;
/*      */     }
/* 4665 */     if (str2 == null) {
/* 4666 */       return str1;
/*      */     }
/* 4668 */     int at = indexOfDifference(str1, str2);
/* 4669 */     if (at == -1) {
/* 4670 */       return "";
/*      */     }
/* 4672 */     return str2.substring(at);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfDifference(String str1, String str2) {
/* 4699 */     if (str1 == str2) {
/* 4700 */       return -1;
/*      */     }
/* 4702 */     if (str1 == null || str2 == null) {
/* 4703 */       return 0;
/*      */     }
/*      */     int i;
/* 4706 */     for (i = 0; i < str1.length() && i < str2.length() && 
/* 4707 */       str1.charAt(i) == str2.charAt(i); i++);
/*      */ 
/*      */ 
/*      */     
/* 4711 */     if (i < str2.length() || i < str1.length()) {
/* 4712 */       return i;
/*      */     }
/* 4714 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getLevenshteinDistance(String s, String t) {
/* 4749 */     if (s == null || t == null) {
/* 4750 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4762 */     int n = s.length();
/* 4763 */     int m = t.length();
/* 4764 */     if (n == 0) {
/* 4765 */       return m;
/*      */     }
/* 4767 */     if (m == 0) {
/* 4768 */       return n;
/*      */     }
/* 4770 */     int[][] d = new int[n + 1][m + 1];
/*      */     
/*      */     int i;
/* 4773 */     for (i = 0; i <= n; i++) {
/* 4774 */       d[i][0] = i;
/*      */     }
/*      */     int j;
/* 4777 */     for (j = 0; j <= m; j++) {
/* 4778 */       d[0][j] = j;
/*      */     }
/*      */ 
/*      */     
/* 4782 */     for (i = 1; i <= n; i++) {
/* 4783 */       char s_i = s.charAt(i - 1);
/*      */ 
/*      */       
/* 4786 */       for (j = 1; j <= m; j++) {
/* 4787 */         int cost; char t_j = t.charAt(j - 1);
/*      */ 
/*      */         
/* 4790 */         if (s_i == t_j) {
/* 4791 */           cost = 0;
/*      */         } else {
/* 4793 */           cost = 1;
/*      */         } 
/*      */ 
/*      */         
/* 4797 */         d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 4802 */     return d[n][m];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int min(int a, int b, int c) {
/* 4815 */     if (b < a) {
/* 4816 */       a = b;
/*      */     }
/* 4818 */     if (c < a) {
/* 4819 */       a = c;
/*      */     }
/* 4821 */     return a;
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\StringUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */