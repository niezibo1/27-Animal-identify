/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import org.apache.commons.lang.math.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanUtils
/*     */ {
/*     */   public static Boolean negate(Boolean bool) {
/*  62 */     if (bool == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     return bool.booleanValue() ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTrue(Boolean bool) {
/*  84 */     if (bool == null) {
/*  85 */       return false;
/*     */     }
/*  87 */     return bool.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFalse(Boolean bool) {
/* 104 */     if (bool == null) {
/* 105 */       return false;
/*     */     }
/* 107 */     return !bool.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(boolean bool) {
/* 124 */     return bool ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(Boolean bool) {
/* 142 */     if (bool == null) {
/* 143 */       return false;
/*     */     }
/* 145 */     return bool.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBooleanDefaultIfNull(Boolean bool, boolean valueIfNull) {
/* 162 */     if (bool == null) {
/* 163 */       return valueIfNull;
/*     */     }
/* 165 */     return bool.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(int value) {
/* 185 */     return !(value == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(int value) {
/* 203 */     return (value == 0) ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(Integer value) {
/* 223 */     if (value == null) {
/* 224 */       return null;
/*     */     }
/* 226 */     return (value.intValue() == 0) ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(int value, int trueValue, int falseValue) {
/* 246 */     if (value == trueValue)
/* 247 */       return true; 
/* 248 */     if (value == falseValue) {
/* 249 */       return false;
/*     */     }
/*     */     
/* 252 */     throw new IllegalArgumentException("The Integer did not match either specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(Integer value, Integer trueValue, Integer falseValue) {
/* 275 */     if (value == null) {
/* 276 */       if (trueValue == null)
/* 277 */         return true; 
/* 278 */       if (falseValue == null)
/* 279 */         return false; 
/*     */     } else {
/* 281 */       if (value.equals(trueValue))
/* 282 */         return true; 
/* 283 */       if (value.equals(falseValue)) {
/* 284 */         return false;
/*     */       }
/*     */     } 
/* 287 */     throw new IllegalArgumentException("The Integer did not match either specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(int value, int trueValue, int falseValue, int nullValue) {
/* 307 */     if (value == trueValue)
/* 308 */       return Boolean.TRUE; 
/* 309 */     if (value == falseValue)
/* 310 */       return Boolean.FALSE; 
/* 311 */     if (value == nullValue) {
/* 312 */       return null;
/*     */     }
/*     */     
/* 315 */     throw new IllegalArgumentException("The Integer did not match any specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(Integer value, Integer trueValue, Integer falseValue, Integer nullValue) {
/* 338 */     if (value == null) {
/* 339 */       if (trueValue == null)
/* 340 */         return Boolean.TRUE; 
/* 341 */       if (falseValue == null)
/* 342 */         return Boolean.FALSE; 
/* 343 */       if (nullValue == null)
/* 344 */         return null; 
/*     */     } else {
/* 346 */       if (value.equals(trueValue))
/* 347 */         return Boolean.TRUE; 
/* 348 */       if (value.equals(falseValue))
/* 349 */         return Boolean.FALSE; 
/* 350 */       if (value.equals(nullValue)) {
/* 351 */         return null;
/*     */       }
/*     */     } 
/* 354 */     throw new IllegalArgumentException("The Integer did not match any specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInteger(boolean bool) {
/* 372 */     return bool ? 1 : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer toIntegerObject(boolean bool) {
/* 388 */     return bool ? NumberUtils.INTEGER_ONE : NumberUtils.INTEGER_ZERO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer toIntegerObject(Boolean bool) {
/* 406 */     if (bool == null) {
/* 407 */       return null;
/*     */     }
/* 409 */     return bool.booleanValue() ? NumberUtils.INTEGER_ONE : NumberUtils.INTEGER_ZERO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInteger(boolean bool, int trueValue, int falseValue) {
/* 426 */     return bool ? trueValue : falseValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInteger(Boolean bool, int trueValue, int falseValue, int nullValue) {
/* 445 */     if (bool == null) {
/* 446 */       return nullValue;
/*     */     }
/* 448 */     return bool.booleanValue() ? trueValue : falseValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer toIntegerObject(boolean bool, Integer trueValue, Integer falseValue) {
/* 467 */     return bool ? trueValue : falseValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer toIntegerObject(Boolean bool, Integer trueValue, Integer falseValue, Integer nullValue) {
/* 489 */     if (bool == null) {
/* 490 */       return nullValue;
/*     */     }
/* 492 */     return bool.booleanValue() ? trueValue : falseValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(String str) {
/* 522 */     if ("true".equalsIgnoreCase(str))
/* 523 */       return Boolean.TRUE; 
/* 524 */     if ("false".equalsIgnoreCase(str))
/* 525 */       return Boolean.FALSE; 
/* 526 */     if ("on".equalsIgnoreCase(str))
/* 527 */       return Boolean.TRUE; 
/* 528 */     if ("off".equalsIgnoreCase(str))
/* 529 */       return Boolean.FALSE; 
/* 530 */     if ("yes".equalsIgnoreCase(str))
/* 531 */       return Boolean.TRUE; 
/* 532 */     if ("no".equalsIgnoreCase(str)) {
/* 533 */       return Boolean.FALSE;
/*     */     }
/*     */     
/* 536 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(String str, String trueString, String falseString, String nullString) {
/* 559 */     if (str == null) {
/* 560 */       if (trueString == null)
/* 561 */         return Boolean.TRUE; 
/* 562 */       if (falseString == null)
/* 563 */         return Boolean.FALSE; 
/* 564 */       if (nullString == null)
/* 565 */         return null; 
/*     */     } else {
/* 567 */       if (str.equals(trueString))
/* 568 */         return Boolean.TRUE; 
/* 569 */       if (str.equals(falseString))
/* 570 */         return Boolean.FALSE; 
/* 571 */       if (str.equals(nullString)) {
/* 572 */         return null;
/*     */       }
/*     */     } 
/* 575 */     throw new IllegalArgumentException("The String did not match any specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(String str) {
/*     */     char ch0;
/*     */     char ch;
/*     */     char ch1;
/* 612 */     if (str == "true") {
/* 613 */       return true;
/*     */     }
/* 615 */     if (str == null) {
/* 616 */       return false;
/*     */     }
/* 618 */     switch (str.length()) {
/*     */       case 2:
/* 620 */         ch0 = str.charAt(0);
/* 621 */         ch1 = str.charAt(1);
/* 622 */         return 
/* 623 */           !((ch0 != 'o' && ch0 != 'O') || (
/* 624 */           ch1 != 'n' && ch1 != 'N'));
/*     */       
/*     */       case 3:
/* 627 */         ch = str.charAt(0);
/* 628 */         if (ch == 'y') {
/* 629 */           return 
/* 630 */             !((str.charAt(1) != 'e' && str.charAt(1) != 'E') || (
/* 631 */             str.charAt(2) != 's' && str.charAt(2) != 'S'));
/*     */         }
/* 633 */         if (ch == 'Y') {
/* 634 */           return 
/* 635 */             !((str.charAt(1) != 'E' && str.charAt(1) != 'e') || (
/* 636 */             str.charAt(2) != 'S' && str.charAt(2) != 's'));
/*     */         }
/*     */       
/*     */       case 4:
/* 640 */         ch = str.charAt(0);
/* 641 */         if (ch == 't') {
/* 642 */           return 
/* 643 */             !((str.charAt(1) != 'r' && str.charAt(1) != 'R') || (
/* 644 */             str.charAt(2) != 'u' && str.charAt(2) != 'U') || (
/* 645 */             str.charAt(3) != 'e' && str.charAt(3) != 'E'));
/*     */         }
/* 647 */         if (ch == 'T') {
/* 648 */           return 
/* 649 */             !((str.charAt(1) != 'R' && str.charAt(1) != 'r') || (
/* 650 */             str.charAt(2) != 'U' && str.charAt(2) != 'u') || (
/* 651 */             str.charAt(3) != 'E' && str.charAt(3) != 'e'));
/*     */         }
/*     */         break;
/*     */     } 
/* 655 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(String str, String trueString, String falseString) {
/* 688 */     if (str == null) {
/* 689 */       if (trueString == null)
/* 690 */         return true; 
/* 691 */       if (falseString == null)
/* 692 */         return false; 
/*     */     } else {
/* 694 */       if (str.equals(trueString))
/* 695 */         return true; 
/* 696 */       if (str.equals(falseString)) {
/* 697 */         return false;
/*     */       }
/*     */     } 
/* 700 */     throw new IllegalArgumentException("The String did not match either specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringTrueFalse(Boolean bool) {
/* 720 */     return toString(bool, "true", "false", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringOnOff(Boolean bool) {
/* 738 */     return toString(bool, "on", "off", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringYesNo(Boolean bool) {
/* 756 */     return toString(bool, "yes", "no", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Boolean bool, String trueString, String falseString, String nullString) {
/* 778 */     if (bool == null) {
/* 779 */       return nullString;
/*     */     }
/* 781 */     return bool.booleanValue() ? trueString : falseString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringTrueFalse(boolean bool) {
/* 800 */     return toString(bool, "true", "false");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringOnOff(boolean bool) {
/* 817 */     return toString(bool, "on", "off");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringYesNo(boolean bool) {
/* 834 */     return toString(bool, "yes", "no");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(boolean bool, String trueString, String falseString) {
/* 853 */     return bool ? trueString : falseString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean xor(boolean[] array) {
/* 874 */     if (array == null)
/* 875 */       throw new IllegalArgumentException("The Array must not be null"); 
/* 876 */     if (array.length == 0) {
/* 877 */       throw new IllegalArgumentException("Array is empty");
/*     */     }
/*     */ 
/*     */     
/* 881 */     int trueCount = 0;
/* 882 */     for (int i = 0; i < array.length; i++) {
/*     */ 
/*     */       
/* 885 */       if (array[i]) {
/* 886 */         if (trueCount < 1) {
/* 887 */           trueCount++;
/*     */         } else {
/* 889 */           return false;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 895 */     return !(trueCount != 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean xor(Boolean[] array) {
/* 914 */     if (array == null)
/* 915 */       throw new IllegalArgumentException("The Array must not be null"); 
/* 916 */     if (array.length == 0) {
/* 917 */       throw new IllegalArgumentException("Array is empty");
/*     */     }
/* 919 */     boolean[] primitive = null;
/*     */     try {
/* 921 */       primitive = ArrayUtils.toPrimitive(array);
/* 922 */     } catch (NullPointerException nullPointerException) {
/* 923 */       throw new IllegalArgumentException("The array must not contain any null elements");
/*     */     } 
/* 925 */     return xor(primitive) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\BooleanUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */