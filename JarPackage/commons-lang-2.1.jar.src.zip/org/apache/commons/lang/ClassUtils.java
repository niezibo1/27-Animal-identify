/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassUtils
/*     */ {
/*     */   public static final char PACKAGE_SEPARATOR_CHAR = '.';
/*  46 */   public static final String PACKAGE_SEPARATOR = String.valueOf('.');
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final char INNER_CLASS_SEPARATOR_CHAR = '$';
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final String INNER_CLASS_SEPARATOR = String.valueOf('$');
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static Map primitiveWrapperMap = new HashMap();
/*     */   static {
/*  63 */     primitiveWrapperMap.put(boolean.class, Boolean.class);
/*  64 */     primitiveWrapperMap.put(byte.class, Byte.class);
/*  65 */     primitiveWrapperMap.put(char.class, Character.class);
/*  66 */     primitiveWrapperMap.put(short.class, Short.class);
/*  67 */     primitiveWrapperMap.put(int.class, Integer.class);
/*  68 */     primitiveWrapperMap.put(long.class, Long.class);
/*  69 */     primitiveWrapperMap.put(double.class, Double.class);
/*  70 */     primitiveWrapperMap.put(float.class, Float.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getShortClassName(Object object, String valueIfNull) {
/*  94 */     if (object == null) {
/*  95 */       return valueIfNull;
/*     */     }
/*  97 */     return getShortClassName(object.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getShortClassName(Class cls) {
/* 107 */     if (cls == null) {
/* 108 */       return "";
/*     */     }
/* 110 */     return getShortClassName(cls.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getShortClassName(String className) {
/* 122 */     if (className == null) {
/* 123 */       return "";
/*     */     }
/* 125 */     if (className.length() == 0) {
/* 126 */       return "";
/*     */     }
/* 128 */     char[] chars = className.toCharArray();
/* 129 */     int lastDot = 0;
/* 130 */     for (int i = 0; i < chars.length; i++) {
/* 131 */       if (chars[i] == '.') {
/* 132 */         lastDot = i + 1;
/* 133 */       } else if (chars[i] == '$') {
/* 134 */         chars[i] = '.';
/*     */       } 
/*     */     } 
/* 137 */     return new String(chars, lastDot, chars.length - lastDot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageName(Object object, String valueIfNull) {
/* 150 */     if (object == null) {
/* 151 */       return valueIfNull;
/*     */     }
/* 153 */     return getPackageName(object.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageName(Class cls) {
/* 163 */     if (cls == null) {
/* 164 */       return "";
/*     */     }
/* 166 */     return getPackageName(cls.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageName(String className) {
/* 179 */     if (className == null) {
/* 180 */       return "";
/*     */     }
/* 182 */     int i = className.lastIndexOf('.');
/* 183 */     if (i == -1) {
/* 184 */       return "";
/*     */     }
/* 186 */     return className.substring(0, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List getAllSuperclasses(Class cls) {
/* 199 */     if (cls == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     List classes = new ArrayList();
/* 203 */     Class superclass = cls.getSuperclass();
/* 204 */     while (superclass != null) {
/* 205 */       classes.add(superclass);
/* 206 */       superclass = superclass.getSuperclass();
/*     */     } 
/* 208 */     return classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List getAllInterfaces(Class cls) {
/* 225 */     if (cls == null) {
/* 226 */       return null;
/*     */     }
/* 228 */     List list = new ArrayList();
/* 229 */     while (cls != null) {
/* 230 */       Class[] interfaces = cls.getInterfaces();
/* 231 */       for (int i = 0; i < interfaces.length; i++) {
/* 232 */         if (list.contains(interfaces[i]) == false) {
/* 233 */           list.add(interfaces[i]);
/*     */         }
/* 235 */         List superInterfaces = getAllInterfaces(interfaces[i]);
/* 236 */         for (Iterator it = superInterfaces.iterator(); it.hasNext(); ) {
/* 237 */           Class intface = it.next();
/* 238 */           if (list.contains(intface) == false) {
/* 239 */             list.add(intface);
/*     */           }
/*     */         } 
/*     */       } 
/* 243 */       cls = cls.getSuperclass();
/*     */     } 
/* 245 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List convertClassNamesToClasses(List classNames) {
/* 263 */     if (classNames == null) {
/* 264 */       return null;
/*     */     }
/* 266 */     List classes = new ArrayList(classNames.size());
/* 267 */     for (Iterator it = classNames.iterator(); it.hasNext(); ) {
/* 268 */       String className = it.next();
/*     */       try {
/* 270 */         classes.add(Class.forName(className));
/* 271 */       } catch (Exception exception) {
/* 272 */         classes.add(null);
/*     */       } 
/*     */     } 
/* 275 */     return classes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List convertClassesToClassNames(List classes) {
/* 291 */     if (classes == null) {
/* 292 */       return null;
/*     */     }
/* 294 */     List classNames = new ArrayList(classes.size());
/* 295 */     for (Iterator it = classes.iterator(); it.hasNext(); ) {
/* 296 */       Class cls = it.next();
/* 297 */       if (cls == null) {
/* 298 */         classNames.add(null); continue;
/*     */       } 
/* 300 */       classNames.add(cls.getName());
/*     */     } 
/*     */     
/* 303 */     return classNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAssignable(Class[] classArray, Class[] toClassArray) {
/* 340 */     if (ArrayUtils.isSameLength((Object[])classArray, (Object[])toClassArray) == false) {
/* 341 */       return false;
/*     */     }
/* 343 */     if (classArray == null) {
/* 344 */       classArray = ArrayUtils.EMPTY_CLASS_ARRAY;
/*     */     }
/* 346 */     if (toClassArray == null) {
/* 347 */       toClassArray = ArrayUtils.EMPTY_CLASS_ARRAY;
/*     */     }
/* 349 */     for (int i = 0; i < classArray.length; i++) {
/* 350 */       if (isAssignable(classArray[i], toClassArray[i]) == false) {
/* 351 */         return false;
/*     */       }
/*     */     } 
/* 354 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAssignable(Class cls, Class toClass) {
/* 384 */     if (toClass == null) {
/* 385 */       return false;
/*     */     }
/*     */     
/* 388 */     if (cls == null) {
/* 389 */       return toClass.isPrimitive() ^ true;
/*     */     }
/* 391 */     if (cls.equals(toClass)) {
/* 392 */       return true;
/*     */     }
/* 394 */     if (cls.isPrimitive()) {
/* 395 */       if (toClass.isPrimitive() == false) {
/* 396 */         return false;
/*     */       }
/* 398 */       if (int.class.equals(cls)) {
/* 399 */         return !(!long.class.equals(toClass) && 
/* 400 */           !float.class.equals(toClass) && 
/* 401 */           !double.class.equals(toClass));
/*     */       }
/* 403 */       if (long.class.equals(cls)) {
/* 404 */         return !(!float.class.equals(toClass) && 
/* 405 */           !double.class.equals(toClass));
/*     */       }
/* 407 */       if (boolean.class.equals(cls)) {
/* 408 */         return false;
/*     */       }
/* 410 */       if (double.class.equals(cls)) {
/* 411 */         return false;
/*     */       }
/* 413 */       if (float.class.equals(cls)) {
/* 414 */         return double.class.equals(toClass);
/*     */       }
/* 416 */       if (char.class.equals(cls)) {
/* 417 */         return !(!int.class.equals(toClass) && 
/* 418 */           !long.class.equals(toClass) && 
/* 419 */           !float.class.equals(toClass) && 
/* 420 */           !double.class.equals(toClass));
/*     */       }
/* 422 */       if (short.class.equals(cls)) {
/* 423 */         return !(!int.class.equals(toClass) && 
/* 424 */           !long.class.equals(toClass) && 
/* 425 */           !float.class.equals(toClass) && 
/* 426 */           !double.class.equals(toClass));
/*     */       }
/* 428 */       if (byte.class.equals(cls)) {
/* 429 */         return !(!short.class.equals(toClass) && 
/* 430 */           !int.class.equals(toClass) && 
/* 431 */           !long.class.equals(toClass) && 
/* 432 */           !float.class.equals(toClass) && 
/* 433 */           !double.class.equals(toClass));
/*     */       }
/*     */       
/* 436 */       return false;
/*     */     } 
/* 438 */     return toClass.isAssignableFrom(cls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class primitiveToWrapper(Class cls) {
/* 451 */     Class convertedClass = cls;
/* 452 */     if (cls != null && cls.isPrimitive()) {
/* 453 */       convertedClass = (Class)primitiveWrapperMap.get(cls);
/*     */     }
/* 455 */     return convertedClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class[] primitivesToWrappers(Class[] classes) {
/* 469 */     if (classes == null) {
/* 470 */       return null;
/*     */     }
/*     */     
/* 473 */     if (classes.length == 0) {
/* 474 */       return classes;
/*     */     }
/*     */     
/* 477 */     Class[] convertedClasses = new Class[classes.length];
/* 478 */     for (int i = 0; i < classes.length; i++) {
/* 479 */       convertedClasses[i] = primitiveToWrapper(classes[i]);
/*     */     }
/* 481 */     return convertedClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInnerClass(Class cls) {
/* 494 */     if (cls == null) {
/* 495 */       return false;
/*     */     }
/* 497 */     return !(cls.getName().indexOf('$') < 0);
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\ClassUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */