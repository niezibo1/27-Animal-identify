/*     */ package org.apache.commons.lang.time;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DurationFormatUtils
/*     */ {
/*     */   public static final String ISO_EXTENDED_FORMAT_PATTERN = "'P'yyyy'Y'M'M'd'DT'H'H'm'M's.S'S'";
/*     */   
/*     */   public static String formatDurationHMS(long durationMillis) {
/*  79 */     return formatDuration(durationMillis, "H:mm:ss.SSS");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatDurationISO(long durationMillis) {
/*  94 */     return formatDuration(durationMillis, "'P'yyyy'Y'M'M'd'DT'H'H'm'M's.S'S'", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatDuration(long durationMillis, String format) {
/* 109 */     return formatDuration(durationMillis, format, true);
/*     */   }
/*     */   public static String formatDurationWords(long durationMillis, boolean suppressLeadingZeroElements, boolean suppressTrailingZeroElements) { String duration = formatDuration(durationMillis, "d' days 'H' hours 'm' minutes 's' seconds'"); if (suppressLeadingZeroElements) {
/*     */       duration = " " + duration; String tmp = StringUtils.replaceOnce(duration, " 0 days", ""); if (tmp.length() != duration.length()) {
/*     */         duration = tmp; tmp = StringUtils.replaceOnce(duration, " 0 hours", ""); if (tmp.length() != duration.length()) {
/*     */           duration = tmp; tmp = StringUtils.replaceOnce(duration, " 0 minutes", ""); duration = tmp; if (tmp.length() != duration.length())
/*     */             duration = StringUtils.replaceOnce(tmp, " 0 seconds", ""); 
/*     */         } 
/*     */       }  if (duration.length() != 0)
/*     */         duration = duration.substring(1); 
/*     */     }  if (suppressTrailingZeroElements) {
/*     */       String tmp = StringUtils.replaceOnce(duration, " 0 seconds", ""); if (tmp.length() != duration.length()) {
/*     */         duration = tmp; tmp = StringUtils.replaceOnce(duration, " 0 minutes", ""); if (tmp.length() != duration.length()) {
/*     */           duration = tmp; tmp = StringUtils.replaceOnce(duration, " 0 hours", ""); if (tmp.length() != duration.length())
/*     */             duration = StringUtils.replaceOnce(tmp, " 0 days", ""); 
/*     */         } 
/*     */       } 
/*     */     }  duration = StringUtils.replaceOnce(duration, "1 seconds", "1 second"); duration = StringUtils.replaceOnce(duration, "1 minutes", "1 minute"); duration = StringUtils.replaceOnce(duration, "1 hours", "1 hour"); duration = StringUtils.replaceOnce(duration, "1 days", "1 day"); return duration; }
/* 127 */   public static String formatPeriodISO(long startMillis, long endMillis) { return formatPeriod(startMillis, endMillis, "'P'yyyy'Y'M'M'd'DT'H'H'm'M's.S'S'", false, TimeZone.getDefault()); } public static String formatPeriod(long startMillis, long endMillis, String format) { return formatPeriod(startMillis, endMillis, format, true, TimeZone.getDefault()); } public static String formatDuration(long durationMillis, String format, boolean padWithZeros) { Token[] tokens = lexx(format);
/*     */     
/* 129 */     int days = 0;
/* 130 */     int hours = 0;
/* 131 */     int minutes = 0;
/* 132 */     int seconds = 0;
/* 133 */     int milliseconds = 0;
/*     */     
/* 135 */     if (Token.containsTokenWithValue(tokens, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 452 */         "d")) { days = (int)(durationMillis / 86400000L); durationMillis -= days * 86400000L; }
/* 453 */      if (Token.containsTokenWithValue(tokens, "H")) { hours = (int)(durationMillis / 3600000L); durationMillis -= hours * 3600000L; }
/* 454 */      if (Token.containsTokenWithValue(tokens, "m")) { minutes = (int)(durationMillis / 60000L); durationMillis -= minutes * 60000L; }
/* 455 */      if (Token.containsTokenWithValue(tokens, "s")) { seconds = (int)(durationMillis / 1000L); durationMillis -= seconds * 1000L; }
/* 456 */      if (Token.containsTokenWithValue(tokens, "S")) milliseconds = (int)durationMillis;  return format(tokens, 0, 0, days, hours, minutes, seconds, milliseconds, padWithZeros); } public static String formatPeriod(long startMillis, long endMillis, String format, boolean padWithZeros, TimeZone timezone) { long millis = endMillis - startMillis; if (millis < 2419200000L) return formatDuration(millis, format, padWithZeros);  Token[] tokens = lexx(format); Calendar start = Calendar.getInstance(timezone); start.setTime(new Date(startMillis)); Calendar end = Calendar.getInstance(timezone); end.setTime(new Date(endMillis)); int years = end.get(1) - start.get(1); int months = end.get(2) - start.get(2); while (months < 0) { months += 12; years--; }  int days = end.get(5) - start.get(5); while (days < 0) { days += 31; months--; }  int hours = end.get(11) - start.get(11); while (hours < 0) { hours += 24; days--; }  int minutes = end.get(12) - start.get(12); while (minutes < 0) { minutes += 60; hours--; }  int seconds = end.get(13) - start.get(13); while (seconds < 0) { seconds += 60; minutes--; }  int milliseconds = end.get(14) - start.get(14); while (milliseconds < 0) { milliseconds += 1000; seconds--; }  milliseconds -= reduceAndCorrect(start, end, 14, milliseconds); seconds -= reduceAndCorrect(start, end, 13, seconds); minutes -= reduceAndCorrect(start, end, 12, minutes); hours -= reduceAndCorrect(start, end, 11, hours); days -= reduceAndCorrect(start, end, 5, days); months -= reduceAndCorrect(start, end, 2, months); years -= reduceAndCorrect(start, end, 1, years); if (!Token.containsTokenWithValue(tokens, "y")) if (Token.containsTokenWithValue(tokens, "M")) { months += 12 * years; years = 0; } else { days += 365 * years; years = 0; }   if (!Token.containsTokenWithValue(tokens, "M")) { days += end.get(6) - start.get(6); months = 0; }  if (!Token.containsTokenWithValue(tokens, "d")) { hours += 24 * days; days = 0; }  if (!Token.containsTokenWithValue(tokens, "H")) { minutes += 60 * hours; hours = 0; }  if (!Token.containsTokenWithValue(tokens, "m")) { seconds += 60 * minutes; minutes = 0; }  if (!Token.containsTokenWithValue(tokens, "s")) { milliseconds += 1000 * seconds; seconds = 0; }  return format(tokens, years, months, days, hours, minutes, seconds, milliseconds, padWithZeros); } static String format(Token[] tokens, int years, int months, int days, int hours, int minutes, int seconds, int milliseconds, boolean padWithZeros) { StringBuffer buffer = new StringBuffer(); boolean lastOutputSeconds = false; int sz = tokens.length; for (int i = 0; i < sz; i++) { Token token = tokens[i]; Object value = token.getValue(); int count = token.getCount(); if (value instanceof StringBuffer) { buffer.append(value.toString()); } else if (value == "y") { buffer.append(padWithZeros ? StringUtils.leftPad(Integer.toString(years), count, '0') : Integer.toString(years)); lastOutputSeconds = false; } else if (value == "M") { buffer.append(padWithZeros ? StringUtils.leftPad(Integer.toString(months), count, '0') : Integer.toString(months)); lastOutputSeconds = false; } else if (value == "d") { buffer.append(padWithZeros ? StringUtils.leftPad(Integer.toString(days), count, '0') : Integer.toString(days)); lastOutputSeconds = false; } else if (value == "H") { buffer.append(padWithZeros ? StringUtils.leftPad(Integer.toString(hours), count, '0') : Integer.toString(hours)); lastOutputSeconds = false; } else if (value == "m") { buffer.append(padWithZeros ? StringUtils.leftPad(Integer.toString(minutes), count, '0') : Integer.toString(minutes)); lastOutputSeconds = false; } else if (value == "s") { buffer.append(padWithZeros ? StringUtils.leftPad(Integer.toString(seconds), count, '0') : Integer.toString(seconds)); lastOutputSeconds = true; } else if (value == "S") { if (lastOutputSeconds) { milliseconds += 1000; String str = padWithZeros ? StringUtils.leftPad(Integer.toString(milliseconds), count, '0') : Integer.toString(milliseconds); buffer.append(str.substring(1)); } else { buffer.append(padWithZeros ? StringUtils.leftPad(Integer.toString(milliseconds), count, '0') : Integer.toString(milliseconds)); }  lastOutputSeconds = false; }  }  return buffer.toString(); } static int reduceAndCorrect(Calendar start, Calendar end, int field, int difference) { end.add(field, -1 * difference); int endValue = end.get(field); int startValue = start.get(field); if (endValue < startValue) { int newdiff = startValue - endValue; end.add(field, newdiff); return newdiff; }  return 0; } static final Object y = "y"; static final Object M = "M"; static final Object d = "d"; static final Object H = "H"; static final Object m = "m"; static final Object s = "s"; static final Object S = "S";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Token[] lexx(String format) {
/* 465 */     char[] array = format.toCharArray();
/* 466 */     ArrayList list = new ArrayList(array.length);
/*     */     
/* 468 */     boolean inLiteral = false;
/* 469 */     StringBuffer buffer = null;
/* 470 */     Token previous = null;
/* 471 */     int sz = array.length;
/* 472 */     for (int i = 0; i < sz; i++) {
/* 473 */       char ch = array[i];
/* 474 */       if (inLiteral && ch != '\'') {
/* 475 */         buffer.append(ch);
/*     */       } else {
/*     */         
/* 478 */         Object value = null;
/* 479 */         switch (ch) {
/*     */           
/*     */           case '\'':
/* 482 */             if (inLiteral) {
/* 483 */               buffer = null;
/* 484 */               inLiteral = false; break;
/*     */             } 
/* 486 */             buffer = new StringBuffer();
/* 487 */             list.add(new Token(buffer));
/* 488 */             inLiteral = true;
/*     */             break;
/*     */           case 'y':
/* 491 */             value = "y"; break;
/* 492 */           case 'M': value = "M"; break;
/* 493 */           case 'd': value = "d"; break;
/* 494 */           case 'H': value = "H"; break;
/* 495 */           case 'm': value = "m"; break;
/* 496 */           case 's': value = "s"; break;
/* 497 */           case 'S': value = "S"; break;
/*     */           default:
/* 499 */             if (buffer == null) {
/* 500 */               buffer = new StringBuffer();
/* 501 */               list.add(new Token(buffer));
/*     */             } 
/* 503 */             buffer.append(ch);
/*     */             break;
/*     */         } 
/* 506 */         if (value != null) {
/* 507 */           if (previous != null && previous.getValue() == value) {
/* 508 */             previous.increment();
/*     */           } else {
/* 510 */             Token token = new Token(value);
/* 511 */             list.add(token);
/* 512 */             previous = token;
/*     */           } 
/* 514 */           buffer = null;
/*     */         } 
/*     */       } 
/* 517 */     }  return list.<Token>toArray(new Token[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Token
/*     */   {
/*     */     private Object value;
/*     */ 
/*     */     
/*     */     private int count;
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean containsTokenWithValue(Token[] tokens, Object value) {
/* 533 */       int sz = tokens.length;
/* 534 */       for (int i = 0; i < sz; i++) {
/* 535 */         if (tokens[i].getValue() == value) {
/* 536 */           return true;
/*     */         }
/*     */       } 
/* 539 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Token(Object value) {
/* 551 */       this.value = value;
/* 552 */       this.count = 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Token(Object value, int count) {
/* 563 */       this.value = value;
/* 564 */       this.count = count;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void increment() {
/* 571 */       this.count++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int getCount() {
/* 580 */       return this.count;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object getValue() {
/* 589 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj2) {
/* 599 */       if (obj2 instanceof Token) {
/* 600 */         Token tok2 = (Token)obj2;
/* 601 */         if (this.value.getClass() != tok2.value.getClass()) {
/* 602 */           return false;
/*     */         }
/* 604 */         if (this.count != tok2.count) {
/* 605 */           return false;
/*     */         }
/* 607 */         if (this.value instanceof StringBuffer)
/* 608 */           return this.value.toString().equals(tok2.value.toString()); 
/* 609 */         if (this.value instanceof Number) {
/* 610 */           return this.value.equals(tok2.value);
/*     */         }
/* 612 */         return !(this.value != tok2.value);
/*     */       } 
/*     */       
/* 615 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 625 */       return StringUtils.repeat(this.value.toString(), this.count);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\time\DurationFormatUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */