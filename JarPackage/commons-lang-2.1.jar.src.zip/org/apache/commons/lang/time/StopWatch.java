/*     */ package org.apache.commons.lang.time;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StopWatch
/*     */ {
/*     */   private static final int STATE_UNSTARTED = 0;
/*     */   private static final int STATE_RUNNING = 1;
/*     */   private static final int STATE_STOPPED = 2;
/*     */   private static final int STATE_SUSPENDED = 3;
/*     */   private static final int STATE_UNSPLIT = 10;
/*     */   private static final int STATE_SPLIT = 11;
/*  65 */   private int runningState = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private int splitState = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private long startTime = -1L;
/*     */ 
/*     */ 
/*     */   
/*  79 */   private long stopTime = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  95 */     if (this.runningState == 2) {
/*  96 */       throw new IllegalStateException("Stopwatch must be reset before being restarted. ");
/*     */     }
/*  98 */     if (this.runningState != 0) {
/*  99 */       throw new IllegalStateException("Stopwatch already started. ");
/*     */     }
/* 101 */     this.stopTime = -1L;
/* 102 */     this.startTime = System.currentTimeMillis();
/* 103 */     this.runningState = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 114 */     if (this.runningState != 1 && this.runningState != 3) {
/* 115 */       throw new IllegalStateException("Stopwatch is not running. ");
/*     */     }
/* 117 */     this.stopTime = System.currentTimeMillis();
/* 118 */     this.runningState = 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 127 */     this.runningState = 0;
/* 128 */     this.splitState = 10;
/* 129 */     this.startTime = -1L;
/* 130 */     this.stopTime = -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void split() {
/* 143 */     if (this.runningState != 1) {
/* 144 */       throw new IllegalStateException("Stopwatch is not running. ");
/*     */     }
/* 146 */     this.stopTime = System.currentTimeMillis();
/* 147 */     this.splitState = 11;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsplit() {
/* 159 */     if (this.splitState != 11) {
/* 160 */       throw new IllegalStateException("Stopwatch has not been split. ");
/*     */     }
/* 162 */     this.stopTime = -1L;
/* 163 */     this.splitState = 10;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void suspend() {
/* 175 */     if (this.runningState != 1) {
/* 176 */       throw new IllegalStateException("Stopwatch must be running to suspend. ");
/*     */     }
/* 178 */     this.stopTime = System.currentTimeMillis();
/* 179 */     this.runningState = 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resume() {
/* 191 */     if (this.runningState != 3) {
/* 192 */       throw new IllegalStateException("Stopwatch must be suspended to resume. ");
/*     */     }
/* 194 */     this.startTime += System.currentTimeMillis() - this.stopTime;
/* 195 */     this.stopTime = -1L;
/* 196 */     this.runningState = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTime() {
/* 208 */     if (this.runningState == 2 || this.runningState == 3) {
/* 209 */       return this.stopTime - this.startTime;
/*     */     }
/* 211 */     if (this.runningState == 0) {
/* 212 */       return 0L;
/*     */     }
/* 214 */     if (this.runningState == 1) {
/* 215 */       return System.currentTimeMillis() - this.startTime;
/*     */     }
/* 217 */     throw new RuntimeException("Illegal running state has occured. ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSplitTime() {
/* 231 */     if (this.splitState != 11) {
/* 232 */       throw new IllegalStateException("Stopwatch must be split to get the split time. ");
/*     */     }
/* 234 */     return this.stopTime - this.startTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 246 */     return DurationFormatUtils.formatDurationHMS(getTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toSplitString() {
/* 259 */     return DurationFormatUtils.formatDurationHMS(getSplitTime());
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\time\StopWatch.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */