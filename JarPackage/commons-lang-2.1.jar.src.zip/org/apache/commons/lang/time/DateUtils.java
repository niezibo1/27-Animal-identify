/*     */ package org.apache.commons.lang.time;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateUtils
/*     */ {
/*  44 */   public static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("GMT");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long MILLIS_PER_SECOND = 1000L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long MILLIS_PER_MINUTE = 60000L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long MILLIS_PER_HOUR = 3600000L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long MILLIS_PER_DAY = 86400000L;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SEMI_MONTH = 1001;
/*     */ 
/*     */ 
/*     */   
/*  72 */   private static final int[][] fields = new int[][] {
/*  73 */       { 14
/*  74 */       }, { 13
/*  75 */       }, { 12
/*  76 */       }, { 11, 10
/*  77 */       }, { 5, 5, 9
/*     */       },
/*     */       {
/*  80 */         2, 1001
/*  81 */       }, { 1
/*  82 */       }, new int[1]
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int RANGE_WEEK_SUNDAY = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int RANGE_WEEK_MONDAY = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int RANGE_WEEK_RELATIVE = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int RANGE_WEEK_CENTER = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int RANGE_MONTH_SUNDAY = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int RANGE_MONTH_MONDAY = 6;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MILLIS_IN_SECOND = 1000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MILLIS_IN_MINUTE = 60000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MILLIS_IN_HOUR = 3600000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MILLIS_IN_DAY = 86400000;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameDay(Date date1, Date date2) {
/* 140 */     if (date1 == null || date2 == null) {
/* 141 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 143 */     Calendar cal1 = Calendar.getInstance();
/* 144 */     cal1.setTime(date1);
/* 145 */     Calendar cal2 = Calendar.getInstance();
/* 146 */     cal2.setTime(date2);
/* 147 */     return isSameDay(cal1, cal2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameDay(Calendar cal1, Calendar cal2) {
/* 164 */     if (cal1 == null || cal2 == null) {
/* 165 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 167 */     return !(cal1.get(0) != cal2.get(0) || 
/* 168 */       cal1.get(1) != cal2.get(1) || 
/* 169 */       cal1.get(6) != cal2.get(6));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameInstant(Date date1, Date date2) {
/* 185 */     if (date1 == null || date2 == null) {
/* 186 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 188 */     return !(date1.getTime() != date2.getTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameInstant(Calendar cal1, Calendar cal2) {
/* 203 */     if (cal1 == null || cal2 == null) {
/* 204 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 206 */     return !(cal1.getTime().getTime() != cal2.getTime().getTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameLocalTime(Calendar cal1, Calendar cal2) {
/* 223 */     if (cal1 == null || cal2 == null) {
/* 224 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 226 */     return !(cal1.get(14) != cal2.get(14) || 
/* 227 */       cal1.get(13) != cal2.get(13) || 
/* 228 */       cal1.get(12) != cal2.get(12) || 
/* 229 */       cal1.get(10) != cal2.get(10) || 
/* 230 */       cal1.get(6) != cal2.get(6) || 
/* 231 */       cal1.get(1) != cal2.get(1) || 
/* 232 */       cal1.get(0) != cal2.get(0) || 
/* 233 */       cal1.getClass() != cal2.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Date parseDate(String str, String[] parsePatterns) throws ParseException {
/* 251 */     if (str == null || parsePatterns == null) {
/* 252 */       throw new IllegalArgumentException("Date and Patterns must not be null");
/*     */     }
/*     */     
/* 255 */     SimpleDateFormat parser = null;
/* 256 */     ParsePosition pos = new ParsePosition(0);
/* 257 */     for (int i = 0; i < parsePatterns.length; i++) {
/* 258 */       if (i == 0) {
/* 259 */         parser = new SimpleDateFormat(parsePatterns[0]);
/*     */       } else {
/* 261 */         parser.applyPattern(parsePatterns[i]);
/*     */       } 
/* 263 */       pos.setIndex(0);
/* 264 */       Date date = parser.parse(str, pos);
/* 265 */       if (date != null && pos.getIndex() == str.length()) {
/* 266 */         return date;
/*     */       }
/*     */     } 
/* 269 */     throw new ParseException("Unable to parse the date: " + str, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Date round(Date date, int field) {
/* 302 */     if (date == null) {
/* 303 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 305 */     Calendar gval = Calendar.getInstance();
/* 306 */     gval.setTime(date);
/* 307 */     modify(gval, field, true);
/* 308 */     return gval.getTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar round(Calendar date, int field) {
/* 340 */     if (date == null) {
/* 341 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 343 */     Calendar rounded = (Calendar)date.clone();
/* 344 */     modify(rounded, field, true);
/* 345 */     return rounded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Date round(Object date, int field) {
/* 379 */     if (date == null) {
/* 380 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 382 */     if (date instanceof Date)
/* 383 */       return round((Date)date, field); 
/* 384 */     if (date instanceof Calendar) {
/* 385 */       return round((Calendar)date, field).getTime();
/*     */     }
/* 387 */     throw new ClassCastException("Could not round " + date);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Date truncate(Date date, int field) {
/* 409 */     if (date == null) {
/* 410 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 412 */     Calendar gval = Calendar.getInstance();
/* 413 */     gval.setTime(date);
/* 414 */     modify(gval, field, false);
/* 415 */     return gval.getTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar truncate(Calendar date, int field) {
/* 435 */     if (date == null) {
/* 436 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 438 */     Calendar truncated = (Calendar)date.clone();
/* 439 */     modify(truncated, field, false);
/* 440 */     return truncated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Date truncate(Object date, int field) {
/* 464 */     if (date == null) {
/* 465 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 467 */     if (date instanceof Date)
/* 468 */       return truncate((Date)date, field); 
/* 469 */     if (date instanceof Calendar) {
/* 470 */       return truncate((Calendar)date, field).getTime();
/*     */     }
/* 472 */     throw new ClassCastException("Could not truncate " + date);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void modify(Calendar val, int field, boolean round) {
/* 486 */     if (val.get(1) > 280000000) {
/* 487 */       throw new ArithmeticException("Calendar value too large for accurate calculations");
/*     */     }
/*     */     
/* 490 */     boolean roundUp = false;
/* 491 */     for (int i = 0; i < fields.length; i++) {
/* 492 */       for (int j = 0; j < (fields[i]).length; j++) {
/* 493 */         if (fields[i][j] == field) {
/*     */           
/* 495 */           if (round && roundUp) {
/* 496 */             if (field == 1001) {
/*     */ 
/*     */ 
/*     */               
/* 500 */               if (val.get(5) == 1) {
/* 501 */                 val.add(5, 15);
/*     */               } else {
/* 503 */                 val.add(5, -15);
/* 504 */                 val.add(2, 1);
/*     */               }
/*     */             
/*     */             } else {
/*     */               
/* 509 */               val.add(fields[i][0], 1);
/*     */             } 
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 516 */       int offset = 0;
/* 517 */       boolean offsetSet = false;
/*     */       
/* 519 */       switch (field) {
/*     */         case 1001:
/* 521 */           if (fields[i][0] == 5) {
/*     */ 
/*     */ 
/*     */             
/* 525 */             offset = val.get(5) - 1;
/*     */ 
/*     */             
/* 528 */             if (offset >= 15) {
/* 529 */               offset -= 15;
/*     */             }
/*     */             
/* 532 */             roundUp = !(offset <= 7);
/* 533 */             offsetSet = true;
/*     */           } 
/*     */           break;
/*     */         case 9:
/* 537 */           if (fields[i][0] == 11) {
/*     */ 
/*     */             
/* 540 */             offset = val.get(11);
/* 541 */             if (offset >= 12) {
/* 542 */               offset -= 12;
/*     */             }
/* 544 */             roundUp = !(offset <= 6);
/* 545 */             offsetSet = true;
/*     */           } 
/*     */           break;
/*     */       } 
/* 549 */       if (!offsetSet) {
/* 550 */         int min = val.getActualMinimum(fields[i][0]);
/* 551 */         int max = val.getActualMaximum(fields[i][0]);
/*     */         
/* 553 */         offset = val.get(fields[i][0]) - min;
/*     */         
/* 555 */         roundUp = !(offset <= (max - min) / 2);
/*     */       } 
/*     */       
/* 558 */       val.set(fields[i][0], val.get(fields[i][0]) - offset);
/*     */     } 
/* 560 */     throw new IllegalArgumentException("The field " + field + " is not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterator iterator(Date focus, int rangeStyle) {
/* 584 */     if (focus == null) {
/* 585 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 587 */     Calendar gval = Calendar.getInstance();
/* 588 */     gval.setTime(focus);
/* 589 */     return iterator(gval, rangeStyle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterator iterator(Calendar focus, int rangeStyle) {
/* 614 */     if (focus == null) {
/* 615 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 617 */     Calendar start = null;
/* 618 */     Calendar end = null;
/* 619 */     int startCutoff = 1;
/* 620 */     int endCutoff = 7;
/* 621 */     switch (rangeStyle) {
/*     */       
/*     */       case 5:
/*     */       case 6:
/* 625 */         start = truncate(focus, 2);
/*     */         
/* 627 */         end = (Calendar)start.clone();
/* 628 */         end.add(2, 1);
/* 629 */         end.add(5, -1);
/*     */         
/* 631 */         if (rangeStyle == 6) {
/* 632 */           startCutoff = 2;
/* 633 */           endCutoff = 1;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/* 641 */         start = truncate(focus, 5);
/* 642 */         end = truncate(focus, 5);
/* 643 */         switch (rangeStyle) {
/*     */ 
/*     */ 
/*     */           
/*     */           case 2:
/* 648 */             startCutoff = 2;
/* 649 */             endCutoff = 1;
/*     */             break;
/*     */           case 3:
/* 652 */             startCutoff = focus.get(7);
/* 653 */             endCutoff = startCutoff - 1;
/*     */             break;
/*     */           case 4:
/* 656 */             startCutoff = focus.get(7) - 3;
/* 657 */             endCutoff = focus.get(7) + 3;
/*     */             break;
/*     */         } 
/*     */         break;
/*     */       default:
/* 662 */         throw new IllegalArgumentException("The range style " + rangeStyle + " is not valid.");
/*     */     } 
/* 664 */     if (startCutoff < 1) {
/* 665 */       startCutoff += 7;
/*     */     }
/* 667 */     if (startCutoff > 7) {
/* 668 */       startCutoff -= 7;
/*     */     }
/* 670 */     if (endCutoff < 1) {
/* 671 */       endCutoff += 7;
/*     */     }
/* 673 */     if (endCutoff > 7) {
/* 674 */       endCutoff -= 7;
/*     */     }
/* 676 */     while (start.get(7) != startCutoff) {
/* 677 */       start.add(5, -1);
/*     */     }
/* 679 */     while (end.get(7) != endCutoff) {
/* 680 */       end.add(5, 1);
/*     */     }
/* 682 */     return new DateIterator(start, end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Iterator iterator(Object focus, int rangeStyle) {
/* 706 */     if (focus == null) {
/* 707 */       throw new IllegalArgumentException("The date must not be null");
/*     */     }
/* 709 */     if (focus instanceof Date)
/* 710 */       return iterator((Date)focus, rangeStyle); 
/* 711 */     if (focus instanceof Calendar) {
/* 712 */       return iterator((Calendar)focus, rangeStyle);
/*     */     }
/* 714 */     throw new ClassCastException("Could not iterate based on " + focus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DateIterator
/*     */     implements Iterator
/*     */   {
/*     */     private final Calendar endFinal;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Calendar spot;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DateIterator(Calendar startFinal, Calendar endFinal) {
/* 733 */       this.endFinal = endFinal;
/* 734 */       this.spot = startFinal;
/* 735 */       this.spot.add(5, -1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 744 */       return this.spot.before(this.endFinal);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object next() {
/* 753 */       if (this.spot.equals(this.endFinal)) {
/* 754 */         throw new NoSuchElementException();
/*     */       }
/* 756 */       this.spot.add(5, 1);
/* 757 */       return this.spot.clone();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {
/* 767 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\time\DateUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */