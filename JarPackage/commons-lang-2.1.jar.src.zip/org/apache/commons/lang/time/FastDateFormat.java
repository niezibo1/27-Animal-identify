/*      */ package org.apache.commons.lang.time;
/*      */ 
/*      */ import java.text.DateFormat;
/*      */ import java.text.DateFormatSymbols;
/*      */ import java.text.FieldPosition;
/*      */ import java.text.Format;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FastDateFormat
/*      */   extends Format
/*      */ {
/*      */   public static final int FULL = 0;
/*      */   public static final int LONG = 1;
/*      */   public static final int MEDIUM = 2;
/*      */   public static final int SHORT = 3;
/*   97 */   static final double LOG_10 = Math.log(10.0D);
/*      */   
/*      */   private static String cDefaultPattern;
/*      */   
/*  101 */   private static Map cInstanceCache = new HashMap(7);
/*  102 */   private static Map cDateInstanceCache = new HashMap(7);
/*  103 */   private static Map cTimeInstanceCache = new HashMap(7);
/*  104 */   private static Map cDateTimeInstanceCache = new HashMap(7);
/*  105 */   private static Map cTimeZoneDisplayCache = new HashMap(7);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String mPattern;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final TimeZone mTimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean mTimeZoneForced;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Locale mLocale;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean mLocaleForced;
/*      */ 
/*      */ 
/*      */   
/*      */   private Rule[] mRules;
/*      */ 
/*      */ 
/*      */   
/*      */   private int mMaxLengthEstimate;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getInstance() {
/*  144 */     return getInstance(getDefaultPattern(), null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getInstance(String pattern) {
/*  157 */     return getInstance(pattern, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getInstance(String pattern, TimeZone timeZone) {
/*  172 */     return getInstance(pattern, timeZone, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getInstance(String pattern, Locale locale) {
/*  186 */     return getInstance(pattern, null, locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized FastDateFormat getInstance(String pattern, TimeZone timeZone, Locale locale) {
/*  203 */     FastDateFormat emptyFormat = new FastDateFormat(pattern, timeZone, locale);
/*  204 */     FastDateFormat format = (FastDateFormat)cInstanceCache.get(emptyFormat);
/*  205 */     if (format == null) {
/*  206 */       format = emptyFormat;
/*  207 */       format.init();
/*  208 */       cInstanceCache.put(format, format);
/*      */     } 
/*  210 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getDateInstance(int style) {
/*  225 */     return getDateInstance(style, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getDateInstance(int style, Locale locale) {
/*  240 */     return getDateInstance(style, null, locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getDateInstance(int style, TimeZone timeZone) {
/*  256 */     return getDateInstance(style, timeZone, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized FastDateFormat getDateInstance(int style, TimeZone timeZone, Locale locale) {
/*  271 */     Object key = new Integer(style);
/*  272 */     if (timeZone != null) {
/*  273 */       key = new Pair(key, timeZone);
/*      */     }
/*  275 */     if (locale != null) {
/*  276 */       key = new Pair(key, locale);
/*      */     }
/*      */     
/*  279 */     FastDateFormat format = (FastDateFormat)cDateInstanceCache.get(key);
/*  280 */     if (format == null) {
/*  281 */       if (locale == null) {
/*  282 */         locale = Locale.getDefault();
/*      */       }
/*      */       
/*      */       try {
/*  286 */         SimpleDateFormat formatter = (SimpleDateFormat)DateFormat.getDateInstance(style, locale);
/*  287 */         String pattern = formatter.toPattern();
/*  288 */         format = getInstance(pattern, timeZone, locale);
/*  289 */         cDateInstanceCache.put(key, format);
/*      */       }
/*  291 */       catch (ClassCastException classCastException) {
/*  292 */         throw new IllegalArgumentException("No date pattern for locale: " + locale);
/*      */       } 
/*      */     } 
/*  295 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getTimeInstance(int style) {
/*  310 */     return getTimeInstance(style, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getTimeInstance(int style, Locale locale) {
/*  325 */     return getTimeInstance(style, null, locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getTimeInstance(int style, TimeZone timeZone) {
/*  341 */     return getTimeInstance(style, timeZone, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized FastDateFormat getTimeInstance(int style, TimeZone timeZone, Locale locale) {
/*  357 */     Object key = new Integer(style);
/*  358 */     if (timeZone != null) {
/*  359 */       key = new Pair(key, timeZone);
/*      */     }
/*  361 */     if (locale != null) {
/*  362 */       key = new Pair(key, locale);
/*      */     }
/*      */     
/*  365 */     FastDateFormat format = (FastDateFormat)cTimeInstanceCache.get(key);
/*  366 */     if (format == null) {
/*  367 */       if (locale == null) {
/*  368 */         locale = Locale.getDefault();
/*      */       }
/*      */       
/*      */       try {
/*  372 */         SimpleDateFormat formatter = (SimpleDateFormat)DateFormat.getTimeInstance(style, locale);
/*  373 */         String pattern = formatter.toPattern();
/*  374 */         format = getInstance(pattern, timeZone, locale);
/*  375 */         cTimeInstanceCache.put(key, format);
/*      */       }
/*  377 */       catch (ClassCastException classCastException) {
/*  378 */         throw new IllegalArgumentException("No date pattern for locale: " + locale);
/*      */       } 
/*      */     } 
/*  381 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getDateTimeInstance(int dateStyle, int timeStyle) {
/*  398 */     return getDateTimeInstance(dateStyle, timeStyle, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getDateTimeInstance(int dateStyle, int timeStyle, Locale locale) {
/*  415 */     return getDateTimeInstance(dateStyle, timeStyle, null, locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FastDateFormat getDateTimeInstance(int dateStyle, int timeStyle, TimeZone timeZone) {
/*  433 */     return getDateTimeInstance(dateStyle, timeStyle, timeZone, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized FastDateFormat getDateTimeInstance(int dateStyle, int timeStyle, TimeZone timeZone, Locale locale) {
/*  451 */     Object key = new Pair(new Integer(dateStyle), new Integer(timeStyle));
/*  452 */     if (timeZone != null) {
/*  453 */       key = new Pair(key, timeZone);
/*      */     }
/*  455 */     if (locale != null) {
/*  456 */       key = new Pair(key, locale);
/*      */     }
/*      */     
/*  459 */     FastDateFormat format = (FastDateFormat)cDateTimeInstanceCache.get(key);
/*  460 */     if (format == null) {
/*  461 */       if (locale == null) {
/*  462 */         locale = Locale.getDefault();
/*      */       }
/*      */       
/*      */       try {
/*  466 */         SimpleDateFormat formatter = (SimpleDateFormat)DateFormat.getDateTimeInstance(dateStyle, timeStyle, 
/*  467 */             locale);
/*  468 */         String pattern = formatter.toPattern();
/*  469 */         format = getInstance(pattern, timeZone, locale);
/*  470 */         cDateTimeInstanceCache.put(key, format);
/*      */       }
/*  472 */       catch (ClassCastException classCastException) {
/*  473 */         throw new IllegalArgumentException("No date time pattern for locale: " + locale);
/*      */       } 
/*      */     } 
/*  476 */     return format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static synchronized String getTimeZoneDisplay(TimeZone tz, boolean daylight, int style, Locale locale) {
/*  491 */     Object key = new TimeZoneDisplayKey(tz, daylight, style, locale);
/*  492 */     String value = (String)cTimeZoneDisplayCache.get(key);
/*  493 */     if (value == null) {
/*      */       
/*  495 */       value = tz.getDisplayName(daylight, style, locale);
/*  496 */       cTimeZoneDisplayCache.put(key, value);
/*      */     } 
/*  498 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static synchronized String getDefaultPattern() {
/*  507 */     if (cDefaultPattern == null) {
/*  508 */       cDefaultPattern = (new SimpleDateFormat()).toPattern();
/*      */     }
/*  510 */     return cDefaultPattern;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected FastDateFormat(String pattern, TimeZone timeZone, Locale locale) {
/*  530 */     if (pattern == null) {
/*  531 */       throw new IllegalArgumentException("The pattern must not be null");
/*      */     }
/*  533 */     this.mPattern = pattern;
/*      */     
/*  535 */     this.mTimeZoneForced = !(timeZone == null);
/*  536 */     if (timeZone == null) {
/*  537 */       timeZone = TimeZone.getDefault();
/*      */     }
/*  539 */     this.mTimeZone = timeZone;
/*      */     
/*  541 */     this.mLocaleForced = !(locale == null);
/*  542 */     if (locale == null) {
/*  543 */       locale = Locale.getDefault();
/*      */     }
/*  545 */     this.mLocale = locale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init() {
/*  552 */     List rulesList = parsePattern();
/*  553 */     this.mRules = (Rule[])rulesList.toArray((Object[])new Rule[rulesList.size()]);
/*      */     
/*  555 */     int len = 0;
/*  556 */     for (int i = this.mRules.length; --i >= 0;) {
/*  557 */       len += this.mRules[i].estimateLength();
/*      */     }
/*      */     
/*  560 */     this.mMaxLengthEstimate = len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List parsePattern() {
/*  572 */     DateFormatSymbols symbols = new DateFormatSymbols(this.mLocale);
/*  573 */     List rules = new ArrayList();
/*      */     
/*  575 */     String[] ERAs = symbols.getEras();
/*  576 */     String[] months = symbols.getMonths();
/*  577 */     String[] shortMonths = symbols.getShortMonths();
/*  578 */     String[] weekdays = symbols.getWeekdays();
/*  579 */     String[] shortWeekdays = symbols.getShortWeekdays();
/*  580 */     String[] AmPmStrings = symbols.getAmPmStrings();
/*      */     
/*  582 */     int length = this.mPattern.length();
/*  583 */     int[] indexRef = new int[1];
/*      */     
/*  585 */     for (int i = 0; i < length; ) {
/*  586 */       indexRef[0] = i;
/*  587 */       String token = parseToken(this.mPattern, indexRef);
/*  588 */       i = indexRef[0];
/*      */       
/*  590 */       int tokenLen = token.length();
/*  591 */       if (tokenLen != 0) {
/*      */         Rule rule;
/*      */         
/*      */         String sub;
/*      */         
/*  596 */         char c = token.charAt(0);
/*      */         
/*  598 */         switch (c) {
/*      */           case 'G':
/*  600 */             rule = new TextField(0, ERAs);
/*      */             break;
/*      */           case 'y':
/*  603 */             if (tokenLen >= 4) {
/*  604 */               rule = selectNumberRule(1, tokenLen); break;
/*      */             } 
/*  606 */             rule = TwoDigitYearField.INSTANCE;
/*      */             break;
/*      */           
/*      */           case 'M':
/*  610 */             if (tokenLen >= 4) {
/*  611 */               rule = new TextField(2, months); break;
/*  612 */             }  if (tokenLen == 3) {
/*  613 */               rule = new TextField(2, shortMonths); break;
/*  614 */             }  if (tokenLen == 2) {
/*  615 */               rule = TwoDigitMonthField.INSTANCE; break;
/*      */             } 
/*  617 */             rule = UnpaddedMonthField.INSTANCE;
/*      */             break;
/*      */           
/*      */           case 'd':
/*  621 */             rule = selectNumberRule(5, tokenLen);
/*      */             break;
/*      */           case 'h':
/*  624 */             rule = new TwelveHourField(selectNumberRule(10, tokenLen));
/*      */             break;
/*      */           case 'H':
/*  627 */             rule = selectNumberRule(11, tokenLen);
/*      */             break;
/*      */           case 'm':
/*  630 */             rule = selectNumberRule(12, tokenLen);
/*      */             break;
/*      */           case 's':
/*  633 */             rule = selectNumberRule(13, tokenLen);
/*      */             break;
/*      */           case 'S':
/*  636 */             rule = selectNumberRule(14, tokenLen);
/*      */             break;
/*      */           case 'E':
/*  639 */             rule = new TextField(7, (tokenLen < 4) ? shortWeekdays : weekdays);
/*      */             break;
/*      */           case 'D':
/*  642 */             rule = selectNumberRule(6, tokenLen);
/*      */             break;
/*      */           case 'F':
/*  645 */             rule = selectNumberRule(8, tokenLen);
/*      */             break;
/*      */           case 'w':
/*  648 */             rule = selectNumberRule(3, tokenLen);
/*      */             break;
/*      */           case 'W':
/*  651 */             rule = selectNumberRule(4, tokenLen);
/*      */             break;
/*      */           case 'a':
/*  654 */             rule = new TextField(9, AmPmStrings);
/*      */             break;
/*      */           case 'k':
/*  657 */             rule = new TwentyFourHourField(selectNumberRule(11, tokenLen));
/*      */             break;
/*      */           case 'K':
/*  660 */             rule = selectNumberRule(10, tokenLen);
/*      */             break;
/*      */           case 'z':
/*  663 */             if (tokenLen >= 4) {
/*  664 */               rule = new TimeZoneNameRule(this.mTimeZone, this.mTimeZoneForced, this.mLocale, 1); break;
/*      */             } 
/*  666 */             rule = new TimeZoneNameRule(this.mTimeZone, this.mTimeZoneForced, this.mLocale, 0);
/*      */             break;
/*      */           
/*      */           case 'Z':
/*  670 */             if (tokenLen == 1) {
/*  671 */               rule = TimeZoneNumberRule.INSTANCE_NO_COLON; break;
/*      */             } 
/*  673 */             rule = TimeZoneNumberRule.INSTANCE_COLON;
/*      */             break;
/*      */           
/*      */           case '\'':
/*  677 */             sub = token.substring(1);
/*  678 */             if (sub.length() == 1) {
/*  679 */               rule = new CharacterLiteral(sub.charAt(0)); break;
/*      */             } 
/*  681 */             rule = new StringLiteral(sub);
/*      */             break;
/*      */           
/*      */           default:
/*  685 */             throw new IllegalArgumentException("Illegal pattern component: " + token);
/*      */         } 
/*      */         
/*  688 */         rules.add(rule); i++;
/*      */       }  break;
/*      */     } 
/*  691 */     return rules;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String parseToken(String pattern, int[] indexRef) {
/*  702 */     StringBuffer buf = new StringBuffer();
/*      */     
/*  704 */     int i = indexRef[0];
/*  705 */     int length = pattern.length();
/*      */     
/*  707 */     char c = pattern.charAt(i);
/*  708 */     if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
/*      */ 
/*      */       
/*  711 */       buf.append(c);
/*      */       
/*  713 */       while (i + 1 < length) {
/*  714 */         char peek = pattern.charAt(i + 1);
/*  715 */         if (peek == c) {
/*  716 */           buf.append(c);
/*  717 */           i++;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         break;
/*      */       } 
/*      */     } else {
/*  724 */       buf.append('\'');
/*      */       
/*  726 */       boolean inLiteral = false;
/*      */       
/*  728 */       for (; i < length; i++) {
/*  729 */         int j; c = pattern.charAt(i);
/*      */         
/*  731 */         if (c == '\'')
/*  732 */         { if (i + 1 < length && pattern.charAt(i + 1) == '\'') {
/*      */             
/*  734 */             i++;
/*  735 */             buf.append(c);
/*      */           } else {
/*  737 */             j = inLiteral ^ true;
/*      */           }  }
/*  739 */         else { if (j == 0 && ((
/*  740 */             c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))) {
/*  741 */             i--;
/*      */             break;
/*      */           } 
/*  744 */           buf.append(c); }
/*      */       
/*      */       } 
/*      */     } 
/*      */     
/*  749 */     indexRef[0] = i;
/*  750 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NumberRule selectNumberRule(int field, int padding) {
/*  761 */     switch (padding) {
/*      */       case 1:
/*  763 */         return new UnpaddedNumberField(field);
/*      */       case 2:
/*  765 */         return new TwoDigitNumberField(field);
/*      */     } 
/*  767 */     return new PaddedNumberField(field, padding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
/*  783 */     if (obj instanceof Date)
/*  784 */       return format((Date)obj, toAppendTo); 
/*  785 */     if (obj instanceof Calendar)
/*  786 */       return format((Calendar)obj, toAppendTo); 
/*  787 */     if (obj instanceof Long) {
/*  788 */       return format(((Long)obj).longValue(), toAppendTo);
/*      */     }
/*  790 */     throw new IllegalArgumentException("Unknown class: " + (
/*  791 */         (obj == null) ? "<null>" : obj.getClass().getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String format(long millis) {
/*  803 */     return format(new Date(millis));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String format(Date date) {
/*  813 */     Calendar c = new GregorianCalendar(this.mTimeZone);
/*  814 */     c.setTime(date);
/*  815 */     return applyRules(c, new StringBuffer(this.mMaxLengthEstimate)).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String format(Calendar calendar) {
/*  825 */     return format(calendar, new StringBuffer(this.mMaxLengthEstimate)).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer format(long millis, StringBuffer buf) {
/*  838 */     return format(new Date(millis), buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer format(Date date, StringBuffer buf) {
/*  850 */     Calendar c = new GregorianCalendar(this.mTimeZone);
/*  851 */     c.setTime(date);
/*  852 */     return applyRules(c, buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer format(Calendar calendar, StringBuffer buf) {
/*  864 */     if (this.mTimeZoneForced) {
/*  865 */       calendar = (Calendar)calendar.clone();
/*  866 */       calendar.setTimeZone(this.mTimeZone);
/*      */     } 
/*  868 */     return applyRules(calendar, buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StringBuffer applyRules(Calendar calendar, StringBuffer buf) {
/*  880 */     Rule[] rules = this.mRules;
/*  881 */     int len = this.mRules.length;
/*  882 */     for (int i = 0; i < len; i++) {
/*  883 */       rules[i].appendTo(buf, calendar);
/*      */     }
/*  885 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object parseObject(String source, ParsePosition pos) {
/*  898 */     pos.setIndex(0);
/*  899 */     pos.setErrorIndex(0);
/*  900 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPattern() {
/*  911 */     return this.mPattern;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TimeZone getTimeZone() {
/*  925 */     return this.mTimeZone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getTimeZoneOverridesCalendar() {
/*  936 */     return this.mTimeZoneForced;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Locale getLocale() {
/*  945 */     return this.mLocale;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxLengthEstimate() {
/*  958 */     return this.mMaxLengthEstimate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/*  970 */     if (obj instanceof FastDateFormat == false) {
/*  971 */       return false;
/*      */     }
/*  973 */     FastDateFormat other = (FastDateFormat)obj;
/*      */     
/*  975 */     if ((this.mPattern == other.mPattern || this.mPattern.equals(other.mPattern)) && (
/*  976 */       this.mTimeZone == other.mTimeZone || this.mTimeZone.equals(other.mTimeZone)) && (
/*  977 */       this.mLocale == other.mLocale || this.mLocale.equals(other.mLocale)) && 
/*  978 */       this.mTimeZoneForced == other.mTimeZoneForced && 
/*  979 */       this.mLocaleForced == other.mLocaleForced)
/*      */     {
/*  981 */       return true;
/*      */     }
/*  983 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  992 */     int total = 0;
/*  993 */     total += this.mPattern.hashCode();
/*  994 */     total += this.mTimeZone.hashCode();
/*  995 */     total += this.mTimeZoneForced ? 1 : 0;
/*  996 */     total += this.mLocale.hashCode();
/*  997 */     total += this.mLocaleForced ? 1 : 0;
/*  998 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1007 */     return "FastDateFormat[" + this.mPattern + "]";
/*      */   }
/*      */ 
/*      */   
/*      */   private static interface Rule
/*      */   {
/*      */     void appendTo(StringBuffer param1StringBuffer, Calendar param1Calendar);
/*      */ 
/*      */     
/*      */     int estimateLength();
/*      */   }
/*      */ 
/*      */   
/*      */   private static interface NumberRule
/*      */     extends Rule
/*      */   {
/*      */     void appendTo(StringBuffer param1StringBuffer, int param1Int);
/*      */   }
/*      */ 
/*      */   
/*      */   private static class CharacterLiteral
/*      */     implements Rule
/*      */   {
/*      */     private final char mValue;
/*      */ 
/*      */     
/*      */     CharacterLiteral(char value) {
/* 1034 */       this.mValue = value;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1038 */       return 1;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1042 */       buffer.append(this.mValue);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class StringLiteral
/*      */     implements Rule
/*      */   {
/*      */     private final String mValue;
/*      */     
/*      */     StringLiteral(String value) {
/* 1053 */       this.mValue = value;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1057 */       return this.mValue.length();
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1061 */       buffer.append(this.mValue);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TextField
/*      */     implements Rule
/*      */   {
/*      */     private final int mField;
/*      */     private final String[] mValues;
/*      */     
/*      */     TextField(int field, String[] values) {
/* 1073 */       this.mField = field;
/* 1074 */       this.mValues = values;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1078 */       int max = 0;
/* 1079 */       for (int i = this.mValues.length; --i >= 0; ) {
/* 1080 */         int len = this.mValues[i].length();
/* 1081 */         if (len > max) {
/* 1082 */           max = len;
/*      */         }
/*      */       } 
/* 1085 */       return max;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1089 */       buffer.append(this.mValues[calendar.get(this.mField)]);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class UnpaddedNumberField
/*      */     implements NumberRule
/*      */   {
/* 1097 */     static final UnpaddedNumberField INSTANCE_YEAR = new UnpaddedNumberField(1);
/*      */     
/*      */     private final int mField;
/*      */     
/*      */     UnpaddedNumberField(int field) {
/* 1102 */       this.mField = field;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1106 */       return 4;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1110 */       appendTo(buffer, calendar.get(this.mField));
/*      */     }
/*      */     
/*      */     public final void appendTo(StringBuffer buffer, int value) {
/* 1114 */       if (value < 10) {
/* 1115 */         buffer.append((char)(value + 48));
/* 1116 */       } else if (value < 100) {
/* 1117 */         buffer.append((char)(value / 10 + 48));
/* 1118 */         buffer.append((char)(value % 10 + 48));
/*      */       } else {
/* 1120 */         buffer.append(Integer.toString(value));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class UnpaddedMonthField
/*      */     implements NumberRule
/*      */   {
/* 1129 */     static final UnpaddedMonthField INSTANCE = new UnpaddedMonthField();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int estimateLength() {
/* 1135 */       return 2;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1139 */       appendTo(buffer, calendar.get(2) + 1);
/*      */     }
/*      */     
/*      */     public final void appendTo(StringBuffer buffer, int value) {
/* 1143 */       if (value < 10) {
/* 1144 */         buffer.append((char)(value + 48));
/*      */       } else {
/* 1146 */         buffer.append((char)(value / 10 + 48));
/* 1147 */         buffer.append((char)(value % 10 + 48));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class PaddedNumberField
/*      */     implements NumberRule
/*      */   {
/*      */     private final int mField;
/*      */     private final int mSize;
/*      */     
/*      */     PaddedNumberField(int field, int size) {
/* 1160 */       if (size < 3)
/*      */       {
/* 1162 */         throw new IllegalArgumentException();
/*      */       }
/* 1164 */       this.mField = field;
/* 1165 */       this.mSize = size;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1169 */       return 4;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1173 */       appendTo(buffer, calendar.get(this.mField));
/*      */     }
/*      */     
/*      */     public final void appendTo(StringBuffer buffer, int value) {
/* 1177 */       if (value < 100) {
/* 1178 */         for (int i = this.mSize; --i >= 2;) {
/* 1179 */           buffer.append('0');
/*      */         }
/* 1181 */         buffer.append((char)(value / 10 + 48));
/* 1182 */         buffer.append((char)(value % 10 + 48));
/*      */       } else {
/*      */         int digits;
/* 1185 */         if (value < 1000) {
/* 1186 */           digits = 3;
/*      */         } else {
/* 1188 */           digits = (int)(Math.log(value) / FastDateFormat.LOG_10) + 1;
/*      */         } 
/* 1190 */         for (int i = this.mSize; --i >= digits;) {
/* 1191 */           buffer.append('0');
/*      */         }
/* 1193 */         buffer.append(Integer.toString(value));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TwoDigitNumberField
/*      */     implements NumberRule
/*      */   {
/*      */     private final int mField;
/*      */     
/*      */     TwoDigitNumberField(int field) {
/* 1205 */       this.mField = field;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1209 */       return 2;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1213 */       appendTo(buffer, calendar.get(this.mField));
/*      */     }
/*      */     
/*      */     public final void appendTo(StringBuffer buffer, int value) {
/* 1217 */       if (value < 100) {
/* 1218 */         buffer.append((char)(value / 10 + 48));
/* 1219 */         buffer.append((char)(value % 10 + 48));
/*      */       } else {
/* 1221 */         buffer.append(Integer.toString(value));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TwoDigitYearField
/*      */     implements NumberRule
/*      */   {
/* 1230 */     static final TwoDigitYearField INSTANCE = new TwoDigitYearField();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int estimateLength() {
/* 1236 */       return 2;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1240 */       appendTo(buffer, calendar.get(1) % 100);
/*      */     }
/*      */     
/*      */     public final void appendTo(StringBuffer buffer, int value) {
/* 1244 */       buffer.append((char)(value / 10 + 48));
/* 1245 */       buffer.append((char)(value % 10 + 48));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TwoDigitMonthField
/*      */     implements NumberRule
/*      */   {
/* 1253 */     static final TwoDigitMonthField INSTANCE = new TwoDigitMonthField();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int estimateLength() {
/* 1259 */       return 2;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1263 */       appendTo(buffer, calendar.get(2) + 1);
/*      */     }
/*      */     
/*      */     public final void appendTo(StringBuffer buffer, int value) {
/* 1267 */       buffer.append((char)(value / 10 + 48));
/* 1268 */       buffer.append((char)(value % 10 + 48));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TwelveHourField
/*      */     implements NumberRule
/*      */   {
/*      */     private final FastDateFormat.NumberRule mRule;
/*      */     
/*      */     TwelveHourField(FastDateFormat.NumberRule rule) {
/* 1279 */       this.mRule = rule;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1283 */       return this.mRule.estimateLength();
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1287 */       int value = calendar.get(10);
/* 1288 */       if (value == 0) {
/* 1289 */         value = calendar.getLeastMaximum(10) + 1;
/*      */       }
/* 1291 */       this.mRule.appendTo(buffer, value);
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, int value) {
/* 1295 */       this.mRule.appendTo(buffer, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TwentyFourHourField
/*      */     implements NumberRule
/*      */   {
/*      */     private final FastDateFormat.NumberRule mRule;
/*      */     
/*      */     TwentyFourHourField(FastDateFormat.NumberRule rule) {
/* 1306 */       this.mRule = rule;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1310 */       return this.mRule.estimateLength();
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1314 */       int value = calendar.get(11);
/* 1315 */       if (value == 0) {
/* 1316 */         value = calendar.getMaximum(11) + 1;
/*      */       }
/* 1318 */       this.mRule.appendTo(buffer, value);
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, int value) {
/* 1322 */       this.mRule.appendTo(buffer, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TimeZoneNameRule
/*      */     implements Rule
/*      */   {
/*      */     private final TimeZone mTimeZone;
/*      */     private final boolean mTimeZoneForced;
/*      */     private final Locale mLocale;
/*      */     private final int mStyle;
/*      */     private final String mStandard;
/*      */     private final String mDaylight;
/*      */     
/*      */     TimeZoneNameRule(TimeZone timeZone, boolean timeZoneForced, Locale locale, int style) {
/* 1338 */       this.mTimeZone = timeZone;
/* 1339 */       this.mTimeZoneForced = timeZoneForced;
/* 1340 */       this.mLocale = locale;
/* 1341 */       this.mStyle = style;
/*      */       
/* 1343 */       if (timeZoneForced) {
/* 1344 */         this.mStandard = FastDateFormat.getTimeZoneDisplay(timeZone, false, style, locale);
/* 1345 */         this.mDaylight = FastDateFormat.getTimeZoneDisplay(timeZone, true, style, locale);
/*      */       } else {
/* 1347 */         this.mStandard = null;
/* 1348 */         this.mDaylight = null;
/*      */       } 
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1353 */       if (this.mTimeZoneForced)
/* 1354 */         return Math.max(this.mStandard.length(), this.mDaylight.length()); 
/* 1355 */       if (this.mStyle == 0) {
/* 1356 */         return 4;
/*      */       }
/* 1358 */       return 40;
/*      */     }
/*      */ 
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1363 */       if (this.mTimeZoneForced) {
/* 1364 */         if (this.mTimeZone.useDaylightTime() && calendar.get(16) != 0) {
/* 1365 */           buffer.append(this.mDaylight);
/*      */         } else {
/* 1367 */           buffer.append(this.mStandard);
/*      */         } 
/*      */       } else {
/* 1370 */         TimeZone timeZone = calendar.getTimeZone();
/* 1371 */         if (timeZone.useDaylightTime() && calendar.get(16) != 0) {
/* 1372 */           buffer.append(FastDateFormat.getTimeZoneDisplay(timeZone, true, this.mStyle, this.mLocale));
/*      */         } else {
/* 1374 */           buffer.append(FastDateFormat.getTimeZoneDisplay(timeZone, false, this.mStyle, this.mLocale));
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class TimeZoneNumberRule
/*      */     implements Rule
/*      */   {
/* 1385 */     static final TimeZoneNumberRule INSTANCE_COLON = new TimeZoneNumberRule(true);
/* 1386 */     static final TimeZoneNumberRule INSTANCE_NO_COLON = new TimeZoneNumberRule(false);
/*      */     
/*      */     final boolean mColon;
/*      */     
/*      */     TimeZoneNumberRule(boolean colon) {
/* 1391 */       this.mColon = colon;
/*      */     }
/*      */     
/*      */     public int estimateLength() {
/* 1395 */       return 5;
/*      */     }
/*      */     
/*      */     public void appendTo(StringBuffer buffer, Calendar calendar) {
/* 1399 */       int offset = calendar.get(15) + calendar.get(16);
/*      */       
/* 1401 */       if (offset < 0) {
/* 1402 */         buffer.append('-');
/* 1403 */         offset = -offset;
/*      */       } else {
/* 1405 */         buffer.append('+');
/*      */       } 
/*      */       
/* 1408 */       int hours = offset / 3600000;
/* 1409 */       buffer.append((char)(hours / 10 + 48));
/* 1410 */       buffer.append((char)(hours % 10 + 48));
/*      */       
/* 1412 */       if (this.mColon) {
/* 1413 */         buffer.append(':');
/*      */       }
/*      */       
/* 1416 */       int minutes = offset / 60000 - 60 * hours;
/* 1417 */       buffer.append((char)(minutes / 10 + 48));
/* 1418 */       buffer.append((char)(minutes % 10 + 48));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TimeZoneDisplayKey
/*      */   {
/*      */     private final TimeZone mTimeZone;
/*      */     
/*      */     private final int mStyle;
/*      */     
/*      */     private final Locale mLocale;
/*      */ 
/*      */     
/*      */     TimeZoneDisplayKey(TimeZone timeZone, boolean daylight, int style, Locale locale) {
/* 1433 */       this.mTimeZone = timeZone;
/* 1434 */       if (daylight) {
/* 1435 */         style |= Integer.MIN_VALUE;
/*      */       }
/* 1437 */       this.mStyle = style;
/* 1438 */       this.mLocale = locale;
/*      */     }
/*      */     
/*      */     public int hashCode() {
/* 1442 */       return this.mStyle * 31 + this.mLocale.hashCode();
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/* 1446 */       if (this == obj) {
/* 1447 */         return true;
/*      */       }
/* 1449 */       if (obj instanceof TimeZoneDisplayKey) {
/* 1450 */         TimeZoneDisplayKey other = (TimeZoneDisplayKey)obj;
/* 1451 */         return 
/* 1452 */           !(!this.mTimeZone.equals(other.mTimeZone) || 
/* 1453 */           this.mStyle != other.mStyle || 
/* 1454 */           !this.mLocale.equals(other.mLocale));
/*      */       } 
/* 1456 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class Pair
/*      */   {
/*      */     private final Object mObj1;
/*      */ 
/*      */     
/*      */     private final Object mObj2;
/*      */ 
/*      */ 
/*      */     
/*      */     public Pair(Object obj1, Object obj2) {
/* 1472 */       this.mObj1 = obj1;
/* 1473 */       this.mObj2 = obj2;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/* 1477 */       if (this == obj) {
/* 1478 */         return true;
/*      */       }
/*      */       
/* 1481 */       if (!(obj instanceof Pair)) {
/* 1482 */         return false;
/*      */       }
/*      */       
/* 1485 */       Pair key = (Pair)obj;
/*      */ 
/*      */       
/* 1488 */       if ((this.mObj1 == null) ? (
/* 1489 */         key.mObj1 == null) : this.mObj1.equals(key.mObj1)) {
/* 1490 */         if (!((this.mObj2 == null) ? (
/* 1491 */           key.mObj2 == null) : this.mObj2.equals(key.mObj2)));
/*      */         return true;
/*      */       } 
/*      */     } public int hashCode() {
/* 1495 */       return (
/* 1496 */         (this.mObj1 == null) ? 0 : this.mObj1.hashCode()) + (
/* 1497 */         (this.mObj2 == null) ? 0 : this.mObj2.hashCode());
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1501 */       return "[" + this.mObj1 + ':' + this.mObj2 + ']';
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\time\FastDateFormat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */