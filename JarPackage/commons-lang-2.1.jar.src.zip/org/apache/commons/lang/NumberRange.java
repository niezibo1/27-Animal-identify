/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberRange
/*     */ {
/*     */   private final Number min;
/*     */   private final Number max;
/*     */   
/*     */   public NumberRange(Number num) {
/*  52 */     if (num == null) {
/*  53 */       throw new NullPointerException("The number must not be null");
/*     */     }
/*     */     
/*  56 */     this.min = num;
/*  57 */     this.max = num;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberRange(Number min, Number max) {
/*  73 */     if (min == null)
/*  74 */       throw new NullPointerException("The minimum value must not be null"); 
/*  75 */     if (max == null) {
/*  76 */       throw new NullPointerException("The maximum value must not be null");
/*     */     }
/*     */     
/*  79 */     if (max.doubleValue() < min.doubleValue()) {
/*  80 */       this.min = this.max = min;
/*     */     } else {
/*  82 */       this.min = min;
/*  83 */       this.max = max;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMinimum() {
/*  93 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMaximum() {
/* 102 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includesNumber(Number number) {
/* 114 */     if (number == null) {
/* 115 */       return false;
/*     */     }
/* 117 */     return !(this.min.doubleValue() > number.doubleValue() || 
/* 118 */       this.max.doubleValue() < number.doubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includesRange(NumberRange range) {
/* 131 */     if (range == null) {
/* 132 */       return false;
/*     */     }
/* 134 */     return !(!includesNumber(range.min) || !includesNumber(range.max));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overlaps(NumberRange range) {
/* 147 */     if (range == null) {
/* 148 */       return false;
/*     */     }
/* 150 */     return !(!range.includesNumber(this.min) && !range.includesNumber(this.max) && 
/* 151 */       !includesRange(range));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 164 */     if (obj == this)
/* 165 */       return true; 
/* 166 */     if (!(obj instanceof NumberRange)) {
/* 167 */       return false;
/*     */     }
/* 169 */     NumberRange range = (NumberRange)obj;
/* 170 */     return !(!this.min.equals(range.min) || !this.max.equals(range.max));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 180 */     int result = 17;
/* 181 */     result = 37 * result + this.min.hashCode();
/* 182 */     result = 37 * result + this.max.hashCode();
/* 183 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 196 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 198 */     if (this.min.doubleValue() < 0.0D) {
/* 199 */       sb.append('(')
/* 200 */         .append(this.min)
/* 201 */         .append(')');
/*     */     } else {
/* 203 */       sb.append(this.min);
/*     */     } 
/*     */     
/* 206 */     sb.append('-');
/*     */     
/* 208 */     if (this.max.doubleValue() < 0.0D) {
/* 209 */       sb.append('(')
/* 210 */         .append(this.max)
/* 211 */         .append(')');
/*     */     } else {
/* 213 */       sb.append(this.max);
/*     */     } 
/*     */     
/* 216 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\NumberRange.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */