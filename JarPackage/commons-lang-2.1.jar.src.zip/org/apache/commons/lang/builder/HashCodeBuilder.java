/*     */ package org.apache.commons.lang.builder;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HashCodeBuilder
/*     */ {
/*     */   private final int iConstant;
/*  88 */   private int iTotal = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder() {
/*  95 */     this.iConstant = 37;
/*  96 */     this.iTotal = 17;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder(int initialNonZeroOddNumber, int multiplierNonZeroOddNumber) {
/* 111 */     if (initialNonZeroOddNumber == 0) {
/* 112 */       throw new IllegalArgumentException("HashCodeBuilder requires a non zero initial value");
/*     */     }
/* 114 */     if (initialNonZeroOddNumber % 2 == 0) {
/* 115 */       throw new IllegalArgumentException("HashCodeBuilder requires an odd initial value");
/*     */     }
/* 117 */     if (multiplierNonZeroOddNumber == 0) {
/* 118 */       throw new IllegalArgumentException("HashCodeBuilder requires a non zero multiplier");
/*     */     }
/* 120 */     if (multiplierNonZeroOddNumber % 2 == 0) {
/* 121 */       throw new IllegalArgumentException("HashCodeBuilder requires an odd multiplier");
/*     */     }
/* 123 */     this.iConstant = multiplierNonZeroOddNumber;
/* 124 */     this.iTotal = initialNonZeroOddNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int reflectionHashCode(Object object) {
/* 150 */     return reflectionHashCode(17, 37, object, false, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int reflectionHashCode(Object object, boolean testTransients) {
/* 176 */     return reflectionHashCode(17, 37, object, testTransients, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int reflectionHashCode(int initialNonZeroOddNumber, int multiplierNonZeroOddNumber, Object object) {
/* 205 */     return reflectionHashCode(initialNonZeroOddNumber, multiplierNonZeroOddNumber, object, false, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int reflectionHashCode(int initialNonZeroOddNumber, int multiplierNonZeroOddNumber, Object object, boolean testTransients) {
/* 237 */     return reflectionHashCode(initialNonZeroOddNumber, multiplierNonZeroOddNumber, object, testTransients, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int reflectionHashCode(int initialNonZeroOddNumber, int multiplierNonZeroOddNumber, Object object, boolean testTransients, Class reflectUpToClass) {
/* 278 */     if (object == null) {
/* 279 */       throw new IllegalArgumentException("The object to build a hash code for must not be null");
/*     */     }
/* 281 */     HashCodeBuilder builder = new HashCodeBuilder(initialNonZeroOddNumber, multiplierNonZeroOddNumber);
/* 282 */     Class clazz = object.getClass();
/* 283 */     reflectionAppend(object, clazz, builder, testTransients);
/* 284 */     while (clazz.getSuperclass() != null && clazz != reflectUpToClass) {
/* 285 */       clazz = clazz.getSuperclass();
/* 286 */       reflectionAppend(object, clazz, builder, testTransients);
/*     */     } 
/* 288 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void reflectionAppend(Object object, Class clazz, HashCodeBuilder builder, boolean useTransients) {
/* 301 */     Field[] fields = clazz.getDeclaredFields();
/* 302 */     AccessibleObject.setAccessible((AccessibleObject[])fields, true);
/* 303 */     for (int i = 0; i < fields.length; i++) {
/* 304 */       Field f = fields[i];
/* 305 */       if (f.getName().indexOf('$') == -1 && (
/* 306 */         useTransients || !Modifier.isTransient(f.getModifiers())) && 
/* 307 */         !Modifier.isStatic(f.getModifiers())) {
/*     */         try {
/* 309 */           builder.append(f.get(object));
/* 310 */         } catch (IllegalAccessException illegalAccessException) {
/*     */ 
/*     */           
/* 313 */           throw new InternalError("Unexpected IllegalAccessException");
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder appendSuper(int superHashCode) {
/* 329 */     this.iTotal = this.iTotal * this.iConstant + superHashCode;
/* 330 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(Object object) {
/* 342 */     if (object == null) {
/* 343 */       this.iTotal *= this.iConstant;
/*     */     
/*     */     }
/* 346 */     else if (object.getClass().isArray() == false) {
/*     */       
/* 348 */       this.iTotal = this.iTotal * this.iConstant + object.hashCode();
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 353 */     else if (object instanceof long[]) {
/* 354 */       append((long[])object);
/* 355 */     } else if (object instanceof int[]) {
/* 356 */       append((int[])object);
/* 357 */     } else if (object instanceof short[]) {
/* 358 */       append((short[])object);
/* 359 */     } else if (object instanceof char[]) {
/* 360 */       append((char[])object);
/* 361 */     } else if (object instanceof byte[]) {
/* 362 */       append((byte[])object);
/* 363 */     } else if (object instanceof double[]) {
/* 364 */       append((double[])object);
/* 365 */     } else if (object instanceof float[]) {
/* 366 */       append((float[])object);
/* 367 */     } else if (object instanceof boolean[]) {
/* 368 */       append((boolean[])object);
/*     */     } else {
/*     */       
/* 371 */       append((Object[])object);
/*     */     } 
/*     */ 
/*     */     
/* 375 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(long value) {
/* 385 */     this.iTotal = this.iTotal * this.iConstant + (int)(value ^ value >> 32L);
/* 386 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(int value) {
/* 396 */     this.iTotal = this.iTotal * this.iConstant + value;
/* 397 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(short value) {
/* 407 */     this.iTotal = this.iTotal * this.iConstant + value;
/* 408 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(char value) {
/* 418 */     this.iTotal = this.iTotal * this.iConstant + value;
/* 419 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(byte value) {
/* 429 */     this.iTotal = this.iTotal * this.iConstant + value;
/* 430 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(double value) {
/* 440 */     return append(Double.doubleToLongBits(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(float value) {
/* 450 */     this.iTotal = this.iTotal * this.iConstant + Float.floatToIntBits(value);
/* 451 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(boolean value) {
/* 464 */     this.iTotal = this.iTotal * this.iConstant + (value ? 0 : 1);
/* 465 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(Object[] array) {
/* 475 */     if (array == null) {
/* 476 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 478 */       for (int i = 0; i < array.length; i++) {
/* 479 */         append(array[i]);
/*     */       }
/*     */     } 
/* 482 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(long[] array) {
/* 492 */     if (array == null) {
/* 493 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 495 */       for (int i = 0; i < array.length; i++) {
/* 496 */         append(array[i]);
/*     */       }
/*     */     } 
/* 499 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(int[] array) {
/* 509 */     if (array == null) {
/* 510 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 512 */       for (int i = 0; i < array.length; i++) {
/* 513 */         append(array[i]);
/*     */       }
/*     */     } 
/* 516 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(short[] array) {
/* 526 */     if (array == null) {
/* 527 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 529 */       for (int i = 0; i < array.length; i++) {
/* 530 */         append(array[i]);
/*     */       }
/*     */     } 
/* 533 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(char[] array) {
/* 543 */     if (array == null) {
/* 544 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 546 */       for (int i = 0; i < array.length; i++) {
/* 547 */         append(array[i]);
/*     */       }
/*     */     } 
/* 550 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(byte[] array) {
/* 560 */     if (array == null) {
/* 561 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 563 */       for (int i = 0; i < array.length; i++) {
/* 564 */         append(array[i]);
/*     */       }
/*     */     } 
/* 567 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(double[] array) {
/* 577 */     if (array == null) {
/* 578 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 580 */       for (int i = 0; i < array.length; i++) {
/* 581 */         append(array[i]);
/*     */       }
/*     */     } 
/* 584 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(float[] array) {
/* 594 */     if (array == null) {
/* 595 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 597 */       for (int i = 0; i < array.length; i++) {
/* 598 */         append(array[i]);
/*     */       }
/*     */     } 
/* 601 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashCodeBuilder append(boolean[] array) {
/* 611 */     if (array == null) {
/* 612 */       this.iTotal *= this.iConstant;
/*     */     } else {
/* 614 */       for (int i = 0; i < array.length; i++) {
/* 615 */         append(array[i]);
/*     */       }
/*     */     } 
/* 618 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toHashCode() {
/* 627 */     return this.iTotal;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\builder\HashCodeBuilder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */