/*     */ package org.apache.commons.lang.builder;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EqualsBuilder
/*     */ {
/*     */   private boolean isEquals = true;
/*     */   
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs) {
/* 121 */     return reflectionEquals(lhs, rhs, false, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs, boolean testTransients) {
/* 145 */     return reflectionEquals(lhs, rhs, testTransients, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean reflectionEquals(Object lhs, Object rhs, boolean testTransients, Class reflectUpToClass) {
/*     */     Class testClass;
/* 174 */     if (lhs == rhs) {
/* 175 */       return true;
/*     */     }
/* 177 */     if (lhs == null || rhs == null) {
/* 178 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     Class lhsClass = lhs.getClass();
/* 185 */     Class rhsClass = rhs.getClass();
/*     */     
/* 187 */     if (lhsClass.isInstance(rhs)) {
/* 188 */       testClass = lhsClass;
/* 189 */       if (!rhsClass.isInstance(lhs))
/*     */       {
/* 191 */         testClass = rhsClass;
/*     */       }
/* 193 */     } else if (rhsClass.isInstance(lhs)) {
/* 194 */       testClass = rhsClass;
/* 195 */       if (!lhsClass.isInstance(rhs))
/*     */       {
/* 197 */         testClass = lhsClass;
/*     */       }
/*     */     } else {
/*     */       
/* 201 */       return false;
/*     */     } 
/* 203 */     EqualsBuilder equalsBuilder = new EqualsBuilder();
/*     */     try {
/* 205 */       reflectionAppend(lhs, rhs, testClass, equalsBuilder, testTransients);
/* 206 */       while (testClass.getSuperclass() != null && testClass != reflectUpToClass) {
/* 207 */         testClass = testClass.getSuperclass();
/* 208 */         reflectionAppend(lhs, rhs, testClass, equalsBuilder, testTransients);
/*     */       } 
/* 210 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 216 */       return false;
/*     */     } 
/* 218 */     return equalsBuilder.isEquals();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void reflectionAppend(Object lhs, Object rhs, Class clazz, EqualsBuilder builder, boolean useTransients) {
/* 237 */     Field[] fields = clazz.getDeclaredFields();
/* 238 */     AccessibleObject.setAccessible((AccessibleObject[])fields, true);
/* 239 */     for (int i = 0; i < fields.length && builder.isEquals; i++) {
/* 240 */       Field f = fields[i];
/* 241 */       if (f.getName().indexOf('$') == -1 && (
/* 242 */         useTransients || !Modifier.isTransient(f.getModifiers())) && 
/* 243 */         !Modifier.isStatic(f.getModifiers())) {
/*     */         try {
/* 245 */           builder.append(f.get(lhs), f.get(rhs));
/* 246 */         } catch (IllegalAccessException illegalAccessException) {
/*     */ 
/*     */           
/* 249 */           throw new InternalError("Unexpected IllegalAccessException");
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder appendSuper(boolean superEquals) {
/* 265 */     if (this.isEquals == false) {
/* 266 */       return this;
/*     */     }
/* 268 */     this.isEquals = superEquals;
/* 269 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(Object lhs, Object rhs) {
/* 283 */     if (this.isEquals == false) {
/* 284 */       return this;
/*     */     }
/* 286 */     if (lhs == rhs) {
/* 287 */       return this;
/*     */     }
/* 289 */     if (lhs == null || rhs == null) {
/* 290 */       setEquals(false);
/* 291 */       return this;
/*     */     } 
/* 293 */     Class lhsClass = lhs.getClass();
/* 294 */     if (!lhsClass.isArray()) {
/*     */       
/* 296 */       this.isEquals = lhs.equals(rhs);
/* 297 */     } else if (lhs.getClass() != rhs.getClass()) {
/*     */       
/* 299 */       setEquals(false);
/*     */ 
/*     */     
/*     */     }
/* 303 */     else if (lhs instanceof long[]) {
/* 304 */       append((long[])lhs, (long[])rhs);
/* 305 */     } else if (lhs instanceof int[]) {
/* 306 */       append((int[])lhs, (int[])rhs);
/* 307 */     } else if (lhs instanceof short[]) {
/* 308 */       append((short[])lhs, (short[])rhs);
/* 309 */     } else if (lhs instanceof char[]) {
/* 310 */       append((char[])lhs, (char[])rhs);
/* 311 */     } else if (lhs instanceof byte[]) {
/* 312 */       append((byte[])lhs, (byte[])rhs);
/* 313 */     } else if (lhs instanceof double[]) {
/* 314 */       append((double[])lhs, (double[])rhs);
/* 315 */     } else if (lhs instanceof float[]) {
/* 316 */       append((float[])lhs, (float[])rhs);
/* 317 */     } else if (lhs instanceof boolean[]) {
/* 318 */       append((boolean[])lhs, (boolean[])rhs);
/*     */     } else {
/*     */       
/* 321 */       append((Object[])lhs, (Object[])rhs);
/*     */     } 
/* 323 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(long lhs, long rhs) {
/* 338 */     if (this.isEquals == false) {
/* 339 */       return this;
/*     */     }
/* 341 */     this.isEquals = !(lhs != rhs);
/* 342 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(int lhs, int rhs) {
/* 353 */     if (this.isEquals == false) {
/* 354 */       return this;
/*     */     }
/* 356 */     this.isEquals = !(lhs != rhs);
/* 357 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(short lhs, short rhs) {
/* 368 */     if (this.isEquals == false) {
/* 369 */       return this;
/*     */     }
/* 371 */     this.isEquals = !(lhs != rhs);
/* 372 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(char lhs, char rhs) {
/* 383 */     if (this.isEquals == false) {
/* 384 */       return this;
/*     */     }
/* 386 */     this.isEquals = !(lhs != rhs);
/* 387 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(byte lhs, byte rhs) {
/* 398 */     if (this.isEquals == false) {
/* 399 */       return this;
/*     */     }
/* 401 */     this.isEquals = !(lhs != rhs);
/* 402 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(double lhs, double rhs) {
/* 419 */     if (this.isEquals == false) {
/* 420 */       return this;
/*     */     }
/* 422 */     return append(Double.doubleToLongBits(lhs), Double.doubleToLongBits(rhs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(float lhs, float rhs) {
/* 439 */     if (this.isEquals == false) {
/* 440 */       return this;
/*     */     }
/* 442 */     return append(Float.floatToIntBits(lhs), Float.floatToIntBits(rhs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(boolean lhs, boolean rhs) {
/* 453 */     if (this.isEquals == false) {
/* 454 */       return this;
/*     */     }
/* 456 */     this.isEquals = !(lhs != rhs);
/* 457 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(Object[] lhs, Object[] rhs) {
/* 471 */     if (this.isEquals == false) {
/* 472 */       return this;
/*     */     }
/* 474 */     if (lhs == rhs) {
/* 475 */       return this;
/*     */     }
/* 477 */     if (lhs == null || rhs == null) {
/* 478 */       setEquals(false);
/* 479 */       return this;
/*     */     } 
/* 481 */     if (lhs.length != rhs.length) {
/* 482 */       setEquals(false);
/* 483 */       return this;
/*     */     } 
/* 485 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 486 */       append(lhs[i], rhs[i]);
/*     */     }
/* 488 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(long[] lhs, long[] rhs) {
/* 502 */     if (this.isEquals == false) {
/* 503 */       return this;
/*     */     }
/* 505 */     if (lhs == rhs) {
/* 506 */       return this;
/*     */     }
/* 508 */     if (lhs == null || rhs == null) {
/* 509 */       setEquals(false);
/* 510 */       return this;
/*     */     } 
/* 512 */     if (lhs.length != rhs.length) {
/* 513 */       setEquals(false);
/* 514 */       return this;
/*     */     } 
/* 516 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 517 */       append(lhs[i], rhs[i]);
/*     */     }
/* 519 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(int[] lhs, int[] rhs) {
/* 533 */     if (this.isEquals == false) {
/* 534 */       return this;
/*     */     }
/* 536 */     if (lhs == rhs) {
/* 537 */       return this;
/*     */     }
/* 539 */     if (lhs == null || rhs == null) {
/* 540 */       setEquals(false);
/* 541 */       return this;
/*     */     } 
/* 543 */     if (lhs.length != rhs.length) {
/* 544 */       setEquals(false);
/* 545 */       return this;
/*     */     } 
/* 547 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 548 */       append(lhs[i], rhs[i]);
/*     */     }
/* 550 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(short[] lhs, short[] rhs) {
/* 564 */     if (this.isEquals == false) {
/* 565 */       return this;
/*     */     }
/* 567 */     if (lhs == rhs) {
/* 568 */       return this;
/*     */     }
/* 570 */     if (lhs == null || rhs == null) {
/* 571 */       setEquals(false);
/* 572 */       return this;
/*     */     } 
/* 574 */     if (lhs.length != rhs.length) {
/* 575 */       setEquals(false);
/* 576 */       return this;
/*     */     } 
/* 578 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 579 */       append(lhs[i], rhs[i]);
/*     */     }
/* 581 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(char[] lhs, char[] rhs) {
/* 595 */     if (this.isEquals == false) {
/* 596 */       return this;
/*     */     }
/* 598 */     if (lhs == rhs) {
/* 599 */       return this;
/*     */     }
/* 601 */     if (lhs == null || rhs == null) {
/* 602 */       setEquals(false);
/* 603 */       return this;
/*     */     } 
/* 605 */     if (lhs.length != rhs.length) {
/* 606 */       setEquals(false);
/* 607 */       return this;
/*     */     } 
/* 609 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 610 */       append(lhs[i], rhs[i]);
/*     */     }
/* 612 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(byte[] lhs, byte[] rhs) {
/* 626 */     if (this.isEquals == false) {
/* 627 */       return this;
/*     */     }
/* 629 */     if (lhs == rhs) {
/* 630 */       return this;
/*     */     }
/* 632 */     if (lhs == null || rhs == null) {
/* 633 */       setEquals(false);
/* 634 */       return this;
/*     */     } 
/* 636 */     if (lhs.length != rhs.length) {
/* 637 */       setEquals(false);
/* 638 */       return this;
/*     */     } 
/* 640 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 641 */       append(lhs[i], rhs[i]);
/*     */     }
/* 643 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(double[] lhs, double[] rhs) {
/* 657 */     if (this.isEquals == false) {
/* 658 */       return this;
/*     */     }
/* 660 */     if (lhs == rhs) {
/* 661 */       return this;
/*     */     }
/* 663 */     if (lhs == null || rhs == null) {
/* 664 */       setEquals(false);
/* 665 */       return this;
/*     */     } 
/* 667 */     if (lhs.length != rhs.length) {
/* 668 */       setEquals(false);
/* 669 */       return this;
/*     */     } 
/* 671 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 672 */       append(lhs[i], rhs[i]);
/*     */     }
/* 674 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(float[] lhs, float[] rhs) {
/* 688 */     if (this.isEquals == false) {
/* 689 */       return this;
/*     */     }
/* 691 */     if (lhs == rhs) {
/* 692 */       return this;
/*     */     }
/* 694 */     if (lhs == null || rhs == null) {
/* 695 */       setEquals(false);
/* 696 */       return this;
/*     */     } 
/* 698 */     if (lhs.length != rhs.length) {
/* 699 */       setEquals(false);
/* 700 */       return this;
/*     */     } 
/* 702 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 703 */       append(lhs[i], rhs[i]);
/*     */     }
/* 705 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EqualsBuilder append(boolean[] lhs, boolean[] rhs) {
/* 719 */     if (this.isEquals == false) {
/* 720 */       return this;
/*     */     }
/* 722 */     if (lhs == rhs) {
/* 723 */       return this;
/*     */     }
/* 725 */     if (lhs == null || rhs == null) {
/* 726 */       setEquals(false);
/* 727 */       return this;
/*     */     } 
/* 729 */     if (lhs.length != rhs.length) {
/* 730 */       setEquals(false);
/* 731 */       return this;
/*     */     } 
/* 733 */     for (int i = 0; i < lhs.length && this.isEquals; i++) {
/* 734 */       append(lhs[i], rhs[i]);
/*     */     }
/* 736 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEquals() {
/* 746 */     return this.isEquals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setEquals(boolean isEquals) {
/* 756 */     this.isEquals = isEquals;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\builder\EqualsBuilder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */