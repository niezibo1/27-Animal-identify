/*     */ package org.apache.commons.lang.builder;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Comparator;
/*     */ import org.apache.commons.lang.math.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompareToBuilder
/*     */ {
/* 106 */   private int comparison = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int reflectionCompare(Object lhs, Object rhs) {
/* 137 */     return reflectionCompare(lhs, rhs, false, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int reflectionCompare(Object lhs, Object rhs, boolean compareTransients) {
/* 169 */     return reflectionCompare(lhs, rhs, compareTransients, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int reflectionCompare(Object lhs, Object rhs, boolean compareTransients, Class reflectUpToClass) {
/* 204 */     if (lhs == rhs) {
/* 205 */       return 0;
/*     */     }
/* 207 */     if (lhs == null || rhs == null) {
/* 208 */       throw new NullPointerException();
/*     */     }
/* 210 */     Class lhsClazz = lhs.getClass();
/* 211 */     if (!lhsClazz.isInstance(rhs)) {
/* 212 */       throw new ClassCastException();
/*     */     }
/* 214 */     CompareToBuilder compareToBuilder = new CompareToBuilder();
/* 215 */     reflectionAppend(lhs, rhs, lhsClazz, compareToBuilder, compareTransients);
/* 216 */     while (lhsClazz.getSuperclass() != null && lhsClazz != reflectUpToClass) {
/* 217 */       lhsClazz = lhsClazz.getSuperclass();
/* 218 */       reflectionAppend(lhs, rhs, lhsClazz, compareToBuilder, compareTransients);
/*     */     } 
/* 220 */     return compareToBuilder.toComparison();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void reflectionAppend(Object lhs, Object rhs, Class clazz, CompareToBuilder builder, boolean useTransients) {
/* 240 */     Field[] fields = clazz.getDeclaredFields();
/* 241 */     AccessibleObject.setAccessible((AccessibleObject[])fields, true);
/* 242 */     for (int i = 0; i < fields.length && builder.comparison == 0; i++) {
/* 243 */       Field f = fields[i];
/* 244 */       if (f.getName().indexOf('$') == -1 && (
/* 245 */         useTransients || !Modifier.isTransient(f.getModifiers())) && 
/* 246 */         !Modifier.isStatic(f.getModifiers())) {
/*     */         try {
/* 248 */           builder.append(f.get(lhs), f.get(rhs));
/* 249 */         } catch (IllegalAccessException illegalAccessException) {
/*     */ 
/*     */           
/* 252 */           throw new InternalError("Unexpected IllegalAccessException");
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder appendSuper(int superCompareTo) {
/* 268 */     if (this.comparison != 0) {
/* 269 */       return this;
/*     */     }
/* 271 */     this.comparison = superCompareTo;
/* 272 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(Object lhs, Object rhs) {
/* 296 */     return append(lhs, rhs, (Comparator)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(Object lhs, Object rhs, Comparator comparator) {
/* 325 */     if (this.comparison != 0) {
/* 326 */       return this;
/*     */     }
/* 328 */     if (lhs == rhs) {
/* 329 */       return this;
/*     */     }
/* 331 */     if (lhs == null) {
/* 332 */       this.comparison = -1;
/* 333 */       return this;
/*     */     } 
/* 335 */     if (rhs == null) {
/* 336 */       this.comparison = 1;
/* 337 */       return this;
/*     */     } 
/* 339 */     if (lhs.getClass().isArray()) {
/*     */ 
/*     */ 
/*     */       
/* 343 */       if (lhs instanceof long[]) {
/* 344 */         append((long[])lhs, (long[])rhs);
/* 345 */       } else if (lhs instanceof int[]) {
/* 346 */         append((int[])lhs, (int[])rhs);
/* 347 */       } else if (lhs instanceof short[]) {
/* 348 */         append((short[])lhs, (short[])rhs);
/* 349 */       } else if (lhs instanceof char[]) {
/* 350 */         append((char[])lhs, (char[])rhs);
/* 351 */       } else if (lhs instanceof byte[]) {
/* 352 */         append((byte[])lhs, (byte[])rhs);
/* 353 */       } else if (lhs instanceof double[]) {
/* 354 */         append((double[])lhs, (double[])rhs);
/* 355 */       } else if (lhs instanceof float[]) {
/* 356 */         append((float[])lhs, (float[])rhs);
/* 357 */       } else if (lhs instanceof boolean[]) {
/* 358 */         append((boolean[])lhs, (boolean[])rhs);
/*     */       }
/*     */       else {
/*     */         
/* 362 */         append((Object[])lhs, (Object[])rhs, comparator);
/*     */       }
/*     */     
/*     */     }
/* 366 */     else if (comparator == null) {
/* 367 */       this.comparison = ((Comparable)lhs).compareTo(rhs);
/*     */     } else {
/* 369 */       this.comparison = comparator.compare(lhs, rhs);
/*     */     } 
/*     */     
/* 372 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(long lhs, long rhs) {
/* 385 */     if (this.comparison != 0) {
/* 386 */       return this;
/*     */     }
/* 388 */     this.comparison = (lhs < rhs) ? -1 : ((lhs > rhs) ? 1 : 0);
/* 389 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(int lhs, int rhs) {
/* 401 */     if (this.comparison != 0) {
/* 402 */       return this;
/*     */     }
/* 404 */     this.comparison = (lhs < rhs) ? -1 : ((lhs > rhs) ? 1 : 0);
/* 405 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(short lhs, short rhs) {
/* 417 */     if (this.comparison != 0) {
/* 418 */       return this;
/*     */     }
/* 420 */     this.comparison = (lhs < rhs) ? -1 : ((lhs > rhs) ? 1 : 0);
/* 421 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(char lhs, char rhs) {
/* 433 */     if (this.comparison != 0) {
/* 434 */       return this;
/*     */     }
/* 436 */     this.comparison = (lhs < rhs) ? -1 : ((lhs > rhs) ? 1 : 0);
/* 437 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(byte lhs, byte rhs) {
/* 449 */     if (this.comparison != 0) {
/* 450 */       return this;
/*     */     }
/* 452 */     this.comparison = (lhs < rhs) ? -1 : ((lhs > rhs) ? 1 : 0);
/* 453 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(double lhs, double rhs) {
/* 470 */     if (this.comparison != 0) {
/* 471 */       return this;
/*     */     }
/* 473 */     this.comparison = NumberUtils.compare(lhs, rhs);
/* 474 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(float lhs, float rhs) {
/* 491 */     if (this.comparison != 0) {
/* 492 */       return this;
/*     */     }
/* 494 */     this.comparison = NumberUtils.compare(lhs, rhs);
/* 495 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(boolean lhs, boolean rhs) {
/* 507 */     if (this.comparison != 0) {
/* 508 */       return this;
/*     */     }
/* 510 */     if (lhs == rhs) {
/* 511 */       return this;
/*     */     }
/* 513 */     if (lhs == false) {
/* 514 */       this.comparison = -1;
/*     */     } else {
/* 516 */       this.comparison = 1;
/*     */     } 
/* 518 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(Object[] lhs, Object[] rhs) {
/* 543 */     return append(lhs, rhs, (Comparator)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(Object[] lhs, Object[] rhs, Comparator comparator) {
/* 570 */     if (this.comparison != 0) {
/* 571 */       return this;
/*     */     }
/* 573 */     if (lhs == rhs) {
/* 574 */       return this;
/*     */     }
/* 576 */     if (lhs == null) {
/* 577 */       this.comparison = -1;
/* 578 */       return this;
/*     */     } 
/* 580 */     if (rhs == null) {
/* 581 */       this.comparison = 1;
/* 582 */       return this;
/*     */     } 
/* 584 */     if (lhs.length != rhs.length) {
/* 585 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 586 */       return this;
/*     */     } 
/* 588 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 589 */       append(lhs[i], rhs[i], comparator);
/*     */     }
/* 591 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(long[] lhs, long[] rhs) {
/* 610 */     if (this.comparison != 0) {
/* 611 */       return this;
/*     */     }
/* 613 */     if (lhs == rhs) {
/* 614 */       return this;
/*     */     }
/* 616 */     if (lhs == null) {
/* 617 */       this.comparison = -1;
/* 618 */       return this;
/*     */     } 
/* 620 */     if (rhs == null) {
/* 621 */       this.comparison = 1;
/* 622 */       return this;
/*     */     } 
/* 624 */     if (lhs.length != rhs.length) {
/* 625 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 626 */       return this;
/*     */     } 
/* 628 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 629 */       append(lhs[i], rhs[i]);
/*     */     }
/* 631 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(int[] lhs, int[] rhs) {
/* 650 */     if (this.comparison != 0) {
/* 651 */       return this;
/*     */     }
/* 653 */     if (lhs == rhs) {
/* 654 */       return this;
/*     */     }
/* 656 */     if (lhs == null) {
/* 657 */       this.comparison = -1;
/* 658 */       return this;
/*     */     } 
/* 660 */     if (rhs == null) {
/* 661 */       this.comparison = 1;
/* 662 */       return this;
/*     */     } 
/* 664 */     if (lhs.length != rhs.length) {
/* 665 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 666 */       return this;
/*     */     } 
/* 668 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 669 */       append(lhs[i], rhs[i]);
/*     */     }
/* 671 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(short[] lhs, short[] rhs) {
/* 690 */     if (this.comparison != 0) {
/* 691 */       return this;
/*     */     }
/* 693 */     if (lhs == rhs) {
/* 694 */       return this;
/*     */     }
/* 696 */     if (lhs == null) {
/* 697 */       this.comparison = -1;
/* 698 */       return this;
/*     */     } 
/* 700 */     if (rhs == null) {
/* 701 */       this.comparison = 1;
/* 702 */       return this;
/*     */     } 
/* 704 */     if (lhs.length != rhs.length) {
/* 705 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 706 */       return this;
/*     */     } 
/* 708 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 709 */       append(lhs[i], rhs[i]);
/*     */     }
/* 711 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(char[] lhs, char[] rhs) {
/* 730 */     if (this.comparison != 0) {
/* 731 */       return this;
/*     */     }
/* 733 */     if (lhs == rhs) {
/* 734 */       return this;
/*     */     }
/* 736 */     if (lhs == null) {
/* 737 */       this.comparison = -1;
/* 738 */       return this;
/*     */     } 
/* 740 */     if (rhs == null) {
/* 741 */       this.comparison = 1;
/* 742 */       return this;
/*     */     } 
/* 744 */     if (lhs.length != rhs.length) {
/* 745 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 746 */       return this;
/*     */     } 
/* 748 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 749 */       append(lhs[i], rhs[i]);
/*     */     }
/* 751 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(byte[] lhs, byte[] rhs) {
/* 770 */     if (this.comparison != 0) {
/* 771 */       return this;
/*     */     }
/* 773 */     if (lhs == rhs) {
/* 774 */       return this;
/*     */     }
/* 776 */     if (lhs == null) {
/* 777 */       this.comparison = -1;
/* 778 */       return this;
/*     */     } 
/* 780 */     if (rhs == null) {
/* 781 */       this.comparison = 1;
/* 782 */       return this;
/*     */     } 
/* 784 */     if (lhs.length != rhs.length) {
/* 785 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 786 */       return this;
/*     */     } 
/* 788 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 789 */       append(lhs[i], rhs[i]);
/*     */     }
/* 791 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(double[] lhs, double[] rhs) {
/* 810 */     if (this.comparison != 0) {
/* 811 */       return this;
/*     */     }
/* 813 */     if (lhs == rhs) {
/* 814 */       return this;
/*     */     }
/* 816 */     if (lhs == null) {
/* 817 */       this.comparison = -1;
/* 818 */       return this;
/*     */     } 
/* 820 */     if (rhs == null) {
/* 821 */       this.comparison = 1;
/* 822 */       return this;
/*     */     } 
/* 824 */     if (lhs.length != rhs.length) {
/* 825 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 826 */       return this;
/*     */     } 
/* 828 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 829 */       append(lhs[i], rhs[i]);
/*     */     }
/* 831 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(float[] lhs, float[] rhs) {
/* 850 */     if (this.comparison != 0) {
/* 851 */       return this;
/*     */     }
/* 853 */     if (lhs == rhs) {
/* 854 */       return this;
/*     */     }
/* 856 */     if (lhs == null) {
/* 857 */       this.comparison = -1;
/* 858 */       return this;
/*     */     } 
/* 860 */     if (rhs == null) {
/* 861 */       this.comparison = 1;
/* 862 */       return this;
/*     */     } 
/* 864 */     if (lhs.length != rhs.length) {
/* 865 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 866 */       return this;
/*     */     } 
/* 868 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 869 */       append(lhs[i], rhs[i]);
/*     */     }
/* 871 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompareToBuilder append(boolean[] lhs, boolean[] rhs) {
/* 890 */     if (this.comparison != 0) {
/* 891 */       return this;
/*     */     }
/* 893 */     if (lhs == rhs) {
/* 894 */       return this;
/*     */     }
/* 896 */     if (lhs == null) {
/* 897 */       this.comparison = -1;
/* 898 */       return this;
/*     */     } 
/* 900 */     if (rhs == null) {
/* 901 */       this.comparison = 1;
/* 902 */       return this;
/*     */     } 
/* 904 */     if (lhs.length != rhs.length) {
/* 905 */       this.comparison = (lhs.length < rhs.length) ? -1 : 1;
/* 906 */       return this;
/*     */     } 
/* 908 */     for (int i = 0; i < lhs.length && this.comparison == 0; i++) {
/* 909 */       append(lhs[i], rhs[i]);
/*     */     }
/* 911 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toComparison() {
/* 924 */     return this.comparison;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\builder\CompareToBuilder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */