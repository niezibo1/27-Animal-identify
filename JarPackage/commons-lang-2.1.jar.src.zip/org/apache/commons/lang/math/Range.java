/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Range
/*     */ {
/*     */   public long getMinimumLong() {
/*  57 */     return getMinimumNumber().longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinimumInteger() {
/*  69 */     return getMinimumNumber().intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMinimumDouble() {
/*  81 */     return getMinimumNumber().doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMinimumFloat() {
/*  93 */     return getMinimumNumber().floatValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaximumLong() {
/* 112 */     return getMaximumNumber().longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumInteger() {
/* 124 */     return getMaximumNumber().intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMaximumDouble() {
/* 136 */     return getMaximumNumber().doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaximumFloat() {
/* 148 */     return getMaximumNumber().floatValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsLong(Number value) {
/* 183 */     if (value == null) {
/* 184 */       return false;
/*     */     }
/* 186 */     return containsLong(value.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsLong(long value) {
/* 201 */     return !(value < getMinimumLong() || value > getMaximumLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsInteger(Number value) {
/* 217 */     if (value == null) {
/* 218 */       return false;
/*     */     }
/* 220 */     return containsInteger(value.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsInteger(int value) {
/* 235 */     return !(value < getMinimumInteger() || value > getMaximumInteger());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsDouble(Number value) {
/* 251 */     if (value == null) {
/* 252 */       return false;
/*     */     }
/* 254 */     return containsDouble(value.doubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsDouble(double value) {
/* 269 */     int compareMin = NumberUtils.compare(getMinimumDouble(), value);
/* 270 */     int compareMax = NumberUtils.compare(getMaximumDouble(), value);
/* 271 */     return !(compareMin > 0 || compareMax < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsFloat(Number value) {
/* 287 */     if (value == null) {
/* 288 */       return false;
/*     */     }
/* 290 */     return containsFloat(value.floatValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsFloat(float value) {
/* 305 */     int compareMin = NumberUtils.compare(getMinimumFloat(), value);
/* 306 */     int compareMax = NumberUtils.compare(getMaximumFloat(), value);
/* 307 */     return !(compareMin > 0 || compareMax < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsRange(Range range) {
/* 331 */     if (range == null) {
/* 332 */       return false;
/*     */     }
/* 334 */     return !(!containsNumber(range.getMinimumNumber()) || 
/* 335 */       !containsNumber(range.getMaximumNumber()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overlapsRange(Range range) {
/* 357 */     if (range == null) {
/* 358 */       return false;
/*     */     }
/* 360 */     return !(!range.containsNumber(getMinimumNumber()) && 
/* 361 */       !range.containsNumber(getMaximumNumber()) && 
/* 362 */       !containsNumber(range.getMinimumNumber()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 381 */     if (obj == this)
/* 382 */       return true; 
/* 383 */     if (obj == null || obj.getClass() != getClass()) {
/* 384 */       return false;
/*     */     }
/* 386 */     Range range = (Range)obj;
/* 387 */     return !(!getMinimumNumber().equals(range.getMinimumNumber()) || 
/* 388 */       !getMaximumNumber().equals(range.getMaximumNumber()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 402 */     int result = 17;
/* 403 */     result = 37 * result + getClass().hashCode();
/* 404 */     result = 37 * result + getMinimumNumber().hashCode();
/* 405 */     result = 37 * result + getMaximumNumber().hashCode();
/* 406 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 421 */     StringBuffer buf = new StringBuffer(32);
/* 422 */     buf.append("Range[");
/* 423 */     buf.append(getMinimumNumber());
/* 424 */     buf.append(',');
/* 425 */     buf.append(getMaximumNumber());
/* 426 */     buf.append(']');
/* 427 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public abstract boolean containsNumber(Number paramNumber);
/*     */   
/*     */   public abstract Number getMaximumNumber();
/*     */   
/*     */   public abstract Number getMinimumNumber();
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\math\Range.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */