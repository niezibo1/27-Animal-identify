/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberRange
/*     */   extends Range
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 71849363892710L;
/*     */   private final Number min;
/*     */   private final Number max;
/*  45 */   private transient int hashCode = 0;
/*     */ 
/*     */ 
/*     */   
/*  49 */   private transient String toString = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberRange(Number num) {
/*  61 */     if (num == null) {
/*  62 */       throw new IllegalArgumentException("The number must not be null");
/*     */     }
/*  64 */     if (num instanceof Comparable == false) {
/*  65 */       throw new IllegalArgumentException("The number must implement Comparable");
/*     */     }
/*  67 */     if (num instanceof Double && ((Double)num).isNaN()) {
/*  68 */       throw new IllegalArgumentException("The number must not be NaN");
/*     */     }
/*  70 */     if (num instanceof Float && ((Float)num).isNaN()) {
/*  71 */       throw new IllegalArgumentException("The number must not be NaN");
/*     */     }
/*     */     
/*  74 */     this.min = num;
/*  75 */     this.max = num;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberRange(Number num1, Number num2) {
/*  97 */     if (num1 == null || num2 == null) {
/*  98 */       throw new IllegalArgumentException("The numbers must not be null");
/*     */     }
/* 100 */     if (num1.getClass() != num2.getClass()) {
/* 101 */       throw new IllegalArgumentException("The numbers must be of the same type");
/*     */     }
/* 103 */     if (num1 instanceof Comparable == false) {
/* 104 */       throw new IllegalArgumentException("The numbers must implement Comparable");
/*     */     }
/* 106 */     if (num1 instanceof Double) {
/* 107 */       if (((Double)num1).isNaN() || ((Double)num2).isNaN()) {
/* 108 */         throw new IllegalArgumentException("The number must not be NaN");
/*     */       }
/* 110 */     } else if (num1 instanceof Float && ((
/* 111 */       (Float)num1).isNaN() || ((Float)num2).isNaN())) {
/* 112 */       throw new IllegalArgumentException("The number must not be NaN");
/*     */     } 
/*     */ 
/*     */     
/* 116 */     int compare = ((Comparable)num1).compareTo(num2);
/* 117 */     if (compare == 0) {
/* 118 */       this.min = num1;
/* 119 */       this.max = num1;
/* 120 */     } else if (compare > 0) {
/* 121 */       this.min = num2;
/* 122 */       this.max = num1;
/*     */     } else {
/* 124 */       this.min = num1;
/* 125 */       this.max = num2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMinimumNumber() {
/* 138 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMaximumNumber() {
/* 147 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsNumber(Number number) {
/* 164 */     if (number == null) {
/* 165 */       return false;
/*     */     }
/* 167 */     if (number.getClass() != this.min.getClass()) {
/* 168 */       throw new IllegalArgumentException("The number must be of the same type as the range numbers");
/*     */     }
/* 170 */     int compareMin = ((Comparable)this.min).compareTo(number);
/* 171 */     int compareMax = ((Comparable)this.max).compareTo(number);
/* 172 */     return !(compareMin > 0 || compareMax < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 191 */     if (obj == this) {
/* 192 */       return true;
/*     */     }
/* 194 */     if (obj instanceof NumberRange == false) {
/* 195 */       return false;
/*     */     }
/* 197 */     NumberRange range = (NumberRange)obj;
/* 198 */     return !(!this.min.equals(range.min) || !this.max.equals(range.max));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 207 */     if (this.hashCode == 0) {
/* 208 */       this.hashCode = 17;
/* 209 */       this.hashCode = 37 * this.hashCode + getClass().hashCode();
/* 210 */       this.hashCode = 37 * this.hashCode + this.min.hashCode();
/* 211 */       this.hashCode = 37 * this.hashCode + this.max.hashCode();
/*     */     } 
/* 213 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 224 */     if (this.toString == null) {
/* 225 */       StringBuffer buf = new StringBuffer(32);
/* 226 */       buf.append("Range[");
/* 227 */       buf.append(this.min);
/* 228 */       buf.append(',');
/* 229 */       buf.append(this.max);
/* 230 */       buf.append(']');
/* 231 */       this.toString = buf.toString();
/*     */     } 
/* 233 */     return this.toString;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\math\NumberRange.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */