/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DoubleRange
/*     */   extends Range
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 71849363892740L;
/*     */   private final double min;
/*     */   private final double max;
/*  43 */   private transient Double minObject = null;
/*     */ 
/*     */ 
/*     */   
/*  47 */   private transient Double maxObject = null;
/*     */ 
/*     */ 
/*     */   
/*  51 */   private transient int hashCode = 0;
/*     */ 
/*     */ 
/*     */   
/*  55 */   private transient String toString = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DoubleRange(double number) {
/*  66 */     if (Double.isNaN(number)) {
/*  67 */       throw new IllegalArgumentException("The number must not be NaN");
/*     */     }
/*  69 */     this.min = number;
/*  70 */     this.max = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DoubleRange(Number number) {
/*  84 */     if (number == null) {
/*  85 */       throw new IllegalArgumentException("The number must not be null");
/*     */     }
/*  87 */     this.min = number.doubleValue();
/*  88 */     this.max = number.doubleValue();
/*  89 */     if (Double.isNaN(this.min) || Double.isNaN(this.max)) {
/*  90 */       throw new IllegalArgumentException("The number must not be NaN");
/*     */     }
/*  92 */     if (number instanceof Double) {
/*  93 */       this.minObject = (Double)number;
/*  94 */       this.maxObject = (Double)number;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DoubleRange(double number1, double number2) {
/* 111 */     if (Double.isNaN(number1) || Double.isNaN(number2)) {
/* 112 */       throw new IllegalArgumentException("The numbers must not be NaN");
/*     */     }
/* 114 */     if (number2 < number1) {
/* 115 */       this.min = number2;
/* 116 */       this.max = number1;
/*     */     } else {
/* 118 */       this.min = number1;
/* 119 */       this.max = number2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DoubleRange(Number number1, Number number2) {
/* 137 */     if (number1 == null || number2 == null) {
/* 138 */       throw new IllegalArgumentException("The numbers must not be null");
/*     */     }
/* 140 */     double number1val = number1.doubleValue();
/* 141 */     double number2val = number2.doubleValue();
/* 142 */     if (Double.isNaN(number1val) || Double.isNaN(number2val)) {
/* 143 */       throw new IllegalArgumentException("The numbers must not be NaN");
/*     */     }
/* 145 */     if (number2val < number1val) {
/* 146 */       this.min = number2val;
/* 147 */       this.max = number1val;
/* 148 */       if (number2 instanceof Double) {
/* 149 */         this.minObject = (Double)number2;
/*     */       }
/* 151 */       if (number1 instanceof Double) {
/* 152 */         this.maxObject = (Double)number1;
/*     */       }
/*     */     } else {
/* 155 */       this.min = number1val;
/* 156 */       this.max = number2val;
/* 157 */       if (number1 instanceof Double) {
/* 158 */         this.minObject = (Double)number1;
/*     */       }
/* 160 */       if (number2 instanceof Double) {
/* 161 */         this.maxObject = (Double)number2;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMinimumNumber() {
/* 175 */     if (this.minObject == null) {
/* 176 */       this.minObject = new Double(this.min);
/*     */     }
/* 178 */     return this.minObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMinimumLong() {
/* 189 */     return (long)this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinimumInteger() {
/* 200 */     return (int)this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMinimumDouble() {
/* 209 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMinimumFloat() {
/* 220 */     return (float)this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMaximumNumber() {
/* 229 */     if (this.maxObject == null) {
/* 230 */       this.maxObject = new Double(this.max);
/*     */     }
/* 232 */     return this.maxObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaximumLong() {
/* 243 */     return (long)this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumInteger() {
/* 254 */     return (int)this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMaximumDouble() {
/* 263 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaximumFloat() {
/* 274 */     return (float)this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsNumber(Number number) {
/* 290 */     if (number == null) {
/* 291 */       return false;
/*     */     }
/* 293 */     return containsDouble(number.doubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsDouble(double value) {
/* 308 */     return !(value < this.min || value > this.max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsRange(Range range) {
/* 325 */     if (range == null) {
/* 326 */       return false;
/*     */     }
/* 328 */     return !(!containsDouble(range.getMinimumDouble()) || 
/* 329 */       !containsDouble(range.getMaximumDouble()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overlapsRange(Range range) {
/* 342 */     if (range == null) {
/* 343 */       return false;
/*     */     }
/* 345 */     return !(!range.containsDouble(this.min) && 
/* 346 */       !range.containsDouble(this.max) && 
/* 347 */       !containsDouble(range.getMinimumDouble()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 362 */     if (obj == this) {
/* 363 */       return true;
/*     */     }
/* 365 */     if (obj instanceof DoubleRange == false) {
/* 366 */       return false;
/*     */     }
/* 368 */     DoubleRange range = (DoubleRange)obj;
/* 369 */     return !(Double.doubleToLongBits(this.min) != Double.doubleToLongBits(range.min) || 
/* 370 */       Double.doubleToLongBits(this.max) != Double.doubleToLongBits(range.max));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 379 */     if (this.hashCode == 0) {
/* 380 */       this.hashCode = 17;
/* 381 */       this.hashCode = 37 * this.hashCode + getClass().hashCode();
/* 382 */       long lng = Double.doubleToLongBits(this.min);
/* 383 */       this.hashCode = 37 * this.hashCode + (int)(lng ^ lng >> 32L);
/* 384 */       lng = Double.doubleToLongBits(this.max);
/* 385 */       this.hashCode = 37 * this.hashCode + (int)(lng ^ lng >> 32L);
/*     */     } 
/* 387 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 398 */     if (this.toString == null) {
/* 399 */       StringBuffer buf = new StringBuffer(32);
/* 400 */       buf.append("Range[");
/* 401 */       buf.append(this.min);
/* 402 */       buf.append(',');
/* 403 */       buf.append(this.max);
/* 404 */       buf.append(']');
/* 405 */       this.toString = buf.toString();
/*     */     } 
/* 407 */     return this.toString;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\math\DoubleRange.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */