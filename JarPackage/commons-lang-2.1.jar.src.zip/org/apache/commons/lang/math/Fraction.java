/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Fraction
/*     */   extends Number
/*     */   implements Serializable, Comparable
/*     */ {
/*     */   private static final long serialVersionUID = 65382027393090L;
/*  44 */   public static final Fraction ZERO = new Fraction(0, 1);
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final Fraction ONE = new Fraction(1, 1);
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final Fraction ONE_HALF = new Fraction(1, 2);
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final Fraction ONE_THIRD = new Fraction(1, 3);
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final Fraction TWO_THIRDS = new Fraction(2, 3);
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final Fraction ONE_QUARTER = new Fraction(1, 4);
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static final Fraction TWO_QUARTERS = new Fraction(2, 4);
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final Fraction THREE_QUARTERS = new Fraction(3, 4);
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static final Fraction ONE_FIFTH = new Fraction(1, 5);
/*     */ 
/*     */ 
/*     */   
/*  80 */   public static final Fraction TWO_FIFTHS = new Fraction(2, 5);
/*     */ 
/*     */ 
/*     */   
/*  84 */   public static final Fraction THREE_FIFTHS = new Fraction(3, 5);
/*     */ 
/*     */ 
/*     */   
/*  88 */   public static final Fraction FOUR_FIFTHS = new Fraction(4, 5);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int numerator;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int denominator;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   private transient int hashCode = 0;
/*     */ 
/*     */ 
/*     */   
/* 107 */   private transient String toString = null;
/*     */ 
/*     */ 
/*     */   
/* 111 */   private transient String toProperString = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Fraction(int numerator, int denominator) {
/* 122 */     this.numerator = numerator;
/* 123 */     this.denominator = denominator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fraction getFraction(int numerator, int denominator) {
/* 138 */     if (denominator == 0) {
/* 139 */       throw new ArithmeticException("The denominator must not be zero");
/*     */     }
/* 141 */     if (denominator < 0) {
/* 142 */       if (numerator == Integer.MIN_VALUE || 
/* 143 */         denominator == Integer.MIN_VALUE) {
/* 144 */         throw new ArithmeticException("overflow: can't negate");
/*     */       }
/* 146 */       numerator = -numerator;
/* 147 */       denominator = -denominator;
/*     */     } 
/* 149 */     return new Fraction(numerator, denominator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fraction getFraction(int whole, int numerator, int denominator) {
/*     */     long numeratorValue;
/* 169 */     if (denominator == 0) {
/* 170 */       throw new ArithmeticException("The denominator must not be zero");
/*     */     }
/* 172 */     if (denominator < 0) {
/* 173 */       throw new ArithmeticException("The denominator must not be negative");
/*     */     }
/* 175 */     if (numerator < 0) {
/* 176 */       throw new ArithmeticException("The numerator must not be negative");
/*     */     }
/*     */     
/* 179 */     if (whole < 0) {
/* 180 */       numeratorValue = whole * denominator - numerator;
/*     */     } else {
/* 182 */       numeratorValue = whole * denominator + numerator;
/*     */     } 
/* 184 */     if (numeratorValue < -2147483648L || 
/* 185 */       numeratorValue > 2147483647L) {
/* 186 */       throw new ArithmeticException("Numerator too large to represent as an Integer.");
/*     */     }
/* 188 */     return new Fraction((int)numeratorValue, denominator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fraction getReducedFraction(int numerator, int denominator) {
/* 203 */     if (denominator == 0) {
/* 204 */       throw new ArithmeticException("The denominator must not be zero");
/*     */     }
/* 206 */     if (numerator == 0) {
/* 207 */       return ZERO;
/*     */     }
/*     */     
/* 210 */     if (denominator == Integer.MIN_VALUE && (numerator & 0x1) == 0) {
/* 211 */       numerator /= 2; denominator /= 2;
/*     */     } 
/* 213 */     if (denominator < 0) {
/* 214 */       if (numerator == Integer.MIN_VALUE || 
/* 215 */         denominator == Integer.MIN_VALUE) {
/* 216 */         throw new ArithmeticException("overflow: can't negate");
/*     */       }
/* 218 */       numerator = -numerator;
/* 219 */       denominator = -denominator;
/*     */     } 
/*     */     
/* 222 */     int gcd = greatestCommonDivisor(numerator, denominator);
/* 223 */     numerator /= gcd;
/* 224 */     denominator /= gcd;
/* 225 */     return new Fraction(numerator, denominator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fraction getFraction(double value) {
/*     */     double delta1;
/* 243 */     int sign = (value < 0.0D) ? -1 : 1;
/* 244 */     value = Math.abs(value);
/* 245 */     if (value > 2.147483647E9D || Double.isNaN(value)) {
/* 246 */       throw new ArithmeticException(
/* 247 */           "The value must not be greater than Integer.MAX_VALUE or NaN");
/*     */     }
/* 249 */     int wholeNumber = (int)value;
/* 250 */     value -= wholeNumber;
/*     */     
/* 252 */     int numer0 = 0;
/* 253 */     int denom0 = 1;
/* 254 */     int numer1 = 1;
/* 255 */     int denom1 = 0;
/* 256 */     int numer2 = 0;
/* 257 */     int denom2 = 0;
/* 258 */     int a1 = (int)value;
/* 259 */     int a2 = 0;
/* 260 */     double x1 = 1.0D;
/* 261 */     double x2 = 0.0D;
/* 262 */     double y1 = value - a1;
/* 263 */     double y2 = 0.0D;
/* 264 */     double delta2 = Double.MAX_VALUE;
/*     */     
/* 266 */     int i = 1;
/*     */     
/*     */     do {
/* 269 */       delta1 = delta2;
/* 270 */       a2 = (int)(x1 / y1);
/* 271 */       x2 = y1;
/* 272 */       y2 = x1 - a2 * y1;
/* 273 */       numer2 = a1 * numer1 + numer0;
/* 274 */       denom2 = a1 * denom1 + denom0;
/* 275 */       double fraction = numer2 / denom2;
/* 276 */       delta2 = Math.abs(value - fraction);
/*     */       
/* 278 */       a1 = a2;
/* 279 */       x1 = x2;
/* 280 */       y1 = y2;
/* 281 */       numer0 = numer1;
/* 282 */       denom0 = denom1;
/* 283 */       numer1 = numer2;
/* 284 */       denom1 = denom2;
/* 285 */       i++;
/*     */     }
/* 287 */     while (delta1 > delta2 && denom2 <= 10000 && denom2 > 0 && i < 25);
/* 288 */     if (i == 25) {
/* 289 */       throw new ArithmeticException("Unable to convert double to fraction");
/*     */     }
/* 291 */     return getReducedFraction((numer0 + wholeNumber * denom0) * sign, denom0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Fraction getFraction(String str) {
/* 313 */     if (str == null) {
/* 314 */       throw new IllegalArgumentException("The string must not be null");
/*     */     }
/*     */     
/* 317 */     int pos = str.indexOf('.');
/* 318 */     if (pos >= 0) {
/* 319 */       return getFraction(Double.parseDouble(str));
/*     */     }
/*     */ 
/*     */     
/* 323 */     pos = str.indexOf(' ');
/* 324 */     if (pos > 0) {
/* 325 */       int whole = Integer.parseInt(str.substring(0, pos));
/* 326 */       str = str.substring(pos + 1);
/* 327 */       pos = str.indexOf('/');
/* 328 */       if (pos < 0) {
/* 329 */         throw new NumberFormatException("The fraction could not be parsed as the format X Y/Z");
/*     */       }
/* 331 */       int i = Integer.parseInt(str.substring(0, pos));
/* 332 */       int j = Integer.parseInt(str.substring(pos + 1));
/* 333 */       return getFraction(whole, i, j);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 338 */     pos = str.indexOf('/');
/* 339 */     if (pos < 0)
/*     */     {
/* 341 */       return getFraction(Integer.parseInt(str), 1);
/*     */     }
/* 343 */     int numer = Integer.parseInt(str.substring(0, pos));
/* 344 */     int denom = Integer.parseInt(str.substring(pos + 1));
/* 345 */     return getFraction(numer, denom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumerator() {
/* 361 */     return this.numerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDenominator() {
/* 370 */     return this.denominator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getProperNumerator() {
/* 385 */     return Math.abs(this.numerator % this.denominator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getProperWhole() {
/* 400 */     return this.numerator / this.denominator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int intValue() {
/* 413 */     return this.numerator / this.denominator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long longValue() {
/* 423 */     return this.numerator / this.denominator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float floatValue() {
/* 433 */     return this.numerator / this.denominator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double doubleValue() {
/* 443 */     return this.numerator / this.denominator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction reduce() {
/* 456 */     int gcd = greatestCommonDivisor(Math.abs(this.numerator), this.denominator);
/* 457 */     return getFraction(this.numerator / gcd, this.denominator / gcd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction invert() {
/* 470 */     if (this.numerator == 0) {
/* 471 */       throw new ArithmeticException("Unable to invert zero.");
/*     */     }
/* 473 */     if (this.numerator == Integer.MIN_VALUE) {
/* 474 */       throw new ArithmeticException("overflow: can't negate numerator");
/*     */     }
/* 476 */     if (this.numerator < 0) {
/* 477 */       return new Fraction(-this.denominator, -this.numerator);
/*     */     }
/* 479 */     return new Fraction(this.denominator, this.numerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction negate() {
/* 492 */     if (this.numerator == Integer.MIN_VALUE) {
/* 493 */       throw new ArithmeticException("overflow: too large to negate");
/*     */     }
/* 495 */     return new Fraction(-this.numerator, this.denominator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction abs() {
/* 508 */     if (this.numerator >= 0) {
/* 509 */       return this;
/*     */     }
/* 511 */     return negate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction pow(int power) {
/* 527 */     if (power == 1)
/* 528 */       return this; 
/* 529 */     if (power == 0)
/* 530 */       return ONE; 
/* 531 */     if (power < 0) {
/* 532 */       if (power == Integer.MIN_VALUE) {
/* 533 */         return invert().pow(2).pow(-(power / 2));
/*     */       }
/* 535 */       return invert().pow(-power);
/*     */     } 
/* 537 */     Fraction f = multiplyBy(this);
/* 538 */     if (power % 2 == 0) {
/* 539 */       return f.pow(power / 2);
/*     */     }
/* 541 */     return f.pow(power / 2).multiplyBy(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int greatestCommonDivisor(int u, int v) {
/* 562 */     if (u > 0) u = -u; 
/* 563 */     if (v > 0) v = -v;
/*     */     
/* 565 */     int k = 0;
/* 566 */     while ((u & 0x1) == 0 && (v & 0x1) == 0 && k < 31) {
/* 567 */       u /= 2; v /= 2; k++;
/*     */     } 
/* 569 */     if (k == 31) {
/* 570 */       throw new ArithmeticException("overflow: gcd is 2^31");
/*     */     }
/*     */ 
/*     */     
/* 574 */     int t = ((u & 0x1) == 1) ? v : -(u / 2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 580 */       while ((t & 0x1) != 0) {
/*     */ 
/*     */ 
/*     */         
/* 584 */         if (t > 0) {
/* 585 */           u = -t;
/*     */         } else {
/* 587 */           v = t;
/*     */         } 
/*     */         
/* 590 */         t = (v - u) / 2;
/*     */ 
/*     */         
/* 593 */         if (t == 0) {
/* 594 */           return -u * (1 << k);
/*     */         }
/*     */       } 
/*     */       t /= 2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int mulAndCheck(int x, int y) {
/* 610 */     long m = x * y;
/* 611 */     if (m < -2147483648L || 
/* 612 */       m > 2147483647L) {
/* 613 */       throw new ArithmeticException("overflow: mul");
/*     */     }
/* 615 */     return (int)m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int mulPosAndCheck(int x, int y) {
/* 629 */     long m = x * y;
/* 630 */     if (m > 2147483647L) {
/* 631 */       throw new ArithmeticException("overflow: mulPos");
/*     */     }
/* 633 */     return (int)m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int addAndCheck(int x, int y) {
/* 646 */     long s = x + y;
/* 647 */     if (s < -2147483648L || 
/* 648 */       s > 2147483647L) {
/* 649 */       throw new ArithmeticException("overflow: add");
/*     */     }
/* 651 */     return (int)s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int subAndCheck(int x, int y) {
/* 664 */     long s = x - y;
/* 665 */     if (s < -2147483648L || 
/* 666 */       s > 2147483647L) {
/* 667 */       throw new ArithmeticException("overflow: add");
/*     */     }
/* 669 */     return (int)s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction add(Fraction fraction) {
/* 683 */     return addSub(fraction, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction subtract(Fraction fraction) {
/* 697 */     return addSub(fraction, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Fraction addSub(Fraction fraction, boolean isAdd) {
/* 711 */     if (fraction == null) {
/* 712 */       throw new IllegalArgumentException("The fraction must not be null");
/*     */     }
/*     */     
/* 715 */     if (this.numerator == 0) {
/* 716 */       return isAdd ? fraction : fraction.negate();
/*     */     }
/* 718 */     if (fraction.numerator == 0) {
/* 719 */       return this;
/*     */     }
/*     */ 
/*     */     
/* 723 */     int d1 = greatestCommonDivisor(this.denominator, fraction.denominator);
/* 724 */     if (d1 == 1) {
/*     */       
/* 726 */       int i = mulAndCheck(this.numerator, fraction.denominator);
/* 727 */       int j = mulAndCheck(fraction.numerator, this.denominator);
/* 728 */       return new Fraction(
/* 729 */           isAdd ? addAndCheck(i, j) : subAndCheck(i, j), 
/* 730 */           mulPosAndCheck(this.denominator, fraction.denominator));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 735 */     BigInteger uvp = BigInteger.valueOf(this.numerator)
/* 736 */       .multiply(BigInteger.valueOf((fraction.denominator / d1)));
/* 737 */     BigInteger upv = BigInteger.valueOf(fraction.numerator)
/* 738 */       .multiply(BigInteger.valueOf((this.denominator / d1)));
/* 739 */     BigInteger t = isAdd ? uvp.add(upv) : uvp.subtract(upv);
/*     */ 
/*     */     
/* 742 */     int tmodd1 = t.mod(BigInteger.valueOf(d1)).intValue();
/* 743 */     int d2 = (tmodd1 == 0) ? d1 : greatestCommonDivisor(tmodd1, d1);
/*     */ 
/*     */     
/* 746 */     BigInteger w = t.divide(BigInteger.valueOf(d2));
/* 747 */     if (w.bitLength() > 31) {
/* 748 */       throw new ArithmeticException(
/* 749 */           "overflow: numerator too large after multiply");
/*     */     }
/* 751 */     return new Fraction(
/* 752 */         w.intValue(), 
/* 753 */         mulPosAndCheck(this.denominator / d1, fraction.denominator / d2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction multiplyBy(Fraction fraction) {
/* 767 */     if (fraction == null) {
/* 768 */       throw new IllegalArgumentException("The fraction must not be null");
/*     */     }
/* 770 */     if (this.numerator == 0 || fraction.numerator == 0) {
/* 771 */       return ZERO;
/*     */     }
/*     */ 
/*     */     
/* 775 */     int d1 = greatestCommonDivisor(this.numerator, fraction.denominator);
/* 776 */     int d2 = greatestCommonDivisor(fraction.numerator, this.denominator);
/* 777 */     return 
/* 778 */       getReducedFraction(mulAndCheck(this.numerator / d1, fraction.numerator / d2), 
/* 779 */         mulPosAndCheck(this.denominator / d2, fraction.denominator / d1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Fraction divideBy(Fraction fraction) {
/* 793 */     if (fraction == null) {
/* 794 */       throw new IllegalArgumentException("The fraction must not be null");
/*     */     }
/* 796 */     if (fraction.numerator == 0) {
/* 797 */       throw new ArithmeticException("The fraction to divide by must not be zero");
/*     */     }
/* 799 */     return multiplyBy(fraction.invert());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 814 */     if (obj == this) {
/* 815 */       return true;
/*     */     }
/* 817 */     if (obj instanceof Fraction == false) {
/* 818 */       return false;
/*     */     }
/* 820 */     Fraction other = (Fraction)obj;
/* 821 */     return !(getNumerator() != other.getNumerator() || 
/* 822 */       getDenominator() != other.getDenominator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 831 */     if (this.hashCode == 0)
/*     */     {
/* 833 */       this.hashCode = 37 * (629 + getNumerator()) + getDenominator();
/*     */     }
/* 835 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object object) {
/* 847 */     Fraction other = (Fraction)object;
/* 848 */     if (this == other) {
/* 849 */       return 0;
/*     */     }
/* 851 */     if (this.numerator == other.numerator && this.denominator == other.denominator) {
/* 852 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 856 */     long first = this.numerator * other.denominator;
/* 857 */     long second = other.numerator * this.denominator;
/* 858 */     if (first == second)
/* 859 */       return 0; 
/* 860 */     if (first < second) {
/* 861 */       return -1;
/*     */     }
/* 863 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 875 */     if (this.toString == null) {
/* 876 */       this.toString = (new StringBuffer(32))
/* 877 */         .append(getNumerator())
/* 878 */         .append('/')
/* 879 */         .append(getDenominator()).toString();
/*     */     }
/* 881 */     return this.toString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toProperString() {
/* 894 */     if (this.toProperString == null) {
/* 895 */       if (this.numerator == 0) {
/* 896 */         this.toProperString = "0";
/* 897 */       } else if (this.numerator == this.denominator) {
/* 898 */         this.toProperString = "1";
/* 899 */       } else if (((this.numerator > 0) ? -this.numerator : this.numerator) < -this.denominator) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 904 */         int properNumerator = getProperNumerator();
/* 905 */         if (properNumerator == 0) {
/* 906 */           this.toProperString = Integer.toString(getProperWhole());
/*     */         } else {
/* 908 */           this.toProperString = (new StringBuffer(32))
/* 909 */             .append(getProperWhole()).append(' ')
/* 910 */             .append(properNumerator).append('/')
/* 911 */             .append(getDenominator()).toString();
/*     */         } 
/*     */       } else {
/* 914 */         this.toProperString = (new StringBuffer(32))
/* 915 */           .append(getNumerator()).append('/')
/* 916 */           .append(getDenominator()).toString();
/*     */       } 
/*     */     }
/* 919 */     return this.toProperString;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\math\Fraction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */