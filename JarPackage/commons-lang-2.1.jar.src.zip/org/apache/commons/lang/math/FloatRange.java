/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FloatRange
/*     */   extends Range
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 71849363892750L;
/*     */   private final float min;
/*     */   private final float max;
/*  43 */   private transient Float minObject = null;
/*     */ 
/*     */ 
/*     */   
/*  47 */   private transient Float maxObject = null;
/*     */ 
/*     */ 
/*     */   
/*  51 */   private transient int hashCode = 0;
/*     */ 
/*     */ 
/*     */   
/*  55 */   private transient String toString = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatRange(float number) {
/*  66 */     if (Float.isNaN(number)) {
/*  67 */       throw new IllegalArgumentException("The number must not be NaN");
/*     */     }
/*  69 */     this.min = number;
/*  70 */     this.max = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatRange(Number number) {
/*  84 */     if (number == null) {
/*  85 */       throw new IllegalArgumentException("The number must not be null");
/*     */     }
/*  87 */     this.min = number.floatValue();
/*  88 */     this.max = number.floatValue();
/*  89 */     if (Float.isNaN(this.min) || Float.isNaN(this.max)) {
/*  90 */       throw new IllegalArgumentException("The number must not be NaN");
/*     */     }
/*  92 */     if (number instanceof Float) {
/*  93 */       this.minObject = (Float)number;
/*  94 */       this.maxObject = (Float)number;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatRange(float number1, float number2) {
/* 111 */     if (Float.isNaN(number1) || Float.isNaN(number2)) {
/* 112 */       throw new IllegalArgumentException("The numbers must not be NaN");
/*     */     }
/* 114 */     if (number2 < number1) {
/* 115 */       this.min = number2;
/* 116 */       this.max = number1;
/*     */     } else {
/* 118 */       this.min = number1;
/* 119 */       this.max = number2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatRange(Number number1, Number number2) {
/* 137 */     if (number1 == null || number2 == null) {
/* 138 */       throw new IllegalArgumentException("The numbers must not be null");
/*     */     }
/* 140 */     float number1val = number1.floatValue();
/* 141 */     float number2val = number2.floatValue();
/* 142 */     if (Float.isNaN(number1val) || Float.isNaN(number2val)) {
/* 143 */       throw new IllegalArgumentException("The numbers must not be NaN");
/*     */     }
/* 145 */     if (number2val < number1val) {
/* 146 */       this.min = number2val;
/* 147 */       this.max = number1val;
/* 148 */       if (number2 instanceof Float) {
/* 149 */         this.minObject = (Float)number2;
/*     */       }
/* 151 */       if (number1 instanceof Float) {
/* 152 */         this.maxObject = (Float)number1;
/*     */       }
/*     */     } else {
/* 155 */       this.min = number1val;
/* 156 */       this.max = number2val;
/* 157 */       if (number1 instanceof Float) {
/* 158 */         this.minObject = (Float)number1;
/*     */       }
/* 160 */       if (number2 instanceof Float) {
/* 161 */         this.maxObject = (Float)number2;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMinimumNumber() {
/* 175 */     if (this.minObject == null) {
/* 176 */       this.minObject = new Float(this.min);
/*     */     }
/* 178 */     return this.minObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMinimumLong() {
/* 189 */     return (long)this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinimumInteger() {
/* 200 */     return (int)this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMinimumDouble() {
/* 209 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMinimumFloat() {
/* 218 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMaximumNumber() {
/* 227 */     if (this.maxObject == null) {
/* 228 */       this.maxObject = new Float(this.max);
/*     */     }
/* 230 */     return this.maxObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaximumLong() {
/* 241 */     return (long)this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumInteger() {
/* 252 */     return (int)this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMaximumDouble() {
/* 261 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaximumFloat() {
/* 270 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsNumber(Number number) {
/* 286 */     if (number == null) {
/* 287 */       return false;
/*     */     }
/* 289 */     return containsFloat(number.floatValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsFloat(float value) {
/* 304 */     return !(value < this.min || value > this.max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsRange(Range range) {
/* 321 */     if (range == null) {
/* 322 */       return false;
/*     */     }
/* 324 */     return !(!containsFloat(range.getMinimumFloat()) || 
/* 325 */       !containsFloat(range.getMaximumFloat()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overlapsRange(Range range) {
/* 338 */     if (range == null) {
/* 339 */       return false;
/*     */     }
/* 341 */     return !(!range.containsFloat(this.min) && 
/* 342 */       !range.containsFloat(this.max) && 
/* 343 */       !containsFloat(range.getMinimumFloat()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 358 */     if (obj == this) {
/* 359 */       return true;
/*     */     }
/* 361 */     if (obj instanceof FloatRange == false) {
/* 362 */       return false;
/*     */     }
/* 364 */     FloatRange range = (FloatRange)obj;
/* 365 */     return !(Float.floatToIntBits(this.min) != Float.floatToIntBits(range.min) || 
/* 366 */       Float.floatToIntBits(this.max) != Float.floatToIntBits(range.max));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 375 */     if (this.hashCode == 0) {
/* 376 */       this.hashCode = 17;
/* 377 */       this.hashCode = 37 * this.hashCode + getClass().hashCode();
/* 378 */       this.hashCode = 37 * this.hashCode + Float.floatToIntBits(this.min);
/* 379 */       this.hashCode = 37 * this.hashCode + Float.floatToIntBits(this.max);
/*     */     } 
/* 381 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 392 */     if (this.toString == null) {
/* 393 */       StringBuffer buf = new StringBuffer(32);
/* 394 */       buf.append("Range[");
/* 395 */       buf.append(this.min);
/* 396 */       buf.append(',');
/* 397 */       buf.append(this.max);
/* 398 */       buf.append(']');
/* 399 */       this.toString = buf.toString();
/*     */     } 
/* 401 */     return this.toString;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\math\FloatRange.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */