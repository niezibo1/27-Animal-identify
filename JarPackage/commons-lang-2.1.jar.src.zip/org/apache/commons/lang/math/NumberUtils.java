/*      */ package org.apache.commons.lang.math;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NumberUtils
/*      */ {
/*   41 */   public static final Long LONG_ZERO = new Long(0L);
/*      */   
/*   43 */   public static final Long LONG_ONE = new Long(1L);
/*      */   
/*   45 */   public static final Long LONG_MINUS_ONE = new Long(-1L);
/*      */   
/*   47 */   public static final Integer INTEGER_ZERO = new Integer(0);
/*      */   
/*   49 */   public static final Integer INTEGER_ONE = new Integer(1);
/*      */   
/*   51 */   public static final Integer INTEGER_MINUS_ONE = new Integer(-1);
/*      */   
/*   53 */   public static final Short SHORT_ZERO = new Short((short)0);
/*      */   
/*   55 */   public static final Short SHORT_ONE = new Short((short)1);
/*      */   
/*   57 */   public static final Short SHORT_MINUS_ONE = new Short((short)-1);
/*      */   
/*   59 */   public static final Byte BYTE_ZERO = new Byte((byte)0);
/*      */   
/*   61 */   public static final Byte BYTE_ONE = new Byte((byte)1);
/*      */   
/*   63 */   public static final Byte BYTE_MINUS_ONE = new Byte((byte)-1);
/*      */   
/*   65 */   public static final Double DOUBLE_ZERO = new Double(0.0D);
/*      */   
/*   67 */   public static final Double DOUBLE_ONE = new Double(1.0D);
/*      */   
/*   69 */   public static final Double DOUBLE_MINUS_ONE = new Double(-1.0D);
/*      */   
/*   71 */   public static final Float FLOAT_ZERO = new Float(0.0F);
/*      */   
/*   73 */   public static final Float FLOAT_ONE = new Float(1.0F);
/*      */   
/*   75 */   public static final Float FLOAT_MINUS_ONE = new Float(-1.0F);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int stringToInt(String str) {
/*  107 */     return toInt(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int toInt(String str) {
/*  128 */     return toInt(str, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int stringToInt(String str, int defaultValue) {
/*  150 */     return toInt(str, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int toInt(String str, int defaultValue) {
/*  171 */     if (str == null) {
/*  172 */       return defaultValue;
/*      */     }
/*      */     try {
/*  175 */       return Integer.parseInt(str);
/*  176 */     } catch (NumberFormatException numberFormatException) {
/*  177 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long toLong(String str) {
/*  199 */     return toLong(str, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long toLong(String str, long defaultValue) {
/*  220 */     if (str == null) {
/*  221 */       return defaultValue;
/*      */     }
/*      */     try {
/*  224 */       return Long.parseLong(str);
/*  225 */     } catch (NumberFormatException numberFormatException) {
/*  226 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float toFloat(String str) {
/*  249 */     return toFloat(str, 0.0F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float toFloat(String str, float defaultValue) {
/*  272 */     if (str == null) {
/*  273 */       return defaultValue;
/*      */     }
/*      */     try {
/*  276 */       return Float.parseFloat(str);
/*  277 */     } catch (NumberFormatException numberFormatException) {
/*  278 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toDouble(String str) {
/*  301 */     return toDouble(str, 0.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toDouble(String str, double defaultValue) {
/*  324 */     if (str == null) {
/*  325 */       return defaultValue;
/*      */     }
/*      */     try {
/*  328 */       return Double.parseDouble(str);
/*  329 */     } catch (NumberFormatException numberFormatException) {
/*  330 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Number createNumber(String str) throws NumberFormatException {
/*      */     String mant, dec, exp;
/*  397 */     if (str == null) {
/*  398 */       return null;
/*      */     }
/*  400 */     if (StringUtils.isBlank(str)) {
/*  401 */       throw new NumberFormatException("A blank string is not a valid number");
/*      */     }
/*  403 */     if (str.startsWith("--"))
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  408 */       return null;
/*      */     }
/*  410 */     if (str.startsWith("0x") || str.startsWith("-0x")) {
/*  411 */       return createInteger(str);
/*      */     }
/*  413 */     char lastChar = str.charAt(str.length() - 1);
/*      */ 
/*      */ 
/*      */     
/*  417 */     int decPos = str.indexOf('.');
/*  418 */     int expPos = str.indexOf('e') + str.indexOf('E') + 1;
/*      */     
/*  420 */     if (decPos > -1) {
/*      */       
/*  422 */       if (expPos > -1) {
/*  423 */         if (expPos < decPos) {
/*  424 */           throw new NumberFormatException(String.valueOf(str) + " is not a valid number.");
/*      */         }
/*  426 */         dec = str.substring(decPos + 1, expPos);
/*      */       } else {
/*  428 */         dec = str.substring(decPos + 1);
/*      */       } 
/*  430 */       mant = str.substring(0, decPos);
/*      */     } else {
/*  432 */       if (expPos > -1) {
/*  433 */         mant = str.substring(0, expPos);
/*      */       } else {
/*  435 */         mant = str;
/*      */       } 
/*  437 */       dec = null;
/*      */     } 
/*  439 */     if (!Character.isDigit(lastChar)) {
/*  440 */       if (expPos > -1 && expPos < str.length() - 1) {
/*  441 */         exp = str.substring(expPos + 1, str.length() - 1);
/*      */       } else {
/*  443 */         exp = null;
/*      */       } 
/*      */       
/*  446 */       String numeric = str.substring(0, str.length() - 1);
/*  447 */       boolean bool = !(!isAllZeros(mant) || !isAllZeros(exp));
/*  448 */       switch (lastChar) {
/*      */         case 'L':
/*      */         case 'l':
/*  451 */           if (dec == null && 
/*  452 */             exp == null && 
/*  453 */             isDigits(numeric.substring(1)) && (
/*  454 */             numeric.charAt(0) == '-' || Character.isDigit(numeric.charAt(0)))) {
/*      */             try {
/*  456 */               return createLong(numeric);
/*  457 */             } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */               
/*  460 */               return createBigInteger(numeric);
/*      */             } 
/*      */           }
/*  463 */           throw new NumberFormatException(String.valueOf(str) + " is not a valid number.");
/*      */         case 'F':
/*      */         case 'f':
/*      */           try {
/*  467 */             Float f = createFloat(numeric);
/*  468 */             if (!f.isInfinite() && (f.floatValue() != 0.0F || bool))
/*      */             {
/*      */               
/*  471 */               return f;
/*      */             }
/*      */           }
/*  474 */           catch (NumberFormatException numberFormatException) {}
/*      */ 
/*      */         
/*      */         case 'D':
/*      */         case 'd':
/*      */           try {
/*  480 */             Double d = createDouble(numeric);
/*  481 */             if (!d.isInfinite() && (d.floatValue() != 0.0D || bool)) {
/*  482 */               return d;
/*      */             }
/*  484 */           } catch (NumberFormatException numberFormatException) {}
/*      */           
/*      */           try {
/*  487 */             return createBigDecimal(numeric);
/*  488 */           } catch (NumberFormatException numberFormatException) {
/*      */             break;
/*      */           } 
/*      */       } 
/*  492 */       throw new NumberFormatException(String.valueOf(str) + " is not a valid number.");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  498 */     if (expPos > -1 && expPos < str.length() - 1) {
/*  499 */       exp = str.substring(expPos + 1, str.length());
/*      */     } else {
/*  501 */       exp = null;
/*      */     } 
/*  503 */     if (dec == null && exp == null) {
/*      */       
/*      */       try {
/*  506 */         return createInteger(str);
/*  507 */       } catch (NumberFormatException numberFormatException) {
/*      */         
/*      */         try {
/*  510 */           return createLong(str);
/*  511 */         } catch (NumberFormatException numberFormatException1) {
/*      */           
/*  513 */           return createBigInteger(str);
/*      */         } 
/*      */       } 
/*      */     }
/*  517 */     boolean allZeros = !(!isAllZeros(mant) || !isAllZeros(exp));
/*      */     try {
/*  519 */       Float f = createFloat(str);
/*  520 */       if (!f.isInfinite() && (f.floatValue() != 0.0F || allZeros)) {
/*  521 */         return f;
/*      */       }
/*  523 */     } catch (NumberFormatException numberFormatException) {}
/*      */     
/*      */     try {
/*  526 */       Double d = createDouble(str);
/*  527 */       if (!d.isInfinite() && (d.doubleValue() != 0.0D || allZeros)) {
/*  528 */         return d;
/*      */       }
/*  530 */     } catch (NumberFormatException numberFormatException) {}
/*      */ 
/*      */     
/*  533 */     return createBigDecimal(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isAllZeros(String str) {
/*  548 */     if (str == null) {
/*  549 */       return true;
/*      */     }
/*  551 */     for (int i = str.length() - 1; i >= 0; i--) {
/*  552 */       if (str.charAt(i) != '0') {
/*  553 */         return false;
/*      */       }
/*      */     } 
/*  556 */     return !(str.length() <= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float createFloat(String str) {
/*  570 */     if (str == null) {
/*  571 */       return null;
/*      */     }
/*  573 */     return Float.valueOf(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double createDouble(String str) {
/*  586 */     if (str == null) {
/*  587 */       return null;
/*      */     }
/*  589 */     return Double.valueOf(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer createInteger(String str) {
/*  603 */     if (str == null) {
/*  604 */       return null;
/*      */     }
/*      */     
/*  607 */     return Integer.decode(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long createLong(String str) {
/*  620 */     if (str == null) {
/*  621 */       return null;
/*      */     }
/*  623 */     return Long.valueOf(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger createBigInteger(String str) {
/*  636 */     if (str == null) {
/*  637 */       return null;
/*      */     }
/*  639 */     return new BigInteger(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal createBigDecimal(String str) {
/*  652 */     if (str == null) {
/*  653 */       return null;
/*      */     }
/*      */     
/*  656 */     if (StringUtils.isBlank(str)) {
/*  657 */       throw new NumberFormatException("A blank string is not a valid number");
/*      */     }
/*  659 */     return new BigDecimal(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long min(long[] array) {
/*  674 */     if (array == null)
/*  675 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  676 */     if (array.length == 0) {
/*  677 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  681 */     long min = array[0];
/*  682 */     for (int i = 1; i < array.length; i++) {
/*  683 */       if (array[i] < min) {
/*  684 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  688 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int min(int[] array) {
/*  701 */     if (array == null)
/*  702 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  703 */     if (array.length == 0) {
/*  704 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  708 */     int min = array[0];
/*  709 */     for (int j = 1; j < array.length; j++) {
/*  710 */       if (array[j] < min) {
/*  711 */         min = array[j];
/*      */       }
/*      */     } 
/*      */     
/*  715 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short min(short[] array) {
/*  728 */     if (array == null)
/*  729 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  730 */     if (array.length == 0) {
/*  731 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  735 */     short min = array[0];
/*  736 */     for (int i = 1; i < array.length; i++) {
/*  737 */       if (array[i] < min) {
/*  738 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  742 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double min(double[] array) {
/*  755 */     if (array == null)
/*  756 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  757 */     if (array.length == 0) {
/*  758 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  762 */     double min = array[0];
/*  763 */     for (int i = 1; i < array.length; i++) {
/*  764 */       if (array[i] < min) {
/*  765 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  769 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float min(float[] array) {
/*  782 */     if (array == null)
/*  783 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  784 */     if (array.length == 0) {
/*  785 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  789 */     float min = array[0];
/*  790 */     for (int i = 1; i < array.length; i++) {
/*  791 */       if (array[i] < min) {
/*  792 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  796 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long max(long[] array) {
/*  811 */     if (array == null)
/*  812 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  813 */     if (array.length == 0) {
/*  814 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  818 */     long max = array[0];
/*  819 */     for (int j = 1; j < array.length; j++) {
/*  820 */       if (array[j] > max) {
/*  821 */         max = array[j];
/*      */       }
/*      */     } 
/*      */     
/*  825 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int max(int[] array) {
/*  838 */     if (array == null)
/*  839 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  840 */     if (array.length == 0) {
/*  841 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  845 */     int max = array[0];
/*  846 */     for (int j = 1; j < array.length; j++) {
/*  847 */       if (array[j] > max) {
/*  848 */         max = array[j];
/*      */       }
/*      */     } 
/*      */     
/*  852 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short max(short[] array) {
/*  865 */     if (array == null)
/*  866 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  867 */     if (array.length == 0) {
/*  868 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  872 */     short max = array[0];
/*  873 */     for (int i = 1; i < array.length; i++) {
/*  874 */       if (array[i] > max) {
/*  875 */         max = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  879 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double max(double[] array) {
/*  892 */     if (array == null)
/*  893 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  894 */     if (array.length == 0) {
/*  895 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  899 */     double max = array[0];
/*  900 */     for (int j = 1; j < array.length; j++) {
/*  901 */       if (array[j] > max) {
/*  902 */         max = array[j];
/*      */       }
/*      */     } 
/*      */     
/*  906 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float max(float[] array) {
/*  919 */     if (array == null)
/*  920 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  921 */     if (array.length == 0) {
/*  922 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  926 */     float max = array[0];
/*  927 */     for (int j = 1; j < array.length; j++) {
/*  928 */       if (array[j] > max) {
/*  929 */         max = array[j];
/*      */       }
/*      */     } 
/*      */     
/*  933 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long min(long a, long b, long c) {
/*  947 */     if (b < a) {
/*  948 */       a = b;
/*      */     }
/*  950 */     if (c < a) {
/*  951 */       a = c;
/*      */     }
/*  953 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int min(int a, int b, int c) {
/*  965 */     if (b < a) {
/*  966 */       a = b;
/*      */     }
/*  968 */     if (c < a) {
/*  969 */       a = c;
/*      */     }
/*  971 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short min(short a, short b, short c) {
/*  983 */     if (b < a) {
/*  984 */       a = b;
/*      */     }
/*  986 */     if (c < a) {
/*  987 */       a = c;
/*      */     }
/*  989 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte min(byte a, byte b, byte c) {
/* 1001 */     if (b < a) {
/* 1002 */       a = b;
/*      */     }
/* 1004 */     if (c < a) {
/* 1005 */       a = c;
/*      */     }
/* 1007 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double min(double a, double b, double c) {
/* 1022 */     return Math.min(Math.min(a, b), c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float min(float a, float b, float c) {
/* 1037 */     return Math.min(Math.min(a, b), c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long max(long a, long b, long c) {
/* 1051 */     if (b > a) {
/* 1052 */       a = b;
/*      */     }
/* 1054 */     if (c > a) {
/* 1055 */       a = c;
/*      */     }
/* 1057 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int max(int a, int b, int c) {
/* 1069 */     if (b > a) {
/* 1070 */       a = b;
/*      */     }
/* 1072 */     if (c > a) {
/* 1073 */       a = c;
/*      */     }
/* 1075 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short max(short a, short b, short c) {
/* 1087 */     if (b > a) {
/* 1088 */       a = b;
/*      */     }
/* 1090 */     if (c > a) {
/* 1091 */       a = c;
/*      */     }
/* 1093 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte max(byte a, byte b, byte c) {
/* 1105 */     if (b > a) {
/* 1106 */       a = b;
/*      */     }
/* 1108 */     if (c > a) {
/* 1109 */       a = c;
/*      */     }
/* 1111 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double max(double a, double b, double c) {
/* 1126 */     return Math.max(Math.max(a, b), c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float max(float a, float b, float c) {
/* 1141 */     return Math.max(Math.max(a, b), c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(double lhs, double rhs) {
/* 1180 */     if (lhs < rhs) {
/* 1181 */       return -1;
/*      */     }
/* 1183 */     if (lhs > rhs) {
/* 1184 */       return 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1190 */     long lhsBits = Double.doubleToLongBits(lhs);
/* 1191 */     long rhsBits = Double.doubleToLongBits(rhs);
/* 1192 */     if (lhsBits == rhsBits) {
/* 1193 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1201 */     if (lhsBits < rhsBits) {
/* 1202 */       return -1;
/*      */     }
/* 1204 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compare(float lhs, float rhs) {
/* 1241 */     if (lhs < rhs) {
/* 1242 */       return -1;
/*      */     }
/* 1244 */     if (lhs > rhs) {
/* 1245 */       return 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1251 */     int lhsBits = Float.floatToIntBits(lhs);
/* 1252 */     int rhsBits = Float.floatToIntBits(rhs);
/* 1253 */     if (lhsBits == rhsBits) {
/* 1254 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1262 */     if (lhsBits < rhsBits) {
/* 1263 */       return -1;
/*      */     }
/* 1265 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDigits(String str) {
/* 1281 */     if (StringUtils.isEmpty(str)) {
/* 1282 */       return false;
/*      */     }
/* 1284 */     for (int i = 0; i < str.length(); i++) {
/* 1285 */       if (!Character.isDigit(str.charAt(i))) {
/* 1286 */         return false;
/*      */       }
/*      */     } 
/* 1289 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumber(String str) {
/* 1306 */     if (StringUtils.isEmpty(str)) {
/* 1307 */       return false;
/*      */     }
/* 1309 */     char[] chars = str.toCharArray();
/* 1310 */     int sz = chars.length;
/* 1311 */     boolean hasExp = false;
/* 1312 */     boolean hasDecPoint = false;
/* 1313 */     boolean allowSigns = false;
/* 1314 */     boolean foundDigit = false;
/*      */     
/* 1316 */     int start = (chars[0] == '-') ? 1 : 0;
/* 1317 */     if (sz > start + 1 && 
/* 1318 */       chars[start] == '0' && chars[start + 1] == 'x') {
/* 1319 */       int j = start + 2;
/* 1320 */       if (j == sz) {
/* 1321 */         return false;
/*      */       }
/*      */       
/* 1324 */       for (; j < chars.length; j++) {
/* 1325 */         if ((chars[j] < '0' || chars[j] > '9') && (
/* 1326 */           chars[j] < 'a' || chars[j] > 'f') && (
/* 1327 */           chars[j] < 'A' || chars[j] > 'F')) {
/* 1328 */           return false;
/*      */         }
/*      */       } 
/* 1331 */       return true;
/*      */     } 
/*      */     
/* 1334 */     sz--;
/*      */     
/* 1336 */     int i = start;
/*      */ 
/*      */     
/* 1339 */     while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
/* 1340 */       if (chars[i] >= '0' && chars[i] <= '9') {
/* 1341 */         foundDigit = true;
/* 1342 */         allowSigns = false;
/*      */       }
/* 1344 */       else if (chars[i] == '.') {
/* 1345 */         if (hasDecPoint || hasExp)
/*      */         {
/* 1347 */           return false;
/*      */         }
/* 1349 */         hasDecPoint = true;
/* 1350 */       } else if (chars[i] == 'e' || chars[i] == 'E') {
/*      */         
/* 1352 */         if (hasExp)
/*      */         {
/* 1354 */           return false;
/*      */         }
/* 1356 */         if (!foundDigit) {
/* 1357 */           return false;
/*      */         }
/* 1359 */         hasExp = true;
/* 1360 */         allowSigns = true;
/* 1361 */       } else if (chars[i] == '+' || chars[i] == '-') {
/* 1362 */         if (!allowSigns) {
/* 1363 */           return false;
/*      */         }
/* 1365 */         allowSigns = false;
/* 1366 */         foundDigit = false;
/*      */       } else {
/* 1368 */         return false;
/*      */       } 
/* 1370 */       i++;
/*      */     } 
/* 1372 */     if (i < chars.length) {
/* 1373 */       if (chars[i] >= '0' && chars[i] <= '9')
/*      */       {
/* 1375 */         return true;
/*      */       }
/* 1377 */       if (chars[i] == 'e' || chars[i] == 'E')
/*      */       {
/* 1379 */         return false;
/*      */       }
/* 1381 */       if (!allowSigns && (
/* 1382 */         chars[i] == 'd' || 
/* 1383 */         chars[i] == 'D' || 
/* 1384 */         chars[i] == 'f' || 
/* 1385 */         chars[i] == 'F')) {
/* 1386 */         return foundDigit;
/*      */       }
/* 1388 */       if (chars[i] == 'l' || 
/* 1389 */         chars[i] == 'L')
/*      */       {
/* 1391 */         return !(!foundDigit || hasExp);
/*      */       }
/*      */       
/* 1394 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1398 */     return !(allowSigns || !foundDigit);
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\math\NumberUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */