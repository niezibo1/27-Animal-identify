/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IntRange
/*     */   extends Range
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 71849363892730L;
/*     */   private final int min;
/*     */   private final int max;
/*  43 */   private transient Integer minObject = null;
/*     */ 
/*     */ 
/*     */   
/*  47 */   private transient Integer maxObject = null;
/*     */ 
/*     */ 
/*     */   
/*  51 */   private transient int hashCode = 0;
/*     */ 
/*     */ 
/*     */   
/*  55 */   private transient String toString = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntRange(int number) {
/*  65 */     this.min = number;
/*  66 */     this.max = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntRange(Number number) {
/*  78 */     if (number == null) {
/*  79 */       throw new IllegalArgumentException("The number must not be null");
/*     */     }
/*  81 */     this.min = number.intValue();
/*  82 */     this.max = number.intValue();
/*  83 */     if (number instanceof Integer) {
/*  84 */       this.minObject = (Integer)number;
/*  85 */       this.maxObject = (Integer)number;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntRange(int number1, int number2) {
/* 101 */     if (number2 < number1) {
/* 102 */       this.min = number2;
/* 103 */       this.max = number1;
/*     */     } else {
/* 105 */       this.min = number1;
/* 106 */       this.max = number2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntRange(Number number1, Number number2) {
/* 123 */     if (number1 == null || number2 == null) {
/* 124 */       throw new IllegalArgumentException("The numbers must not be null");
/*     */     }
/* 126 */     int number1val = number1.intValue();
/* 127 */     int number2val = number2.intValue();
/* 128 */     if (number2val < number1val) {
/* 129 */       this.min = number2val;
/* 130 */       this.max = number1val;
/* 131 */       if (number2 instanceof Integer) {
/* 132 */         this.minObject = (Integer)number2;
/*     */       }
/* 134 */       if (number1 instanceof Integer) {
/* 135 */         this.maxObject = (Integer)number1;
/*     */       }
/*     */     } else {
/* 138 */       this.min = number1val;
/* 139 */       this.max = number2val;
/* 140 */       if (number1 instanceof Integer) {
/* 141 */         this.minObject = (Integer)number1;
/*     */       }
/* 143 */       if (number2 instanceof Integer) {
/* 144 */         this.maxObject = (Integer)number2;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMinimumNumber() {
/* 158 */     if (this.minObject == null) {
/* 159 */       this.minObject = new Integer(this.min);
/*     */     }
/* 161 */     return this.minObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMinimumLong() {
/* 170 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinimumInteger() {
/* 179 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMinimumDouble() {
/* 188 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMinimumFloat() {
/* 197 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMaximumNumber() {
/* 206 */     if (this.maxObject == null) {
/* 207 */       this.maxObject = new Integer(this.max);
/*     */     }
/* 209 */     return this.maxObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaximumLong() {
/* 218 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumInteger() {
/* 227 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMaximumDouble() {
/* 236 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaximumFloat() {
/* 245 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsNumber(Number number) {
/* 261 */     if (number == null) {
/* 262 */       return false;
/*     */     }
/* 264 */     return containsInteger(number.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsInteger(int value) {
/* 279 */     return !(value < this.min || value > this.max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsRange(Range range) {
/* 296 */     if (range == null) {
/* 297 */       return false;
/*     */     }
/* 299 */     return !(!containsInteger(range.getMinimumInteger()) || 
/* 300 */       !containsInteger(range.getMaximumInteger()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overlapsRange(Range range) {
/* 313 */     if (range == null) {
/* 314 */       return false;
/*     */     }
/* 316 */     return !(!range.containsInteger(this.min) && 
/* 317 */       !range.containsInteger(this.max) && 
/* 318 */       !containsInteger(range.getMinimumInteger()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 333 */     if (obj == this) {
/* 334 */       return true;
/*     */     }
/* 336 */     if (obj instanceof IntRange == false) {
/* 337 */       return false;
/*     */     }
/* 339 */     IntRange range = (IntRange)obj;
/* 340 */     return !(this.min != range.min || this.max != range.max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 349 */     if (this.hashCode == 0) {
/* 350 */       this.hashCode = 17;
/* 351 */       this.hashCode = 37 * this.hashCode + getClass().hashCode();
/* 352 */       this.hashCode = 37 * this.hashCode + this.min;
/* 353 */       this.hashCode = 37 * this.hashCode + this.max;
/*     */     } 
/* 355 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 366 */     if (this.toString == null) {
/* 367 */       StringBuffer buf = new StringBuffer(32);
/* 368 */       buf.append("Range[");
/* 369 */       buf.append(this.min);
/* 370 */       buf.append(',');
/* 371 */       buf.append(this.max);
/* 372 */       buf.append(']');
/* 373 */       this.toString = buf.toString();
/*     */     } 
/* 375 */     return this.toString;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\math\IntRange.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */