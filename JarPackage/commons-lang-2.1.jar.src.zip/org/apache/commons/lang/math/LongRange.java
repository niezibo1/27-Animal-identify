/*     */ package org.apache.commons.lang.math;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LongRange
/*     */   extends Range
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 71849363892720L;
/*     */   private final long min;
/*     */   private final long max;
/*  43 */   private transient Long minObject = null;
/*     */ 
/*     */ 
/*     */   
/*  47 */   private transient Long maxObject = null;
/*     */ 
/*     */ 
/*     */   
/*  51 */   private transient int hashCode = 0;
/*     */ 
/*     */ 
/*     */   
/*  55 */   private transient String toString = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LongRange(long number) {
/*  65 */     this.min = number;
/*  66 */     this.max = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LongRange(Number number) {
/*  79 */     if (number == null) {
/*  80 */       throw new IllegalArgumentException("The number must not be null");
/*     */     }
/*  82 */     this.min = number.longValue();
/*  83 */     this.max = number.longValue();
/*  84 */     if (number instanceof Long) {
/*  85 */       this.minObject = (Long)number;
/*  86 */       this.maxObject = (Long)number;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LongRange(long number1, long number2) {
/* 102 */     if (number2 < number1) {
/* 103 */       this.min = number2;
/* 104 */       this.max = number1;
/*     */     } else {
/* 106 */       this.min = number1;
/* 107 */       this.max = number2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LongRange(Number number1, Number number2) {
/* 124 */     if (number1 == null || number2 == null) {
/* 125 */       throw new IllegalArgumentException("The numbers must not be null");
/*     */     }
/* 127 */     long number1val = number1.longValue();
/* 128 */     long number2val = number2.longValue();
/* 129 */     if (number2val < number1val) {
/* 130 */       this.min = number2val;
/* 131 */       this.max = number1val;
/* 132 */       if (number2 instanceof Long) {
/* 133 */         this.minObject = (Long)number2;
/*     */       }
/* 135 */       if (number1 instanceof Long) {
/* 136 */         this.maxObject = (Long)number1;
/*     */       }
/*     */     } else {
/* 139 */       this.min = number1val;
/* 140 */       this.max = number2val;
/* 141 */       if (number1 instanceof Long) {
/* 142 */         this.minObject = (Long)number1;
/*     */       }
/* 144 */       if (number2 instanceof Long) {
/* 145 */         this.maxObject = (Long)number2;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMinimumNumber() {
/* 159 */     if (this.minObject == null) {
/* 160 */       this.minObject = new Long(this.min);
/*     */     }
/* 162 */     return this.minObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMinimumLong() {
/* 171 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinimumInteger() {
/* 182 */     return (int)this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMinimumDouble() {
/* 193 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMinimumFloat() {
/* 204 */     return (float)this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getMaximumNumber() {
/* 213 */     if (this.maxObject == null) {
/* 214 */       this.maxObject = new Long(this.max);
/*     */     }
/* 216 */     return this.maxObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaximumLong() {
/* 225 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaximumInteger() {
/* 236 */     return (int)this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMaximumDouble() {
/* 247 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaximumFloat() {
/* 258 */     return (float)this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsNumber(Number number) {
/* 274 */     if (number == null) {
/* 275 */       return false;
/*     */     }
/* 277 */     return containsLong(number.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsLong(long value) {
/* 292 */     return !(value < this.min || value > this.max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsRange(Range range) {
/* 309 */     if (range == null) {
/* 310 */       return false;
/*     */     }
/* 312 */     return !(!containsLong(range.getMinimumLong()) || 
/* 313 */       !containsLong(range.getMaximumLong()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overlapsRange(Range range) {
/* 326 */     if (range == null) {
/* 327 */       return false;
/*     */     }
/* 329 */     return !(!range.containsLong(this.min) && 
/* 330 */       !range.containsLong(this.max) && 
/* 331 */       !containsLong(range.getMinimumLong()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 346 */     if (obj == this) {
/* 347 */       return true;
/*     */     }
/* 349 */     if (obj instanceof LongRange == false) {
/* 350 */       return false;
/*     */     }
/* 352 */     LongRange range = (LongRange)obj;
/* 353 */     return !(this.min != range.min || this.max != range.max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 362 */     if (this.hashCode == 0) {
/* 363 */       this.hashCode = 17;
/* 364 */       this.hashCode = 37 * this.hashCode + getClass().hashCode();
/* 365 */       this.hashCode = 37 * this.hashCode + (int)(this.min ^ this.min >> 32L);
/* 366 */       this.hashCode = 37 * this.hashCode + (int)(this.max ^ this.max >> 32L);
/*     */     } 
/* 368 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 379 */     if (this.toString == null) {
/* 380 */       StringBuffer buf = new StringBuffer(32);
/* 381 */       buf.append("Range[");
/* 382 */       buf.append(this.min);
/* 383 */       buf.append(',');
/* 384 */       buf.append(this.max);
/* 385 */       buf.append(']');
/* 386 */       this.toString = buf.toString();
/*     */     } 
/* 388 */     return this.toString;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\math\LongRange.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */