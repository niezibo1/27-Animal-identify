/*     */ package org.apache.commons.lang.exception;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NestableDelegate
/*     */   implements Serializable
/*     */ {
/*     */   private static final transient String MUST_BE_THROWABLE = "The Nestable implementation passed to the NestableDelegate(Nestable) constructor must extend java.lang.Throwable";
/*  60 */   private Throwable nestable = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean topDown = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean trimStackFrames = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean matchSubclasses = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NestableDelegate(Nestable nestable) {
/* 101 */     if (nestable instanceof Throwable) {
/* 102 */       this.nestable = (Throwable)nestable;
/*     */     } else {
/* 104 */       throw new IllegalArgumentException("The Nestable implementation passed to the NestableDelegate(Nestable) constructor must extend java.lang.Throwable");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(int index) {
/* 122 */     Throwable t = getThrowable(index);
/* 123 */     if (Nestable.class.isInstance(t)) {
/* 124 */       return ((Nestable)t).getMessage(0);
/*     */     }
/* 126 */     return t.getMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String baseMsg) {
/* 144 */     StringBuffer msg = new StringBuffer();
/* 145 */     if (baseMsg != null) {
/* 146 */       msg.append(baseMsg);
/*     */     }
/*     */     
/* 149 */     Throwable nestedCause = ExceptionUtils.getCause(this.nestable);
/* 150 */     if (nestedCause != null) {
/* 151 */       String causeMsg = nestedCause.getMessage();
/* 152 */       if (causeMsg != null) {
/* 153 */         if (baseMsg != null) {
/* 154 */           msg.append(": ");
/*     */         }
/* 156 */         msg.append(causeMsg);
/*     */       } 
/*     */     } 
/*     */     
/* 160 */     return (msg.length() > 0) ? msg.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getMessages() {
/* 175 */     Throwable[] throwables = getThrowables();
/* 176 */     String[] msgs = new String[throwables.length];
/* 177 */     for (int i = 0; i < throwables.length; i++) {
/* 178 */       msgs[i] = 
/* 179 */         Nestable.class.isInstance(throwables[i]) ? (
/* 180 */         (Nestable)throwables[i]).getMessage(0) : 
/* 181 */         throwables[i].getMessage();
/*     */     }
/* 183 */     return msgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getThrowable(int index) {
/* 199 */     if (index == 0) {
/* 200 */       return this.nestable;
/*     */     }
/* 202 */     Throwable[] throwables = getThrowables();
/* 203 */     return throwables[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getThrowableCount() {
/* 214 */     return ExceptionUtils.getThrowableCount(this.nestable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable[] getThrowables() {
/* 226 */     return ExceptionUtils.getThrowables(this.nestable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfThrowable(Class type, int fromIndex) {
/* 254 */     if (type == null) {
/* 255 */       return -1;
/*     */     }
/* 257 */     if (fromIndex < 0) {
/* 258 */       throw new IndexOutOfBoundsException("The start index was out of bounds: " + fromIndex);
/*     */     }
/* 260 */     Throwable[] throwables = ExceptionUtils.getThrowables(this.nestable);
/* 261 */     if (fromIndex >= throwables.length) {
/* 262 */       throw new IndexOutOfBoundsException("The start index was out of bounds: " + 
/* 263 */           fromIndex + " >= " + throwables.length);
/*     */     }
/* 265 */     if (matchSubclasses) {
/* 266 */       for (int i = fromIndex; i < throwables.length; i++) {
/* 267 */         if (type.isAssignableFrom(throwables[i].getClass())) {
/* 268 */           return i;
/*     */         }
/*     */       } 
/*     */     } else {
/* 272 */       for (int i = fromIndex; i < throwables.length; i++) {
/* 273 */         if (type.equals(throwables[i].getClass())) {
/* 274 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/* 278 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace() {
/* 286 */     printStackTrace(System.err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream out) {
/* 297 */     synchronized (out) {
/* 298 */       PrintWriter pw = new PrintWriter(out, false);
/* 299 */       printStackTrace(pw);
/*     */       
/* 301 */       pw.flush();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter out) {
/* 317 */     Throwable throwable = this.nestable;
/*     */     
/* 319 */     if (ExceptionUtils.isThrowableNested()) {
/* 320 */       if (throwable instanceof Nestable) {
/* 321 */         ((Nestable)throwable).printPartialStackTrace(out);
/*     */       } else {
/* 323 */         throwable.printStackTrace(out);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 329 */     List stacks = new ArrayList();
/* 330 */     while (throwable != null) {
/* 331 */       String[] st = getStackFrames(throwable);
/* 332 */       stacks.add(st);
/* 333 */       throwable = ExceptionUtils.getCause(throwable);
/*     */     } 
/*     */ 
/*     */     
/* 337 */     String separatorLine = "Caused by: ";
/* 338 */     if (!topDown) {
/* 339 */       separatorLine = "Rethrown as: ";
/* 340 */       Collections.reverse(stacks);
/*     */     } 
/*     */ 
/*     */     
/* 344 */     if (trimStackFrames) {
/* 345 */       trimStackFrames(stacks);
/*     */     }
/*     */     
/* 348 */     synchronized (out) {
/* 349 */       for (Iterator iter = stacks.iterator(); iter.hasNext(); ) {
/* 350 */         String[] st = (String[])iter.next();
/* 351 */         for (int i = 0, len = st.length; i < len; i++) {
/* 352 */           out.println(st[i]);
/*     */         }
/* 354 */         if (iter.hasNext()) {
/* 355 */           out.print(separatorLine);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getStackFrames(Throwable t) {
/* 371 */     StringWriter sw = new StringWriter();
/* 372 */     PrintWriter pw = new PrintWriter(sw, true);
/*     */ 
/*     */     
/* 375 */     if (t instanceof Nestable) {
/* 376 */       ((Nestable)t).printPartialStackTrace(pw);
/*     */     } else {
/* 378 */       t.printStackTrace(pw);
/*     */     } 
/* 380 */     return ExceptionUtils.getStackFrames(sw.getBuffer().toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void trimStackFrames(List stacks) {
/* 392 */     for (int size = stacks.size(), i = size - 1; i > 0; i--) {
/* 393 */       String[] curr = stacks.get(i);
/* 394 */       String[] next = stacks.get(i - 1);
/*     */       
/* 396 */       List currList = new ArrayList(Arrays.asList((Object[])curr));
/* 397 */       List nextList = new ArrayList(Arrays.asList((Object[])next));
/* 398 */       ExceptionUtils.removeCommonFrames(currList, nextList);
/*     */       
/* 400 */       int trimmed = curr.length - currList.size();
/* 401 */       if (trimmed > 0) {
/* 402 */         currList.add("\t... " + trimmed + " more");
/* 403 */         stacks.set(
/* 404 */             i, 
/* 405 */             currList.toArray(new String[currList.size()]));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\exception\NestableDelegate.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */