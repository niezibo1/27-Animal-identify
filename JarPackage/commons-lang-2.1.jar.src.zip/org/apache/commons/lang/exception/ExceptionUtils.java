/*     */ package org.apache.commons.lang.exception;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.lang.ArrayUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.lang.SystemUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionUtils
/*     */ {
/*     */   static final String WRAPPED_MARKER = " [wrapped] ";
/*     */   
/*     */   static {
/*     */     Method getCauseMethod;
/*     */   }
/*     */   
/*  60 */   private static String[] CAUSE_METHOD_NAMES = new String[] { 
/*  61 */       "getCause", 
/*  62 */       "getNextException", 
/*  63 */       "getTargetException", 
/*  64 */       "getException", 
/*  65 */       "getSourceException", 
/*  66 */       "getRootCause", 
/*  67 */       "getCausedByException", 
/*  68 */       "getNested", 
/*  69 */       "getLinkedException", 
/*  70 */       "getNestedException", 
/*  71 */       "getLinkedCause", 
/*  72 */       "getThrowable" };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Method THROWABLE_CAUSE_METHOD;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  82 */       getCauseMethod = Throwable.class.getMethod("getCause", null);
/*  83 */     } catch (Exception exception) {
/*  84 */       getCauseMethod = null;
/*     */     } 
/*  86 */     THROWABLE_CAUSE_METHOD = getCauseMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addCauseMethodName(String methodName) {
/* 106 */     if (StringUtils.isNotEmpty(methodName) && !isCauseMethodName(methodName)) {
/* 107 */       List list = getCauseMethodNameList();
/* 108 */       if (list.add(methodName)) {
/* 109 */         CAUSE_METHOD_NAMES = toArray(list);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeCauseMethodName(String methodName) {
/* 123 */     if (StringUtils.isNotEmpty(methodName)) {
/* 124 */       List list = getCauseMethodNameList();
/* 125 */       if (list.remove(methodName)) {
/* 126 */         CAUSE_METHOD_NAMES = toArray(list);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] toArray(List list) {
/* 137 */     return (String[])list.toArray((Object[])new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ArrayList getCauseMethodNameList() {
/* 145 */     return new ArrayList(Arrays.asList((Object[])CAUSE_METHOD_NAMES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCauseMethodName(String methodName) {
/* 158 */     return !(ArrayUtils.indexOf((Object[])CAUSE_METHOD_NAMES, methodName) < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Throwable getCause(Throwable throwable) {
/* 193 */     return getCause(throwable, CAUSE_METHOD_NAMES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Throwable getCause(Throwable throwable, String[] methodNames) {
/* 215 */     if (throwable == null) {
/* 216 */       return null;
/*     */     }
/* 218 */     Throwable cause = getCauseUsingWellKnownTypes(throwable);
/* 219 */     if (cause == null) {
/* 220 */       if (methodNames == null) {
/* 221 */         methodNames = CAUSE_METHOD_NAMES;
/*     */       }
/* 223 */       for (int i = 0; i < methodNames.length; i++) {
/* 224 */         String methodName = methodNames[i];
/* 225 */         if (methodName != null) {
/* 226 */           cause = getCauseUsingMethodName(throwable, methodName);
/* 227 */           if (cause != null) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 233 */       if (cause == null) {
/* 234 */         cause = getCauseUsingFieldName(throwable, "detail");
/*     */       }
/*     */     } 
/* 237 */     return cause;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Throwable getRootCause(Throwable throwable) {
/* 252 */     Throwable cause = getCause(throwable);
/* 253 */     if (cause != null) {
/* 254 */       throwable = cause;
/* 255 */       while ((throwable = getCause(throwable)) != null) {
/* 256 */         cause = throwable;
/*     */       }
/*     */     } 
/* 259 */     return cause;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Throwable getCauseUsingWellKnownTypes(Throwable throwable) {
/* 273 */     if (throwable instanceof Nestable)
/* 274 */       return ((Nestable)throwable).getCause(); 
/* 275 */     if (throwable instanceof SQLException)
/* 276 */       return ((SQLException)throwable).getNextException(); 
/* 277 */     if (throwable instanceof InvocationTargetException) {
/* 278 */       return ((InvocationTargetException)throwable).getTargetException();
/*     */     }
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Throwable getCauseUsingMethodName(Throwable throwable, String methodName) {
/* 292 */     Method method = null;
/*     */     
/* 294 */     try { method = throwable.getClass().getMethod(methodName, null); }
/* 295 */     catch (NoSuchMethodException noSuchMethodException) {  }
/* 296 */     catch (SecurityException securityException) {}
/*     */ 
/*     */     
/* 299 */     if (method != null && Throwable.class.isAssignableFrom(method.getReturnType())) {
/*     */       
/* 301 */       try { return (Throwable)method.invoke(throwable, ArrayUtils.EMPTY_OBJECT_ARRAY); }
/* 302 */       catch (IllegalAccessException illegalAccessException) {  }
/* 303 */       catch (IllegalArgumentException illegalArgumentException) {  }
/* 304 */       catch (InvocationTargetException invocationTargetException) {}
/*     */     }
/*     */     
/* 307 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Throwable getCauseUsingFieldName(Throwable throwable, String fieldName) {
/* 318 */     Field field = null;
/*     */     
/* 320 */     try { field = throwable.getClass().getField(fieldName); }
/* 321 */     catch (NoSuchFieldException noSuchFieldException) {  }
/* 322 */     catch (SecurityException securityException) {}
/*     */ 
/*     */     
/* 325 */     if (field != null && Throwable.class.isAssignableFrom(field.getType())) {
/*     */       
/* 327 */       try { return (Throwable)field.get(throwable); }
/* 328 */       catch (IllegalAccessException illegalAccessException) {  }
/* 329 */       catch (IllegalArgumentException illegalArgumentException) {}
/*     */     }
/*     */     
/* 332 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isThrowableNested() {
/* 345 */     return !(THROWABLE_CAUSE_METHOD == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNestedThrowable(Throwable throwable) {
/* 358 */     if (throwable == null) {
/* 359 */       return false;
/*     */     }
/*     */     
/* 362 */     if (throwable instanceof Nestable)
/* 363 */       return true; 
/* 364 */     if (throwable instanceof SQLException)
/* 365 */       return true; 
/* 366 */     if (throwable instanceof InvocationTargetException)
/* 367 */       return true; 
/* 368 */     if (isThrowableNested()) {
/* 369 */       return true;
/*     */     }
/*     */     
/* 372 */     Class cls = throwable.getClass();
/* 373 */     for (int i = 0, isize = CAUSE_METHOD_NAMES.length; i < isize; i++) {
/*     */       
/* 375 */       try { Method method = cls.getMethod(CAUSE_METHOD_NAMES[i], null);
/* 376 */         if (method != null && Throwable.class.isAssignableFrom(method.getReturnType())) {
/* 377 */           return true;
/*     */         } }
/* 379 */       catch (NoSuchMethodException noSuchMethodException) {  }
/* 380 */       catch (SecurityException securityException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 385 */     try { Field field = cls.getField("detail");
/* 386 */       if (field != null) {
/* 387 */         return true;
/*     */       } }
/* 389 */     catch (NoSuchFieldException noSuchFieldException) {  }
/* 390 */     catch (SecurityException securityException) {}
/*     */ 
/*     */     
/* 393 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getThrowableCount(Throwable throwable) {
/* 409 */     int count = 0;
/* 410 */     while (throwable != null) {
/* 411 */       count++;
/* 412 */       throwable = getCause(throwable);
/*     */     } 
/* 414 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Throwable[] getThrowables(Throwable throwable) {
/* 431 */     List list = new ArrayList();
/* 432 */     while (throwable != null) {
/* 433 */       list.add(throwable);
/* 434 */       throwable = getCause(throwable);
/*     */     } 
/* 436 */     return list.<Throwable>toArray(new Throwable[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int indexOfThrowable(Throwable throwable, Class clazz) {
/* 455 */     return indexOf(throwable, clazz, 0, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int indexOfThrowable(Throwable throwable, Class clazz, int fromIndex) {
/* 478 */     return indexOf(throwable, clazz, fromIndex, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int indexOfType(Throwable throwable, Class type) {
/* 498 */     return indexOf(throwable, type, 0, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int indexOfType(Throwable throwable, Class type, int fromIndex) {
/* 522 */     return indexOf(throwable, type, fromIndex, true);
/*     */   }
/*     */   
/*     */   private static int indexOf(Throwable throwable, Class type, int fromIndex, boolean subclass) {
/* 526 */     if (throwable == null || type == null) {
/* 527 */       return -1;
/*     */     }
/* 529 */     if (fromIndex < 0) {
/* 530 */       fromIndex = 0;
/*     */     }
/* 532 */     Throwable[] throwables = getThrowables(throwable);
/* 533 */     if (fromIndex >= throwables.length) {
/* 534 */       return -1;
/*     */     }
/* 536 */     if (subclass) {
/* 537 */       for (int i = fromIndex; i < throwables.length; i++) {
/* 538 */         if (type.isAssignableFrom(throwables[i].getClass())) {
/* 539 */           return i;
/*     */         }
/*     */       } 
/*     */     } else {
/* 543 */       for (int i = fromIndex; i < throwables.length; i++) {
/* 544 */         if (type.equals(throwables[i].getClass())) {
/* 545 */           return i;
/*     */         }
/*     */       } 
/*     */     } 
/* 549 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printRootCauseStackTrace(Throwable throwable) {
/* 569 */     printRootCauseStackTrace(throwable, System.err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printRootCauseStackTrace(Throwable throwable, PrintStream stream) {
/* 589 */     if (throwable == null) {
/*     */       return;
/*     */     }
/* 592 */     if (stream == null) {
/* 593 */       throw new IllegalArgumentException("The PrintStream must not be null");
/*     */     }
/* 595 */     String[] trace = getRootCauseStackTrace(throwable);
/* 596 */     for (int i = 0; i < trace.length; i++) {
/* 597 */       stream.println(trace[i]);
/*     */     }
/* 599 */     stream.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printRootCauseStackTrace(Throwable throwable, PrintWriter writer) {
/* 619 */     if (throwable == null) {
/*     */       return;
/*     */     }
/* 622 */     if (writer == null) {
/* 623 */       throw new IllegalArgumentException("The PrintWriter must not be null");
/*     */     }
/* 625 */     String[] trace = getRootCauseStackTrace(throwable);
/* 626 */     for (int i = 0; i < trace.length; i++) {
/* 627 */       writer.println(trace[i]);
/*     */     }
/* 629 */     writer.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getRootCauseStackTrace(Throwable throwable) {
/* 642 */     if (throwable == null) {
/* 643 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*     */     }
/* 645 */     Throwable[] throwables = getThrowables(throwable);
/* 646 */     int count = throwables.length;
/* 647 */     ArrayList frames = new ArrayList();
/* 648 */     List nextTrace = getStackFrameList(throwables[count - 1]);
/* 649 */     for (int i = count; --i >= 0; ) {
/* 650 */       List trace = nextTrace;
/* 651 */       if (i != 0) {
/* 652 */         nextTrace = getStackFrameList(throwables[i - 1]);
/* 653 */         removeCommonFrames(trace, nextTrace);
/*     */       } 
/* 655 */       if (i == count - 1) {
/* 656 */         frames.add(throwables[i].toString());
/*     */       } else {
/* 658 */         frames.add(" [wrapped] " + throwables[i].toString());
/*     */       } 
/* 660 */       for (int j = 0; j < trace.size(); j++) {
/* 661 */         frames.add(trace.get(j));
/*     */       }
/*     */     } 
/* 664 */     return frames.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeCommonFrames(List causeFrames, List wrapperFrames) {
/* 676 */     if (causeFrames == null || wrapperFrames == null) {
/* 677 */       throw new IllegalArgumentException("The List must not be null");
/*     */     }
/* 679 */     int causeFrameIndex = causeFrames.size() - 1;
/* 680 */     int wrapperFrameIndex = wrapperFrames.size() - 1;
/* 681 */     while (causeFrameIndex >= 0 && wrapperFrameIndex >= 0) {
/*     */ 
/*     */       
/* 684 */       String causeFrame = causeFrames.get(causeFrameIndex);
/* 685 */       String wrapperFrame = wrapperFrames.get(wrapperFrameIndex);
/* 686 */       if (causeFrame.equals(wrapperFrame)) {
/* 687 */         causeFrames.remove(causeFrameIndex);
/*     */       }
/* 689 */       causeFrameIndex--;
/* 690 */       wrapperFrameIndex--;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getStackTrace(Throwable throwable) {
/* 703 */     StringWriter sw = new StringWriter();
/* 704 */     PrintWriter pw = new PrintWriter(sw, true);
/* 705 */     throwable.printStackTrace(pw);
/* 706 */     return sw.getBuffer().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFullStackTrace(Throwable throwable) {
/* 717 */     StringWriter sw = new StringWriter();
/* 718 */     PrintWriter pw = new PrintWriter(sw, true);
/* 719 */     Throwable[] ts = getThrowables(throwable);
/* 720 */     for (int i = 0; i < ts.length; i++) {
/* 721 */       ts[i].printStackTrace(pw);
/* 722 */       if (isNestedThrowable(ts[i])) {
/*     */         break;
/*     */       }
/*     */     } 
/* 726 */     return sw.getBuffer().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getStackFrames(Throwable throwable) {
/* 739 */     if (throwable == null) {
/* 740 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*     */     }
/* 742 */     return getStackFrames(getStackTrace(throwable));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String[] getStackFrames(String stackTrace) {
/* 757 */     String linebreak = SystemUtils.LINE_SEPARATOR;
/* 758 */     StringTokenizer frames = new StringTokenizer(stackTrace, linebreak);
/* 759 */     List list = new LinkedList();
/* 760 */     while (frames.hasMoreTokens()) {
/* 761 */       list.add(frames.nextToken());
/*     */     }
/* 763 */     return toArray(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static List getStackFrameList(Throwable t) {
/* 778 */     String stackTrace = getStackTrace(t);
/* 779 */     String linebreak = SystemUtils.LINE_SEPARATOR;
/* 780 */     StringTokenizer frames = new StringTokenizer(stackTrace, linebreak);
/* 781 */     List list = new LinkedList();
/* 782 */     boolean traceStarted = false;
/* 783 */     while (frames.hasMoreTokens()) {
/* 784 */       String token = frames.nextToken();
/*     */       
/* 786 */       int at = token.indexOf("at");
/* 787 */       if (at != -1 && token.substring(0, at).trim().length() == 0) {
/* 788 */         traceStarted = true;
/* 789 */         list.add(token); continue;
/* 790 */       }  if (traceStarted) {
/*     */         break;
/*     */       }
/*     */     } 
/* 794 */     return list;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\exception\ExceptionUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */