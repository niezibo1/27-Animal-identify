/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerializationUtils
/*     */ {
/*     */   public static Object clone(Serializable object) {
/*  79 */     return deserialize(serialize(object));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void serialize(Serializable obj, OutputStream outputStream) {
/* 100 */     if (outputStream == null) {
/* 101 */       throw new IllegalArgumentException("The OutputStream must not be null");
/*     */     }
/* 103 */     ObjectOutputStream out = null;
/*     */     
/*     */     try {
/* 106 */       out = new ObjectOutputStream(outputStream);
/* 107 */       out.writeObject(obj);
/*     */     }
/* 109 */     catch (IOException ex) {
/* 110 */       throw new SerializationException(ex);
/*     */     } finally {
/*     */       try {
/* 113 */         if (out != null) {
/* 114 */           out.close();
/*     */         }
/* 116 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] serialize(Serializable obj) {
/* 131 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
/* 132 */     serialize(obj, baos);
/* 133 */     return baos.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object deserialize(InputStream inputStream) {
/* 154 */     if (inputStream == null) {
/* 155 */       throw new IllegalArgumentException("The InputStream must not be null");
/*     */     }
/* 157 */     ObjectInputStream in = null;
/*     */     
/*     */     try {
/* 160 */       in = new ObjectInputStream(inputStream);
/* 161 */       return in.readObject();
/*     */     }
/* 163 */     catch (ClassNotFoundException ex) {
/* 164 */       throw new SerializationException(ex);
/* 165 */     } catch (IOException ex) {
/* 166 */       throw new SerializationException(ex);
/*     */     } finally {
/*     */       try {
/* 169 */         if (in != null) {
/* 170 */           in.close();
/*     */         }
/* 172 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object deserialize(byte[] objectData) {
/* 187 */     if (objectData == null) {
/* 188 */       throw new IllegalArgumentException("The byte[] must not be null");
/*     */     }
/* 190 */     ByteArrayInputStream bais = new ByteArrayInputStream(objectData);
/* 191 */     return deserialize(bais);
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\SerializationUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */