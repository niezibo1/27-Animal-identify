/*    */ package org.apache.commons.lang;
/*    */ 
/*    */ import org.apache.commons.lang.exception.NestableRuntimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializationException
/*    */   extends NestableRuntimeException
/*    */ {
/*    */   public SerializationException() {}
/*    */   
/*    */   public SerializationException(String msg) {
/* 46 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SerializationException(Throwable cause) {
/* 57 */     super(cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SerializationException(String msg, Throwable cause) {
/* 69 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\SerializationException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */