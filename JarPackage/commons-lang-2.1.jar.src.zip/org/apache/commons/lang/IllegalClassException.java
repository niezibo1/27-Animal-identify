/*    */ package org.apache.commons.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalClassException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   public IllegalClassException(Class expected, Object actual) {
/* 54 */     super(
/* 55 */         "Expected: " + 
/* 56 */         safeGetClassName(expected) + 
/* 57 */         ", actual: " + (
/* 58 */         (actual == null) ? "null" : actual.getClass().getName()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IllegalClassException(Class expected, Class actual) {
/* 68 */     super(
/* 69 */         "Expected: " + 
/* 70 */         safeGetClassName(expected) + 
/* 71 */         ", actual: " + 
/* 72 */         safeGetClassName(actual));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IllegalClassException(String message) {
/* 81 */     super(message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final String safeGetClassName(Class cls) {
/* 92 */     return (cls == null) ? null : cls.getName();
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\IllegalClassException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */