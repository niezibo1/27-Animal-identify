/*      */ package org.apache.commons.lang;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.lang.builder.EqualsBuilder;
/*      */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*      */ import org.apache.commons.lang.builder.ToStringBuilder;
/*      */ import org.apache.commons.lang.builder.ToStringStyle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ArrayUtils
/*      */ {
/*   54 */   public static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*      */ 
/*      */ 
/*      */   
/*   58 */   public static final Class[] EMPTY_CLASS_ARRAY = new Class[0];
/*      */ 
/*      */ 
/*      */   
/*   62 */   public static final String[] EMPTY_STRING_ARRAY = new String[0];
/*      */ 
/*      */ 
/*      */   
/*   66 */   public static final long[] EMPTY_LONG_ARRAY = new long[0];
/*      */ 
/*      */ 
/*      */   
/*   70 */   public static final Long[] EMPTY_LONG_OBJECT_ARRAY = new Long[0];
/*      */ 
/*      */ 
/*      */   
/*   74 */   public static final int[] EMPTY_INT_ARRAY = new int[0];
/*      */ 
/*      */ 
/*      */   
/*   78 */   public static final Integer[] EMPTY_INTEGER_OBJECT_ARRAY = new Integer[0];
/*      */ 
/*      */ 
/*      */   
/*   82 */   public static final short[] EMPTY_SHORT_ARRAY = new short[0];
/*      */ 
/*      */ 
/*      */   
/*   86 */   public static final Short[] EMPTY_SHORT_OBJECT_ARRAY = new Short[0];
/*      */ 
/*      */ 
/*      */   
/*   90 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*      */ 
/*      */ 
/*      */   
/*   94 */   public static final Byte[] EMPTY_BYTE_OBJECT_ARRAY = new Byte[0];
/*      */ 
/*      */ 
/*      */   
/*   98 */   public static final double[] EMPTY_DOUBLE_ARRAY = new double[0];
/*      */ 
/*      */ 
/*      */   
/*  102 */   public static final Double[] EMPTY_DOUBLE_OBJECT_ARRAY = new Double[0];
/*      */ 
/*      */ 
/*      */   
/*  106 */   public static final float[] EMPTY_FLOAT_ARRAY = new float[0];
/*      */ 
/*      */ 
/*      */   
/*  110 */   public static final Float[] EMPTY_FLOAT_OBJECT_ARRAY = new Float[0];
/*      */ 
/*      */ 
/*      */   
/*  114 */   public static final boolean[] EMPTY_BOOLEAN_ARRAY = new boolean[0];
/*      */ 
/*      */ 
/*      */   
/*  118 */   public static final Boolean[] EMPTY_BOOLEAN_OBJECT_ARRAY = new Boolean[0];
/*      */ 
/*      */ 
/*      */   
/*  122 */   public static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*      */ 
/*      */ 
/*      */   
/*  126 */   public static final Character[] EMPTY_CHARACTER_OBJECT_ARRAY = new Character[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(Object array) {
/*  152 */     return toString(array, "{}");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(Object array, String stringIfNull) {
/*  168 */     if (array == null) {
/*  169 */       return stringIfNull;
/*      */     }
/*  171 */     return (new ToStringBuilder(array, ToStringStyle.SIMPLE_STYLE)).append(array).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int hashCode(Object array) {
/*  183 */     return (new HashCodeBuilder()).append(array).toHashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEquals(Object array1, Object array2) {
/*  197 */     return (new EqualsBuilder()).append(array1, array2).isEquals();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map toMap(Object[] array) {
/*  228 */     if (array == null) {
/*  229 */       return null;
/*      */     }
/*  231 */     Map map = new HashMap((int)(array.length * 1.5D));
/*  232 */     for (int i = 0; i < array.length; i++) {
/*  233 */       Object object = array[i];
/*  234 */       if (object instanceof Map.Entry) {
/*  235 */         Map.Entry entry = (Map.Entry)object;
/*  236 */         map.put(entry.getKey(), entry.getValue());
/*  237 */       } else if (object instanceof Object[]) {
/*  238 */         Object[] entry = (Object[])object;
/*  239 */         if (entry.length < 2) {
/*  240 */           throw new IllegalArgumentException("Array element " + i + ", '" + 
/*  241 */               object + 
/*  242 */               "', has a length less than 2");
/*      */         }
/*  244 */         map.put(entry[0], entry[1]);
/*      */       } else {
/*  246 */         throw new IllegalArgumentException("Array element " + i + ", '" + 
/*  247 */             object + 
/*  248 */             "', is neither of type Map.Entry nor an Array");
/*      */       } 
/*      */     } 
/*  251 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] clone(Object[] array) {
/*  269 */     if (array == null) {
/*  270 */       return null;
/*      */     }
/*  272 */     return (Object[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] clone(long[] array) {
/*  285 */     if (array == null) {
/*  286 */       return null;
/*      */     }
/*  288 */     return (long[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] clone(int[] array) {
/*  301 */     if (array == null) {
/*  302 */       return null;
/*      */     }
/*  304 */     return (int[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] clone(short[] array) {
/*  317 */     if (array == null) {
/*  318 */       return null;
/*      */     }
/*  320 */     return (short[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] clone(char[] array) {
/*  333 */     if (array == null) {
/*  334 */       return null;
/*      */     }
/*  336 */     return (char[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] clone(byte[] array) {
/*  349 */     if (array == null) {
/*  350 */       return null;
/*      */     }
/*  352 */     return (byte[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] clone(double[] array) {
/*  365 */     if (array == null) {
/*  366 */       return null;
/*      */     }
/*  368 */     return (double[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] clone(float[] array) {
/*  381 */     if (array == null) {
/*  382 */       return null;
/*      */     }
/*  384 */     return (float[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] clone(boolean[] array) {
/*  397 */     if (array == null) {
/*  398 */       return null;
/*      */     }
/*  400 */     return (boolean[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] subarray(Object[] array, int startIndexInclusive, int endIndexExclusive) {
/*  433 */     if (array == null) {
/*  434 */       return null;
/*      */     }
/*  436 */     if (startIndexInclusive < 0) {
/*  437 */       startIndexInclusive = 0;
/*      */     }
/*  439 */     if (endIndexExclusive > array.length) {
/*  440 */       endIndexExclusive = array.length;
/*      */     }
/*  442 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  443 */     Class type = array.getClass().getComponentType();
/*  444 */     if (newSize <= 0) {
/*  445 */       return (Object[])Array.newInstance(type, 0);
/*      */     }
/*  447 */     Object[] subarray = (Object[])Array.newInstance(type, newSize);
/*  448 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  449 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] subarray(long[] array, int startIndexInclusive, int endIndexExclusive) {
/*  472 */     if (array == null) {
/*  473 */       return null;
/*      */     }
/*  475 */     if (startIndexInclusive < 0) {
/*  476 */       startIndexInclusive = 0;
/*      */     }
/*  478 */     if (endIndexExclusive > array.length) {
/*  479 */       endIndexExclusive = array.length;
/*      */     }
/*  481 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  482 */     if (newSize <= 0) {
/*  483 */       return EMPTY_LONG_ARRAY;
/*      */     }
/*      */     
/*  486 */     long[] subarray = new long[newSize];
/*  487 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  488 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] subarray(int[] array, int startIndexInclusive, int endIndexExclusive) {
/*  511 */     if (array == null) {
/*  512 */       return null;
/*      */     }
/*  514 */     if (startIndexInclusive < 0) {
/*  515 */       startIndexInclusive = 0;
/*      */     }
/*  517 */     if (endIndexExclusive > array.length) {
/*  518 */       endIndexExclusive = array.length;
/*      */     }
/*  520 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  521 */     if (newSize <= 0) {
/*  522 */       return EMPTY_INT_ARRAY;
/*      */     }
/*      */     
/*  525 */     int[] subarray = new int[newSize];
/*  526 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  527 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] subarray(short[] array, int startIndexInclusive, int endIndexExclusive) {
/*  550 */     if (array == null) {
/*  551 */       return null;
/*      */     }
/*  553 */     if (startIndexInclusive < 0) {
/*  554 */       startIndexInclusive = 0;
/*      */     }
/*  556 */     if (endIndexExclusive > array.length) {
/*  557 */       endIndexExclusive = array.length;
/*      */     }
/*  559 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  560 */     if (newSize <= 0) {
/*  561 */       return EMPTY_SHORT_ARRAY;
/*      */     }
/*      */     
/*  564 */     short[] subarray = new short[newSize];
/*  565 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  566 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] subarray(char[] array, int startIndexInclusive, int endIndexExclusive) {
/*  589 */     if (array == null) {
/*  590 */       return null;
/*      */     }
/*  592 */     if (startIndexInclusive < 0) {
/*  593 */       startIndexInclusive = 0;
/*      */     }
/*  595 */     if (endIndexExclusive > array.length) {
/*  596 */       endIndexExclusive = array.length;
/*      */     }
/*  598 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  599 */     if (newSize <= 0) {
/*  600 */       return EMPTY_CHAR_ARRAY;
/*      */     }
/*      */     
/*  603 */     char[] subarray = new char[newSize];
/*  604 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  605 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] subarray(byte[] array, int startIndexInclusive, int endIndexExclusive) {
/*  628 */     if (array == null) {
/*  629 */       return null;
/*      */     }
/*  631 */     if (startIndexInclusive < 0) {
/*  632 */       startIndexInclusive = 0;
/*      */     }
/*  634 */     if (endIndexExclusive > array.length) {
/*  635 */       endIndexExclusive = array.length;
/*      */     }
/*  637 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  638 */     if (newSize <= 0) {
/*  639 */       return EMPTY_BYTE_ARRAY;
/*      */     }
/*      */     
/*  642 */     byte[] subarray = new byte[newSize];
/*  643 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  644 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] subarray(double[] array, int startIndexInclusive, int endIndexExclusive) {
/*  667 */     if (array == null) {
/*  668 */       return null;
/*      */     }
/*  670 */     if (startIndexInclusive < 0) {
/*  671 */       startIndexInclusive = 0;
/*      */     }
/*  673 */     if (endIndexExclusive > array.length) {
/*  674 */       endIndexExclusive = array.length;
/*      */     }
/*  676 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  677 */     if (newSize <= 0) {
/*  678 */       return EMPTY_DOUBLE_ARRAY;
/*      */     }
/*      */     
/*  681 */     double[] subarray = new double[newSize];
/*  682 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  683 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] subarray(float[] array, int startIndexInclusive, int endIndexExclusive) {
/*  706 */     if (array == null) {
/*  707 */       return null;
/*      */     }
/*  709 */     if (startIndexInclusive < 0) {
/*  710 */       startIndexInclusive = 0;
/*      */     }
/*  712 */     if (endIndexExclusive > array.length) {
/*  713 */       endIndexExclusive = array.length;
/*      */     }
/*  715 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  716 */     if (newSize <= 0) {
/*  717 */       return EMPTY_FLOAT_ARRAY;
/*      */     }
/*      */     
/*  720 */     float[] subarray = new float[newSize];
/*  721 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  722 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] subarray(boolean[] array, int startIndexInclusive, int endIndexExclusive) {
/*  745 */     if (array == null) {
/*  746 */       return null;
/*      */     }
/*  748 */     if (startIndexInclusive < 0) {
/*  749 */       startIndexInclusive = 0;
/*      */     }
/*  751 */     if (endIndexExclusive > array.length) {
/*  752 */       endIndexExclusive = array.length;
/*      */     }
/*  754 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  755 */     if (newSize <= 0) {
/*  756 */       return EMPTY_BOOLEAN_ARRAY;
/*      */     }
/*      */     
/*  759 */     boolean[] subarray = new boolean[newSize];
/*  760 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  761 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(Object[] array1, Object[] array2) {
/*  778 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  779 */       array2 == null && array1 != null && array1.length > 0) || (
/*  780 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  781 */       return false;
/*      */     }
/*  783 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(long[] array1, long[] array2) {
/*  796 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  797 */       array2 == null && array1 != null && array1.length > 0) || (
/*  798 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  799 */       return false;
/*      */     }
/*  801 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(int[] array1, int[] array2) {
/*  814 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  815 */       array2 == null && array1 != null && array1.length > 0) || (
/*  816 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  817 */       return false;
/*      */     }
/*  819 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(short[] array1, short[] array2) {
/*  832 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  833 */       array2 == null && array1 != null && array1.length > 0) || (
/*  834 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  835 */       return false;
/*      */     }
/*  837 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(char[] array1, char[] array2) {
/*  850 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  851 */       array2 == null && array1 != null && array1.length > 0) || (
/*  852 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  853 */       return false;
/*      */     }
/*  855 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(byte[] array1, byte[] array2) {
/*  868 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  869 */       array2 == null && array1 != null && array1.length > 0) || (
/*  870 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  871 */       return false;
/*      */     }
/*  873 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(double[] array1, double[] array2) {
/*  886 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  887 */       array2 == null && array1 != null && array1.length > 0) || (
/*  888 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  889 */       return false;
/*      */     }
/*  891 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(float[] array1, float[] array2) {
/*  904 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  905 */       array2 == null && array1 != null && array1.length > 0) || (
/*  906 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  907 */       return false;
/*      */     }
/*  909 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(boolean[] array1, boolean[] array2) {
/*  922 */     if ((array1 == null && array2 != null && array2.length > 0) || (
/*  923 */       array2 == null && array1 != null && array1.length > 0) || (
/*  924 */       array1 != null && array2 != null && array1.length != array2.length)) {
/*  925 */       return false;
/*      */     }
/*  927 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getLength(Object array) {
/*  952 */     if (array == null) {
/*  953 */       return 0;
/*      */     }
/*  955 */     return Array.getLength(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameType(Object array1, Object array2) {
/*  969 */     if (array1 == null || array2 == null) {
/*  970 */       throw new IllegalArgumentException("The Array must not be null");
/*      */     }
/*  972 */     return array1.getClass().getName().equals(array2.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(Object[] array) {
/*  987 */     if (array == null) {
/*      */       return;
/*      */     }
/*  990 */     int i = 0;
/*  991 */     int j = array.length - 1;
/*      */     
/*  993 */     while (j > i) {
/*  994 */       Object tmp = array[j];
/*  995 */       array[j] = array[i];
/*  996 */       array[i] = tmp;
/*  997 */       j--;
/*  998 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(long[] array) {
/* 1010 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1013 */     int i = 0;
/* 1014 */     int j = array.length - 1;
/*      */     
/* 1016 */     while (j > i) {
/* 1017 */       long tmp = array[j];
/* 1018 */       array[j] = array[i];
/* 1019 */       array[i] = tmp;
/* 1020 */       j--;
/* 1021 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(int[] array) {
/* 1033 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1036 */     int i = 0;
/* 1037 */     int j = array.length - 1;
/*      */     
/* 1039 */     while (j > i) {
/* 1040 */       int tmp = array[j];
/* 1041 */       array[j] = array[i];
/* 1042 */       array[i] = tmp;
/* 1043 */       j--;
/* 1044 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(short[] array) {
/* 1056 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1059 */     int i = 0;
/* 1060 */     int j = array.length - 1;
/*      */     
/* 1062 */     while (j > i) {
/* 1063 */       short tmp = array[j];
/* 1064 */       array[j] = array[i];
/* 1065 */       array[i] = tmp;
/* 1066 */       j--;
/* 1067 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(char[] array) {
/* 1079 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1082 */     int i = 0;
/* 1083 */     int j = array.length - 1;
/*      */     
/* 1085 */     while (j > i) {
/* 1086 */       char tmp = array[j];
/* 1087 */       array[j] = array[i];
/* 1088 */       array[i] = tmp;
/* 1089 */       j--;
/* 1090 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(byte[] array) {
/* 1102 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1105 */     int i = 0;
/* 1106 */     int j = array.length - 1;
/*      */     
/* 1108 */     while (j > i) {
/* 1109 */       byte tmp = array[j];
/* 1110 */       array[j] = array[i];
/* 1111 */       array[i] = tmp;
/* 1112 */       j--;
/* 1113 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(double[] array) {
/* 1125 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1128 */     int i = 0;
/* 1129 */     int j = array.length - 1;
/*      */     
/* 1131 */     while (j > i) {
/* 1132 */       double tmp = array[j];
/* 1133 */       array[j] = array[i];
/* 1134 */       array[i] = tmp;
/* 1135 */       j--;
/* 1136 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(float[] array) {
/* 1148 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1151 */     int i = 0;
/* 1152 */     int j = array.length - 1;
/*      */     
/* 1154 */     while (j > i) {
/* 1155 */       float tmp = array[j];
/* 1156 */       array[j] = array[i];
/* 1157 */       array[i] = tmp;
/* 1158 */       j--;
/* 1159 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(boolean[] array) {
/* 1171 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1174 */     int i = 0;
/* 1175 */     int j = array.length - 1;
/*      */     
/* 1177 */     while (j > i) {
/* 1178 */       boolean tmp = array[j];
/* 1179 */       array[j] = array[i];
/* 1180 */       array[i] = tmp;
/* 1181 */       j--;
/* 1182 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(Object[] array, Object objectToFind) {
/* 1202 */     return indexOf(array, objectToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(Object[] array, Object objectToFind, int startIndex) {
/* 1220 */     if (array == null) {
/* 1221 */       return -1;
/*      */     }
/* 1223 */     if (startIndex < 0) {
/* 1224 */       startIndex = 0;
/*      */     }
/* 1226 */     if (objectToFind == null) {
/* 1227 */       for (int i = startIndex; i < array.length; i++) {
/* 1228 */         if (array[i] == null) {
/* 1229 */           return i;
/*      */         }
/*      */       } 
/*      */     } else {
/* 1233 */       for (int i = startIndex; i < array.length; i++) {
/* 1234 */         if (objectToFind.equals(array[i])) {
/* 1235 */           return i;
/*      */         }
/*      */       } 
/*      */     } 
/* 1239 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(Object[] array, Object objectToFind) {
/* 1253 */     return lastIndexOf(array, objectToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(Object[] array, Object objectToFind, int startIndex) {
/* 1271 */     if (array == null) {
/* 1272 */       return -1;
/*      */     }
/* 1274 */     if (startIndex < 0)
/* 1275 */       return -1; 
/* 1276 */     if (startIndex >= array.length) {
/* 1277 */       startIndex = array.length - 1;
/*      */     }
/* 1279 */     if (objectToFind == null) {
/* 1280 */       for (int i = startIndex; i >= 0; i--) {
/* 1281 */         if (array[i] == null) {
/* 1282 */           return i;
/*      */         }
/*      */       } 
/*      */     } else {
/* 1286 */       for (int i = startIndex; i >= 0; i--) {
/* 1287 */         if (objectToFind.equals(array[i])) {
/* 1288 */           return i;
/*      */         }
/*      */       } 
/*      */     } 
/* 1292 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(Object[] array, Object objectToFind) {
/* 1305 */     return !(indexOf(array, objectToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(long[] array, long valueToFind) {
/* 1321 */     return indexOf(array, valueToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(long[] array, long valueToFind, int startIndex) {
/* 1339 */     if (array == null) {
/* 1340 */       return -1;
/*      */     }
/* 1342 */     if (startIndex < 0) {
/* 1343 */       startIndex = 0;
/*      */     }
/* 1345 */     for (int i = startIndex; i < array.length; i++) {
/* 1346 */       if (valueToFind == array[i]) {
/* 1347 */         return i;
/*      */       }
/*      */     } 
/* 1350 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(long[] array, long valueToFind) {
/* 1364 */     return lastIndexOf(array, valueToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(long[] array, long valueToFind, int startIndex) {
/* 1382 */     if (array == null) {
/* 1383 */       return -1;
/*      */     }
/* 1385 */     if (startIndex < 0)
/* 1386 */       return -1; 
/* 1387 */     if (startIndex >= array.length) {
/* 1388 */       startIndex = array.length - 1;
/*      */     }
/* 1390 */     for (int i = startIndex; i >= 0; i--) {
/* 1391 */       if (valueToFind == array[i]) {
/* 1392 */         return i;
/*      */       }
/*      */     } 
/* 1395 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(long[] array, long valueToFind) {
/* 1408 */     return !(indexOf(array, valueToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(int[] array, int valueToFind) {
/* 1424 */     return indexOf(array, valueToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(int[] array, int valueToFind, int startIndex) {
/* 1442 */     if (array == null) {
/* 1443 */       return -1;
/*      */     }
/* 1445 */     if (startIndex < 0) {
/* 1446 */       startIndex = 0;
/*      */     }
/* 1448 */     for (int i = startIndex; i < array.length; i++) {
/* 1449 */       if (valueToFind == array[i]) {
/* 1450 */         return i;
/*      */       }
/*      */     } 
/* 1453 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(int[] array, int valueToFind) {
/* 1467 */     return lastIndexOf(array, valueToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(int[] array, int valueToFind, int startIndex) {
/* 1485 */     if (array == null) {
/* 1486 */       return -1;
/*      */     }
/* 1488 */     if (startIndex < 0)
/* 1489 */       return -1; 
/* 1490 */     if (startIndex >= array.length) {
/* 1491 */       startIndex = array.length - 1;
/*      */     }
/* 1493 */     for (int i = startIndex; i >= 0; i--) {
/* 1494 */       if (valueToFind == array[i]) {
/* 1495 */         return i;
/*      */       }
/*      */     } 
/* 1498 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(int[] array, int valueToFind) {
/* 1511 */     return !(indexOf(array, valueToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(short[] array, short valueToFind) {
/* 1527 */     return indexOf(array, valueToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(short[] array, short valueToFind, int startIndex) {
/* 1545 */     if (array == null) {
/* 1546 */       return -1;
/*      */     }
/* 1548 */     if (startIndex < 0) {
/* 1549 */       startIndex = 0;
/*      */     }
/* 1551 */     for (int i = startIndex; i < array.length; i++) {
/* 1552 */       if (valueToFind == array[i]) {
/* 1553 */         return i;
/*      */       }
/*      */     } 
/* 1556 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(short[] array, short valueToFind) {
/* 1570 */     return lastIndexOf(array, valueToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(short[] array, short valueToFind, int startIndex) {
/* 1588 */     if (array == null) {
/* 1589 */       return -1;
/*      */     }
/* 1591 */     if (startIndex < 0)
/* 1592 */       return -1; 
/* 1593 */     if (startIndex >= array.length) {
/* 1594 */       startIndex = array.length - 1;
/*      */     }
/* 1596 */     for (int i = startIndex; i >= 0; i--) {
/* 1597 */       if (valueToFind == array[i]) {
/* 1598 */         return i;
/*      */       }
/*      */     } 
/* 1601 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(short[] array, short valueToFind) {
/* 1614 */     return !(indexOf(array, valueToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(char[] array, char valueToFind) {
/* 1631 */     return indexOf(array, valueToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(char[] array, char valueToFind, int startIndex) {
/* 1650 */     if (array == null) {
/* 1651 */       return -1;
/*      */     }
/* 1653 */     if (startIndex < 0) {
/* 1654 */       startIndex = 0;
/*      */     }
/* 1656 */     for (int i = startIndex; i < array.length; i++) {
/* 1657 */       if (valueToFind == array[i]) {
/* 1658 */         return i;
/*      */       }
/*      */     } 
/* 1661 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(char[] array, char valueToFind) {
/* 1676 */     return lastIndexOf(array, valueToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(char[] array, char valueToFind, int startIndex) {
/* 1695 */     if (array == null) {
/* 1696 */       return -1;
/*      */     }
/* 1698 */     if (startIndex < 0)
/* 1699 */       return -1; 
/* 1700 */     if (startIndex >= array.length) {
/* 1701 */       startIndex = array.length - 1;
/*      */     }
/* 1703 */     for (int i = startIndex; i >= 0; i--) {
/* 1704 */       if (valueToFind == array[i]) {
/* 1705 */         return i;
/*      */       }
/*      */     } 
/* 1708 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(char[] array, char valueToFind) {
/* 1722 */     return !(indexOf(array, valueToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(byte[] array, byte valueToFind) {
/* 1738 */     return indexOf(array, valueToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(byte[] array, byte valueToFind, int startIndex) {
/* 1756 */     if (array == null) {
/* 1757 */       return -1;
/*      */     }
/* 1759 */     if (startIndex < 0) {
/* 1760 */       startIndex = 0;
/*      */     }
/* 1762 */     for (int i = startIndex; i < array.length; i++) {
/* 1763 */       if (valueToFind == array[i]) {
/* 1764 */         return i;
/*      */       }
/*      */     } 
/* 1767 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(byte[] array, byte valueToFind) {
/* 1781 */     return lastIndexOf(array, valueToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(byte[] array, byte valueToFind, int startIndex) {
/* 1799 */     if (array == null) {
/* 1800 */       return -1;
/*      */     }
/* 1802 */     if (startIndex < 0)
/* 1803 */       return -1; 
/* 1804 */     if (startIndex >= array.length) {
/* 1805 */       startIndex = array.length - 1;
/*      */     }
/* 1807 */     for (int i = startIndex; i >= 0; i--) {
/* 1808 */       if (valueToFind == array[i]) {
/* 1809 */         return i;
/*      */       }
/*      */     } 
/* 1812 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(byte[] array, byte valueToFind) {
/* 1825 */     return !(indexOf(array, valueToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(double[] array, double valueToFind) {
/* 1841 */     return indexOf(array, valueToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(double[] array, double valueToFind, double tolerance) {
/* 1858 */     return indexOf(array, valueToFind, 0, tolerance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(double[] array, double valueToFind, int startIndex) {
/* 1876 */     if (isEmpty(array)) {
/* 1877 */       return -1;
/*      */     }
/* 1879 */     if (startIndex < 0) {
/* 1880 */       startIndex = 0;
/*      */     }
/* 1882 */     for (int i = startIndex; i < array.length; i++) {
/* 1883 */       if (valueToFind == array[i]) {
/* 1884 */         return i;
/*      */       }
/*      */     } 
/* 1887 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(double[] array, double valueToFind, int startIndex, double tolerance) {
/* 1908 */     if (isEmpty(array)) {
/* 1909 */       return -1;
/*      */     }
/* 1911 */     if (startIndex < 0) {
/* 1912 */       startIndex = 0;
/*      */     }
/* 1914 */     double min = valueToFind - tolerance;
/* 1915 */     double max = valueToFind + tolerance;
/* 1916 */     for (int i = startIndex; i < array.length; i++) {
/* 1917 */       if (array[i] >= min && array[i] <= max) {
/* 1918 */         return i;
/*      */       }
/*      */     } 
/* 1921 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(double[] array, double valueToFind) {
/* 1935 */     return lastIndexOf(array, valueToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(double[] array, double valueToFind, double tolerance) {
/* 1952 */     return lastIndexOf(array, valueToFind, 2147483647, tolerance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(double[] array, double valueToFind, int startIndex) {
/* 1970 */     if (isEmpty(array)) {
/* 1971 */       return -1;
/*      */     }
/* 1973 */     if (startIndex < 0)
/* 1974 */       return -1; 
/* 1975 */     if (startIndex >= array.length) {
/* 1976 */       startIndex = array.length - 1;
/*      */     }
/* 1978 */     for (int i = startIndex; i >= 0; i--) {
/* 1979 */       if (valueToFind == array[i]) {
/* 1980 */         return i;
/*      */       }
/*      */     } 
/* 1983 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(double[] array, double valueToFind, int startIndex, double tolerance) {
/* 2004 */     if (isEmpty(array)) {
/* 2005 */       return -1;
/*      */     }
/* 2007 */     if (startIndex < 0)
/* 2008 */       return -1; 
/* 2009 */     if (startIndex >= array.length) {
/* 2010 */       startIndex = array.length - 1;
/*      */     }
/* 2012 */     double min = valueToFind - tolerance;
/* 2013 */     double max = valueToFind + tolerance;
/* 2014 */     for (int i = startIndex; i >= 0; i--) {
/* 2015 */       if (array[i] >= min && array[i] <= max) {
/* 2016 */         return i;
/*      */       }
/*      */     } 
/* 2019 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(double[] array, double valueToFind) {
/* 2032 */     return !(indexOf(array, valueToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(double[] array, double valueToFind, double tolerance) {
/* 2049 */     return !(indexOf(array, valueToFind, 0, tolerance) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(float[] array, float valueToFind) {
/* 2065 */     return indexOf(array, valueToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(float[] array, float valueToFind, int startIndex) {
/* 2083 */     if (isEmpty(array)) {
/* 2084 */       return -1;
/*      */     }
/* 2086 */     if (startIndex < 0) {
/* 2087 */       startIndex = 0;
/*      */     }
/* 2089 */     for (int i = startIndex; i < array.length; i++) {
/* 2090 */       if (valueToFind == array[i]) {
/* 2091 */         return i;
/*      */       }
/*      */     } 
/* 2094 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(float[] array, float valueToFind) {
/* 2108 */     return lastIndexOf(array, valueToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(float[] array, float valueToFind, int startIndex) {
/* 2126 */     if (isEmpty(array)) {
/* 2127 */       return -1;
/*      */     }
/* 2129 */     if (startIndex < 0)
/* 2130 */       return -1; 
/* 2131 */     if (startIndex >= array.length) {
/* 2132 */       startIndex = array.length - 1;
/*      */     }
/* 2134 */     for (int i = startIndex; i >= 0; i--) {
/* 2135 */       if (valueToFind == array[i]) {
/* 2136 */         return i;
/*      */       }
/*      */     } 
/* 2139 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(float[] array, float valueToFind) {
/* 2152 */     return !(indexOf(array, valueToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(boolean[] array, boolean valueToFind) {
/* 2168 */     return indexOf(array, valueToFind, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(boolean[] array, boolean valueToFind, int startIndex) {
/* 2186 */     if (isEmpty(array)) {
/* 2187 */       return -1;
/*      */     }
/* 2189 */     if (startIndex < 0) {
/* 2190 */       startIndex = 0;
/*      */     }
/* 2192 */     for (int i = startIndex; i < array.length; i++) {
/* 2193 */       if (valueToFind == array[i]) {
/* 2194 */         return i;
/*      */       }
/*      */     } 
/* 2197 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(boolean[] array, boolean valueToFind) {
/* 2211 */     return lastIndexOf(array, valueToFind, 2147483647);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(boolean[] array, boolean valueToFind, int startIndex) {
/* 2229 */     if (isEmpty(array)) {
/* 2230 */       return -1;
/*      */     }
/* 2232 */     if (startIndex < 0)
/* 2233 */       return -1; 
/* 2234 */     if (startIndex >= array.length) {
/* 2235 */       startIndex = array.length - 1;
/*      */     }
/* 2237 */     for (int i = startIndex; i >= 0; i--) {
/* 2238 */       if (valueToFind == array[i]) {
/* 2239 */         return i;
/*      */       }
/*      */     } 
/* 2242 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(boolean[] array, boolean valueToFind) {
/* 2255 */     return !(indexOf(array, valueToFind) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] toPrimitive(Long[] array) {
/* 2273 */     if (array == null)
/* 2274 */       return null; 
/* 2275 */     if (array.length == 0) {
/* 2276 */       return EMPTY_LONG_ARRAY;
/*      */     }
/* 2278 */     long[] result = new long[array.length];
/* 2279 */     for (int i = 0; i < array.length; i++) {
/* 2280 */       result[i] = array[i].longValue();
/*      */     }
/* 2282 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] toPrimitive(Long[] array, long valueForNull) {
/* 2295 */     if (array == null)
/* 2296 */       return null; 
/* 2297 */     if (array.length == 0) {
/* 2298 */       return EMPTY_LONG_ARRAY;
/*      */     }
/* 2300 */     long[] result = new long[array.length];
/* 2301 */     for (int i = 0; i < array.length; i++) {
/* 2302 */       Long b = array[i];
/* 2303 */       result[i] = (b == null) ? valueForNull : b.longValue();
/*      */     } 
/* 2305 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long[] toObject(long[] array) {
/* 2317 */     if (array == null)
/* 2318 */       return null; 
/* 2319 */     if (array.length == 0) {
/* 2320 */       return EMPTY_LONG_OBJECT_ARRAY;
/*      */     }
/* 2322 */     Long[] result = new Long[array.length];
/* 2323 */     for (int i = 0; i < array.length; i++) {
/* 2324 */       result[i] = new Long(array[i]);
/*      */     }
/* 2326 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] toPrimitive(Integer[] array) {
/* 2341 */     if (array == null)
/* 2342 */       return null; 
/* 2343 */     if (array.length == 0) {
/* 2344 */       return EMPTY_INT_ARRAY;
/*      */     }
/* 2346 */     int[] result = new int[array.length];
/* 2347 */     for (int i = 0; i < array.length; i++) {
/* 2348 */       result[i] = array[i].intValue();
/*      */     }
/* 2350 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] toPrimitive(Integer[] array, int valueForNull) {
/* 2363 */     if (array == null)
/* 2364 */       return null; 
/* 2365 */     if (array.length == 0) {
/* 2366 */       return EMPTY_INT_ARRAY;
/*      */     }
/* 2368 */     int[] result = new int[array.length];
/* 2369 */     for (int i = 0; i < array.length; i++) {
/* 2370 */       Integer b = array[i];
/* 2371 */       result[i] = (b == null) ? valueForNull : b.intValue();
/*      */     } 
/* 2373 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer[] toObject(int[] array) {
/* 2385 */     if (array == null)
/* 2386 */       return null; 
/* 2387 */     if (array.length == 0) {
/* 2388 */       return EMPTY_INTEGER_OBJECT_ARRAY;
/*      */     }
/* 2390 */     Integer[] result = new Integer[array.length];
/* 2391 */     for (int i = 0; i < array.length; i++) {
/* 2392 */       result[i] = new Integer(array[i]);
/*      */     }
/* 2394 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] toPrimitive(Short[] array) {
/* 2409 */     if (array == null)
/* 2410 */       return null; 
/* 2411 */     if (array.length == 0) {
/* 2412 */       return EMPTY_SHORT_ARRAY;
/*      */     }
/* 2414 */     short[] result = new short[array.length];
/* 2415 */     for (int i = 0; i < array.length; i++) {
/* 2416 */       result[i] = array[i].shortValue();
/*      */     }
/* 2418 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] toPrimitive(Short[] array, short valueForNull) {
/* 2431 */     if (array == null)
/* 2432 */       return null; 
/* 2433 */     if (array.length == 0) {
/* 2434 */       return EMPTY_SHORT_ARRAY;
/*      */     }
/* 2436 */     short[] result = new short[array.length];
/* 2437 */     for (int i = 0; i < array.length; i++) {
/* 2438 */       Short b = array[i];
/* 2439 */       result[i] = (b == null) ? valueForNull : b.shortValue();
/*      */     } 
/* 2441 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Short[] toObject(short[] array) {
/* 2453 */     if (array == null)
/* 2454 */       return null; 
/* 2455 */     if (array.length == 0) {
/* 2456 */       return EMPTY_SHORT_OBJECT_ARRAY;
/*      */     }
/* 2458 */     Short[] result = new Short[array.length];
/* 2459 */     for (int i = 0; i < array.length; i++) {
/* 2460 */       result[i] = new Short(array[i]);
/*      */     }
/* 2462 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toPrimitive(Byte[] array) {
/* 2477 */     if (array == null)
/* 2478 */       return null; 
/* 2479 */     if (array.length == 0) {
/* 2480 */       return EMPTY_BYTE_ARRAY;
/*      */     }
/* 2482 */     byte[] result = new byte[array.length];
/* 2483 */     for (int i = 0; i < array.length; i++) {
/* 2484 */       result[i] = array[i].byteValue();
/*      */     }
/* 2486 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toPrimitive(Byte[] array, byte valueForNull) {
/* 2499 */     if (array == null)
/* 2500 */       return null; 
/* 2501 */     if (array.length == 0) {
/* 2502 */       return EMPTY_BYTE_ARRAY;
/*      */     }
/* 2504 */     byte[] result = new byte[array.length];
/* 2505 */     for (int i = 0; i < array.length; i++) {
/* 2506 */       Byte b = array[i];
/* 2507 */       result[i] = (b == null) ? valueForNull : b.byteValue();
/*      */     } 
/* 2509 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Byte[] toObject(byte[] array) {
/* 2521 */     if (array == null)
/* 2522 */       return null; 
/* 2523 */     if (array.length == 0) {
/* 2524 */       return EMPTY_BYTE_OBJECT_ARRAY;
/*      */     }
/* 2526 */     Byte[] result = new Byte[array.length];
/* 2527 */     for (int i = 0; i < array.length; i++) {
/* 2528 */       result[i] = new Byte(array[i]);
/*      */     }
/* 2530 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] toPrimitive(Double[] array) {
/* 2545 */     if (array == null)
/* 2546 */       return null; 
/* 2547 */     if (array.length == 0) {
/* 2548 */       return EMPTY_DOUBLE_ARRAY;
/*      */     }
/* 2550 */     double[] result = new double[array.length];
/* 2551 */     for (int i = 0; i < array.length; i++) {
/* 2552 */       result[i] = array[i].doubleValue();
/*      */     }
/* 2554 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] toPrimitive(Double[] array, double valueForNull) {
/* 2567 */     if (array == null)
/* 2568 */       return null; 
/* 2569 */     if (array.length == 0) {
/* 2570 */       return EMPTY_DOUBLE_ARRAY;
/*      */     }
/* 2572 */     double[] result = new double[array.length];
/* 2573 */     for (int i = 0; i < array.length; i++) {
/* 2574 */       Double b = array[i];
/* 2575 */       result[i] = (b == null) ? valueForNull : b.doubleValue();
/*      */     } 
/* 2577 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double[] toObject(double[] array) {
/* 2589 */     if (array == null)
/* 2590 */       return null; 
/* 2591 */     if (array.length == 0) {
/* 2592 */       return EMPTY_DOUBLE_OBJECT_ARRAY;
/*      */     }
/* 2594 */     Double[] result = new Double[array.length];
/* 2595 */     for (int i = 0; i < array.length; i++) {
/* 2596 */       result[i] = new Double(array[i]);
/*      */     }
/* 2598 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] toPrimitive(Float[] array) {
/* 2613 */     if (array == null)
/* 2614 */       return null; 
/* 2615 */     if (array.length == 0) {
/* 2616 */       return EMPTY_FLOAT_ARRAY;
/*      */     }
/* 2618 */     float[] result = new float[array.length];
/* 2619 */     for (int i = 0; i < array.length; i++) {
/* 2620 */       result[i] = array[i].floatValue();
/*      */     }
/* 2622 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] toPrimitive(Float[] array, float valueForNull) {
/* 2635 */     if (array == null)
/* 2636 */       return null; 
/* 2637 */     if (array.length == 0) {
/* 2638 */       return EMPTY_FLOAT_ARRAY;
/*      */     }
/* 2640 */     float[] result = new float[array.length];
/* 2641 */     for (int i = 0; i < array.length; i++) {
/* 2642 */       Float b = array[i];
/* 2643 */       result[i] = (b == null) ? valueForNull : b.floatValue();
/*      */     } 
/* 2645 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float[] toObject(float[] array) {
/* 2657 */     if (array == null)
/* 2658 */       return null; 
/* 2659 */     if (array.length == 0) {
/* 2660 */       return EMPTY_FLOAT_OBJECT_ARRAY;
/*      */     }
/* 2662 */     Float[] result = new Float[array.length];
/* 2663 */     for (int i = 0; i < array.length; i++) {
/* 2664 */       result[i] = new Float(array[i]);
/*      */     }
/* 2666 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] toPrimitive(Boolean[] array) {
/* 2681 */     if (array == null)
/* 2682 */       return null; 
/* 2683 */     if (array.length == 0) {
/* 2684 */       return EMPTY_BOOLEAN_ARRAY;
/*      */     }
/* 2686 */     boolean[] result = new boolean[array.length];
/* 2687 */     for (int i = 0; i < array.length; i++) {
/* 2688 */       result[i] = array[i].booleanValue();
/*      */     }
/* 2690 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] toPrimitive(Boolean[] array, boolean valueForNull) {
/* 2703 */     if (array == null)
/* 2704 */       return null; 
/* 2705 */     if (array.length == 0) {
/* 2706 */       return EMPTY_BOOLEAN_ARRAY;
/*      */     }
/* 2708 */     boolean[] result = new boolean[array.length];
/* 2709 */     for (int i = 0; i < array.length; i++) {
/* 2710 */       Boolean b = array[i];
/* 2711 */       result[i] = (b == null) ? valueForNull : b.booleanValue();
/*      */     } 
/* 2713 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean[] toObject(boolean[] array) {
/* 2725 */     if (array == null)
/* 2726 */       return null; 
/* 2727 */     if (array.length == 0) {
/* 2728 */       return EMPTY_BOOLEAN_OBJECT_ARRAY;
/*      */     }
/* 2730 */     Boolean[] result = new Boolean[array.length];
/* 2731 */     for (int i = 0; i < array.length; i++) {
/* 2732 */       result[i] = array[i] ? Boolean.TRUE : Boolean.FALSE;
/*      */     }
/* 2734 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(Object[] array) {
/* 2746 */     if (array == null || array.length == 0) {
/* 2747 */       return true;
/*      */     }
/* 2749 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(long[] array) {
/* 2760 */     if (array == null || array.length == 0) {
/* 2761 */       return true;
/*      */     }
/* 2763 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(int[] array) {
/* 2774 */     if (array == null || array.length == 0) {
/* 2775 */       return true;
/*      */     }
/* 2777 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(short[] array) {
/* 2788 */     if (array == null || array.length == 0) {
/* 2789 */       return true;
/*      */     }
/* 2791 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(char[] array) {
/* 2802 */     if (array == null || array.length == 0) {
/* 2803 */       return true;
/*      */     }
/* 2805 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(byte[] array) {
/* 2816 */     if (array == null || array.length == 0) {
/* 2817 */       return true;
/*      */     }
/* 2819 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(double[] array) {
/* 2830 */     if (array == null || array.length == 0) {
/* 2831 */       return true;
/*      */     }
/* 2833 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(float[] array) {
/* 2844 */     if (array == null || array.length == 0) {
/* 2845 */       return true;
/*      */     }
/* 2847 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEmpty(boolean[] array) {
/* 2858 */     if (array == null || array.length == 0) {
/* 2859 */       return true;
/*      */     }
/* 2861 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] addAll(Object[] array1, Object[] array2) {
/* 2886 */     if (array1 == null)
/* 2887 */       return clone(array2); 
/* 2888 */     if (array2 == null) {
/* 2889 */       return clone(array1);
/*      */     }
/* 2891 */     Object[] joinedArray = (Object[])Array.newInstance(array1.getClass().getComponentType(), 
/* 2892 */         array1.length + array2.length);
/* 2893 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 2894 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 2895 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] addAll(boolean[] array1, boolean[] array2) {
/* 2916 */     if (array1 == null)
/* 2917 */       return clone(array2); 
/* 2918 */     if (array2 == null) {
/* 2919 */       return clone(array1);
/*      */     }
/* 2921 */     boolean[] joinedArray = new boolean[array1.length + array2.length];
/* 2922 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 2923 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 2924 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] addAll(char[] array1, char[] array2) {
/* 2945 */     if (array1 == null)
/* 2946 */       return clone(array2); 
/* 2947 */     if (array2 == null) {
/* 2948 */       return clone(array1);
/*      */     }
/* 2950 */     char[] joinedArray = new char[array1.length + array2.length];
/* 2951 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 2952 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 2953 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] addAll(byte[] array1, byte[] array2) {
/* 2974 */     if (array1 == null)
/* 2975 */       return clone(array2); 
/* 2976 */     if (array2 == null) {
/* 2977 */       return clone(array1);
/*      */     }
/* 2979 */     byte[] joinedArray = new byte[array1.length + array2.length];
/* 2980 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 2981 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 2982 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] addAll(short[] array1, short[] array2) {
/* 3003 */     if (array1 == null)
/* 3004 */       return clone(array2); 
/* 3005 */     if (array2 == null) {
/* 3006 */       return clone(array1);
/*      */     }
/* 3008 */     short[] joinedArray = new short[array1.length + array2.length];
/* 3009 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3010 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3011 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] addAll(int[] array1, int[] array2) {
/* 3032 */     if (array1 == null)
/* 3033 */       return clone(array2); 
/* 3034 */     if (array2 == null) {
/* 3035 */       return clone(array1);
/*      */     }
/* 3037 */     int[] joinedArray = new int[array1.length + array2.length];
/* 3038 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3039 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3040 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] addAll(long[] array1, long[] array2) {
/* 3061 */     if (array1 == null)
/* 3062 */       return clone(array2); 
/* 3063 */     if (array2 == null) {
/* 3064 */       return clone(array1);
/*      */     }
/* 3066 */     long[] joinedArray = new long[array1.length + array2.length];
/* 3067 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3068 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3069 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] addAll(float[] array1, float[] array2) {
/* 3090 */     if (array1 == null)
/* 3091 */       return clone(array2); 
/* 3092 */     if (array2 == null) {
/* 3093 */       return clone(array1);
/*      */     }
/* 3095 */     float[] joinedArray = new float[array1.length + array2.length];
/* 3096 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3097 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3098 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] addAll(double[] array1, double[] array2) {
/* 3119 */     if (array1 == null)
/* 3120 */       return clone(array2); 
/* 3121 */     if (array2 == null) {
/* 3122 */       return clone(array1);
/*      */     }
/* 3124 */     double[] joinedArray = new double[array1.length + array2.length];
/* 3125 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3126 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3127 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] add(Object[] array, Object element) {
/* 3154 */     Class type = (array != null) ? array.getClass() : ((element != null) ? element.getClass() : Object.class);
/* 3155 */     Object[] newArray = (Object[])copyArrayGrow1(array, type);
/* 3156 */     newArray[newArray.length - 1] = element;
/* 3157 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] add(boolean[] array, boolean element) {
/* 3182 */     boolean[] newArray = (boolean[])copyArrayGrow1(array, boolean.class);
/* 3183 */     newArray[newArray.length - 1] = element;
/* 3184 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] add(byte[] array, byte element) {
/* 3209 */     byte[] newArray = (byte[])copyArrayGrow1(array, byte.class);
/* 3210 */     newArray[newArray.length - 1] = element;
/* 3211 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] add(char[] array, char element) {
/* 3236 */     char[] newArray = (char[])copyArrayGrow1(array, char.class);
/* 3237 */     newArray[newArray.length - 1] = element;
/* 3238 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] add(double[] array, double element) {
/* 3263 */     double[] newArray = (double[])copyArrayGrow1(array, double.class);
/* 3264 */     newArray[newArray.length - 1] = element;
/* 3265 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] add(float[] array, float element) {
/* 3290 */     float[] newArray = (float[])copyArrayGrow1(array, float.class);
/* 3291 */     newArray[newArray.length - 1] = element;
/* 3292 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] add(int[] array, int element) {
/* 3317 */     int[] newArray = (int[])copyArrayGrow1(array, int.class);
/* 3318 */     newArray[newArray.length - 1] = element;
/* 3319 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] add(long[] array, long element) {
/* 3344 */     long[] newArray = (long[])copyArrayGrow1(array, long.class);
/* 3345 */     newArray[newArray.length - 1] = element;
/* 3346 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] add(short[] array, short element) {
/* 3371 */     short[] newArray = (short[])copyArrayGrow1(array, short.class);
/* 3372 */     newArray[newArray.length - 1] = element;
/* 3373 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object copyArrayGrow1(Object array, Class newArrayComponentType) {
/* 3386 */     if (array != null) {
/* 3387 */       int arrayLength = Array.getLength(array);
/* 3388 */       Object newArray = Array.newInstance(array.getClass().getComponentType(), arrayLength + 1);
/* 3389 */       System.arraycopy(array, 0, newArray, 0, arrayLength);
/* 3390 */       return newArray;
/*      */     } 
/* 3392 */     return Array.newInstance(newArrayComponentType, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] add(Object[] array, int index, Object element) {
/* 3425 */     Class clss = null;
/* 3426 */     if (array != null) {
/* 3427 */       clss = array.getClass().getComponentType();
/*      */     }
/* 3429 */     else if (element != null) {
/* 3430 */       clss = element.getClass();
/*      */     } else {
/* 3432 */       return new Object[] { null };
/*      */     } 
/* 3434 */     return (Object[])add(array, index, element, clss);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] add(boolean[] array, int index, boolean element) {
/* 3465 */     return (boolean[])add(array, index, new Boolean(element), boolean.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] add(char[] array, int index, char element) {
/* 3497 */     return (char[])add(array, index, new Character(element), char.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] add(byte[] array, int index, byte element) {
/* 3528 */     return (byte[])add(array, index, new Byte(element), byte.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] add(short[] array, int index, short element) {
/* 3559 */     return (short[])add(array, index, new Short(element), short.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] add(int[] array, int index, int element) {
/* 3590 */     return (int[])add(array, index, new Integer(element), int.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] add(long[] array, int index, long element) {
/* 3621 */     return (long[])add(array, index, new Long(element), long.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] add(float[] array, int index, float element) {
/* 3652 */     return (float[])add(array, index, new Float(element), float.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] add(double[] array, int index, double element) {
/* 3683 */     return (double[])add(array, index, new Double(element), double.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object add(Object array, int index, Object element, Class clss) {
/* 3698 */     if (array == null) {
/* 3699 */       if (index != 0) {
/* 3700 */         throw new IndexOutOfBoundsException("Index: " + index + ", Length: 0");
/*      */       }
/* 3702 */       Object joinedArray = Array.newInstance(clss, 1);
/* 3703 */       Array.set(joinedArray, 0, element);
/* 3704 */       return joinedArray;
/*      */     } 
/* 3706 */     int length = Array.getLength(array);
/* 3707 */     if (index > length || index < 0) {
/* 3708 */       throw new IndexOutOfBoundsException("Index: " + index + ", Length: " + length);
/*      */     }
/* 3710 */     Object result = Array.newInstance(clss, length + 1);
/* 3711 */     System.arraycopy(array, 0, result, 0, index);
/* 3712 */     Array.set(result, index, element);
/* 3713 */     if (index < length) {
/* 3714 */       System.arraycopy(array, index, result, index + 1, length - index);
/*      */     }
/* 3716 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] remove(Object[] array, int index) {
/* 3748 */     return (Object[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] removeElement(Object[] array, Object element) {
/* 3777 */     int index = indexOf(array, element);
/* 3778 */     if (index == -1) {
/* 3779 */       return clone(array);
/*      */     }
/* 3781 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] remove(boolean[] array, int index) {
/* 3813 */     return (boolean[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] removeElement(boolean[] array, boolean element) {
/* 3842 */     int index = indexOf(array, element);
/* 3843 */     if (index == -1) {
/* 3844 */       return clone(array);
/*      */     }
/* 3846 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] remove(byte[] array, int index) {
/* 3878 */     return (byte[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] removeElement(byte[] array, byte element) {
/* 3907 */     int index = indexOf(array, element);
/* 3908 */     if (index == -1) {
/* 3909 */       return clone(array);
/*      */     }
/* 3911 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] remove(char[] array, int index) {
/* 3943 */     return (char[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] removeElement(char[] array, char element) {
/* 3972 */     int index = indexOf(array, element);
/* 3973 */     if (index == -1) {
/* 3974 */       return clone(array);
/*      */     }
/* 3976 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] remove(double[] array, int index) {
/* 4008 */     return (double[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] removeElement(double[] array, double element) {
/* 4037 */     int index = indexOf(array, element);
/* 4038 */     if (index == -1) {
/* 4039 */       return clone(array);
/*      */     }
/* 4041 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] remove(float[] array, int index) {
/* 4073 */     return (float[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] removeElement(float[] array, float element) {
/* 4102 */     int index = indexOf(array, element);
/* 4103 */     if (index == -1) {
/* 4104 */       return clone(array);
/*      */     }
/* 4106 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] remove(int[] array, int index) {
/* 4138 */     return (int[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] removeElement(int[] array, int element) {
/* 4167 */     int index = indexOf(array, element);
/* 4168 */     if (index == -1) {
/* 4169 */       return clone(array);
/*      */     }
/* 4171 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] remove(long[] array, int index) {
/* 4203 */     return (long[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] removeElement(long[] array, long element) {
/* 4232 */     int index = indexOf(array, element);
/* 4233 */     if (index == -1) {
/* 4234 */       return clone(array);
/*      */     }
/* 4236 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] remove(short[] array, int index) {
/* 4268 */     return (short[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] removeElement(short[] array, short element) {
/* 4297 */     int index = indexOf(array, element);
/* 4298 */     if (index == -1) {
/* 4299 */       return clone(array);
/*      */     }
/* 4301 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object remove(Object array, int index) {
/* 4326 */     int length = getLength(array);
/* 4327 */     if (index < 0 || index >= length) {
/* 4328 */       throw new IndexOutOfBoundsException("Index: " + index + ", Length: " + length);
/*      */     }
/*      */     
/* 4331 */     Object result = Array.newInstance(array.getClass().getComponentType(), length - 1);
/* 4332 */     System.arraycopy(array, 0, result, 0, index);
/* 4333 */     if (index < length - 1) {
/* 4334 */       System.arraycopy(array, index + 1, result, index, length - index - 1);
/*      */     }
/*      */     
/* 4337 */     return result;
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\ArrayUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */