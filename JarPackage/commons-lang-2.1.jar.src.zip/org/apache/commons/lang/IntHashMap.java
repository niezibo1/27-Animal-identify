/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IntHashMap
/*     */ {
/*     */   private transient Entry[] table;
/*     */   private transient int count;
/*     */   private int threshold;
/*     */   private float loadFactor;
/*     */   
/*     */   private static class Entry
/*     */   {
/*     */     int hash;
/*     */     int key;
/*     */     Object value;
/*     */     Entry next;
/*     */     
/*     */     protected Entry(int hash, int key, Object value, Entry next) {
/*  83 */       this.hash = hash;
/*  84 */       this.key = key;
/*  85 */       this.value = value;
/*  86 */       this.next = next;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntHashMap() {
/*  95 */     this(20, 0.75F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntHashMap(int initialCapacity) {
/* 107 */     this(initialCapacity, 0.75F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntHashMap(int initialCapacity, float loadFactor) {
/* 121 */     if (initialCapacity < 0) {
/* 122 */       throw new IllegalArgumentException("Illegal Capacity: " + initialCapacity);
/*     */     }
/* 124 */     if (loadFactor <= 0.0F) {
/* 125 */       throw new IllegalArgumentException("Illegal Load: " + loadFactor);
/*     */     }
/* 127 */     if (initialCapacity == 0) {
/* 128 */       initialCapacity = 1;
/*     */     }
/*     */     
/* 131 */     this.loadFactor = loadFactor;
/* 132 */     this.table = new Entry[initialCapacity];
/* 133 */     this.threshold = (int)(initialCapacity * loadFactor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 142 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 152 */     return !(this.count != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Object value) {
/* 174 */     if (value == null) {
/* 175 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 178 */     Entry[] tab = this.table;
/* 179 */     for (int i = tab.length; i-- > 0;) {
/* 180 */       for (Entry e = tab[i]; e != null; e = e.next) {
/* 181 */         if (e.value.equals(value)) {
/* 182 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 202 */     return contains(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(int key) {
/* 215 */     Entry[] tab = this.table;
/* 216 */     int hash = key;
/* 217 */     int index = (hash & Integer.MAX_VALUE) % tab.length;
/* 218 */     for (Entry e = tab[index]; e != null; e = e.next) {
/* 219 */       if (e.hash == hash) {
/* 220 */         return true;
/*     */       }
/*     */     } 
/* 223 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(int key) {
/* 236 */     Entry[] tab = this.table;
/* 237 */     int hash = key;
/* 238 */     int index = (hash & Integer.MAX_VALUE) % tab.length;
/* 239 */     for (Entry e = tab[index]; e != null; e = e.next) {
/* 240 */       if (e.hash == hash) {
/* 241 */         return e.value;
/*     */       }
/*     */     } 
/* 244 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rehash() {
/* 257 */     int oldCapacity = this.table.length;
/* 258 */     Entry[] oldMap = this.table;
/*     */     
/* 260 */     int newCapacity = oldCapacity * 2 + 1;
/* 261 */     Entry[] newMap = new Entry[newCapacity];
/*     */     
/* 263 */     this.threshold = (int)(newCapacity * this.loadFactor);
/* 264 */     this.table = newMap;
/*     */     
/* 266 */     for (int i = oldCapacity; i-- > 0;) {
/* 267 */       for (Entry old = oldMap[i]; old != null; ) {
/* 268 */         Entry e = old;
/* 269 */         old = old.next;
/*     */         
/* 271 */         int index = (e.hash & Integer.MAX_VALUE) % newCapacity;
/* 272 */         e.next = newMap[index];
/* 273 */         newMap[index] = e;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(int key, Object value) {
/* 295 */     Entry[] tab = this.table;
/* 296 */     int hash = key;
/* 297 */     int index = (hash & Integer.MAX_VALUE) % tab.length;
/* 298 */     for (Entry e = tab[index]; e != null; e = e.next) {
/* 299 */       if (e.hash == hash) {
/* 300 */         Object old = e.value;
/* 301 */         e.value = value;
/* 302 */         return old;
/*     */       } 
/*     */     } 
/*     */     
/* 306 */     if (this.count >= this.threshold) {
/*     */       
/* 308 */       rehash();
/*     */       
/* 310 */       tab = this.table;
/* 311 */       index = (hash & Integer.MAX_VALUE) % tab.length;
/*     */     } 
/*     */ 
/*     */     
/* 315 */     Entry entry1 = new Entry(hash, key, value, tab[index]);
/* 316 */     tab[index] = entry1;
/* 317 */     this.count++;
/* 318 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(int key) {
/* 333 */     Entry[] tab = this.table;
/* 334 */     int hash = key;
/* 335 */     int index = (hash & Integer.MAX_VALUE) % tab.length;
/* 336 */     for (Entry e = tab[index], prev = null; e != null; prev = e, e = e.next) {
/* 337 */       if (e.hash == hash) {
/* 338 */         if (prev != null) {
/* 339 */           prev.next = e.next;
/*     */         } else {
/* 341 */           tab[index] = e.next;
/*     */         } 
/* 343 */         this.count--;
/* 344 */         Object oldValue = e.value;
/* 345 */         e.value = null;
/* 346 */         return oldValue;
/*     */       } 
/*     */     } 
/* 349 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clear() {
/* 356 */     Entry[] tab = this.table;
/* 357 */     for (int index = tab.length; --index >= 0;) {
/* 358 */       tab[index] = null;
/*     */     }
/* 360 */     this.count = 0;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\IntHashMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */