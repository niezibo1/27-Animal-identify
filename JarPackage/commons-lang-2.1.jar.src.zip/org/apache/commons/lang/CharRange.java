/*     */ package org.apache.commons.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharRange
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 8270183163158333422L;
/*     */   private final char start;
/*     */   private final char end;
/*     */   private final boolean negated;
/*     */   private transient String iToString;
/*     */   
/*     */   public CharRange(char ch) {
/*  54 */     this(ch, ch, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharRange(char ch, boolean negated) {
/*  67 */     this(ch, ch, negated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharRange(char start, char end) {
/*  77 */     this(start, end, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharRange(char start, char end, boolean negated) {
/*  96 */     if (start > end) {
/*  97 */       char temp = start;
/*  98 */       start = end;
/*  99 */       end = temp;
/*     */     } 
/*     */     
/* 102 */     this.start = start;
/* 103 */     this.end = end;
/* 104 */     this.negated = negated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getStart() {
/* 115 */     return this.start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getEnd() {
/* 124 */     return this.end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNegated() {
/* 136 */     return this.negated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(char ch) {
/* 148 */     return !((!(ch < this.start || ch > this.end)) == this.negated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(CharRange range) {
/* 160 */     if (range == null) {
/* 161 */       throw new IllegalArgumentException("The Range must not be null");
/*     */     }
/* 163 */     if (this.negated) {
/* 164 */       if (range.negated) {
/* 165 */         return !(this.start < range.start || this.end > range.end);
/*     */       }
/* 167 */       return !(range.end >= this.start && range.start <= this.end);
/*     */     } 
/*     */     
/* 170 */     if (range.negated) {
/* 171 */       return !(this.start != '\000' || this.end != Character.MAX_VALUE);
/*     */     }
/* 173 */     return !(this.start > range.start || this.end < range.end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 188 */     if (obj == this) {
/* 189 */       return true;
/*     */     }
/* 191 */     if (obj instanceof CharRange == false) {
/* 192 */       return false;
/*     */     }
/* 194 */     CharRange other = (CharRange)obj;
/* 195 */     return !(this.start != other.start || this.end != other.end || this.negated != other.negated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 204 */     return 83 + this.start + 7 * this.end + (this.negated ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 213 */     if (this.iToString == null) {
/* 214 */       StringBuffer buf = new StringBuffer(4);
/* 215 */       if (isNegated()) {
/* 216 */         buf.append('^');
/*     */       }
/* 218 */       buf.append(this.start);
/* 219 */       if (this.start != this.end) {
/* 220 */         buf.append('-');
/* 221 */         buf.append(this.end);
/*     */       } 
/* 223 */       this.iToString = buf.toString();
/*     */     } 
/* 225 */     return this.iToString;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-lang-2.1.jar!\org\apache\commons\lang\CharRange.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */