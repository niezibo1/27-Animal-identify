package org.apache.commons.collections;

import java.util.Collection;

public interface BoundedCollection extends Collection {
  boolean isFull();
  
  int maxSize();
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-collections-3.2.1-1.0.0.jar!\org\apache\commons\collections\BoundedCollection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */