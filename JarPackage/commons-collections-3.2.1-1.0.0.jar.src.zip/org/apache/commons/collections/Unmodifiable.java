package org.apache.commons.collections;

public interface Unmodifiable {}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-collections-3.2.1-1.0.0.jar!\org\apache\commons\collections\Unmodifiable.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */