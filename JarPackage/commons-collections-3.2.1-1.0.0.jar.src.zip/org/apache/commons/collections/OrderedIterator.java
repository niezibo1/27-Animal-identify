package org.apache.commons.collections;

import java.util.Iterator;

public interface OrderedIterator extends Iterator {
  boolean hasPrevious();
  
  Object previous();
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-collections-3.2.1-1.0.0.jar!\org\apache\commons\collections\OrderedIterator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */