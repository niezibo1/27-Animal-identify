package org.apache.commons.collections;

public interface PriorityQueue {
  void clear();
  
  boolean isEmpty();
  
  void insert(Object paramObject);
  
  Object peek();
  
  Object pop();
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-collections-3.2.1-1.0.0.jar!\org\apache\commons\collections\PriorityQueue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */