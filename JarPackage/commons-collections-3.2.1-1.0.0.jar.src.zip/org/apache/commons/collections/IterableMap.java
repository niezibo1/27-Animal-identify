package org.apache.commons.collections;

import java.util.Map;

public interface IterableMap extends Map {
  MapIterator mapIterator();
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\commons-collections-3.2.1-1.0.0.jar!\org\apache\commons\collections\IterableMap.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */