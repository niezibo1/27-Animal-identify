/*     */ package okhttp3.internal.ws;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.Call;
/*     */ import okhttp3.Callback;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.Protocol;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.Response;
/*     */ import okhttp3.WebSocket;
/*     */ import okhttp3.WebSocketListener;
/*     */ import okhttp3.internal.Internal;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.connection.StreamAllocation;
/*     */ import okio.BufferedSink;
/*     */ import okio.BufferedSource;
/*     */ import okio.ByteString;
/*     */ import okio.Okio;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RealWebSocket
/*     */   implements WebSocket, WebSocketReader.FrameCallback
/*     */ {
/*  54 */   private static final List<Protocol> ONLY_HTTP1 = Collections.singletonList(Protocol.HTTP_1_1);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long MAX_QUEUE_SIZE = 16777216L;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long CANCEL_AFTER_CLOSE_MILLIS = 60000L;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Request originalRequest;
/*     */ 
/*     */ 
/*     */   
/*     */   final WebSocketListener listener;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Random random;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String key;
/*     */ 
/*     */ 
/*     */   
/*     */   private Call call;
/*     */ 
/*     */   
/*     */   private final Runnable writerRunnable;
/*     */ 
/*     */   
/*     */   private WebSocketReader reader;
/*     */ 
/*     */   
/*     */   private WebSocketWriter writer;
/*     */ 
/*     */   
/*     */   private ScheduledExecutorService executor;
/*     */ 
/*     */   
/*     */   private Streams streams;
/*     */ 
/*     */   
/* 100 */   private final ArrayDeque<ByteString> pongQueue = new ArrayDeque<>();
/*     */ 
/*     */   
/* 103 */   private final ArrayDeque<Object> messageAndCloseQueue = new ArrayDeque();
/*     */ 
/*     */ 
/*     */   
/*     */   private long queueSize;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean enqueuedClose;
/*     */ 
/*     */ 
/*     */   
/*     */   private ScheduledFuture<?> cancelFuture;
/*     */ 
/*     */   
/* 118 */   private int receivedCloseCode = -1;
/*     */ 
/*     */   
/*     */   private String receivedCloseReason;
/*     */ 
/*     */   
/*     */   private boolean failed;
/*     */ 
/*     */   
/*     */   int pingCount;
/*     */   
/*     */   int pongCount;
/*     */ 
/*     */   
/*     */   public RealWebSocket(Request request, WebSocketListener listener, Random random) {
/* 133 */     if (!"GET".equals(request.method())) {
/* 134 */       throw new IllegalArgumentException("Request must be GET: " + request.method());
/*     */     }
/* 136 */     this.originalRequest = request;
/* 137 */     this.listener = listener;
/* 138 */     this.random = random;
/*     */     
/* 140 */     byte[] nonce = new byte[16];
/* 141 */     random.nextBytes(nonce);
/* 142 */     this.key = ByteString.of(nonce).base64();
/*     */     
/* 144 */     this.writerRunnable = new Runnable() {
/*     */         public void run() {
/*     */           try {
/* 147 */             while (RealWebSocket.this.writeOneFrame());
/*     */           }
/* 149 */           catch (IOException e) {
/* 150 */             RealWebSocket.this.failWebSocket(e, null);
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public Request request() {
/* 157 */     return this.originalRequest;
/*     */   }
/*     */   
/*     */   public synchronized long queueSize() {
/* 161 */     return this.queueSize;
/*     */   }
/*     */   
/*     */   public void cancel() {
/* 165 */     this.call.cancel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(OkHttpClient client) {
/* 171 */     client = client.newBuilder().protocols(ONLY_HTTP1).build();
/* 172 */     final int pingIntervalMillis = client.pingIntervalMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     final Request request = this.originalRequest.newBuilder().header("Upgrade", "websocket").header("Connection", "Upgrade").header("Sec-WebSocket-Key", this.key).header("Sec-WebSocket-Version", "13").build();
/* 179 */     this.call = Internal.instance.newWebSocketCall(client, request);
/* 180 */     this.call.enqueue(new Callback() {
/*     */           public void onResponse(Call call, Response response) {
/*     */             try {
/* 183 */               RealWebSocket.this.checkResponse(response);
/* 184 */             } catch (ProtocolException e) {
/* 185 */               RealWebSocket.this.failWebSocket(e, response);
/* 186 */               Util.closeQuietly((Closeable)response);
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/* 191 */             StreamAllocation streamAllocation = Internal.instance.streamAllocation(call);
/* 192 */             streamAllocation.noNewStreams();
/* 193 */             RealWebSocket.Streams streams = streamAllocation.connection().newWebSocketStreams(streamAllocation);
/*     */ 
/*     */             
/*     */             try {
/* 197 */               RealWebSocket.this.listener.onOpen(RealWebSocket.this, response);
/* 198 */               String name = "OkHttp WebSocket " + request.url().redact();
/* 199 */               RealWebSocket.this.initReaderAndWriter(name, pingIntervalMillis, streams);
/* 200 */               streamAllocation.connection().socket().setSoTimeout(0);
/* 201 */               RealWebSocket.this.loopReader();
/* 202 */             } catch (Exception e) {
/* 203 */               RealWebSocket.this.failWebSocket(e, null);
/*     */             } 
/*     */           }
/*     */           
/*     */           public void onFailure(Call call, IOException e) {
/* 208 */             RealWebSocket.this.failWebSocket(e, null);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   void checkResponse(Response response) throws ProtocolException {
/* 214 */     if (response.code() != 101) {
/* 215 */       throw new ProtocolException("Expected HTTP 101 response but was '" + response
/* 216 */           .code() + " " + response.message() + "'");
/*     */     }
/*     */     
/* 219 */     String headerConnection = response.header("Connection");
/* 220 */     if (!"Upgrade".equalsIgnoreCase(headerConnection)) {
/* 221 */       throw new ProtocolException("Expected 'Connection' header value 'Upgrade' but was '" + headerConnection + "'");
/*     */     }
/*     */ 
/*     */     
/* 225 */     String headerUpgrade = response.header("Upgrade");
/* 226 */     if (!"websocket".equalsIgnoreCase(headerUpgrade)) {
/* 227 */       throw new ProtocolException("Expected 'Upgrade' header value 'websocket' but was '" + headerUpgrade + "'");
/*     */     }
/*     */ 
/*     */     
/* 231 */     String headerAccept = response.header("Sec-WebSocket-Accept");
/*     */     
/* 233 */     String acceptExpected = ByteString.encodeUtf8(this.key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").sha1().base64();
/* 234 */     if (!acceptExpected.equals(headerAccept)) {
/* 235 */       throw new ProtocolException("Expected 'Sec-WebSocket-Accept' header value '" + acceptExpected + "' but was '" + headerAccept + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initReaderAndWriter(String name, long pingIntervalMillis, Streams streams) throws IOException {
/* 242 */     synchronized (this) {
/* 243 */       this.streams = streams;
/* 244 */       this.writer = new WebSocketWriter(streams.client, streams.sink, this.random);
/* 245 */       this.executor = new ScheduledThreadPoolExecutor(1, Util.threadFactory(name, false));
/* 246 */       if (pingIntervalMillis != 0L) {
/* 247 */         this.executor.scheduleAtFixedRate(new PingRunnable(), pingIntervalMillis, pingIntervalMillis, TimeUnit.MILLISECONDS);
/*     */       }
/*     */       
/* 250 */       if (!this.messageAndCloseQueue.isEmpty()) {
/* 251 */         runWriter();
/*     */       }
/*     */     } 
/*     */     
/* 255 */     this.reader = new WebSocketReader(streams.client, streams.source, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void loopReader() throws IOException {
/* 260 */     while (this.receivedCloseCode == -1)
/*     */     {
/* 262 */       this.reader.processNextFrame();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean processNextFrame() throws IOException {
/*     */     try {
/* 272 */       this.reader.processNextFrame();
/* 273 */       return (this.receivedCloseCode == -1);
/* 274 */     } catch (Exception e) {
/* 275 */       failWebSocket(e, null);
/* 276 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void awaitTermination(int timeout, TimeUnit timeUnit) throws InterruptedException {
/* 284 */     this.executor.awaitTermination(timeout, timeUnit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void tearDown() throws InterruptedException {
/* 291 */     if (this.cancelFuture != null) {
/* 292 */       this.cancelFuture.cancel(false);
/*     */     }
/* 294 */     this.executor.shutdown();
/* 295 */     this.executor.awaitTermination(10L, TimeUnit.SECONDS);
/*     */   }
/*     */   
/*     */   synchronized int pingCount() {
/* 299 */     return this.pingCount;
/*     */   }
/*     */   
/*     */   synchronized int pongCount() {
/* 303 */     return this.pongCount;
/*     */   }
/*     */   
/*     */   public void onReadMessage(String text) throws IOException {
/* 307 */     this.listener.onMessage(this, text);
/*     */   }
/*     */   
/*     */   public void onReadMessage(ByteString bytes) throws IOException {
/* 311 */     this.listener.onMessage(this, bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void onReadPing(ByteString payload) {
/* 316 */     if (this.failed || (this.enqueuedClose && this.messageAndCloseQueue.isEmpty()))
/*     */       return; 
/* 318 */     this.pongQueue.add(payload);
/* 319 */     runWriter();
/* 320 */     this.pingCount++;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void onReadPong(ByteString buffer) {
/* 325 */     this.pongCount++;
/*     */   }
/*     */   
/*     */   public void onReadClose(int code, String reason) {
/* 329 */     if (code == -1) throw new IllegalArgumentException();
/*     */     
/* 331 */     Streams toClose = null;
/* 332 */     synchronized (this) {
/* 333 */       if (this.receivedCloseCode != -1) throw new IllegalStateException("already closed"); 
/* 334 */       this.receivedCloseCode = code;
/* 335 */       this.receivedCloseReason = reason;
/* 336 */       if (this.enqueuedClose && this.messageAndCloseQueue.isEmpty()) {
/* 337 */         toClose = this.streams;
/* 338 */         this.streams = null;
/* 339 */         if (this.cancelFuture != null) this.cancelFuture.cancel(false); 
/* 340 */         this.executor.shutdown();
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 345 */       this.listener.onClosing(this, code, reason);
/*     */       
/* 347 */       if (toClose != null) {
/* 348 */         this.listener.onClosed(this, code, reason);
/*     */       }
/*     */     } finally {
/* 351 */       Util.closeQuietly(toClose);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean send(String text) {
/* 358 */     if (text == null) throw new NullPointerException("text == null"); 
/* 359 */     return send(ByteString.encodeUtf8(text), 1);
/*     */   }
/*     */   
/*     */   public boolean send(ByteString bytes) {
/* 363 */     if (bytes == null) throw new NullPointerException("bytes == null"); 
/* 364 */     return send(bytes, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized boolean send(ByteString data, int formatOpcode) {
/* 369 */     if (this.failed || this.enqueuedClose) return false;
/*     */ 
/*     */     
/* 372 */     if (this.queueSize + data.size() > 16777216L) {
/* 373 */       close(1001, null);
/* 374 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 378 */     this.queueSize += data.size();
/* 379 */     this.messageAndCloseQueue.add(new Message(formatOpcode, data));
/* 380 */     runWriter();
/* 381 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized boolean pong(ByteString payload) {
/* 386 */     if (this.failed || (this.enqueuedClose && this.messageAndCloseQueue.isEmpty())) return false;
/*     */     
/* 388 */     this.pongQueue.add(payload);
/* 389 */     runWriter();
/* 390 */     return true;
/*     */   }
/*     */   
/*     */   public boolean close(int code, String reason) {
/* 394 */     return close(code, reason, 60000L);
/*     */   }
/*     */   
/*     */   synchronized boolean close(int code, String reason, long cancelAfterCloseMillis) {
/* 398 */     WebSocketProtocol.validateCloseCode(code);
/*     */     
/* 400 */     ByteString reasonBytes = null;
/* 401 */     if (reason != null) {
/* 402 */       reasonBytes = ByteString.encodeUtf8(reason);
/* 403 */       if (reasonBytes.size() > 123L) {
/* 404 */         throw new IllegalArgumentException("reason.size() > 123: " + reason);
/*     */       }
/*     */     } 
/*     */     
/* 408 */     if (this.failed || this.enqueuedClose) return false;
/*     */ 
/*     */     
/* 411 */     this.enqueuedClose = true;
/*     */ 
/*     */     
/* 414 */     this.messageAndCloseQueue.add(new Close(code, reasonBytes, cancelAfterCloseMillis));
/* 415 */     runWriter();
/* 416 */     return true;
/*     */   }
/*     */   
/*     */   private void runWriter() {
/* 420 */     assert Thread.holdsLock(this);
/*     */     
/* 422 */     if (this.executor != null) {
/* 423 */       this.executor.execute(this.writerRunnable);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean writeOneFrame() throws IOException {
/*     */     WebSocketWriter writer;
/*     */     ByteString pong;
/* 443 */     Object messageOrClose = null;
/* 444 */     int receivedCloseCode = -1;
/* 445 */     String receivedCloseReason = null;
/* 446 */     Streams streamsToClose = null;
/*     */     
/* 448 */     synchronized (this) {
/* 449 */       if (this.failed) {
/* 450 */         return false;
/*     */       }
/*     */       
/* 453 */       writer = this.writer;
/* 454 */       pong = this.pongQueue.poll();
/* 455 */       if (pong == null) {
/* 456 */         messageOrClose = this.messageAndCloseQueue.poll();
/* 457 */         if (messageOrClose instanceof Close) {
/* 458 */           receivedCloseCode = this.receivedCloseCode;
/* 459 */           receivedCloseReason = this.receivedCloseReason;
/* 460 */           if (receivedCloseCode != -1) {
/* 461 */             streamsToClose = this.streams;
/* 462 */             this.streams = null;
/* 463 */             this.executor.shutdown();
/*     */           } else {
/*     */             
/* 466 */             this.cancelFuture = this.executor.schedule(new CancelRunnable(), ((Close)messageOrClose).cancelAfterCloseMillis, TimeUnit.MILLISECONDS);
/*     */           }
/*     */         
/* 469 */         } else if (messageOrClose == null) {
/* 470 */           return false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 476 */       if (pong != null) {
/* 477 */         writer.writePong(pong);
/*     */       }
/* 479 */       else if (messageOrClose instanceof Message) {
/* 480 */         ByteString data = ((Message)messageOrClose).data;
/* 481 */         BufferedSink sink = Okio.buffer(writer.newMessageSink(((Message)messageOrClose).formatOpcode, data
/* 482 */               .size()));
/* 483 */         sink.write(data);
/* 484 */         sink.close();
/* 485 */         synchronized (this) {
/* 486 */           this.queueSize -= data.size();
/*     */         }
/*     */       
/* 489 */       } else if (messageOrClose instanceof Close) {
/* 490 */         Close close = (Close)messageOrClose;
/* 491 */         writer.writeClose(close.code, close.reason);
/*     */ 
/*     */         
/* 494 */         if (streamsToClose != null) {
/* 495 */           this.listener.onClosed(this, receivedCloseCode, receivedCloseReason);
/*     */         }
/*     */       } else {
/*     */         
/* 499 */         throw new AssertionError();
/*     */       } 
/*     */       
/* 502 */       return true;
/*     */     } finally {
/* 504 */       Util.closeQuietly(streamsToClose);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private final class PingRunnable
/*     */     implements Runnable
/*     */   {
/*     */     public void run() {
/* 513 */       RealWebSocket.this.writePingFrame();
/*     */     }
/*     */   }
/*     */   
/*     */   void writePingFrame() {
/*     */     WebSocketWriter writer;
/* 519 */     synchronized (this) {
/* 520 */       if (this.failed)
/* 521 */         return;  writer = this.writer;
/*     */     } 
/*     */     
/*     */     try {
/* 525 */       writer.writePing(ByteString.EMPTY);
/* 526 */     } catch (IOException e) {
/* 527 */       failWebSocket(e, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void failWebSocket(Exception e, Response response) {
/*     */     Streams streamsToClose;
/* 533 */     synchronized (this) {
/* 534 */       if (this.failed)
/* 535 */         return;  this.failed = true;
/* 536 */       streamsToClose = this.streams;
/* 537 */       this.streams = null;
/* 538 */       if (this.cancelFuture != null) this.cancelFuture.cancel(false); 
/* 539 */       if (this.executor != null) this.executor.shutdown();
/*     */     
/*     */     } 
/*     */     try {
/* 543 */       this.listener.onFailure(this, e, response);
/*     */     } finally {
/* 545 */       Util.closeQuietly(streamsToClose);
/*     */     } 
/*     */   }
/*     */   
/*     */   static final class Message {
/*     */     final int formatOpcode;
/*     */     final ByteString data;
/*     */     
/*     */     Message(int formatOpcode, ByteString data) {
/* 554 */       this.formatOpcode = formatOpcode;
/* 555 */       this.data = data;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class Close {
/*     */     final int code;
/*     */     final ByteString reason;
/*     */     final long cancelAfterCloseMillis;
/*     */     
/*     */     Close(int code, ByteString reason, long cancelAfterCloseMillis) {
/* 565 */       this.code = code;
/* 566 */       this.reason = reason;
/* 567 */       this.cancelAfterCloseMillis = cancelAfterCloseMillis;
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class Streams implements Closeable {
/*     */     public final boolean client;
/*     */     public final BufferedSource source;
/*     */     public final BufferedSink sink;
/*     */     
/*     */     public Streams(boolean client, BufferedSource source, BufferedSink sink) {
/* 577 */       this.client = client;
/* 578 */       this.source = source;
/* 579 */       this.sink = sink;
/*     */     }
/*     */   }
/*     */   
/*     */   final class CancelRunnable implements Runnable {
/*     */     public void run() {
/* 585 */       RealWebSocket.this.cancel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\ws\RealWebSocket.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */