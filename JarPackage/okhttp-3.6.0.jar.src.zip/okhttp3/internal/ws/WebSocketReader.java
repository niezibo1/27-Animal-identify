/*     */ package okhttp3.internal.ws;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSource;
/*     */ import okio.ByteString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WebSocketReader
/*     */ {
/*     */   final boolean isClient;
/*     */   final BufferedSource source;
/*     */   final FrameCallback frameCallback;
/*     */   boolean closed;
/*     */   int opcode;
/*     */   long frameLength;
/*     */   long frameBytesRead;
/*     */   boolean isFinalFrame;
/*     */   boolean isControlFrame;
/*     */   boolean isMasked;
/*  75 */   final byte[] maskKey = new byte[4];
/*  76 */   final byte[] maskBuffer = new byte[8192];
/*     */   
/*     */   WebSocketReader(boolean isClient, BufferedSource source, FrameCallback frameCallback) {
/*  79 */     if (source == null) throw new NullPointerException("source == null"); 
/*  80 */     if (frameCallback == null) throw new NullPointerException("frameCallback == null"); 
/*  81 */     this.isClient = isClient;
/*  82 */     this.source = source;
/*  83 */     this.frameCallback = frameCallback;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processNextFrame() throws IOException {
/*  97 */     readHeader();
/*  98 */     if (this.isControlFrame) {
/*  99 */       readControlFrame();
/*     */     } else {
/* 101 */       readMessageFrame();
/*     */     } 
/*     */   }
/*     */   private void readHeader() throws IOException {
/*     */     int b0;
/* 106 */     if (this.closed) throw new IOException("closed");
/*     */ 
/*     */ 
/*     */     
/* 110 */     long timeoutBefore = this.source.timeout().timeoutNanos();
/* 111 */     this.source.timeout().clearTimeout();
/*     */     try {
/* 113 */       b0 = this.source.readByte() & 0xFF;
/*     */     } finally {
/* 115 */       this.source.timeout().timeout(timeoutBefore, TimeUnit.NANOSECONDS);
/*     */     } 
/*     */     
/* 118 */     this.opcode = b0 & 0xF;
/* 119 */     this.isFinalFrame = ((b0 & 0x80) != 0);
/* 120 */     this.isControlFrame = ((b0 & 0x8) != 0);
/*     */ 
/*     */     
/* 123 */     if (this.isControlFrame && !this.isFinalFrame) {
/* 124 */       throw new ProtocolException("Control frames must be final.");
/*     */     }
/*     */     
/* 127 */     boolean reservedFlag1 = ((b0 & 0x40) != 0);
/* 128 */     boolean reservedFlag2 = ((b0 & 0x20) != 0);
/* 129 */     boolean reservedFlag3 = ((b0 & 0x10) != 0);
/* 130 */     if (reservedFlag1 || reservedFlag2 || reservedFlag3)
/*     */     {
/* 132 */       throw new ProtocolException("Reserved flags are unsupported.");
/*     */     }
/*     */     
/* 135 */     int b1 = this.source.readByte() & 0xFF;
/*     */     
/* 137 */     this.isMasked = ((b1 & 0x80) != 0);
/* 138 */     if (this.isMasked == this.isClient)
/*     */     {
/* 140 */       throw new ProtocolException(this.isClient ? "Server-sent frames must not be masked." : "Client-sent frames must be masked.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     this.frameLength = (b1 & 0x7F);
/* 147 */     if (this.frameLength == 126L) {
/* 148 */       this.frameLength = this.source.readShort() & 0xFFFFL;
/* 149 */     } else if (this.frameLength == 127L) {
/* 150 */       this.frameLength = this.source.readLong();
/* 151 */       if (this.frameLength < 0L) {
/* 152 */         throw new ProtocolException("Frame length 0x" + 
/* 153 */             Long.toHexString(this.frameLength) + " > 0x7FFFFFFFFFFFFFFF");
/*     */       }
/*     */     } 
/* 156 */     this.frameBytesRead = 0L;
/*     */     
/* 158 */     if (this.isControlFrame && this.frameLength > 125L) {
/* 159 */       throw new ProtocolException("Control frame must be less than 125B.");
/*     */     }
/*     */     
/* 162 */     if (this.isMasked)
/*     */     {
/* 164 */       this.source.readFully(this.maskKey); } 
/*     */   } private void readControlFrame() throws IOException {
/*     */     int code;
/*     */     String reason;
/*     */     long bufferSize;
/* 169 */     Buffer buffer = new Buffer();
/* 170 */     if (this.frameBytesRead < this.frameLength) {
/* 171 */       if (this.isClient) {
/* 172 */         this.source.readFully(buffer, this.frameLength);
/*     */       } else {
/* 174 */         while (this.frameBytesRead < this.frameLength) {
/* 175 */           int toRead = (int)Math.min(this.frameLength - this.frameBytesRead, this.maskBuffer.length);
/* 176 */           int read = this.source.read(this.maskBuffer, 0, toRead);
/* 177 */           if (read == -1) throw new EOFException(); 
/* 178 */           WebSocketProtocol.toggleMask(this.maskBuffer, read, this.maskKey, this.frameBytesRead);
/* 179 */           buffer.write(this.maskBuffer, 0, read);
/* 180 */           this.frameBytesRead += read;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 185 */     switch (this.opcode) {
/*     */       case 9:
/* 187 */         this.frameCallback.onReadPing(buffer.readByteString());
/*     */         return;
/*     */       case 10:
/* 190 */         this.frameCallback.onReadPong(buffer.readByteString());
/*     */         return;
/*     */       case 8:
/* 193 */         code = 1005;
/* 194 */         reason = "";
/* 195 */         bufferSize = buffer.size();
/* 196 */         if (bufferSize == 1L)
/* 197 */           throw new ProtocolException("Malformed close payload length of 1."); 
/* 198 */         if (bufferSize != 0L) {
/* 199 */           code = buffer.readShort();
/* 200 */           reason = buffer.readUtf8();
/* 201 */           String codeExceptionMessage = WebSocketProtocol.closeCodeExceptionMessage(code);
/* 202 */           if (codeExceptionMessage != null) throw new ProtocolException(codeExceptionMessage); 
/*     */         } 
/* 204 */         this.frameCallback.onReadClose(code, reason);
/* 205 */         this.closed = true;
/*     */         return;
/*     */     } 
/* 208 */     throw new ProtocolException("Unknown control opcode: " + Integer.toHexString(this.opcode));
/*     */   }
/*     */ 
/*     */   
/*     */   private void readMessageFrame() throws IOException {
/* 213 */     int opcode = this.opcode;
/* 214 */     if (opcode != 1 && opcode != 2) {
/* 215 */       throw new ProtocolException("Unknown opcode: " + Integer.toHexString(opcode));
/*     */     }
/*     */     
/* 218 */     Buffer message = new Buffer();
/* 219 */     readMessage(message);
/*     */     
/* 221 */     if (opcode == 1) {
/* 222 */       this.frameCallback.onReadMessage(message.readUtf8());
/*     */     } else {
/* 224 */       this.frameCallback.onReadMessage(message.readByteString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void readUntilNonControlFrame() throws IOException {
/* 230 */     while (!this.closed) {
/* 231 */       readHeader();
/* 232 */       if (!this.isControlFrame) {
/*     */         break;
/*     */       }
/* 235 */       readControlFrame();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readMessage(Buffer sink) throws IOException {
/*     */     while (true) {
/*     */       long read;
/* 246 */       if (this.closed) throw new IOException("closed");
/*     */       
/* 248 */       if (this.frameBytesRead == this.frameLength) {
/* 249 */         if (this.isFinalFrame)
/*     */           return; 
/* 251 */         readUntilNonControlFrame();
/* 252 */         if (this.opcode != 0) {
/* 253 */           throw new ProtocolException("Expected continuation opcode. Got: " + Integer.toHexString(this.opcode));
/*     */         }
/* 255 */         if (this.isFinalFrame && this.frameLength == 0L) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */       
/* 260 */       long toRead = this.frameLength - this.frameBytesRead;
/*     */ 
/*     */       
/* 263 */       if (this.isMasked) {
/* 264 */         toRead = Math.min(toRead, this.maskBuffer.length);
/* 265 */         read = this.source.read(this.maskBuffer, 0, (int)toRead);
/* 266 */         if (read == -1L) throw new EOFException(); 
/* 267 */         WebSocketProtocol.toggleMask(this.maskBuffer, read, this.maskKey, this.frameBytesRead);
/* 268 */         sink.write(this.maskBuffer, 0, (int)read);
/*     */       } else {
/* 270 */         read = this.source.read(sink, toRead);
/* 271 */         if (read == -1L) throw new EOFException();
/*     */       
/*     */       } 
/* 274 */       this.frameBytesRead += read;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface FrameCallback {
/*     */     void onReadMessage(String param1String) throws IOException;
/*     */     
/*     */     void onReadMessage(ByteString param1ByteString) throws IOException;
/*     */     
/*     */     void onReadPing(ByteString param1ByteString);
/*     */     
/*     */     void onReadPong(ByteString param1ByteString);
/*     */     
/*     */     void onReadClose(int param1Int, String param1String);
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\ws\WebSocketReader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */