/*     */ package okhttp3.internal.ws;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Random;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSink;
/*     */ import okio.ByteString;
/*     */ import okio.Sink;
/*     */ import okio.Timeout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WebSocketWriter
/*     */ {
/*     */   final boolean isClient;
/*     */   final Random random;
/*     */   final BufferedSink sink;
/*     */   boolean writerClosed;
/*  56 */   final Buffer buffer = new Buffer();
/*  57 */   final FrameSink frameSink = new FrameSink();
/*     */   
/*     */   boolean activeWriter;
/*     */   
/*     */   final byte[] maskKey;
/*     */   final byte[] maskBuffer;
/*     */   
/*     */   WebSocketWriter(boolean isClient, BufferedSink sink, Random random) {
/*  65 */     if (sink == null) throw new NullPointerException("sink == null"); 
/*  66 */     if (random == null) throw new NullPointerException("random == null"); 
/*  67 */     this.isClient = isClient;
/*  68 */     this.sink = sink;
/*  69 */     this.random = random;
/*     */ 
/*     */     
/*  72 */     this.maskKey = isClient ? new byte[4] : null;
/*  73 */     this.maskBuffer = isClient ? new byte[8192] : null;
/*     */   }
/*     */ 
/*     */   
/*     */   void writePing(ByteString payload) throws IOException {
/*  78 */     synchronized (this) {
/*  79 */       writeControlFrameSynchronized(9, payload);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void writePong(ByteString payload) throws IOException {
/*  85 */     synchronized (this) {
/*  86 */       writeControlFrameSynchronized(10, payload);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeClose(int code, ByteString reason) throws IOException {
/*  98 */     ByteString payload = ByteString.EMPTY;
/*  99 */     if (code != 0 || reason != null) {
/* 100 */       if (code != 0) {
/* 101 */         WebSocketProtocol.validateCloseCode(code);
/*     */       }
/* 103 */       Buffer buffer = new Buffer();
/* 104 */       buffer.writeShort(code);
/* 105 */       if (reason != null) {
/* 106 */         buffer.write(reason);
/*     */       }
/* 108 */       payload = buffer.readByteString();
/*     */     } 
/*     */     
/* 111 */     synchronized (this) {
/*     */       try {
/* 113 */         writeControlFrameSynchronized(8, payload);
/*     */       } finally {
/* 115 */         this.writerClosed = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeControlFrameSynchronized(int opcode, ByteString payload) throws IOException {
/* 121 */     assert Thread.holdsLock(this);
/*     */     
/* 123 */     if (this.writerClosed) throw new IOException("closed");
/*     */     
/* 125 */     int length = payload.size();
/* 126 */     if (length > 125L) {
/* 127 */       throw new IllegalArgumentException("Payload size must be less than or equal to 125");
/*     */     }
/*     */ 
/*     */     
/* 131 */     int b0 = 0x80 | opcode;
/* 132 */     this.sink.writeByte(b0);
/*     */     
/* 134 */     int b1 = length;
/* 135 */     if (this.isClient) {
/* 136 */       b1 |= 0x80;
/* 137 */       this.sink.writeByte(b1);
/*     */       
/* 139 */       this.random.nextBytes(this.maskKey);
/* 140 */       this.sink.write(this.maskKey);
/*     */       
/* 142 */       byte[] bytes = payload.toByteArray();
/* 143 */       WebSocketProtocol.toggleMask(bytes, bytes.length, this.maskKey, 0L);
/* 144 */       this.sink.write(bytes);
/*     */     } else {
/* 146 */       this.sink.writeByte(b1);
/* 147 */       this.sink.write(payload);
/*     */     } 
/*     */     
/* 150 */     this.sink.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Sink newMessageSink(int formatOpcode, long contentLength) {
/* 158 */     if (this.activeWriter) {
/* 159 */       throw new IllegalStateException("Another message writer is active. Did you call close()?");
/*     */     }
/* 161 */     this.activeWriter = true;
/*     */ 
/*     */     
/* 164 */     this.frameSink.formatOpcode = formatOpcode;
/* 165 */     this.frameSink.contentLength = contentLength;
/* 166 */     this.frameSink.isFirstFrame = true;
/* 167 */     this.frameSink.closed = false;
/*     */     
/* 169 */     return this.frameSink;
/*     */   }
/*     */ 
/*     */   
/*     */   void writeMessageFrameSynchronized(int formatOpcode, long byteCount, boolean isFirstFrame, boolean isFinal) throws IOException {
/* 174 */     assert Thread.holdsLock(this);
/*     */     
/* 176 */     if (this.writerClosed) throw new IOException("closed");
/*     */     
/* 178 */     int b0 = isFirstFrame ? formatOpcode : 0;
/* 179 */     if (isFinal) {
/* 180 */       b0 |= 0x80;
/*     */     }
/* 182 */     this.sink.writeByte(b0);
/*     */     
/* 184 */     int b1 = 0;
/* 185 */     if (this.isClient) {
/* 186 */       b1 |= 0x80;
/*     */     }
/* 188 */     if (byteCount <= 125L) {
/* 189 */       b1 |= (int)byteCount;
/* 190 */       this.sink.writeByte(b1);
/* 191 */     } else if (byteCount <= 65535L) {
/* 192 */       b1 |= 0x7E;
/* 193 */       this.sink.writeByte(b1);
/* 194 */       this.sink.writeShort((int)byteCount);
/*     */     } else {
/* 196 */       b1 |= 0x7F;
/* 197 */       this.sink.writeByte(b1);
/* 198 */       this.sink.writeLong(byteCount);
/*     */     } 
/*     */     
/* 201 */     if (this.isClient) {
/* 202 */       this.random.nextBytes(this.maskKey);
/* 203 */       this.sink.write(this.maskKey);
/*     */       long written;
/* 205 */       for (written = 0L; written < byteCount; ) {
/* 206 */         int toRead = (int)Math.min(byteCount, this.maskBuffer.length);
/* 207 */         int read = this.buffer.read(this.maskBuffer, 0, toRead);
/* 208 */         if (read == -1) throw new AssertionError(); 
/* 209 */         WebSocketProtocol.toggleMask(this.maskBuffer, read, this.maskKey, written);
/* 210 */         this.sink.write(this.maskBuffer, 0, read);
/* 211 */         written += read;
/*     */       } 
/*     */     } else {
/* 214 */       this.sink.write(this.buffer, byteCount);
/*     */     } 
/*     */     
/* 217 */     this.sink.emit();
/*     */   }
/*     */   
/*     */   final class FrameSink implements Sink {
/*     */     int formatOpcode;
/*     */     long contentLength;
/*     */     boolean isFirstFrame;
/*     */     boolean closed;
/*     */     
/*     */     public void write(Buffer source, long byteCount) throws IOException {
/* 227 */       if (this.closed) throw new IOException("closed");
/*     */       
/* 229 */       WebSocketWriter.this.buffer.write(source, byteCount);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       boolean deferWrite = (this.isFirstFrame && this.contentLength != -1L && WebSocketWriter.this.buffer.size() > this.contentLength - 8192L);
/*     */       
/* 236 */       long emitCount = WebSocketWriter.this.buffer.completeSegmentByteCount();
/* 237 */       if (emitCount > 0L && !deferWrite) {
/* 238 */         synchronized (WebSocketWriter.this) {
/* 239 */           WebSocketWriter.this.writeMessageFrameSynchronized(this.formatOpcode, emitCount, this.isFirstFrame, false);
/*     */         } 
/* 241 */         this.isFirstFrame = false;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void flush() throws IOException {
/* 246 */       if (this.closed) throw new IOException("closed");
/*     */       
/* 248 */       synchronized (WebSocketWriter.this) {
/* 249 */         WebSocketWriter.this.writeMessageFrameSynchronized(this.formatOpcode, WebSocketWriter.this.buffer.size(), this.isFirstFrame, false);
/*     */       } 
/* 251 */       this.isFirstFrame = false;
/*     */     }
/*     */     
/*     */     public Timeout timeout() {
/* 255 */       return WebSocketWriter.this.sink.timeout();
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 260 */       if (this.closed) throw new IOException("closed");
/*     */       
/* 262 */       synchronized (WebSocketWriter.this) {
/* 263 */         WebSocketWriter.this.writeMessageFrameSynchronized(this.formatOpcode, WebSocketWriter.this.buffer.size(), this.isFirstFrame, true);
/*     */       } 
/* 265 */       this.closed = true;
/* 266 */       WebSocketWriter.this.activeWriter = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\ws\WebSocketWriter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */