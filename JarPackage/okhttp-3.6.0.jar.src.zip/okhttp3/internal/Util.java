/*     */ package okhttp3.internal;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.net.IDN;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.regex.Pattern;
/*     */ import okhttp3.HttpUrl;
/*     */ import okhttp3.RequestBody;
/*     */ import okhttp3.ResponseBody;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSource;
/*     */ import okio.ByteString;
/*     */ import okio.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Util
/*     */ {
/*  45 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*  46 */   public static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*  48 */   public static final ResponseBody EMPTY_RESPONSE = ResponseBody.create(null, EMPTY_BYTE_ARRAY);
/*  49 */   public static final RequestBody EMPTY_REQUEST = RequestBody.create(null, EMPTY_BYTE_ARRAY);
/*     */   
/*  51 */   private static final ByteString UTF_8_BOM = ByteString.decodeHex("efbbbf");
/*  52 */   private static final ByteString UTF_16_BE_BOM = ByteString.decodeHex("feff");
/*  53 */   private static final ByteString UTF_16_LE_BOM = ByteString.decodeHex("fffe");
/*  54 */   private static final ByteString UTF_32_BE_BOM = ByteString.decodeHex("0000ffff");
/*  55 */   private static final ByteString UTF_32_LE_BOM = ByteString.decodeHex("ffff0000");
/*     */   
/*  57 */   public static final Charset UTF_8 = Charset.forName("UTF-8");
/*  58 */   private static final Charset UTF_16_BE = Charset.forName("UTF-16BE");
/*  59 */   private static final Charset UTF_16_LE = Charset.forName("UTF-16LE");
/*  60 */   private static final Charset UTF_32_BE = Charset.forName("UTF-32BE");
/*  61 */   private static final Charset UTF_32_LE = Charset.forName("UTF-32LE");
/*     */ 
/*     */   
/*  64 */   public static final TimeZone UTC = TimeZone.getTimeZone("GMT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private static final Pattern VERIFY_AS_IP_ADDRESS = Pattern.compile("([0-9a-fA-F]*:[0-9a-fA-F:.]*)|([\\d.]+)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkOffsetAndCount(long arrayLength, long offset, long count) {
/*  83 */     if ((offset | count) < 0L || offset > arrayLength || arrayLength - offset < count) {
/*  84 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean equal(Object a, Object b) {
/*  90 */     return (a == b || (a != null && a.equals(b)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeQuietly(Closeable closeable) {
/*  98 */     if (closeable != null) {
/*     */       try {
/* 100 */         closeable.close();
/* 101 */       } catch (RuntimeException rethrown) {
/* 102 */         throw rethrown;
/* 103 */       } catch (Exception exception) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeQuietly(Socket socket) {
/* 113 */     if (socket != null) {
/*     */       try {
/* 115 */         socket.close();
/* 116 */       } catch (AssertionError e) {
/* 117 */         if (!isAndroidGetsocknameError(e)) throw e; 
/* 118 */       } catch (RuntimeException rethrown) {
/* 119 */         throw rethrown;
/* 120 */       } catch (Exception exception) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeQuietly(ServerSocket serverSocket) {
/* 130 */     if (serverSocket != null) {
/*     */       try {
/* 132 */         serverSocket.close();
/* 133 */       } catch (RuntimeException rethrown) {
/* 134 */         throw rethrown;
/* 135 */       } catch (Exception exception) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean discard(Source source, int timeout, TimeUnit timeUnit) {
/*     */     try {
/* 147 */       return skipAll(source, timeout, timeUnit);
/* 148 */     } catch (IOException e) {
/* 149 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean skipAll(Source source, int duration, TimeUnit timeUnit) throws IOException {
/* 158 */     long now = System.nanoTime();
/*     */     
/* 160 */     long originalDuration = source.timeout().hasDeadline() ? (source.timeout().deadlineNanoTime() - now) : Long.MAX_VALUE;
/*     */     
/* 162 */     source.timeout().deadlineNanoTime(now + Math.min(originalDuration, timeUnit.toNanos(duration)));
/*     */     try {
/* 164 */       Buffer skipBuffer = new Buffer();
/* 165 */       while (source.read(skipBuffer, 8192L) != -1L) {
/* 166 */         skipBuffer.clear();
/*     */       }
/* 168 */       return true;
/* 169 */     } catch (InterruptedIOException e) {
/* 170 */       return false;
/*     */     } finally {
/* 172 */       if (originalDuration == Long.MAX_VALUE) {
/* 173 */         source.timeout().clearDeadline();
/*     */       } else {
/* 175 */         source.timeout().deadlineNanoTime(now + originalDuration);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> List<T> immutableList(List<T> list) {
/* 182 */     return Collections.unmodifiableList(new ArrayList<>(list));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> List<T> immutableList(T... elements) {
/* 187 */     return Collections.unmodifiableList(Arrays.asList((T[])elements.clone()));
/*     */   }
/*     */   
/*     */   public static ThreadFactory threadFactory(final String name, final boolean daemon) {
/* 191 */     return new ThreadFactory() {
/*     */         public Thread newThread(Runnable runnable) {
/* 193 */           Thread result = new Thread(runnable, name);
/* 194 */           result.setDaemon(daemon);
/* 195 */           return result;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T[] intersect(Class<T> arrayType, T[] first, T[] second) {
/* 206 */     List<T> result = intersect(first, second);
/* 207 */     return result.toArray((T[])Array.newInstance(arrayType, result.size()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> List<T> intersect(T[] first, T[] second) {
/* 215 */     List<T> result = new ArrayList<>();
/* 216 */     for (T a : first) {
/* 217 */       for (T b : second) {
/* 218 */         if (a.equals(b)) {
/* 219 */           result.add(b);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 224 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String hostHeader(HttpUrl url, boolean includeDefaultPort) {
/* 230 */     String host = url.host().contains(":") ? ("[" + url.host() + "]") : url.host();
/* 231 */     return (includeDefaultPort || url.port() != HttpUrl.defaultPort(url.scheme())) ? (host + ":" + url
/* 232 */       .port()) : host;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHumanReadableAscii(String s) {
/* 238 */     for (int i = 0, length = s.length(); i < length; ) {
/* 239 */       int c = s.codePointAt(i);
/* 240 */       if (c > 31 && c < 127) {
/*     */         i += Character.charCount(c); continue;
/* 242 */       }  Buffer buffer = new Buffer();
/* 243 */       buffer.writeUtf8(s, 0, i); int j;
/* 244 */       for (j = i; j < length; j += Character.charCount(c)) {
/* 245 */         c = s.codePointAt(j);
/* 246 */         buffer.writeUtf8CodePoint((c > 31 && c < 127) ? c : 63);
/*     */       } 
/* 248 */       return buffer.readUtf8();
/*     */     } 
/* 250 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAndroidGetsocknameError(AssertionError e) {
/* 258 */     return (e.getCause() != null && e.getMessage() != null && e
/* 259 */       .getMessage().contains("getsockname failed"));
/*     */   }
/*     */   
/*     */   public static <T> int indexOf(T[] array, T value) {
/* 263 */     for (int i = 0, size = array.length; i < size; i++) {
/* 264 */       if (equal(array[i], value)) return i; 
/*     */     } 
/* 266 */     return -1;
/*     */   }
/*     */   
/*     */   public static String[] concat(String[] array, String value) {
/* 270 */     String[] result = new String[array.length + 1];
/* 271 */     System.arraycopy(array, 0, result, 0, array.length);
/* 272 */     result[result.length - 1] = value;
/* 273 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int skipLeadingAsciiWhitespace(String input, int pos, int limit) {
/* 281 */     for (int i = pos; i < limit; i++) {
/* 282 */       switch (input.charAt(i)) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\f':
/*     */         case '\r':
/*     */         case ' ':
/*     */           break;
/*     */         default:
/* 290 */           return i;
/*     */       } 
/*     */     } 
/* 293 */     return limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int skipTrailingAsciiWhitespace(String input, int pos, int limit) {
/* 301 */     for (int i = limit - 1; i >= pos; i--) {
/* 302 */       switch (input.charAt(i)) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\f':
/*     */         case '\r':
/*     */         case ' ':
/*     */           break;
/*     */         default:
/* 310 */           return i + 1;
/*     */       } 
/*     */     } 
/* 313 */     return pos;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String trimSubstring(String string, int pos, int limit) {
/* 318 */     int start = skipLeadingAsciiWhitespace(string, pos, limit);
/* 319 */     int end = skipTrailingAsciiWhitespace(string, start, limit);
/* 320 */     return string.substring(start, end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int delimiterOffset(String input, int pos, int limit, String delimiters) {
/* 328 */     for (int i = pos; i < limit; i++) {
/* 329 */       if (delimiters.indexOf(input.charAt(i)) != -1) return i; 
/*     */     } 
/* 331 */     return limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int delimiterOffset(String input, int pos, int limit, char delimiter) {
/* 339 */     for (int i = pos; i < limit; i++) {
/* 340 */       if (input.charAt(i) == delimiter) return i; 
/*     */     } 
/* 342 */     return limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String domainToAscii(String input) {
/*     */     try {
/* 353 */       String result = IDN.toASCII(input).toLowerCase(Locale.US);
/* 354 */       if (result.isEmpty()) return null;
/*     */ 
/*     */       
/* 357 */       if (containsInvalidHostnameAsciiCodes(result)) {
/* 358 */         return null;
/*     */       }
/*     */       
/* 361 */       return result;
/* 362 */     } catch (IllegalArgumentException e) {
/* 363 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean containsInvalidHostnameAsciiCodes(String hostnameAscii) {
/* 368 */     for (int i = 0; i < hostnameAscii.length(); i++) {
/* 369 */       char c = hostnameAscii.charAt(i);
/*     */ 
/*     */ 
/*     */       
/* 373 */       if (c <= '\037' || c >= '') {
/* 374 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 379 */       if (" #%/:?@[\\]".indexOf(c) != -1) {
/* 380 */         return true;
/*     */       }
/*     */     } 
/* 383 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int indexOfControlOrNonAscii(String input) {
/* 392 */     for (int i = 0, length = input.length(); i < length; i++) {
/* 393 */       char c = input.charAt(i);
/* 394 */       if (c <= '\037' || c >= '') {
/* 395 */         return i;
/*     */       }
/*     */     } 
/* 398 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean verifyAsIpAddress(String host) {
/* 403 */     return VERIFY_AS_IP_ADDRESS.matcher(host).matches();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String format(String format, Object... args) {
/* 408 */     return String.format(Locale.US, format, args);
/*     */   }
/*     */   
/*     */   public static Charset bomAwareCharset(BufferedSource source, Charset charset) throws IOException {
/* 412 */     if (source.rangeEquals(0L, UTF_8_BOM)) {
/* 413 */       source.skip(UTF_8_BOM.size());
/* 414 */       return UTF_8;
/*     */     } 
/* 416 */     if (source.rangeEquals(0L, UTF_16_BE_BOM)) {
/* 417 */       source.skip(UTF_16_BE_BOM.size());
/* 418 */       return UTF_16_BE;
/*     */     } 
/* 420 */     if (source.rangeEquals(0L, UTF_16_LE_BOM)) {
/* 421 */       source.skip(UTF_16_LE_BOM.size());
/* 422 */       return UTF_16_LE;
/*     */     } 
/* 424 */     if (source.rangeEquals(0L, UTF_32_BE_BOM)) {
/* 425 */       source.skip(UTF_32_BE_BOM.size());
/* 426 */       return UTF_32_BE;
/*     */     } 
/* 428 */     if (source.rangeEquals(0L, UTF_32_LE_BOM)) {
/* 429 */       source.skip(UTF_32_LE_BOM.size());
/* 430 */       return UTF_32_LE;
/*     */     } 
/* 432 */     return charset;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\Util.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */