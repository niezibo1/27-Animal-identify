/*     */ package okhttp3.internal.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import okhttp3.Connection;
/*     */ import okhttp3.HttpUrl;
/*     */ import okhttp3.Interceptor;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.Response;
/*     */ import okhttp3.internal.connection.StreamAllocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RealInterceptorChain
/*     */   implements Interceptor.Chain
/*     */ {
/*     */   private final List<Interceptor> interceptors;
/*     */   private final StreamAllocation streamAllocation;
/*     */   private final HttpCodec httpCodec;
/*     */   private final Connection connection;
/*     */   private final int index;
/*     */   private final Request request;
/*     */   private int calls;
/*     */   
/*     */   public RealInterceptorChain(List<Interceptor> interceptors, StreamAllocation streamAllocation, HttpCodec httpCodec, Connection connection, int index, Request request) {
/*  42 */     this.interceptors = interceptors;
/*  43 */     this.connection = connection;
/*  44 */     this.streamAllocation = streamAllocation;
/*  45 */     this.httpCodec = httpCodec;
/*  46 */     this.index = index;
/*  47 */     this.request = request;
/*     */   }
/*     */   
/*     */   public Connection connection() {
/*  51 */     return this.connection;
/*     */   }
/*     */   
/*     */   public StreamAllocation streamAllocation() {
/*  55 */     return this.streamAllocation;
/*     */   }
/*     */   
/*     */   public HttpCodec httpStream() {
/*  59 */     return this.httpCodec;
/*     */   }
/*     */   
/*     */   public Request request() {
/*  63 */     return this.request;
/*     */   }
/*     */   
/*     */   public Response proceed(Request request) throws IOException {
/*  67 */     return proceed(request, this.streamAllocation, this.httpCodec, this.connection);
/*     */   }
/*     */ 
/*     */   
/*     */   public Response proceed(Request request, StreamAllocation streamAllocation, HttpCodec httpCodec, Connection connection) throws IOException {
/*  72 */     if (this.index >= this.interceptors.size()) throw new AssertionError();
/*     */     
/*  74 */     this.calls++;
/*     */ 
/*     */     
/*  77 */     if (this.httpCodec != null && !sameConnection(request.url())) {
/*  78 */       throw new IllegalStateException("network interceptor " + this.interceptors.get(this.index - 1) + " must retain the same host and port");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  83 */     if (this.httpCodec != null && this.calls > 1) {
/*  84 */       throw new IllegalStateException("network interceptor " + this.interceptors.get(this.index - 1) + " must call proceed() exactly once");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  89 */     RealInterceptorChain next = new RealInterceptorChain(this.interceptors, streamAllocation, httpCodec, connection, this.index + 1, request);
/*     */     
/*  91 */     Interceptor interceptor = this.interceptors.get(this.index);
/*  92 */     Response response = interceptor.intercept(next);
/*     */ 
/*     */     
/*  95 */     if (httpCodec != null && this.index + 1 < this.interceptors.size() && next.calls != 1) {
/*  96 */       throw new IllegalStateException("network interceptor " + interceptor + " must call proceed() exactly once");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 101 */     if (response == null) {
/* 102 */       throw new NullPointerException("interceptor " + interceptor + " returned null");
/*     */     }
/*     */     
/* 105 */     return response;
/*     */   }
/*     */   
/*     */   private boolean sameConnection(HttpUrl url) {
/* 109 */     return (url.host().equals(this.connection.route().address().url().host()) && url
/* 110 */       .port() == this.connection.route().address().url().port());
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http\RealInterceptorChain.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */