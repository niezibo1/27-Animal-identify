package okhttp3.internal.http;

public interface UnrepeatableRequestBody {}


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http\UnrepeatableRequestBody.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */