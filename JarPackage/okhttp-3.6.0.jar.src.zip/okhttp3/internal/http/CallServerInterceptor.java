/*    */ package okhttp3.internal.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.ProtocolException;
/*    */ import okhttp3.Interceptor;
/*    */ import okhttp3.Request;
/*    */ import okhttp3.Response;
/*    */ import okhttp3.internal.Util;
/*    */ import okhttp3.internal.connection.StreamAllocation;
/*    */ import okio.BufferedSink;
/*    */ import okio.Okio;
/*    */ import okio.Sink;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CallServerInterceptor
/*    */   implements Interceptor
/*    */ {
/*    */   private final boolean forWebSocket;
/*    */   
/*    */   public CallServerInterceptor(boolean forWebSocket) {
/* 34 */     this.forWebSocket = forWebSocket;
/*    */   }
/*    */   
/*    */   public Response intercept(Interceptor.Chain chain) throws IOException {
/* 38 */     HttpCodec httpCodec = ((RealInterceptorChain)chain).httpStream();
/* 39 */     StreamAllocation streamAllocation = ((RealInterceptorChain)chain).streamAllocation();
/* 40 */     Request request = chain.request();
/*    */     
/* 42 */     long sentRequestMillis = System.currentTimeMillis();
/* 43 */     httpCodec.writeRequestHeaders(request);
/*    */     
/* 45 */     Response.Builder responseBuilder = null;
/* 46 */     if (HttpMethod.permitsRequestBody(request.method()) && request.body() != null) {
/*    */ 
/*    */ 
/*    */       
/* 50 */       if ("100-continue".equalsIgnoreCase(request.header("Expect"))) {
/* 51 */         httpCodec.flushRequest();
/* 52 */         responseBuilder = httpCodec.readResponseHeaders(true);
/*    */       } 
/*    */ 
/*    */       
/* 56 */       if (responseBuilder == null) {
/* 57 */         Sink requestBodyOut = httpCodec.createRequestBody(request, request.body().contentLength());
/* 58 */         BufferedSink bufferedRequestBody = Okio.buffer(requestBodyOut);
/* 59 */         request.body().writeTo(bufferedRequestBody);
/* 60 */         bufferedRequestBody.close();
/*    */       } 
/*    */     } 
/*    */     
/* 64 */     httpCodec.finishRequest();
/*    */     
/* 66 */     if (responseBuilder == null) {
/* 67 */       responseBuilder = httpCodec.readResponseHeaders(false);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 75 */     Response response = responseBuilder.request(request).handshake(streamAllocation.connection().handshake()).sentRequestAtMillis(sentRequestMillis).receivedResponseAtMillis(System.currentTimeMillis()).build();
/*    */     
/* 77 */     int code = response.code();
/* 78 */     if (this.forWebSocket && code == 101) {
/*    */ 
/*    */ 
/*    */       
/* 82 */       response = response.newBuilder().body(Util.EMPTY_RESPONSE).build();
/*    */     }
/*    */     else {
/*    */       
/* 86 */       response = response.newBuilder().body(httpCodec.openResponseBody(response)).build();
/*    */     } 
/*    */     
/* 89 */     if ("close".equalsIgnoreCase(response.request().header("Connection")) || "close"
/* 90 */       .equalsIgnoreCase(response.header("Connection"))) {
/* 91 */       streamAllocation.noNewStreams();
/*    */     }
/*    */     
/* 94 */     if ((code == 204 || code == 205) && response.body().contentLength() > 0L) {
/* 95 */       throw new ProtocolException("HTTP " + code + " had non-zero Content-Length: " + response
/* 96 */           .body().contentLength());
/*    */     }
/*    */     
/* 99 */     return response;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http\CallServerInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */