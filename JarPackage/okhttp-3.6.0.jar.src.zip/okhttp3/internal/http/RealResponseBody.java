/*    */ package okhttp3.internal.http;
/*    */ 
/*    */ import okhttp3.Headers;
/*    */ import okhttp3.MediaType;
/*    */ import okhttp3.ResponseBody;
/*    */ import okio.BufferedSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RealResponseBody
/*    */   extends ResponseBody
/*    */ {
/*    */   private final Headers headers;
/*    */   private final BufferedSource source;
/*    */   
/*    */   public RealResponseBody(Headers headers, BufferedSource source) {
/* 28 */     this.headers = headers;
/* 29 */     this.source = source;
/*    */   }
/*    */   
/*    */   public MediaType contentType() {
/* 33 */     String contentType = this.headers.get("Content-Type");
/* 34 */     return (contentType != null) ? MediaType.parse(contentType) : null;
/*    */   }
/*    */   
/*    */   public long contentLength() {
/* 38 */     return HttpHeaders.contentLength(this.headers);
/*    */   }
/*    */   
/*    */   public BufferedSource source() {
/* 42 */     return this.source;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http\RealResponseBody.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */