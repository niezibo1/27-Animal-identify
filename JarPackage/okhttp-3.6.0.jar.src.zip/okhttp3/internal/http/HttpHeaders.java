/*     */ package okhttp3.internal.http;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import okhttp3.Challenge;
/*     */ import okhttp3.Cookie;
/*     */ import okhttp3.CookieJar;
/*     */ import okhttp3.Headers;
/*     */ import okhttp3.HttpUrl;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.Response;
/*     */ import okhttp3.internal.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpHeaders
/*     */ {
/*     */   private static final String TOKEN = "([^ \"=]*)";
/*     */   private static final String QUOTED_STRING = "\"([^\"]*)\"";
/*  43 */   private static final Pattern PARAMETER = Pattern.compile(" +([^ \"=]*)=(:?\"([^\"]*)\"|([^ \"=]*)) *(:?,|$)");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long contentLength(Response response) {
/*  49 */     return contentLength(response.headers());
/*     */   }
/*     */   
/*     */   public static long contentLength(Headers headers) {
/*  53 */     return stringToLong(headers.get("Content-Length"));
/*     */   }
/*     */   
/*     */   private static long stringToLong(String s) {
/*  57 */     if (s == null) return -1L; 
/*     */     try {
/*  59 */       return Long.parseLong(s);
/*  60 */     } catch (NumberFormatException e) {
/*  61 */       return -1L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean varyMatches(Response cachedResponse, Headers cachedRequest, Request newRequest) {
/*  71 */     for (String field : varyFields(cachedResponse)) {
/*  72 */       if (!Util.equal(cachedRequest.values(field), newRequest.headers(field))) return false; 
/*     */     } 
/*  74 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasVaryAll(Response response) {
/*  81 */     return hasVaryAll(response.headers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasVaryAll(Headers responseHeaders) {
/*  88 */     return varyFields(responseHeaders).contains("*");
/*     */   }
/*     */   
/*     */   private static Set<String> varyFields(Response response) {
/*  92 */     return varyFields(response.headers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> varyFields(Headers responseHeaders) {
/*  99 */     Set<String> result = Collections.emptySet();
/* 100 */     for (int i = 0, size = responseHeaders.size(); i < size; i++) {
/* 101 */       if ("Vary".equalsIgnoreCase(responseHeaders.name(i))) {
/*     */         
/* 103 */         String value = responseHeaders.value(i);
/* 104 */         if (result.isEmpty()) {
/* 105 */           result = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
/*     */         }
/* 107 */         for (String varyField : value.split(","))
/* 108 */           result.add(varyField.trim()); 
/*     */       } 
/*     */     } 
/* 111 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Headers varyHeaders(Response response) {
/* 122 */     Headers requestHeaders = response.networkResponse().request().headers();
/* 123 */     Headers responseHeaders = response.headers();
/* 124 */     return varyHeaders(requestHeaders, responseHeaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Headers varyHeaders(Headers requestHeaders, Headers responseHeaders) {
/* 132 */     Set<String> varyFields = varyFields(responseHeaders);
/* 133 */     if (varyFields.isEmpty()) return (new Headers.Builder()).build();
/*     */     
/* 135 */     Headers.Builder result = new Headers.Builder();
/* 136 */     for (int i = 0, size = requestHeaders.size(); i < size; i++) {
/* 137 */       String fieldName = requestHeaders.name(i);
/* 138 */       if (varyFields.contains(fieldName)) {
/* 139 */         result.add(fieldName, requestHeaders.value(i));
/*     */       }
/*     */     } 
/* 142 */     return result.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Challenge> parseChallenges(Headers responseHeaders, String challengeHeader) {
/* 155 */     List<Challenge> challenges = new ArrayList<>();
/* 156 */     List<String> authenticationHeaders = responseHeaders.values(challengeHeader);
/* 157 */     for (String header : authenticationHeaders) {
/* 158 */       int index = header.indexOf(' ');
/* 159 */       if (index == -1)
/*     */         continue; 
/* 161 */       Matcher matcher = PARAMETER.matcher(header); int i;
/* 162 */       for (i = index; matcher.find(i); i = matcher.end()) {
/* 163 */         if (header.regionMatches(true, matcher.start(1), "realm", 0, 5)) {
/* 164 */           String scheme = header.substring(0, index);
/* 165 */           String realm = matcher.group(3);
/* 166 */           if (realm != null) {
/* 167 */             challenges.add(new Challenge(scheme, realm));
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 173 */     return challenges;
/*     */   }
/*     */   
/*     */   public static void receiveHeaders(CookieJar cookieJar, HttpUrl url, Headers headers) {
/* 177 */     if (cookieJar == CookieJar.NO_COOKIES)
/*     */       return; 
/* 179 */     List<Cookie> cookies = Cookie.parseAll(url, headers);
/* 180 */     if (cookies.isEmpty())
/*     */       return; 
/* 182 */     cookieJar.saveFromResponse(url, cookies);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasBody(Response response) {
/* 188 */     if (response.request().method().equals("HEAD")) {
/* 189 */       return false;
/*     */     }
/*     */     
/* 192 */     int responseCode = response.code();
/* 193 */     if ((responseCode < 100 || responseCode >= 200) && responseCode != 204 && responseCode != 304)
/*     */     {
/*     */       
/* 196 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 201 */     if (contentLength(response) != -1L || "chunked"
/* 202 */       .equalsIgnoreCase(response.header("Transfer-Encoding"))) {
/* 203 */       return true;
/*     */     }
/*     */     
/* 206 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int skipUntil(String input, int pos, String characters) {
/* 214 */     for (; pos < input.length() && 
/* 215 */       characters.indexOf(input.charAt(pos)) == -1; pos++);
/*     */ 
/*     */ 
/*     */     
/* 219 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int skipWhitespace(String input, int pos) {
/* 227 */     for (; pos < input.length(); pos++) {
/* 228 */       char c = input.charAt(pos);
/* 229 */       if (c != ' ' && c != '\t') {
/*     */         break;
/*     */       }
/*     */     } 
/* 233 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int parseSeconds(String value, int defaultValue) {
/*     */     try {
/* 242 */       long seconds = Long.parseLong(value);
/* 243 */       if (seconds > 2147483647L)
/* 244 */         return Integer.MAX_VALUE; 
/* 245 */       if (seconds < 0L) {
/* 246 */         return 0;
/*     */       }
/* 248 */       return (int)seconds;
/*     */     }
/* 250 */     catch (NumberFormatException e) {
/* 251 */       return defaultValue;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http\HttpHeaders.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */