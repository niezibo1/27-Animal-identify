/*     */ package okhttp3.internal.http;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.HttpRetryException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.Proxy;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import okhttp3.Address;
/*     */ import okhttp3.CertificatePinner;
/*     */ import okhttp3.HttpUrl;
/*     */ import okhttp3.Interceptor;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.RequestBody;
/*     */ import okhttp3.Response;
/*     */ import okhttp3.Route;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.connection.RealConnection;
/*     */ import okhttp3.internal.connection.RouteException;
/*     */ import okhttp3.internal.connection.StreamAllocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RetryAndFollowUpInterceptor
/*     */   implements Interceptor
/*     */ {
/*     */   private static final int MAX_FOLLOW_UPS = 20;
/*     */   private final OkHttpClient client;
/*     */   private final boolean forWebSocket;
/*     */   private StreamAllocation streamAllocation;
/*     */   private Object callStackTrace;
/*     */   private volatile boolean canceled;
/*     */   
/*     */   public RetryAndFollowUpInterceptor(OkHttpClient client, boolean forWebSocket) {
/*  72 */     this.client = client;
/*  73 */     this.forWebSocket = forWebSocket;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel() {
/*  86 */     this.canceled = true;
/*  87 */     StreamAllocation streamAllocation = this.streamAllocation;
/*  88 */     if (streamAllocation != null) streamAllocation.cancel(); 
/*     */   }
/*     */   
/*     */   public boolean isCanceled() {
/*  92 */     return this.canceled;
/*     */   }
/*     */   
/*     */   public void setCallStackTrace(Object callStackTrace) {
/*  96 */     this.callStackTrace = callStackTrace;
/*     */   }
/*     */   
/*     */   public StreamAllocation streamAllocation() {
/* 100 */     return this.streamAllocation;
/*     */   }
/*     */   
/*     */   public Response intercept(Interceptor.Chain chain) throws IOException {
/* 104 */     Request request = chain.request();
/*     */     
/* 106 */     this
/* 107 */       .streamAllocation = new StreamAllocation(this.client.connectionPool(), createAddress(request.url()), this.callStackTrace);
/*     */     
/* 109 */     int followUpCount = 0;
/* 110 */     Response priorResponse = null;
/*     */     while (true) {
/* 112 */       if (this.canceled) {
/* 113 */         this.streamAllocation.release();
/* 114 */         throw new IOException("Canceled");
/*     */       } 
/*     */       
/* 117 */       Response response = null;
/* 118 */       boolean releaseConnection = true;
/*     */       try {
/* 120 */         response = ((RealInterceptorChain)chain).proceed(request, this.streamAllocation, null, null);
/* 121 */         releaseConnection = false;
/* 122 */       } catch (RouteException e) {
/*     */         
/* 124 */         if (!recover(e.getLastConnectException(), false, request)) {
/* 125 */           throw e.getLastConnectException();
/*     */         }
/* 127 */         releaseConnection = false;
/*     */         continue;
/* 129 */       } catch (IOException e) {
/*     */         
/* 131 */         boolean requestSendStarted = !(e instanceof okhttp3.internal.http2.ConnectionShutdownException);
/* 132 */         if (!recover(e, requestSendStarted, request)) throw e; 
/* 133 */         releaseConnection = false;
/*     */         
/*     */         continue;
/*     */       } finally {
/* 137 */         if (releaseConnection) {
/* 138 */           this.streamAllocation.streamFailed(null);
/* 139 */           this.streamAllocation.release();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 144 */       if (priorResponse != null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 149 */         response = response.newBuilder().priorResponse(priorResponse.newBuilder().body(null).build()).build();
/*     */       }
/*     */       
/* 152 */       Request followUp = followUpRequest(response);
/*     */       
/* 154 */       if (followUp == null) {
/* 155 */         if (!this.forWebSocket) {
/* 156 */           this.streamAllocation.release();
/*     */         }
/* 158 */         return response;
/*     */       } 
/*     */       
/* 161 */       Util.closeQuietly((Closeable)response.body());
/*     */       
/* 163 */       if (++followUpCount > 20) {
/* 164 */         this.streamAllocation.release();
/* 165 */         throw new ProtocolException("Too many follow-up requests: " + followUpCount);
/*     */       } 
/*     */       
/* 168 */       if (followUp.body() instanceof UnrepeatableRequestBody) {
/* 169 */         this.streamAllocation.release();
/* 170 */         throw new HttpRetryException("Cannot retry streamed HTTP body", response.code());
/*     */       } 
/*     */       
/* 173 */       if (!sameConnection(response, followUp.url())) {
/* 174 */         this.streamAllocation.release();
/* 175 */         this
/* 176 */           .streamAllocation = new StreamAllocation(this.client.connectionPool(), createAddress(followUp.url()), this.callStackTrace);
/* 177 */       } else if (this.streamAllocation.codec() != null) {
/* 178 */         throw new IllegalStateException("Closing the body of " + response + " didn't close its backing stream. Bad interceptor?");
/*     */       } 
/*     */ 
/*     */       
/* 182 */       request = followUp;
/* 183 */       priorResponse = response;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Address createAddress(HttpUrl url) {
/* 188 */     SSLSocketFactory sslSocketFactory = null;
/* 189 */     HostnameVerifier hostnameVerifier = null;
/* 190 */     CertificatePinner certificatePinner = null;
/* 191 */     if (url.isHttps()) {
/* 192 */       sslSocketFactory = this.client.sslSocketFactory();
/* 193 */       hostnameVerifier = this.client.hostnameVerifier();
/* 194 */       certificatePinner = this.client.certificatePinner();
/*     */     } 
/*     */     
/* 197 */     return new Address(url.host(), url.port(), this.client.dns(), this.client.socketFactory(), sslSocketFactory, hostnameVerifier, certificatePinner, this.client
/* 198 */         .proxyAuthenticator(), this.client
/* 199 */         .proxy(), this.client.protocols(), this.client.connectionSpecs(), this.client.proxySelector());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean recover(IOException e, boolean requestSendStarted, Request userRequest) {
/* 209 */     this.streamAllocation.streamFailed(e);
/*     */ 
/*     */     
/* 212 */     if (!this.client.retryOnConnectionFailure()) return false;
/*     */ 
/*     */     
/* 215 */     if (requestSendStarted && userRequest.body() instanceof UnrepeatableRequestBody) return false;
/*     */ 
/*     */     
/* 218 */     if (!isRecoverable(e, requestSendStarted)) return false;
/*     */ 
/*     */     
/* 221 */     if (!this.streamAllocation.hasMoreRoutes()) return false;
/*     */ 
/*     */     
/* 224 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isRecoverable(IOException e, boolean requestSendStarted) {
/* 229 */     if (e instanceof ProtocolException) {
/* 230 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 235 */     if (e instanceof java.io.InterruptedIOException) {
/* 236 */       return (e instanceof java.net.SocketTimeoutException && !requestSendStarted);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 241 */     if (e instanceof javax.net.ssl.SSLHandshakeException)
/*     */     {
/*     */       
/* 244 */       if (e.getCause() instanceof java.security.cert.CertificateException) {
/* 245 */         return false;
/*     */       }
/*     */     }
/* 248 */     if (e instanceof javax.net.ssl.SSLPeerUnverifiedException)
/*     */     {
/* 250 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     return true;
/*     */   }
/*     */   
/*     */   private Request followUpRequest(Response userResponse) throws IOException {
/*     */     Proxy selectedProxy;
/*     */     String location;
/*     */     HttpUrl url;
/*     */     boolean sameScheme;
/*     */     Request.Builder requestBuilder;
/* 265 */     if (userResponse == null) throw new IllegalStateException(); 
/* 266 */     RealConnection realConnection = this.streamAllocation.connection();
/*     */     
/* 268 */     Route route = (realConnection != null) ? realConnection.route() : null;
/*     */     
/* 270 */     int responseCode = userResponse.code();
/*     */     
/* 272 */     String method = userResponse.request().method();
/* 273 */     switch (responseCode) {
/*     */ 
/*     */       
/*     */       case 407:
/* 277 */         selectedProxy = (route != null) ? route.proxy() : this.client.proxy();
/* 278 */         if (selectedProxy.type() != Proxy.Type.HTTP) {
/* 279 */           throw new ProtocolException("Received HTTP_PROXY_AUTH (407) code while not using proxy");
/*     */         }
/* 281 */         return this.client.proxyAuthenticator().authenticate(route, userResponse);
/*     */       
/*     */       case 401:
/* 284 */         return this.client.authenticator().authenticate(route, userResponse);
/*     */ 
/*     */ 
/*     */       
/*     */       case 307:
/*     */       case 308:
/* 290 */         if (!method.equals("GET") && !method.equals("HEAD")) {
/* 291 */           return null;
/*     */         }
/*     */ 
/*     */       
/*     */       case 300:
/*     */       case 301:
/*     */       case 302:
/*     */       case 303:
/* 299 */         if (!this.client.followRedirects()) return null;
/*     */         
/* 301 */         location = userResponse.header("Location");
/* 302 */         if (location == null) return null; 
/* 303 */         url = userResponse.request().url().resolve(location);
/*     */ 
/*     */         
/* 306 */         if (url == null) return null;
/*     */ 
/*     */         
/* 309 */         sameScheme = url.scheme().equals(userResponse.request().url().scheme());
/* 310 */         if (!sameScheme && !this.client.followSslRedirects()) return null;
/*     */ 
/*     */         
/* 313 */         requestBuilder = userResponse.request().newBuilder();
/* 314 */         if (HttpMethod.permitsRequestBody(method)) {
/* 315 */           boolean maintainBody = HttpMethod.redirectsWithBody(method);
/* 316 */           if (HttpMethod.redirectsToGet(method)) {
/* 317 */             requestBuilder.method("GET", null);
/*     */           } else {
/* 319 */             RequestBody requestBody = maintainBody ? userResponse.request().body() : null;
/* 320 */             requestBuilder.method(method, requestBody);
/*     */           } 
/* 322 */           if (!maintainBody) {
/* 323 */             requestBuilder.removeHeader("Transfer-Encoding");
/* 324 */             requestBuilder.removeHeader("Content-Length");
/* 325 */             requestBuilder.removeHeader("Content-Type");
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 332 */         if (!sameConnection(userResponse, url)) {
/* 333 */           requestBuilder.removeHeader("Authorization");
/*     */         }
/*     */         
/* 336 */         return requestBuilder.url(url).build();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 408:
/* 342 */         if (userResponse.request().body() instanceof UnrepeatableRequestBody) {
/* 343 */           return null;
/*     */         }
/*     */         
/* 346 */         return userResponse.request();
/*     */     } 
/*     */     
/* 349 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean sameConnection(Response response, HttpUrl followUp) {
/* 358 */     HttpUrl url = response.request().url();
/* 359 */     return (url.host().equals(followUp.host()) && url
/* 360 */       .port() == followUp.port() && url
/* 361 */       .scheme().equals(followUp.scheme()));
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http\RetryAndFollowUpInterceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */