/*     */ package okhttp3.internal.tls;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.TrustAnchor;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TrustRootIndex
/*     */ {
/*     */   public abstract X509Certificate findByIssuerAndSignature(X509Certificate paramX509Certificate);
/*     */   
/*     */   public static TrustRootIndex get(X509TrustManager trustManager) {
/*     */     try {
/*  38 */       Method method = trustManager.getClass().getDeclaredMethod("findTrustAnchorByIssuerAndSignature", new Class[] { X509Certificate.class });
/*     */       
/*  40 */       method.setAccessible(true);
/*  41 */       return new AndroidTrustRootIndex(trustManager, method);
/*  42 */     } catch (NoSuchMethodException e) {
/*  43 */       return get(trustManager.getAcceptedIssuers());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static TrustRootIndex get(X509Certificate... caCerts) {
/*  48 */     return new BasicTrustRootIndex(caCerts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AndroidTrustRootIndex
/*     */     extends TrustRootIndex
/*     */   {
/*     */     private final X509TrustManager trustManager;
/*     */ 
/*     */     
/*     */     private final Method findByIssuerAndSignatureMethod;
/*     */ 
/*     */ 
/*     */     
/*     */     AndroidTrustRootIndex(X509TrustManager trustManager, Method findByIssuerAndSignatureMethod) {
/*  65 */       this.findByIssuerAndSignatureMethod = findByIssuerAndSignatureMethod;
/*  66 */       this.trustManager = trustManager;
/*     */     }
/*     */     
/*     */     public X509Certificate findByIssuerAndSignature(X509Certificate cert) {
/*     */       try {
/*  71 */         TrustAnchor trustAnchor = (TrustAnchor)this.findByIssuerAndSignatureMethod.invoke(this.trustManager, new Object[] { cert });
/*     */         
/*  73 */         return (trustAnchor != null) ? trustAnchor
/*  74 */           .getTrustedCert() : null;
/*     */       }
/*  76 */       catch (IllegalAccessException e) {
/*  77 */         throw new AssertionError();
/*  78 */       } catch (InvocationTargetException e) {
/*  79 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  85 */       if (obj == this) {
/*  86 */         return true;
/*     */       }
/*  88 */       if (!(obj instanceof AndroidTrustRootIndex)) {
/*  89 */         return false;
/*     */       }
/*  91 */       AndroidTrustRootIndex that = (AndroidTrustRootIndex)obj;
/*  92 */       return (this.trustManager.equals(that.trustManager) && this.findByIssuerAndSignatureMethod
/*  93 */         .equals(that.findByIssuerAndSignatureMethod));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  98 */       return this.trustManager.hashCode() + 31 * this.findByIssuerAndSignatureMethod.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class BasicTrustRootIndex
/*     */     extends TrustRootIndex
/*     */   {
/* 107 */     private final Map<X500Principal, Set<X509Certificate>> subjectToCaCerts = new LinkedHashMap<>(); public BasicTrustRootIndex(X509Certificate... caCerts) {
/* 108 */       for (X509Certificate caCert : caCerts) {
/* 109 */         X500Principal subject = caCert.getSubjectX500Principal();
/* 110 */         Set<X509Certificate> subjectCaCerts = this.subjectToCaCerts.get(subject);
/* 111 */         if (subjectCaCerts == null) {
/* 112 */           subjectCaCerts = new LinkedHashSet<>(1);
/* 113 */           this.subjectToCaCerts.put(subject, subjectCaCerts);
/*     */         } 
/* 115 */         subjectCaCerts.add(caCert);
/*     */       } 
/*     */     }
/*     */     
/*     */     public X509Certificate findByIssuerAndSignature(X509Certificate cert) {
/* 120 */       X500Principal issuer = cert.getIssuerX500Principal();
/* 121 */       Set<X509Certificate> subjectCaCerts = this.subjectToCaCerts.get(issuer);
/* 122 */       if (subjectCaCerts == null) return null;
/*     */       
/* 124 */       for (X509Certificate caCert : subjectCaCerts) {
/* 125 */         PublicKey publicKey = caCert.getPublicKey();
/*     */         try {
/* 127 */           cert.verify(publicKey);
/* 128 */           return caCert;
/* 129 */         } catch (Exception exception) {}
/*     */       } 
/*     */ 
/*     */       
/* 133 */       return null;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other) {
/* 137 */       if (other == this) return true; 
/* 138 */       return (other instanceof BasicTrustRootIndex && ((BasicTrustRootIndex)other).subjectToCaCerts
/* 139 */         .equals(this.subjectToCaCerts));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 143 */       return this.subjectToCaCerts.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\tls\TrustRootIndex.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */