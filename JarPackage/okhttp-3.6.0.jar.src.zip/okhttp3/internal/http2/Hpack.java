/*     */ package okhttp3.internal.http2;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import okhttp3.internal.Util;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSink;
/*     */ import okio.BufferedSource;
/*     */ import okio.ByteString;
/*     */ import okio.Okio;
/*     */ import okio.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Hpack
/*     */ {
/*     */   private static final int PREFIX_4_BITS = 15;
/*     */   private static final int PREFIX_5_BITS = 31;
/*     */   private static final int PREFIX_6_BITS = 63;
/*     */   private static final int PREFIX_7_BITS = 127;
/*  47 */   static final Header[] STATIC_HEADER_TABLE = new Header[] { new Header(Header.TARGET_AUTHORITY, ""), new Header(Header.TARGET_METHOD, "GET"), new Header(Header.TARGET_METHOD, "POST"), new Header(Header.TARGET_PATH, "/"), new Header(Header.TARGET_PATH, "/index.html"), new Header(Header.TARGET_SCHEME, "http"), new Header(Header.TARGET_SCHEME, "https"), new Header(Header.RESPONSE_STATUS, "200"), new Header(Header.RESPONSE_STATUS, "204"), new Header(Header.RESPONSE_STATUS, "206"), new Header(Header.RESPONSE_STATUS, "304"), new Header(Header.RESPONSE_STATUS, "400"), new Header(Header.RESPONSE_STATUS, "404"), new Header(Header.RESPONSE_STATUS, "500"), new Header("accept-charset", ""), new Header("accept-encoding", "gzip, deflate"), new Header("accept-language", ""), new Header("accept-ranges", ""), new Header("accept", ""), new Header("access-control-allow-origin", ""), new Header("age", ""), new Header("allow", ""), new Header("authorization", ""), new Header("cache-control", ""), new Header("content-disposition", ""), new Header("content-encoding", ""), new Header("content-language", ""), new Header("content-length", ""), new Header("content-location", ""), new Header("content-range", ""), new Header("content-type", ""), new Header("cookie", ""), new Header("date", ""), new Header("etag", ""), new Header("expect", ""), new Header("expires", ""), new Header("from", ""), new Header("host", ""), new Header("if-match", ""), new Header("if-modified-since", ""), new Header("if-none-match", ""), new Header("if-range", ""), new Header("if-unmodified-since", ""), new Header("last-modified", ""), new Header("link", ""), new Header("location", ""), new Header("max-forwards", ""), new Header("proxy-authenticate", ""), new Header("proxy-authorization", ""), new Header("range", ""), new Header("referer", ""), new Header("refresh", ""), new Header("retry-after", ""), new Header("server", ""), new Header("set-cookie", ""), new Header("strict-transport-security", ""), new Header("transfer-encoding", ""), new Header("user-agent", ""), new Header("vary", ""), new Header("via", ""), new Header("www-authenticate", "") };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Reader
/*     */   {
/* 117 */     private final List<Header> headerList = new ArrayList<>();
/*     */     
/*     */     private final BufferedSource source;
/*     */     
/*     */     private final int headerTableSizeSetting;
/*     */     
/*     */     private int maxDynamicTableByteCount;
/* 124 */     Header[] dynamicTable = new Header[8];
/*     */     
/* 126 */     int nextHeaderIndex = this.dynamicTable.length - 1;
/* 127 */     int headerCount = 0;
/* 128 */     int dynamicTableByteCount = 0;
/*     */     
/*     */     Reader(int headerTableSizeSetting, Source source) {
/* 131 */       this(headerTableSizeSetting, headerTableSizeSetting, source);
/*     */     }
/*     */     
/*     */     Reader(int headerTableSizeSetting, int maxDynamicTableByteCount, Source source) {
/* 135 */       this.headerTableSizeSetting = headerTableSizeSetting;
/* 136 */       this.maxDynamicTableByteCount = maxDynamicTableByteCount;
/* 137 */       this.source = Okio.buffer(source);
/*     */     }
/*     */     
/*     */     int maxDynamicTableByteCount() {
/* 141 */       return this.maxDynamicTableByteCount;
/*     */     }
/*     */     
/*     */     private void adjustDynamicTableByteCount() {
/* 145 */       if (this.maxDynamicTableByteCount < this.dynamicTableByteCount) {
/* 146 */         if (this.maxDynamicTableByteCount == 0) {
/* 147 */           clearDynamicTable();
/*     */         } else {
/* 149 */           evictToRecoverBytes(this.dynamicTableByteCount - this.maxDynamicTableByteCount);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private void clearDynamicTable() {
/* 155 */       Arrays.fill((Object[])this.dynamicTable, (Object)null);
/* 156 */       this.nextHeaderIndex = this.dynamicTable.length - 1;
/* 157 */       this.headerCount = 0;
/* 158 */       this.dynamicTableByteCount = 0;
/*     */     }
/*     */ 
/*     */     
/*     */     private int evictToRecoverBytes(int bytesToRecover) {
/* 163 */       int entriesToEvict = 0;
/* 164 */       if (bytesToRecover > 0) {
/*     */         
/* 166 */         for (int j = this.dynamicTable.length - 1; j >= this.nextHeaderIndex && bytesToRecover > 0; j--) {
/* 167 */           bytesToRecover -= (this.dynamicTable[j]).hpackSize;
/* 168 */           this.dynamicTableByteCount -= (this.dynamicTable[j]).hpackSize;
/* 169 */           this.headerCount--;
/* 170 */           entriesToEvict++;
/*     */         } 
/* 172 */         System.arraycopy(this.dynamicTable, this.nextHeaderIndex + 1, this.dynamicTable, this.nextHeaderIndex + 1 + entriesToEvict, this.headerCount);
/*     */         
/* 174 */         this.nextHeaderIndex += entriesToEvict;
/*     */       } 
/* 176 */       return entriesToEvict;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void readHeaders() throws IOException {
/* 184 */       while (!this.source.exhausted()) {
/* 185 */         int b = this.source.readByte() & 0xFF;
/* 186 */         if (b == 128)
/* 187 */           throw new IOException("index == 0"); 
/* 188 */         if ((b & 0x80) == 128) {
/* 189 */           int i = readInt(b, 127);
/* 190 */           readIndexedHeader(i - 1); continue;
/* 191 */         }  if (b == 64) {
/* 192 */           readLiteralHeaderWithIncrementalIndexingNewName(); continue;
/* 193 */         }  if ((b & 0x40) == 64) {
/* 194 */           int i = readInt(b, 63);
/* 195 */           readLiteralHeaderWithIncrementalIndexingIndexedName(i - 1); continue;
/* 196 */         }  if ((b & 0x20) == 32) {
/* 197 */           this.maxDynamicTableByteCount = readInt(b, 31);
/* 198 */           if (this.maxDynamicTableByteCount < 0 || this.maxDynamicTableByteCount > this.headerTableSizeSetting)
/*     */           {
/* 200 */             throw new IOException("Invalid dynamic table size update " + this.maxDynamicTableByteCount);
/*     */           }
/* 202 */           adjustDynamicTableByteCount(); continue;
/* 203 */         }  if (b == 16 || b == 0) {
/* 204 */           readLiteralHeaderWithoutIndexingNewName(); continue;
/*     */         } 
/* 206 */         int index = readInt(b, 15);
/* 207 */         readLiteralHeaderWithoutIndexingIndexedName(index - 1);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public List<Header> getAndResetHeaderList() {
/* 213 */       List<Header> result = new ArrayList<>(this.headerList);
/* 214 */       this.headerList.clear();
/* 215 */       return result;
/*     */     }
/*     */     
/*     */     private void readIndexedHeader(int index) throws IOException {
/* 219 */       if (isStaticHeader(index)) {
/* 220 */         Header staticEntry = Hpack.STATIC_HEADER_TABLE[index];
/* 221 */         this.headerList.add(staticEntry);
/*     */       } else {
/* 223 */         int dynamicTableIndex = dynamicTableIndex(index - Hpack.STATIC_HEADER_TABLE.length);
/* 224 */         if (dynamicTableIndex < 0 || dynamicTableIndex > this.dynamicTable.length - 1) {
/* 225 */           throw new IOException("Header index too large " + (index + 1));
/*     */         }
/* 227 */         this.headerList.add(this.dynamicTable[dynamicTableIndex]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private int dynamicTableIndex(int index) {
/* 233 */       return this.nextHeaderIndex + 1 + index;
/*     */     }
/*     */     
/*     */     private void readLiteralHeaderWithoutIndexingIndexedName(int index) throws IOException {
/* 237 */       ByteString name = getName(index);
/* 238 */       ByteString value = readByteString();
/* 239 */       this.headerList.add(new Header(name, value));
/*     */     }
/*     */     
/*     */     private void readLiteralHeaderWithoutIndexingNewName() throws IOException {
/* 243 */       ByteString name = Hpack.checkLowercase(readByteString());
/* 244 */       ByteString value = readByteString();
/* 245 */       this.headerList.add(new Header(name, value));
/*     */     }
/*     */ 
/*     */     
/*     */     private void readLiteralHeaderWithIncrementalIndexingIndexedName(int nameIndex) throws IOException {
/* 250 */       ByteString name = getName(nameIndex);
/* 251 */       ByteString value = readByteString();
/* 252 */       insertIntoDynamicTable(-1, new Header(name, value));
/*     */     }
/*     */     
/*     */     private void readLiteralHeaderWithIncrementalIndexingNewName() throws IOException {
/* 256 */       ByteString name = Hpack.checkLowercase(readByteString());
/* 257 */       ByteString value = readByteString();
/* 258 */       insertIntoDynamicTable(-1, new Header(name, value));
/*     */     }
/*     */     
/*     */     private ByteString getName(int index) {
/* 262 */       if (isStaticHeader(index)) {
/* 263 */         return (Hpack.STATIC_HEADER_TABLE[index]).name;
/*     */       }
/* 265 */       return (this.dynamicTable[dynamicTableIndex(index - Hpack.STATIC_HEADER_TABLE.length)]).name;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isStaticHeader(int index) {
/* 270 */       return (index >= 0 && index <= Hpack.STATIC_HEADER_TABLE.length - 1);
/*     */     }
/*     */ 
/*     */     
/*     */     private void insertIntoDynamicTable(int index, Header entry) {
/* 275 */       this.headerList.add(entry);
/*     */       
/* 277 */       int delta = entry.hpackSize;
/* 278 */       if (index != -1) {
/* 279 */         delta -= (this.dynamicTable[dynamicTableIndex(index)]).hpackSize;
/*     */       }
/*     */ 
/*     */       
/* 283 */       if (delta > this.maxDynamicTableByteCount) {
/* 284 */         clearDynamicTable();
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 289 */       int bytesToRecover = this.dynamicTableByteCount + delta - this.maxDynamicTableByteCount;
/* 290 */       int entriesEvicted = evictToRecoverBytes(bytesToRecover);
/*     */       
/* 292 */       if (index == -1) {
/* 293 */         if (this.headerCount + 1 > this.dynamicTable.length) {
/* 294 */           Header[] doubled = new Header[this.dynamicTable.length * 2];
/* 295 */           System.arraycopy(this.dynamicTable, 0, doubled, this.dynamicTable.length, this.dynamicTable.length);
/* 296 */           this.nextHeaderIndex = this.dynamicTable.length - 1;
/* 297 */           this.dynamicTable = doubled;
/*     */         } 
/* 299 */         index = this.nextHeaderIndex--;
/* 300 */         this.dynamicTable[index] = entry;
/* 301 */         this.headerCount++;
/*     */       } else {
/* 303 */         index += dynamicTableIndex(index) + entriesEvicted;
/* 304 */         this.dynamicTable[index] = entry;
/*     */       } 
/* 306 */       this.dynamicTableByteCount += delta;
/*     */     }
/*     */     
/*     */     private int readByte() throws IOException {
/* 310 */       return this.source.readByte() & 0xFF;
/*     */     }
/*     */     
/*     */     int readInt(int firstByte, int prefixMask) throws IOException {
/* 314 */       int b, prefix = firstByte & prefixMask;
/* 315 */       if (prefix < prefixMask) {
/* 316 */         return prefix;
/*     */       }
/*     */ 
/*     */       
/* 320 */       int result = prefixMask;
/* 321 */       int shift = 0;
/*     */       while (true) {
/* 323 */         b = readByte();
/* 324 */         if ((b & 0x80) != 0) {
/* 325 */           result += (b & 0x7F) << shift;
/* 326 */           shift += 7; continue;
/*     */         }  break;
/* 328 */       }  result += b << shift;
/*     */ 
/*     */ 
/*     */       
/* 332 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     ByteString readByteString() throws IOException {
/* 337 */       int firstByte = readByte();
/* 338 */       boolean huffmanDecode = ((firstByte & 0x80) == 128);
/* 339 */       int length = readInt(firstByte, 127);
/*     */       
/* 341 */       if (huffmanDecode) {
/* 342 */         return ByteString.of(Huffman.get().decode(this.source.readByteArray(length)));
/*     */       }
/* 344 */       return this.source.readByteString(length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 349 */   static final Map<ByteString, Integer> NAME_TO_FIRST_INDEX = nameToFirstIndex();
/*     */   
/*     */   private static Map<ByteString, Integer> nameToFirstIndex() {
/* 352 */     Map<ByteString, Integer> result = new LinkedHashMap<>(STATIC_HEADER_TABLE.length);
/* 353 */     for (int i = 0; i < STATIC_HEADER_TABLE.length; i++) {
/* 354 */       if (!result.containsKey((STATIC_HEADER_TABLE[i]).name)) {
/* 355 */         result.put((STATIC_HEADER_TABLE[i]).name, Integer.valueOf(i));
/*     */       }
/*     */     } 
/* 358 */     return Collections.unmodifiableMap(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Writer
/*     */   {
/*     */     private static final int SETTINGS_HEADER_TABLE_SIZE = 4096;
/*     */ 
/*     */     
/*     */     private static final int SETTINGS_HEADER_TABLE_SIZE_LIMIT = 16384;
/*     */ 
/*     */     
/*     */     private final Buffer out;
/*     */ 
/*     */     
/*     */     private final boolean useCompression;
/*     */ 
/*     */     
/* 378 */     private int smallestHeaderTableSizeSetting = Integer.MAX_VALUE;
/*     */     
/*     */     private boolean emitDynamicTableSizeUpdate;
/*     */     
/*     */     int headerTableSizeSetting;
/*     */     
/*     */     int maxDynamicTableByteCount;
/* 385 */     Header[] dynamicTable = new Header[8];
/*     */     
/* 387 */     int nextHeaderIndex = this.dynamicTable.length - 1;
/* 388 */     int headerCount = 0;
/* 389 */     int dynamicTableByteCount = 0;
/*     */     
/*     */     Writer(Buffer out) {
/* 392 */       this(4096, true, out);
/*     */     }
/*     */     
/*     */     Writer(int headerTableSizeSetting, boolean useCompression, Buffer out) {
/* 396 */       this.headerTableSizeSetting = headerTableSizeSetting;
/* 397 */       this.maxDynamicTableByteCount = headerTableSizeSetting;
/* 398 */       this.useCompression = useCompression;
/* 399 */       this.out = out;
/*     */     }
/*     */     
/*     */     private void clearDynamicTable() {
/* 403 */       Arrays.fill((Object[])this.dynamicTable, (Object)null);
/* 404 */       this.nextHeaderIndex = this.dynamicTable.length - 1;
/* 405 */       this.headerCount = 0;
/* 406 */       this.dynamicTableByteCount = 0;
/*     */     }
/*     */ 
/*     */     
/*     */     private int evictToRecoverBytes(int bytesToRecover) {
/* 411 */       int entriesToEvict = 0;
/* 412 */       if (bytesToRecover > 0) {
/*     */         
/* 414 */         for (int j = this.dynamicTable.length - 1; j >= this.nextHeaderIndex && bytesToRecover > 0; j--) {
/* 415 */           bytesToRecover -= (this.dynamicTable[j]).hpackSize;
/* 416 */           this.dynamicTableByteCount -= (this.dynamicTable[j]).hpackSize;
/* 417 */           this.headerCount--;
/* 418 */           entriesToEvict++;
/*     */         } 
/* 420 */         System.arraycopy(this.dynamicTable, this.nextHeaderIndex + 1, this.dynamicTable, this.nextHeaderIndex + 1 + entriesToEvict, this.headerCount);
/*     */         
/* 422 */         Arrays.fill((Object[])this.dynamicTable, this.nextHeaderIndex + 1, this.nextHeaderIndex + 1 + entriesToEvict, (Object)null);
/* 423 */         this.nextHeaderIndex += entriesToEvict;
/*     */       } 
/* 425 */       return entriesToEvict;
/*     */     }
/*     */     
/*     */     private void insertIntoDynamicTable(Header entry) {
/* 429 */       int delta = entry.hpackSize;
/*     */ 
/*     */       
/* 432 */       if (delta > this.maxDynamicTableByteCount) {
/* 433 */         clearDynamicTable();
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 438 */       int bytesToRecover = this.dynamicTableByteCount + delta - this.maxDynamicTableByteCount;
/* 439 */       evictToRecoverBytes(bytesToRecover);
/*     */       
/* 441 */       if (this.headerCount + 1 > this.dynamicTable.length) {
/* 442 */         Header[] doubled = new Header[this.dynamicTable.length * 2];
/* 443 */         System.arraycopy(this.dynamicTable, 0, doubled, this.dynamicTable.length, this.dynamicTable.length);
/* 444 */         this.nextHeaderIndex = this.dynamicTable.length - 1;
/* 445 */         this.dynamicTable = doubled;
/*     */       } 
/* 447 */       int index = this.nextHeaderIndex--;
/* 448 */       this.dynamicTable[index] = entry;
/* 449 */       this.headerCount++;
/* 450 */       this.dynamicTableByteCount += delta;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void writeHeaders(List<Header> headerBlock) throws IOException {
/* 456 */       if (this.emitDynamicTableSizeUpdate) {
/* 457 */         if (this.smallestHeaderTableSizeSetting < this.maxDynamicTableByteCount)
/*     */         {
/* 459 */           writeInt(this.smallestHeaderTableSizeSetting, 31, 32);
/*     */         }
/* 461 */         this.emitDynamicTableSizeUpdate = false;
/* 462 */         this.smallestHeaderTableSizeSetting = Integer.MAX_VALUE;
/* 463 */         writeInt(this.maxDynamicTableByteCount, 31, 32);
/*     */       } 
/*     */       
/* 466 */       for (int i = 0, size = headerBlock.size(); i < size; i++) {
/* 467 */         Header header = headerBlock.get(i);
/* 468 */         ByteString name = header.name.toAsciiLowercase();
/* 469 */         ByteString value = header.value;
/* 470 */         int headerIndex = -1;
/* 471 */         int headerNameIndex = -1;
/*     */         
/* 473 */         Integer staticIndex = Hpack.NAME_TO_FIRST_INDEX.get(name);
/* 474 */         if (staticIndex != null) {
/* 475 */           headerNameIndex = staticIndex.intValue() + 1;
/* 476 */           if (headerNameIndex > 1 && headerNameIndex < 8)
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 481 */             if (Util.equal((Hpack.STATIC_HEADER_TABLE[headerNameIndex - 1]).value, value)) {
/* 482 */               headerIndex = headerNameIndex;
/* 483 */             } else if (Util.equal((Hpack.STATIC_HEADER_TABLE[headerNameIndex]).value, value)) {
/* 484 */               headerIndex = headerNameIndex + 1;
/*     */             } 
/*     */           }
/*     */         } 
/*     */         
/* 489 */         if (headerIndex == -1) {
/* 490 */           for (int j = this.nextHeaderIndex + 1, length = this.dynamicTable.length; j < length; j++) {
/* 491 */             if (Util.equal((this.dynamicTable[j]).name, name)) {
/* 492 */               if (Util.equal((this.dynamicTable[j]).value, value)) {
/* 493 */                 headerIndex = j - this.nextHeaderIndex + Hpack.STATIC_HEADER_TABLE.length; break;
/*     */               } 
/* 495 */               if (headerNameIndex == -1) {
/* 496 */                 headerNameIndex = j - this.nextHeaderIndex + Hpack.STATIC_HEADER_TABLE.length;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         }
/*     */         
/* 502 */         if (headerIndex != -1) {
/*     */           
/* 504 */           writeInt(headerIndex, 127, 128);
/* 505 */         } else if (headerNameIndex == -1) {
/*     */           
/* 507 */           this.out.writeByte(64);
/* 508 */           writeByteString(name);
/* 509 */           writeByteString(value);
/* 510 */           insertIntoDynamicTable(header);
/* 511 */         } else if (name.startsWith(Header.PSEUDO_PREFIX) && !Header.TARGET_AUTHORITY.equals(name)) {
/*     */ 
/*     */           
/* 514 */           writeInt(headerNameIndex, 15, 0);
/* 515 */           writeByteString(value);
/*     */         } else {
/*     */           
/* 518 */           writeInt(headerNameIndex, 63, 64);
/* 519 */           writeByteString(value);
/* 520 */           insertIntoDynamicTable(header);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void writeInt(int value, int prefixMask, int bits) {
/* 528 */       if (value < prefixMask) {
/* 529 */         this.out.writeByte(bits | value);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 534 */       this.out.writeByte(bits | prefixMask);
/* 535 */       value -= prefixMask;
/*     */ 
/*     */       
/* 538 */       while (value >= 128) {
/* 539 */         int b = value & 0x7F;
/* 540 */         this.out.writeByte(b | 0x80);
/* 541 */         value >>>= 7;
/*     */       } 
/* 543 */       this.out.writeByte(value);
/*     */     }
/*     */     
/*     */     void writeByteString(ByteString data) throws IOException {
/* 547 */       if (this.useCompression && Huffman.get().encodedLength(data) < data.size()) {
/* 548 */         Buffer huffmanBuffer = new Buffer();
/* 549 */         Huffman.get().encode(data, (BufferedSink)huffmanBuffer);
/* 550 */         ByteString huffmanBytes = huffmanBuffer.readByteString();
/* 551 */         writeInt(huffmanBytes.size(), 127, 128);
/* 552 */         this.out.write(huffmanBytes);
/*     */       } else {
/* 554 */         writeInt(data.size(), 127, 0);
/* 555 */         this.out.write(data);
/*     */       } 
/*     */     }
/*     */     
/*     */     void setHeaderTableSizeSetting(int headerTableSizeSetting) {
/* 560 */       this.headerTableSizeSetting = headerTableSizeSetting;
/* 561 */       int effectiveHeaderTableSize = Math.min(headerTableSizeSetting, 16384);
/*     */ 
/*     */       
/* 564 */       if (this.maxDynamicTableByteCount == effectiveHeaderTableSize)
/*     */         return; 
/* 566 */       if (effectiveHeaderTableSize < this.maxDynamicTableByteCount) {
/* 567 */         this.smallestHeaderTableSizeSetting = Math.min(this.smallestHeaderTableSizeSetting, effectiveHeaderTableSize);
/*     */       }
/*     */       
/* 570 */       this.emitDynamicTableSizeUpdate = true;
/* 571 */       this.maxDynamicTableByteCount = effectiveHeaderTableSize;
/* 572 */       adjustDynamicTableByteCount();
/*     */     }
/*     */     
/*     */     private void adjustDynamicTableByteCount() {
/* 576 */       if (this.maxDynamicTableByteCount < this.dynamicTableByteCount) {
/* 577 */         if (this.maxDynamicTableByteCount == 0) {
/* 578 */           clearDynamicTable();
/*     */         } else {
/* 580 */           evictToRecoverBytes(this.dynamicTableByteCount - this.maxDynamicTableByteCount);
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ByteString checkLowercase(ByteString name) throws IOException {
/* 591 */     for (int i = 0, length = name.size(); i < length; i++) {
/* 592 */       byte c = name.getByte(i);
/* 593 */       if (c >= 65 && c <= 90) {
/* 594 */         throw new IOException("PROTOCOL_ERROR response malformed: mixed case name: " + name.utf8());
/*     */       }
/*     */     } 
/* 597 */     return name;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http2\Hpack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */