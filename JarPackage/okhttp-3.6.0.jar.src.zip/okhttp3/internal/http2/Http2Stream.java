/*     */ package okhttp3.internal.http2;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import okio.AsyncTimeout;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSource;
/*     */ import okio.Sink;
/*     */ import okio.Source;
/*     */ import okio.Timeout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Stream
/*     */ {
/*  41 */   long unacknowledgedBytesRead = 0L;
/*     */ 
/*     */   
/*     */   long bytesLeftInWriteWindow;
/*     */ 
/*     */   
/*     */   final int id;
/*     */ 
/*     */   
/*     */   final Http2Connection connection;
/*     */ 
/*     */   
/*     */   private final List<Header> requestHeaders;
/*     */ 
/*     */   
/*     */   private List<Header> responseHeaders;
/*     */ 
/*     */   
/*     */   private boolean hasResponseHeaders;
/*     */   
/*     */   private final FramingSource source;
/*     */   
/*     */   final FramingSink sink;
/*     */   
/*  65 */   final StreamTimeout readTimeout = new StreamTimeout();
/*  66 */   final StreamTimeout writeTimeout = new StreamTimeout();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   ErrorCode errorCode = null;
/*     */ 
/*     */   
/*     */   Http2Stream(int id, Http2Connection connection, boolean outFinished, boolean inFinished, List<Header> requestHeaders) {
/*  77 */     if (connection == null) throw new NullPointerException("connection == null"); 
/*  78 */     if (requestHeaders == null) throw new NullPointerException("requestHeaders == null"); 
/*  79 */     this.id = id;
/*  80 */     this.connection = connection;
/*  81 */     this
/*  82 */       .bytesLeftInWriteWindow = connection.peerSettings.getInitialWindowSize();
/*  83 */     this.source = new FramingSource(connection.okHttpSettings.getInitialWindowSize());
/*  84 */     this.sink = new FramingSink();
/*  85 */     this.source.finished = inFinished;
/*  86 */     this.sink.finished = outFinished;
/*  87 */     this.requestHeaders = requestHeaders;
/*     */   }
/*     */   
/*     */   public int getId() {
/*  91 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isOpen() {
/* 106 */     if (this.errorCode != null) {
/* 107 */       return false;
/*     */     }
/* 109 */     if ((this.source.finished || this.source.closed) && (this.sink.finished || this.sink.closed) && this.hasResponseHeaders)
/*     */     {
/*     */       
/* 112 */       return false;
/*     */     }
/* 114 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocallyInitiated() {
/* 119 */     boolean streamIsClient = ((this.id & 0x1) == 1);
/* 120 */     return (this.connection.client == streamIsClient);
/*     */   }
/*     */   
/*     */   public Http2Connection getConnection() {
/* 124 */     return this.connection;
/*     */   }
/*     */   
/*     */   public List<Header> getRequestHeaders() {
/* 128 */     return this.requestHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized List<Header> takeResponseHeaders() throws IOException {
/* 137 */     if (!isLocallyInitiated()) {
/* 138 */       throw new IllegalStateException("servers cannot read response headers");
/*     */     }
/* 140 */     this.readTimeout.enter();
/*     */     try {
/* 142 */       while (this.responseHeaders == null && this.errorCode == null) {
/* 143 */         waitForIo();
/*     */       }
/*     */     } finally {
/* 146 */       this.readTimeout.exitAndThrowIfTimedOut();
/*     */     } 
/* 148 */     List<Header> result = this.responseHeaders;
/* 149 */     if (result != null) {
/* 150 */       this.responseHeaders = null;
/* 151 */       return result;
/*     */     } 
/* 153 */     throw new StreamResetException(this.errorCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ErrorCode getErrorCode() {
/* 161 */     return this.errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendResponseHeaders(List<Header> responseHeaders, boolean out) throws IOException {
/* 171 */     assert !Thread.holdsLock(this);
/* 172 */     if (responseHeaders == null) {
/* 173 */       throw new NullPointerException("responseHeaders == null");
/*     */     }
/* 175 */     boolean outFinished = false;
/* 176 */     synchronized (this) {
/* 177 */       this.hasResponseHeaders = true;
/* 178 */       if (!out) {
/* 179 */         this.sink.finished = true;
/* 180 */         outFinished = true;
/*     */       } 
/*     */     } 
/* 183 */     this.connection.writeSynReply(this.id, outFinished, responseHeaders);
/*     */     
/* 185 */     if (outFinished) {
/* 186 */       this.connection.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   public Timeout readTimeout() {
/* 191 */     return (Timeout)this.readTimeout;
/*     */   }
/*     */   
/*     */   public Timeout writeTimeout() {
/* 195 */     return (Timeout)this.writeTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public Source getSource() {
/* 200 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sink getSink() {
/* 210 */     synchronized (this) {
/* 211 */       if (!this.hasResponseHeaders && !isLocallyInitiated()) {
/* 212 */         throw new IllegalStateException("reply before requesting the sink");
/*     */       }
/*     */     } 
/* 215 */     return this.sink;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close(ErrorCode rstStatusCode) throws IOException {
/* 223 */     if (!closeInternal(rstStatusCode)) {
/*     */       return;
/*     */     }
/* 226 */     this.connection.writeSynReset(this.id, rstStatusCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeLater(ErrorCode errorCode) {
/* 234 */     if (!closeInternal(errorCode)) {
/*     */       return;
/*     */     }
/* 237 */     this.connection.writeSynResetLater(this.id, errorCode);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean closeInternal(ErrorCode errorCode) {
/* 242 */     assert !Thread.holdsLock(this);
/* 243 */     synchronized (this) {
/* 244 */       if (this.errorCode != null) {
/* 245 */         return false;
/*     */       }
/* 247 */       if (this.source.finished && this.sink.finished) {
/* 248 */         return false;
/*     */       }
/* 250 */       this.errorCode = errorCode;
/* 251 */       notifyAll();
/*     */     } 
/* 253 */     this.connection.removeStream(this.id);
/* 254 */     return true;
/*     */   }
/*     */   
/*     */   void receiveHeaders(List<Header> headers) {
/* 258 */     assert !Thread.holdsLock(this);
/* 259 */     boolean open = true;
/* 260 */     synchronized (this) {
/* 261 */       this.hasResponseHeaders = true;
/* 262 */       if (this.responseHeaders == null) {
/* 263 */         this.responseHeaders = headers;
/* 264 */         open = isOpen();
/* 265 */         notifyAll();
/*     */       } else {
/* 267 */         List<Header> newHeaders = new ArrayList<>();
/* 268 */         newHeaders.addAll(this.responseHeaders);
/* 269 */         newHeaders.add(null);
/* 270 */         newHeaders.addAll(headers);
/* 271 */         this.responseHeaders = newHeaders;
/*     */       } 
/*     */     } 
/* 274 */     if (!open) {
/* 275 */       this.connection.removeStream(this.id);
/*     */     }
/*     */   }
/*     */   
/*     */   void receiveData(BufferedSource in, int length) throws IOException {
/* 280 */     assert !Thread.holdsLock(this);
/* 281 */     this.source.receive(in, length);
/*     */   }
/*     */   void receiveFin() {
/*     */     boolean open;
/* 285 */     assert !Thread.holdsLock(this);
/*     */     
/* 287 */     synchronized (this) {
/* 288 */       this.source.finished = true;
/* 289 */       open = isOpen();
/* 290 */       notifyAll();
/*     */     } 
/* 292 */     if (!open) {
/* 293 */       this.connection.removeStream(this.id);
/*     */     }
/*     */   }
/*     */   
/*     */   synchronized void receiveRstStream(ErrorCode errorCode) {
/* 298 */     if (this.errorCode == null) {
/* 299 */       this.errorCode = errorCode;
/* 300 */       notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class FramingSource
/*     */     implements Source
/*     */   {
/* 311 */     private final Buffer receiveBuffer = new Buffer();
/*     */ 
/*     */     
/* 314 */     private final Buffer readBuffer = new Buffer();
/*     */ 
/*     */ 
/*     */     
/*     */     private final long maxByteCount;
/*     */ 
/*     */     
/*     */     boolean closed;
/*     */ 
/*     */     
/*     */     boolean finished;
/*     */ 
/*     */ 
/*     */     
/*     */     FramingSource(long maxByteCount) {
/* 329 */       this.maxByteCount = maxByteCount;
/*     */     }
/*     */     public long read(Buffer sink, long byteCount) throws IOException {
/*     */       long read;
/* 333 */       if (byteCount < 0L) throw new IllegalArgumentException("byteCount < 0: " + byteCount);
/*     */ 
/*     */       
/* 336 */       synchronized (Http2Stream.this) {
/* 337 */         waitUntilReadable();
/* 338 */         checkNotClosed();
/* 339 */         if (this.readBuffer.size() == 0L) return -1L;
/*     */ 
/*     */         
/* 342 */         read = this.readBuffer.read(sink, Math.min(byteCount, this.readBuffer.size()));
/*     */ 
/*     */         
/* 345 */         Http2Stream.this.unacknowledgedBytesRead += read;
/* 346 */         if (Http2Stream.this.unacknowledgedBytesRead >= (Http2Stream.this.connection.okHttpSettings
/* 347 */           .getInitialWindowSize() / 2)) {
/* 348 */           Http2Stream.this.connection.writeWindowUpdateLater(Http2Stream.this.id, Http2Stream.this.unacknowledgedBytesRead);
/* 349 */           Http2Stream.this.unacknowledgedBytesRead = 0L;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 354 */       synchronized (Http2Stream.this.connection) {
/* 355 */         Http2Stream.this.connection.unacknowledgedBytesRead += read;
/* 356 */         if (Http2Stream.this.connection.unacknowledgedBytesRead >= (Http2Stream.this.connection.okHttpSettings
/* 357 */           .getInitialWindowSize() / 2)) {
/* 358 */           Http2Stream.this.connection.writeWindowUpdateLater(0, Http2Stream.this.connection.unacknowledgedBytesRead);
/* 359 */           Http2Stream.this.connection.unacknowledgedBytesRead = 0L;
/*     */         } 
/*     */       } 
/*     */       
/* 363 */       return read;
/*     */     }
/*     */ 
/*     */     
/*     */     private void waitUntilReadable() throws IOException {
/* 368 */       Http2Stream.this.readTimeout.enter();
/*     */       try {
/* 370 */         while (this.readBuffer.size() == 0L && !this.finished && !this.closed && Http2Stream.this.errorCode == null) {
/* 371 */           Http2Stream.this.waitForIo();
/*     */         }
/*     */       } finally {
/* 374 */         Http2Stream.this.readTimeout.exitAndThrowIfTimedOut();
/*     */       } 
/*     */     }
/*     */     
/*     */     void receive(BufferedSource in, long byteCount) throws IOException {
/* 379 */       assert !Thread.holdsLock(Http2Stream.this);
/*     */       
/* 381 */       while (byteCount > 0L) {
/*     */         boolean finished, flowControlError;
/*     */         
/* 384 */         synchronized (Http2Stream.this) {
/* 385 */           finished = this.finished;
/* 386 */           flowControlError = (byteCount + this.readBuffer.size() > this.maxByteCount);
/*     */         } 
/*     */ 
/*     */         
/* 390 */         if (flowControlError) {
/* 391 */           in.skip(byteCount);
/* 392 */           Http2Stream.this.closeLater(ErrorCode.FLOW_CONTROL_ERROR);
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 397 */         if (finished) {
/* 398 */           in.skip(byteCount);
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 403 */         long read = in.read(this.receiveBuffer, byteCount);
/* 404 */         if (read == -1L) throw new EOFException(); 
/* 405 */         byteCount -= read;
/*     */ 
/*     */         
/* 408 */         synchronized (Http2Stream.this) {
/* 409 */           boolean wasEmpty = (this.readBuffer.size() == 0L);
/* 410 */           this.readBuffer.writeAll((Source)this.receiveBuffer);
/* 411 */           if (wasEmpty) {
/* 412 */             Http2Stream.this.notifyAll();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public Timeout timeout() {
/* 419 */       return (Timeout)Http2Stream.this.readTimeout;
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 423 */       synchronized (Http2Stream.this) {
/* 424 */         this.closed = true;
/* 425 */         this.readBuffer.clear();
/* 426 */         Http2Stream.this.notifyAll();
/*     */       } 
/* 428 */       Http2Stream.this.cancelStreamIfNecessary();
/*     */     }
/*     */     
/*     */     private void checkNotClosed() throws IOException {
/* 432 */       if (this.closed) {
/* 433 */         throw new IOException("stream closed");
/*     */       }
/* 435 */       if (Http2Stream.this.errorCode != null)
/* 436 */         throw new StreamResetException(Http2Stream.this.errorCode); 
/*     */     } }
/*     */   
/*     */   void cancelStreamIfNecessary() throws IOException {
/*     */     boolean open;
/*     */     boolean cancel;
/* 442 */     assert !Thread.holdsLock(this);
/*     */ 
/*     */     
/* 445 */     synchronized (this) {
/* 446 */       cancel = (!this.source.finished && this.source.closed && (this.sink.finished || this.sink.closed));
/* 447 */       open = isOpen();
/*     */     } 
/* 449 */     if (cancel) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 454 */       close(ErrorCode.CANCEL);
/* 455 */     } else if (!open) {
/* 456 */       this.connection.removeStream(this.id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final class FramingSink
/*     */     implements Sink
/*     */   {
/*     */     private static final long EMIT_BUFFER_SIZE = 16384L;
/*     */ 
/*     */     
/* 468 */     private final Buffer sendBuffer = new Buffer();
/*     */ 
/*     */     
/*     */     boolean closed;
/*     */ 
/*     */     
/*     */     boolean finished;
/*     */ 
/*     */     
/*     */     public void write(Buffer source, long byteCount) throws IOException {
/* 478 */       assert !Thread.holdsLock(Http2Stream.this);
/* 479 */       this.sendBuffer.write(source, byteCount);
/* 480 */       while (this.sendBuffer.size() >= 16384L) {
/* 481 */         emitFrame(false);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void emitFrame(boolean outFinished) throws IOException {
/*     */       long toWrite;
/* 491 */       synchronized (Http2Stream.this) {
/* 492 */         Http2Stream.this.writeTimeout.enter();
/*     */         try {
/* 494 */           while (Http2Stream.this.bytesLeftInWriteWindow <= 0L && !this.finished && !this.closed && Http2Stream.this.errorCode == null) {
/* 495 */             Http2Stream.this.waitForIo();
/*     */           }
/*     */         } finally {
/* 498 */           Http2Stream.this.writeTimeout.exitAndThrowIfTimedOut();
/*     */         } 
/*     */         
/* 501 */         Http2Stream.this.checkOutNotClosed();
/* 502 */         toWrite = Math.min(Http2Stream.this.bytesLeftInWriteWindow, this.sendBuffer.size());
/* 503 */         Http2Stream.this.bytesLeftInWriteWindow -= toWrite;
/*     */       } 
/*     */       
/* 506 */       Http2Stream.this.writeTimeout.enter();
/*     */       try {
/* 508 */         Http2Stream.this.connection.writeData(Http2Stream.this.id, (outFinished && toWrite == this.sendBuffer.size()), this.sendBuffer, toWrite);
/*     */       } finally {
/* 510 */         Http2Stream.this.writeTimeout.exitAndThrowIfTimedOut();
/*     */       } 
/*     */     }
/*     */     
/*     */     public void flush() throws IOException {
/* 515 */       assert !Thread.holdsLock(Http2Stream.this);
/* 516 */       synchronized (Http2Stream.this) {
/* 517 */         Http2Stream.this.checkOutNotClosed();
/*     */       } 
/* 519 */       while (this.sendBuffer.size() > 0L) {
/* 520 */         emitFrame(false);
/* 521 */         Http2Stream.this.connection.flush();
/*     */       } 
/*     */     }
/*     */     
/*     */     public Timeout timeout() {
/* 526 */       return (Timeout)Http2Stream.this.writeTimeout;
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 530 */       assert !Thread.holdsLock(Http2Stream.this);
/* 531 */       synchronized (Http2Stream.this) {
/* 532 */         if (this.closed)
/*     */           return; 
/* 534 */       }  if (!Http2Stream.this.sink.finished)
/*     */       {
/* 536 */         if (this.sendBuffer.size() > 0L) {
/* 537 */           while (this.sendBuffer.size() > 0L) {
/* 538 */             emitFrame(true);
/*     */           }
/*     */         } else {
/*     */           
/* 542 */           Http2Stream.this.connection.writeData(Http2Stream.this.id, true, null, 0L);
/*     */         } 
/*     */       }
/* 545 */       synchronized (Http2Stream.this) {
/* 546 */         this.closed = true;
/*     */       } 
/* 548 */       Http2Stream.this.connection.flush();
/* 549 */       Http2Stream.this.cancelStreamIfNecessary();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addBytesToWriteWindow(long delta) {
/* 557 */     this.bytesLeftInWriteWindow += delta;
/* 558 */     if (delta > 0L) notifyAll(); 
/*     */   }
/*     */   
/*     */   void checkOutNotClosed() throws IOException {
/* 562 */     if (this.sink.closed)
/* 563 */       throw new IOException("stream closed"); 
/* 564 */     if (this.sink.finished)
/* 565 */       throw new IOException("stream finished"); 
/* 566 */     if (this.errorCode != null) {
/* 567 */       throw new StreamResetException(this.errorCode);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void waitForIo() throws InterruptedIOException {
/*     */     try {
/* 577 */       wait();
/* 578 */     } catch (InterruptedException e) {
/* 579 */       throw new InterruptedIOException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class StreamTimeout
/*     */     extends AsyncTimeout
/*     */   {
/*     */     protected void timedOut() {
/* 589 */       Http2Stream.this.closeLater(ErrorCode.CANCEL);
/*     */     }
/*     */     
/*     */     protected IOException newTimeoutException(IOException cause) {
/* 593 */       SocketTimeoutException socketTimeoutException = new SocketTimeoutException("timeout");
/* 594 */       if (cause != null) {
/* 595 */         socketTimeoutException.initCause(cause);
/*     */       }
/* 597 */       return socketTimeoutException;
/*     */     }
/*     */     
/*     */     public void exitAndThrowIfTimedOut() throws IOException {
/* 601 */       if (exit()) throw newTimeoutException(null); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http2\Http2Stream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */