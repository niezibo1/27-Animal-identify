/*    */ package okhttp3.internal.http2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ErrorCode
/*    */ {
/* 21 */   NO_ERROR(0),
/*    */   
/* 23 */   PROTOCOL_ERROR(1),
/*    */   
/* 25 */   INTERNAL_ERROR(2),
/*    */   
/* 27 */   FLOW_CONTROL_ERROR(3),
/*    */   
/* 29 */   REFUSED_STREAM(7),
/*    */   
/* 31 */   CANCEL(8);
/*    */   
/*    */   public final int httpCode;
/*    */   
/*    */   ErrorCode(int httpCode) {
/* 36 */     this.httpCode = httpCode;
/*    */   }
/*    */   
/*    */   public static ErrorCode fromHttp2(int code) {
/* 40 */     for (ErrorCode errorCode : values()) {
/* 41 */       if (errorCode.httpCode == code) return errorCode; 
/*    */     } 
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http2\ErrorCode.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */