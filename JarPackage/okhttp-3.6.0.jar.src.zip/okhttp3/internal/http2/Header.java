/*    */ package okhttp3.internal.http2;
/*    */ 
/*    */ import okhttp3.internal.Util;
/*    */ import okio.ByteString;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Header
/*    */ {
/* 24 */   public static final ByteString PSEUDO_PREFIX = ByteString.encodeUtf8(":");
/* 25 */   public static final ByteString RESPONSE_STATUS = ByteString.encodeUtf8(":status");
/* 26 */   public static final ByteString TARGET_METHOD = ByteString.encodeUtf8(":method");
/* 27 */   public static final ByteString TARGET_PATH = ByteString.encodeUtf8(":path");
/* 28 */   public static final ByteString TARGET_SCHEME = ByteString.encodeUtf8(":scheme");
/* 29 */   public static final ByteString TARGET_AUTHORITY = ByteString.encodeUtf8(":authority");
/*    */   
/*    */   public final ByteString name;
/*    */   
/*    */   public final ByteString value;
/*    */   
/*    */   final int hpackSize;
/*    */ 
/*    */   
/*    */   public Header(String name, String value) {
/* 39 */     this(ByteString.encodeUtf8(name), ByteString.encodeUtf8(value));
/*    */   }
/*    */   
/*    */   public Header(ByteString name, String value) {
/* 43 */     this(name, ByteString.encodeUtf8(value));
/*    */   }
/*    */   
/*    */   public Header(ByteString name, ByteString value) {
/* 47 */     this.name = name;
/* 48 */     this.value = value;
/* 49 */     this.hpackSize = 32 + name.size() + value.size();
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 53 */     if (other instanceof Header) {
/* 54 */       Header that = (Header)other;
/* 55 */       return (this.name.equals(that.name) && this.value
/* 56 */         .equals(that.value));
/*    */     } 
/* 58 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 62 */     int result = 17;
/* 63 */     result = 31 * result + this.name.hashCode();
/* 64 */     result = 31 * result + this.value.hashCode();
/* 65 */     return result;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 69 */     return Util.format("%s: %s", new Object[] { this.name.utf8(), this.value.utf8() });
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http2\Header.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */