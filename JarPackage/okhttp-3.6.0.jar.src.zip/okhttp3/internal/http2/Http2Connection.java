/*     */ package okhttp3.internal.http2;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.Protocol;
/*     */ import okhttp3.internal.NamedRunnable;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.platform.Platform;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSink;
/*     */ import okio.BufferedSource;
/*     */ import okio.ByteString;
/*     */ import okio.Okio;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Connection
/*     */   implements Closeable
/*     */ {
/*  69 */   static final ExecutorService executor = new ThreadPoolExecutor(0, 2147483647, 60L, TimeUnit.SECONDS, new SynchronousQueue<>(), 
/*     */       
/*  71 */       Util.threadFactory("OkHttp Http2Connection", true));
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean client;
/*     */ 
/*     */   
/*     */   final Listener listener;
/*     */ 
/*     */   
/*  81 */   final Map<Integer, Http2Stream> streams = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   final String hostname;
/*     */ 
/*     */   
/*     */   int lastGoodStreamId;
/*     */   
/*     */   int nextStreamId;
/*     */   
/*     */   boolean shutdown;
/*     */   
/*     */   private final ExecutorService pushExecutor;
/*     */   
/*     */   private Map<Integer, Ping> pings;
/*     */   
/*     */   final PushObserver pushObserver;
/*     */   
/*     */   private int nextPingId;
/*     */   
/* 101 */   long unacknowledgedBytesRead = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long bytesLeftInWriteWindow;
/*     */ 
/*     */ 
/*     */   
/* 110 */   Settings okHttpSettings = new Settings();
/*     */ 
/*     */   
/*     */   private static final int OKHTTP_CLIENT_WINDOW_SIZE = 16777216;
/*     */ 
/*     */   
/* 116 */   final Settings peerSettings = new Settings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean receivedInitialPeerSettings = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Socket socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Http2Writer writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final ReaderRunnable readerRunnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Set<Integer> currentPushRequests;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Protocol getProtocol() {
/* 162 */     return Protocol.HTTP_2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int openStreamCount() {
/* 169 */     return this.streams.size();
/*     */   }
/*     */   
/*     */   synchronized Http2Stream getStream(int id) {
/* 173 */     return this.streams.get(Integer.valueOf(id));
/*     */   }
/*     */   
/*     */   synchronized Http2Stream removeStream(int streamId) {
/* 177 */     Http2Stream stream = this.streams.remove(Integer.valueOf(streamId));
/* 178 */     notifyAll();
/* 179 */     return stream;
/*     */   }
/*     */   
/*     */   public synchronized int maxConcurrentStreams() {
/* 183 */     return this.peerSettings.getMaxConcurrentStreams(2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Stream pushStream(int associatedStreamId, List<Header> requestHeaders, boolean out) throws IOException {
/* 195 */     if (this.client) throw new IllegalStateException("Client cannot push requests."); 
/* 196 */     return newStream(associatedStreamId, requestHeaders, out);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Stream newStream(List<Header> requestHeaders, boolean out) throws IOException {
/* 205 */     return newStream(0, requestHeaders, out);
/*     */   }
/*     */   private Http2Stream newStream(int associatedStreamId, List<Header> requestHeaders, boolean out) throws IOException {
/*     */     boolean flushHeaders;
/*     */     Http2Stream stream;
/* 210 */     boolean outFinished = !out;
/* 211 */     boolean inFinished = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     synchronized (this.writer) {
/* 217 */       int streamId; synchronized (this) {
/* 218 */         if (this.shutdown) {
/* 219 */           throw new ConnectionShutdownException();
/*     */         }
/* 221 */         streamId = this.nextStreamId;
/* 222 */         this.nextStreamId += 2;
/* 223 */         stream = new Http2Stream(streamId, this, outFinished, inFinished, requestHeaders);
/* 224 */         flushHeaders = (!out || this.bytesLeftInWriteWindow == 0L || stream.bytesLeftInWriteWindow == 0L);
/* 225 */         if (stream.isOpen()) {
/* 226 */           this.streams.put(Integer.valueOf(streamId), stream);
/*     */         }
/*     */       } 
/* 229 */       if (associatedStreamId == 0)
/* 230 */       { this.writer.synStream(outFinished, streamId, associatedStreamId, requestHeaders); }
/* 231 */       else { if (this.client) {
/* 232 */           throw new IllegalArgumentException("client streams shouldn't have associated stream IDs");
/*     */         }
/* 234 */         this.writer.pushPromise(associatedStreamId, streamId, requestHeaders); }
/*     */     
/*     */     } 
/*     */     
/* 238 */     if (flushHeaders) {
/* 239 */       this.writer.flush();
/*     */     }
/*     */     
/* 242 */     return stream;
/*     */   }
/*     */ 
/*     */   
/*     */   void writeSynReply(int streamId, boolean outFinished, List<Header> alternating) throws IOException {
/* 247 */     this.writer.synReply(outFinished, streamId, alternating);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeData(int streamId, boolean outFinished, Buffer buffer, long byteCount) throws IOException {
/* 264 */     if (byteCount == 0L) {
/* 265 */       this.writer.data(outFinished, streamId, buffer, 0);
/*     */       
/*     */       return;
/*     */     } 
/* 269 */     while (byteCount > 0L) {
/*     */       int toWrite;
/* 271 */       synchronized (this) { while (true) {
/*     */           try {
/* 273 */             if (this.bytesLeftInWriteWindow <= 0L) {
/*     */ 
/*     */               
/* 276 */               if (!this.streams.containsKey(Integer.valueOf(streamId))) {
/* 277 */                 throw new IOException("stream closed");
/*     */               }
/* 279 */               wait(); continue;
/*     */             } 
/* 281 */           } catch (InterruptedException e) {
/* 282 */             throw new InterruptedIOException();
/*     */           }  break;
/*     */         } 
/* 285 */         toWrite = (int)Math.min(byteCount, this.bytesLeftInWriteWindow);
/* 286 */         toWrite = Math.min(toWrite, this.writer.maxDataLength());
/* 287 */         this.bytesLeftInWriteWindow -= toWrite; }
/*     */ 
/*     */       
/* 290 */       byteCount -= toWrite;
/* 291 */       this.writer.data((outFinished && byteCount == 0L), streamId, buffer, toWrite);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addBytesToWriteWindow(long delta) {
/* 299 */     this.bytesLeftInWriteWindow += delta;
/* 300 */     if (delta > 0L) notifyAll(); 
/*     */   }
/*     */   
/*     */   void writeSynResetLater(final int streamId, final ErrorCode errorCode) {
/* 304 */     executor.execute((Runnable)new NamedRunnable("OkHttp %s stream %d", new Object[] { this.hostname, Integer.valueOf(streamId) }) {
/*     */           public void execute() {
/*     */             try {
/* 307 */               Http2Connection.this.writeSynReset(streamId, errorCode);
/* 308 */             } catch (IOException iOException) {}
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   void writeSynReset(int streamId, ErrorCode statusCode) throws IOException {
/* 315 */     this.writer.rstStream(streamId, statusCode);
/*     */   }
/*     */   
/*     */   void writeWindowUpdateLater(final int streamId, final long unacknowledgedBytesRead) {
/* 319 */     executor.execute((Runnable)new NamedRunnable("OkHttp Window Update %s stream %d", new Object[] { this.hostname, Integer.valueOf(streamId) }) {
/*     */           public void execute() {
/*     */             try {
/* 322 */               Http2Connection.this.writer.windowUpdate(streamId, unacknowledgedBytesRead);
/* 323 */             } catch (IOException iOException) {}
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Ping ping() throws IOException {
/*     */     int pingId;
/* 334 */     Ping ping = new Ping();
/*     */     
/* 336 */     synchronized (this) {
/* 337 */       if (this.shutdown) {
/* 338 */         throw new ConnectionShutdownException();
/*     */       }
/* 340 */       pingId = this.nextPingId;
/* 341 */       this.nextPingId += 2;
/* 342 */       if (this.pings == null) this.pings = new LinkedHashMap<>(); 
/* 343 */       this.pings.put(Integer.valueOf(pingId), ping);
/*     */     } 
/* 345 */     writePing(false, pingId, 1330343787, ping);
/* 346 */     return ping;
/*     */   }
/*     */ 
/*     */   
/*     */   void writePingLater(final boolean reply, final int payload1, final int payload2, final Ping ping) {
/* 351 */     executor.execute((Runnable)new NamedRunnable("OkHttp %s ping %08x%08x", new Object[] { this.hostname, 
/* 352 */             Integer.valueOf(payload1), Integer.valueOf(payload2) }) {
/*     */           public void execute() {
/*     */             try {
/* 355 */               Http2Connection.this.writePing(reply, payload1, payload2, ping);
/* 356 */             } catch (IOException iOException) {}
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   void writePing(boolean reply, int payload1, int payload2, Ping ping) throws IOException {
/* 363 */     synchronized (this.writer) {
/*     */       
/* 365 */       if (ping != null) ping.send(); 
/* 366 */       this.writer.ping(reply, payload1, payload2);
/*     */     } 
/*     */   }
/*     */   
/*     */   synchronized Ping removePing(int id) {
/* 371 */     return (this.pings != null) ? this.pings.remove(Integer.valueOf(id)) : null;
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 375 */     this.writer.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown(ErrorCode statusCode) throws IOException {
/* 384 */     synchronized (this.writer) {
/*     */       int lastGoodStreamId;
/* 386 */       synchronized (this) {
/* 387 */         if (this.shutdown) {
/*     */           return;
/*     */         }
/* 390 */         this.shutdown = true;
/* 391 */         lastGoodStreamId = this.lastGoodStreamId;
/*     */       } 
/*     */ 
/*     */       
/* 395 */       this.writer.goAway(lastGoodStreamId, statusCode, Util.EMPTY_BYTE_ARRAY);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 404 */     close(ErrorCode.NO_ERROR, ErrorCode.CANCEL);
/*     */   }
/*     */   
/*     */   void close(ErrorCode connectionCode, ErrorCode streamCode) throws IOException {
/* 408 */     assert !Thread.holdsLock(this);
/* 409 */     IOException thrown = null;
/*     */     try {
/* 411 */       shutdown(connectionCode);
/* 412 */     } catch (IOException e) {
/* 413 */       thrown = e;
/*     */     } 
/*     */     
/* 416 */     Http2Stream[] streamsToClose = null;
/* 417 */     Ping[] pingsToCancel = null;
/* 418 */     synchronized (this) {
/* 419 */       if (!this.streams.isEmpty()) {
/* 420 */         streamsToClose = (Http2Stream[])this.streams.values().toArray((Object[])new Http2Stream[this.streams.size()]);
/* 421 */         this.streams.clear();
/*     */       } 
/* 423 */       if (this.pings != null) {
/* 424 */         pingsToCancel = (Ping[])this.pings.values().toArray((Object[])new Ping[this.pings.size()]);
/* 425 */         this.pings = null;
/*     */       } 
/*     */     } 
/*     */     
/* 429 */     if (streamsToClose != null) {
/* 430 */       for (Http2Stream stream : streamsToClose) {
/*     */         try {
/* 432 */           stream.close(streamCode);
/* 433 */         } catch (IOException e) {
/* 434 */           if (thrown != null) thrown = e;
/*     */         
/*     */         } 
/*     */       } 
/*     */     }
/* 439 */     if (pingsToCancel != null) {
/* 440 */       for (Ping ping : pingsToCancel) {
/* 441 */         ping.cancel();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 447 */       this.writer.close();
/* 448 */     } catch (IOException e) {
/* 449 */       if (thrown == null) thrown = e;
/*     */     
/*     */     } 
/*     */     
/*     */     try {
/* 454 */       this.socket.close();
/* 455 */     } catch (IOException e) {
/* 456 */       thrown = e;
/*     */     } 
/*     */     
/* 459 */     if (thrown != null) throw thrown;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() throws IOException {
/* 467 */     start(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void start(boolean sendConnectionPreface) throws IOException {
/* 475 */     if (sendConnectionPreface) {
/* 476 */       this.writer.connectionPreface();
/* 477 */       this.writer.settings(this.okHttpSettings);
/* 478 */       int windowSize = this.okHttpSettings.getInitialWindowSize();
/* 479 */       if (windowSize != 65535) {
/* 480 */         this.writer.windowUpdate(0, (windowSize - 65535));
/*     */       }
/*     */     } 
/* 483 */     (new Thread((Runnable)this.readerRunnable)).start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSettings(Settings settings) throws IOException {
/* 488 */     synchronized (this.writer) {
/* 489 */       synchronized (this) {
/* 490 */         if (this.shutdown) {
/* 491 */           throw new ConnectionShutdownException();
/*     */         }
/* 493 */         this.okHttpSettings.merge(settings);
/* 494 */         this.writer.settings(settings);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized boolean isShutdown() {
/* 500 */     return this.shutdown;
/*     */   }
/*     */   
/*     */   public static class Builder {
/*     */     Socket socket;
/*     */     String hostname;
/*     */     BufferedSource source;
/*     */     BufferedSink sink;
/* 508 */     Http2Connection.Listener listener = Http2Connection.Listener.REFUSE_INCOMING_STREAMS;
/* 509 */     PushObserver pushObserver = PushObserver.CANCEL;
/*     */ 
/*     */     
/*     */     boolean client;
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(boolean client) {
/* 517 */       this.client = client;
/*     */     }
/*     */     
/*     */     public Builder socket(Socket socket) throws IOException {
/* 521 */       return socket(socket, ((InetSocketAddress)socket.getRemoteSocketAddress()).getHostName(), 
/* 522 */           Okio.buffer(Okio.source(socket)), Okio.buffer(Okio.sink(socket)));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder socket(Socket socket, String hostname, BufferedSource source, BufferedSink sink) {
/* 527 */       this.socket = socket;
/* 528 */       this.hostname = hostname;
/* 529 */       this.source = source;
/* 530 */       this.sink = sink;
/* 531 */       return this;
/*     */     }
/*     */     
/*     */     public Builder listener(Http2Connection.Listener listener) {
/* 535 */       this.listener = listener;
/* 536 */       return this;
/*     */     }
/*     */     
/*     */     public Builder pushObserver(PushObserver pushObserver) {
/* 540 */       this.pushObserver = pushObserver;
/* 541 */       return this;
/*     */     }
/*     */     
/*     */     public Http2Connection build() throws IOException {
/* 545 */       return new Http2Connection(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class ReaderRunnable
/*     */     extends NamedRunnable
/*     */     implements Http2Reader.Handler
/*     */   {
/*     */     final Http2Reader reader;
/*     */     
/*     */     ReaderRunnable(Http2Reader reader) {
/* 557 */       super("OkHttp %s", new Object[] { this$0.hostname });
/* 558 */       this.reader = reader;
/*     */     }
/*     */     
/*     */     protected void execute() {
/* 562 */       ErrorCode connectionErrorCode = ErrorCode.INTERNAL_ERROR;
/* 563 */       ErrorCode streamErrorCode = ErrorCode.INTERNAL_ERROR;
/*     */       try {
/* 565 */         this.reader.readConnectionPreface(this);
/* 566 */         while (this.reader.nextFrame(false, this));
/*     */         
/* 568 */         connectionErrorCode = ErrorCode.NO_ERROR;
/* 569 */         streamErrorCode = ErrorCode.CANCEL;
/* 570 */       } catch (IOException e) {
/* 571 */         connectionErrorCode = ErrorCode.PROTOCOL_ERROR;
/* 572 */         streamErrorCode = ErrorCode.PROTOCOL_ERROR;
/*     */       } finally {
/*     */         try {
/* 575 */           Http2Connection.this.close(connectionErrorCode, streamErrorCode);
/* 576 */         } catch (IOException iOException) {}
/*     */         
/* 578 */         Util.closeQuietly(this.reader);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void data(boolean inFinished, int streamId, BufferedSource source, int length) throws IOException {
/* 584 */       if (Http2Connection.this.pushedStream(streamId)) {
/* 585 */         Http2Connection.this.pushDataLater(streamId, source, length, inFinished);
/*     */         return;
/*     */       } 
/* 588 */       Http2Stream dataStream = Http2Connection.this.getStream(streamId);
/* 589 */       if (dataStream == null) {
/* 590 */         Http2Connection.this.writeSynResetLater(streamId, ErrorCode.PROTOCOL_ERROR);
/* 591 */         source.skip(length);
/*     */         return;
/*     */       } 
/* 594 */       dataStream.receiveData(source, length);
/* 595 */       if (inFinished) {
/* 596 */         dataStream.receiveFin();
/*     */       }
/*     */     }
/*     */     
/*     */     public void headers(boolean inFinished, int streamId, int associatedStreamId, List<Header> headerBlock) {
/*     */       Http2Stream stream;
/* 602 */       if (Http2Connection.this.pushedStream(streamId)) {
/* 603 */         Http2Connection.this.pushHeadersLater(streamId, headerBlock, inFinished);
/*     */         
/*     */         return;
/*     */       } 
/* 607 */       synchronized (Http2Connection.this) {
/*     */         
/* 609 */         if (Http2Connection.this.shutdown)
/*     */           return; 
/* 611 */         stream = Http2Connection.this.getStream(streamId);
/*     */         
/* 613 */         if (stream == null) {
/*     */           
/* 615 */           if (streamId <= Http2Connection.this.lastGoodStreamId) {
/*     */             return;
/*     */           }
/* 618 */           if (streamId % 2 == Http2Connection.this.nextStreamId % 2) {
/*     */             return;
/*     */           }
/* 621 */           final Http2Stream newStream = new Http2Stream(streamId, Http2Connection.this, false, inFinished, headerBlock);
/*     */           
/* 623 */           Http2Connection.this.lastGoodStreamId = streamId;
/* 624 */           Http2Connection.this.streams.put(Integer.valueOf(streamId), newStream);
/* 625 */           Http2Connection.executor.execute((Runnable)new NamedRunnable("OkHttp %s stream %d", new Object[] { this.this$0.hostname, Integer.valueOf(streamId) }) {
/*     */                 public void execute() {
/*     */                   try {
/* 628 */                     Http2Connection.this.listener.onStream(newStream);
/* 629 */                   } catch (IOException e) {
/* 630 */                     Platform.get().log(4, "Http2Connection.Listener failure for " + Http2Connection.this.hostname, e);
/*     */                     try {
/* 632 */                       newStream.close(ErrorCode.PROTOCOL_ERROR);
/* 633 */                     } catch (IOException iOException) {}
/*     */                   } 
/*     */                 }
/*     */               });
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */       
/* 643 */       stream.receiveHeaders(headerBlock);
/* 644 */       if (inFinished) stream.receiveFin(); 
/*     */     }
/*     */     
/*     */     public void rstStream(int streamId, ErrorCode errorCode) {
/* 648 */       if (Http2Connection.this.pushedStream(streamId)) {
/* 649 */         Http2Connection.this.pushResetLater(streamId, errorCode);
/*     */         return;
/*     */       } 
/* 652 */       Http2Stream rstStream = Http2Connection.this.removeStream(streamId);
/* 653 */       if (rstStream != null) {
/* 654 */         rstStream.receiveRstStream(errorCode);
/*     */       }
/*     */     }
/*     */     
/*     */     public void settings(boolean clearPrevious, Settings newSettings) {
/* 659 */       long delta = 0L;
/* 660 */       Http2Stream[] streamsToNotify = null;
/* 661 */       synchronized (Http2Connection.this) {
/* 662 */         int priorWriteWindowSize = Http2Connection.this.peerSettings.getInitialWindowSize();
/* 663 */         if (clearPrevious) Http2Connection.this.peerSettings.clear(); 
/* 664 */         Http2Connection.this.peerSettings.merge(newSettings);
/* 665 */         applyAndAckSettings(newSettings);
/* 666 */         int peerInitialWindowSize = Http2Connection.this.peerSettings.getInitialWindowSize();
/* 667 */         if (peerInitialWindowSize != -1 && peerInitialWindowSize != priorWriteWindowSize) {
/* 668 */           delta = (peerInitialWindowSize - priorWriteWindowSize);
/* 669 */           if (!Http2Connection.this.receivedInitialPeerSettings) {
/* 670 */             Http2Connection.this.addBytesToWriteWindow(delta);
/* 671 */             Http2Connection.this.receivedInitialPeerSettings = true;
/*     */           } 
/* 673 */           if (!Http2Connection.this.streams.isEmpty()) {
/* 674 */             streamsToNotify = (Http2Stream[])Http2Connection.this.streams.values().toArray((Object[])new Http2Stream[Http2Connection.this.streams.size()]);
/*     */           }
/*     */         } 
/* 677 */         Http2Connection.executor.execute((Runnable)new NamedRunnable("OkHttp %s settings", new Object[] { this.this$0.hostname }) {
/*     */               public void execute() {
/* 679 */                 Http2Connection.this.listener.onSettings(Http2Connection.this);
/*     */               }
/*     */             });
/*     */       } 
/* 683 */       if (streamsToNotify != null && delta != 0L) {
/* 684 */         for (Http2Stream stream : streamsToNotify) {
/* 685 */           synchronized (stream) {
/* 686 */             stream.addBytesToWriteWindow(delta);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private void applyAndAckSettings(final Settings peerSettings) {
/* 693 */       Http2Connection.executor.execute((Runnable)new NamedRunnable("OkHttp %s ACK Settings", new Object[] { this.this$0.hostname }) {
/*     */             public void execute() {
/*     */               try {
/* 696 */                 Http2Connection.this.writer.applyAndAckSettings(peerSettings);
/* 697 */               } catch (IOException iOException) {}
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void ackSettings() {}
/*     */ 
/*     */     
/*     */     public void ping(boolean reply, int payload1, int payload2) {
/* 708 */       if (reply) {
/* 709 */         Ping ping = Http2Connection.this.removePing(payload1);
/* 710 */         if (ping != null) {
/* 711 */           ping.receive();
/*     */         }
/*     */       } else {
/*     */         
/* 715 */         Http2Connection.this.writePingLater(true, payload1, payload2, null);
/*     */       } 
/*     */     }
/*     */     public void goAway(int lastGoodStreamId, ErrorCode errorCode, ByteString debugData) {
/*     */       Http2Stream[] streamsCopy;
/* 720 */       if (debugData.size() > 0);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 725 */       synchronized (Http2Connection.this) {
/* 726 */         streamsCopy = (Http2Stream[])Http2Connection.this.streams.values().toArray((Object[])new Http2Stream[Http2Connection.this.streams.size()]);
/* 727 */         Http2Connection.this.shutdown = true;
/*     */       } 
/*     */ 
/*     */       
/* 731 */       for (Http2Stream http2Stream : streamsCopy) {
/* 732 */         if (http2Stream.getId() > lastGoodStreamId && http2Stream.isLocallyInitiated()) {
/* 733 */           http2Stream.receiveRstStream(ErrorCode.REFUSED_STREAM);
/* 734 */           Http2Connection.this.removeStream(http2Stream.getId());
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void windowUpdate(int streamId, long windowSizeIncrement) {
/* 740 */       if (streamId == 0) {
/* 741 */         synchronized (Http2Connection.this) {
/* 742 */           Http2Connection.this.bytesLeftInWriteWindow += windowSizeIncrement;
/* 743 */           Http2Connection.this.notifyAll();
/*     */         } 
/*     */       } else {
/* 746 */         Http2Stream stream = Http2Connection.this.getStream(streamId);
/* 747 */         if (stream != null) {
/* 748 */           synchronized (stream) {
/* 749 */             stream.addBytesToWriteWindow(windowSizeIncrement);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void priority(int streamId, int streamDependency, int weight, boolean exclusive) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void pushPromise(int streamId, int promisedStreamId, List<Header> requestHeaders) {
/* 762 */       Http2Connection.this.pushRequestLater(promisedStreamId, requestHeaders);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void alternateService(int streamId, String origin, ByteString protocol, String host, int port, long maxAge) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean pushedStream(int streamId) {
/* 773 */     return (streamId != 0 && (streamId & 0x1) == 0);
/*     */   }
/*     */   
/*     */   Http2Connection(Builder builder) {
/* 777 */     this.currentPushRequests = new LinkedHashSet<>(); this.pushObserver = builder.pushObserver; this.client = builder.client; this.listener = builder.listener; this.nextStreamId = builder.client ? 1 : 2; if (builder.client)
/*     */       this.nextStreamId += 2;  this.nextPingId = builder.client ? 1 : 2; if (builder.client)
/*     */       this.okHttpSettings.set(7, 16777216);  this.hostname = builder.hostname; this.pushExecutor = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<>(), Util.threadFactory(Util.format("OkHttp %s Push Observer", new Object[] { this.hostname }), true)); this.peerSettings.set(7, 65535); this.peerSettings.set(5, 16384); this.bytesLeftInWriteWindow = this.peerSettings.getInitialWindowSize(); this.socket = builder.socket; this.writer = new Http2Writer(builder.sink, this.client);
/* 780 */     this.readerRunnable = new ReaderRunnable(new Http2Reader(builder.source, this.client)); } void pushRequestLater(final int streamId, final List<Header> requestHeaders) { synchronized (this) {
/* 781 */       if (this.currentPushRequests.contains(Integer.valueOf(streamId))) {
/* 782 */         writeSynResetLater(streamId, ErrorCode.PROTOCOL_ERROR);
/*     */         return;
/*     */       } 
/* 785 */       this.currentPushRequests.add(Integer.valueOf(streamId));
/*     */     } 
/* 787 */     this.pushExecutor.execute((Runnable)new NamedRunnable("OkHttp %s Push Request[%s]", new Object[] { this.hostname, Integer.valueOf(streamId) }) {
/*     */           public void execute() {
/* 789 */             boolean cancel = Http2Connection.this.pushObserver.onRequest(streamId, requestHeaders);
/*     */             try {
/* 791 */               if (cancel) {
/* 792 */                 Http2Connection.this.writer.rstStream(streamId, ErrorCode.CANCEL);
/* 793 */                 synchronized (Http2Connection.this) {
/* 794 */                   Http2Connection.this.currentPushRequests.remove(Integer.valueOf(streamId));
/*     */                 } 
/*     */               } 
/* 797 */             } catch (IOException iOException) {}
/*     */           }
/*     */         }); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void pushHeadersLater(final int streamId, final List<Header> requestHeaders, final boolean inFinished) {
/* 805 */     this.pushExecutor.execute((Runnable)new NamedRunnable("OkHttp %s Push Headers[%s]", new Object[] { this.hostname, Integer.valueOf(streamId) }) {
/*     */           public void execute() {
/* 807 */             boolean cancel = Http2Connection.this.pushObserver.onHeaders(streamId, requestHeaders, inFinished);
/*     */             try {
/* 809 */               if (cancel) Http2Connection.this.writer.rstStream(streamId, ErrorCode.CANCEL); 
/* 810 */               if (cancel || inFinished) {
/* 811 */                 synchronized (Http2Connection.this) {
/* 812 */                   Http2Connection.this.currentPushRequests.remove(Integer.valueOf(streamId));
/*     */                 } 
/*     */               }
/* 815 */             } catch (IOException iOException) {}
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void pushDataLater(final int streamId, BufferedSource source, final int byteCount, final boolean inFinished) throws IOException {
/* 827 */     final Buffer buffer = new Buffer();
/* 828 */     source.require(byteCount);
/* 829 */     source.read(buffer, byteCount);
/* 830 */     if (buffer.size() != byteCount) throw new IOException(buffer.size() + " != " + byteCount); 
/* 831 */     this.pushExecutor.execute((Runnable)new NamedRunnable("OkHttp %s Push Data[%s]", new Object[] { this.hostname, Integer.valueOf(streamId) }) {
/*     */           public void execute() {
/*     */             try {
/* 834 */               boolean cancel = Http2Connection.this.pushObserver.onData(streamId, (BufferedSource)buffer, byteCount, inFinished);
/* 835 */               if (cancel) Http2Connection.this.writer.rstStream(streamId, ErrorCode.CANCEL); 
/* 836 */               if (cancel || inFinished) {
/* 837 */                 synchronized (Http2Connection.this) {
/* 838 */                   Http2Connection.this.currentPushRequests.remove(Integer.valueOf(streamId));
/*     */                 } 
/*     */               }
/* 841 */             } catch (IOException iOException) {}
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   void pushResetLater(final int streamId, final ErrorCode errorCode) {
/* 848 */     this.pushExecutor.execute((Runnable)new NamedRunnable("OkHttp %s Push Reset[%s]", new Object[] { this.hostname, Integer.valueOf(streamId) }) {
/*     */           public void execute() {
/* 850 */             Http2Connection.this.pushObserver.onReset(streamId, errorCode);
/* 851 */             synchronized (Http2Connection.this) {
/* 852 */               Http2Connection.this.currentPushRequests.remove(Integer.valueOf(streamId));
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static abstract class Listener
/*     */   {
/* 860 */     public static final Listener REFUSE_INCOMING_STREAMS = new Listener() {
/*     */         public void onStream(Http2Stream stream) throws IOException {
/* 862 */           stream.close(ErrorCode.REFUSED_STREAM);
/*     */         }
/*     */       };
/*     */     
/*     */     public abstract void onStream(Http2Stream param1Http2Stream) throws IOException;
/*     */     
/*     */     public void onSettings(Http2Connection connection) {}
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http2\Http2Connection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */