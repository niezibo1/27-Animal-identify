/*     */ package okhttp3.internal.http2;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import okhttp3.internal.Util;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSource;
/*     */ import okio.ByteString;
/*     */ import okio.Source;
/*     */ import okio.Timeout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Http2Reader
/*     */   implements Closeable
/*     */ {
/*  60 */   static final Logger logger = Logger.getLogger(Http2.class.getName());
/*     */   
/*     */   private final BufferedSource source;
/*     */   
/*     */   private final ContinuationSource continuation;
/*     */   
/*     */   private final boolean client;
/*     */   
/*     */   final Hpack.Reader hpackReader;
/*     */   
/*     */   public Http2Reader(BufferedSource source, boolean client) {
/*  71 */     this.source = source;
/*  72 */     this.client = client;
/*  73 */     this.continuation = new ContinuationSource(this.source);
/*  74 */     this.hpackReader = new Hpack.Reader(4096, this.continuation);
/*     */   }
/*     */   
/*     */   public void readConnectionPreface(Handler handler) throws IOException {
/*  78 */     if (this.client) {
/*     */       
/*  80 */       if (!nextFrame(true, handler)) {
/*  81 */         throw Http2.ioException("Required SETTINGS preface not received", new Object[0]);
/*     */       }
/*     */     } else {
/*     */       
/*  85 */       ByteString connectionPreface = this.source.readByteString(Http2.CONNECTION_PREFACE.size());
/*  86 */       if (logger.isLoggable(Level.FINE)) logger.fine(Util.format("<< CONNECTION %s", new Object[] { connectionPreface.hex() })); 
/*  87 */       if (!Http2.CONNECTION_PREFACE.equals(connectionPreface)) {
/*  88 */         throw Http2.ioException("Expected a connection header but was %s", new Object[] { connectionPreface.utf8() });
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean nextFrame(boolean requireSettings, Handler handler) throws IOException {
/*     */     try {
/*  95 */       this.source.require(9L);
/*  96 */     } catch (IOException e) {
/*  97 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     int length = readMedium(this.source);
/* 112 */     if (length < 0 || length > 16384) {
/* 113 */       throw Http2.ioException("FRAME_SIZE_ERROR: %s", new Object[] { Integer.valueOf(length) });
/*     */     }
/* 115 */     byte type = (byte)(this.source.readByte() & 0xFF);
/* 116 */     if (requireSettings && type != 4) {
/* 117 */       throw Http2.ioException("Expected a SETTINGS frame but was %s", new Object[] { Byte.valueOf(type) });
/*     */     }
/* 119 */     byte flags = (byte)(this.source.readByte() & 0xFF);
/* 120 */     int streamId = this.source.readInt() & Integer.MAX_VALUE;
/* 121 */     if (logger.isLoggable(Level.FINE)) logger.fine(Http2.frameLog(true, streamId, length, type, flags));
/*     */     
/* 123 */     switch (type)
/*     */     { case 0:
/* 125 */         readData(handler, length, flags, streamId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 164 */         return true;case 1: readHeaders(handler, length, flags, streamId); return true;case 2: readPriority(handler, length, flags, streamId); return true;case 3: readRstStream(handler, length, flags, streamId); return true;case 4: readSettings(handler, length, flags, streamId); return true;case 5: readPushPromise(handler, length, flags, streamId); return true;case 6: readPing(handler, length, flags, streamId); return true;case 7: readGoAway(handler, length, flags, streamId); return true;case 8: readWindowUpdate(handler, length, flags, streamId); return true; }  this.source.skip(length); return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void readHeaders(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 169 */     if (streamId == 0) throw Http2.ioException("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0", new Object[0]);
/*     */     
/* 171 */     boolean endStream = ((flags & 0x1) != 0);
/*     */     
/* 173 */     short padding = ((flags & 0x8) != 0) ? (short)(this.source.readByte() & 0xFF) : 0;
/*     */     
/* 175 */     if ((flags & 0x20) != 0) {
/* 176 */       readPriority(handler, streamId);
/* 177 */       length -= 5;
/*     */     } 
/*     */     
/* 180 */     length = lengthWithoutPadding(length, flags, padding);
/*     */     
/* 182 */     List<Header> headerBlock = readHeaderBlock(length, padding, flags, streamId);
/*     */     
/* 184 */     handler.headers(endStream, streamId, -1, headerBlock);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Header> readHeaderBlock(int length, short padding, byte flags, int streamId) throws IOException {
/* 189 */     this.continuation.length = this.continuation.left = length;
/* 190 */     this.continuation.padding = padding;
/* 191 */     this.continuation.flags = flags;
/* 192 */     this.continuation.streamId = streamId;
/*     */ 
/*     */ 
/*     */     
/* 196 */     this.hpackReader.readHeaders();
/* 197 */     return this.hpackReader.getAndResetHeaderList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readData(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 203 */     boolean inFinished = ((flags & 0x1) != 0);
/* 204 */     boolean gzipped = ((flags & 0x20) != 0);
/* 205 */     if (gzipped) {
/* 206 */       throw Http2.ioException("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA", new Object[0]);
/*     */     }
/*     */     
/* 209 */     short padding = ((flags & 0x8) != 0) ? (short)(this.source.readByte() & 0xFF) : 0;
/* 210 */     length = lengthWithoutPadding(length, flags, padding);
/*     */     
/* 212 */     handler.data(inFinished, streamId, this.source, length);
/* 213 */     this.source.skip(padding);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readPriority(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 218 */     if (length != 5) throw Http2.ioException("TYPE_PRIORITY length: %d != 5", new Object[] { Integer.valueOf(length) }); 
/* 219 */     if (streamId == 0) throw Http2.ioException("TYPE_PRIORITY streamId == 0", new Object[0]); 
/* 220 */     readPriority(handler, streamId);
/*     */   }
/*     */   
/*     */   private void readPriority(Handler handler, int streamId) throws IOException {
/* 224 */     int w1 = this.source.readInt();
/* 225 */     boolean exclusive = ((w1 & Integer.MIN_VALUE) != 0);
/* 226 */     int streamDependency = w1 & Integer.MAX_VALUE;
/* 227 */     int weight = (this.source.readByte() & 0xFF) + 1;
/* 228 */     handler.priority(streamId, streamDependency, weight, exclusive);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readRstStream(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 233 */     if (length != 4) throw Http2.ioException("TYPE_RST_STREAM length: %d != 4", new Object[] { Integer.valueOf(length) }); 
/* 234 */     if (streamId == 0) throw Http2.ioException("TYPE_RST_STREAM streamId == 0", new Object[0]); 
/* 235 */     int errorCodeInt = this.source.readInt();
/* 236 */     ErrorCode errorCode = ErrorCode.fromHttp2(errorCodeInt);
/* 237 */     if (errorCode == null) {
/* 238 */       throw Http2.ioException("TYPE_RST_STREAM unexpected error code: %d", new Object[] { Integer.valueOf(errorCodeInt) });
/*     */     }
/* 240 */     handler.rstStream(streamId, errorCode);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readSettings(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 245 */     if (streamId != 0) throw Http2.ioException("TYPE_SETTINGS streamId != 0", new Object[0]); 
/* 246 */     if ((flags & 0x1) != 0) {
/* 247 */       if (length != 0) throw Http2.ioException("FRAME_SIZE_ERROR ack frame should be empty!", new Object[0]); 
/* 248 */       handler.ackSettings();
/*     */       
/*     */       return;
/*     */     } 
/* 252 */     if (length % 6 != 0) throw Http2.ioException("TYPE_SETTINGS length %% 6 != 0: %s", new Object[] { Integer.valueOf(length) }); 
/* 253 */     Settings settings = new Settings();
/* 254 */     for (int i = 0; i < length; i += 6) {
/* 255 */       short id = this.source.readShort();
/* 256 */       int value = this.source.readInt();
/*     */       
/* 258 */       switch (id) {
/*     */ 
/*     */         
/*     */         case 2:
/* 262 */           if (value != 0 && value != 1) {
/* 263 */             throw Http2.ioException("PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1", new Object[0]);
/*     */           }
/*     */           break;
/*     */         case 3:
/* 267 */           id = 4;
/*     */           break;
/*     */         case 4:
/* 270 */           id = 7;
/* 271 */           if (value < 0) {
/* 272 */             throw Http2.ioException("PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1", new Object[0]);
/*     */           }
/*     */           break;
/*     */         case 5:
/* 276 */           if (value < 16384 || value > 16777215) {
/* 277 */             throw Http2.ioException("PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: %s", new Object[] { Integer.valueOf(value) });
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 285 */       settings.set(id, value);
/*     */     } 
/* 287 */     handler.settings(false, settings);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readPushPromise(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 292 */     if (streamId == 0) {
/* 293 */       throw Http2.ioException("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0", new Object[0]);
/*     */     }
/* 295 */     short padding = ((flags & 0x8) != 0) ? (short)(this.source.readByte() & 0xFF) : 0;
/* 296 */     int promisedStreamId = this.source.readInt() & Integer.MAX_VALUE;
/* 297 */     length -= 4;
/* 298 */     length = lengthWithoutPadding(length, flags, padding);
/* 299 */     List<Header> headerBlock = readHeaderBlock(length, padding, flags, streamId);
/* 300 */     handler.pushPromise(streamId, promisedStreamId, headerBlock);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readPing(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 305 */     if (length != 8) throw Http2.ioException("TYPE_PING length != 8: %s", new Object[] { Integer.valueOf(length) }); 
/* 306 */     if (streamId != 0) throw Http2.ioException("TYPE_PING streamId != 0", new Object[0]); 
/* 307 */     int payload1 = this.source.readInt();
/* 308 */     int payload2 = this.source.readInt();
/* 309 */     boolean ack = ((flags & 0x1) != 0);
/* 310 */     handler.ping(ack, payload1, payload2);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readGoAway(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 315 */     if (length < 8) throw Http2.ioException("TYPE_GOAWAY length < 8: %s", new Object[] { Integer.valueOf(length) }); 
/* 316 */     if (streamId != 0) throw Http2.ioException("TYPE_GOAWAY streamId != 0", new Object[0]); 
/* 317 */     int lastStreamId = this.source.readInt();
/* 318 */     int errorCodeInt = this.source.readInt();
/* 319 */     int opaqueDataLength = length - 8;
/* 320 */     ErrorCode errorCode = ErrorCode.fromHttp2(errorCodeInt);
/* 321 */     if (errorCode == null) {
/* 322 */       throw Http2.ioException("TYPE_GOAWAY unexpected error code: %d", new Object[] { Integer.valueOf(errorCodeInt) });
/*     */     }
/* 324 */     ByteString debugData = ByteString.EMPTY;
/* 325 */     if (opaqueDataLength > 0) {
/* 326 */       debugData = this.source.readByteString(opaqueDataLength);
/*     */     }
/* 328 */     handler.goAway(lastStreamId, errorCode, debugData);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readWindowUpdate(Handler handler, int length, byte flags, int streamId) throws IOException {
/* 333 */     if (length != 4) throw Http2.ioException("TYPE_WINDOW_UPDATE length !=4: %s", new Object[] { Integer.valueOf(length) }); 
/* 334 */     long increment = this.source.readInt() & 0x7FFFFFFFL;
/* 335 */     if (increment == 0L) throw Http2.ioException("windowSizeIncrement was 0", new Object[] { Long.valueOf(increment) }); 
/* 336 */     handler.windowUpdate(streamId, increment);
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 340 */     this.source.close();
/*     */   }
/*     */   static interface Handler {
/*     */     void data(boolean param1Boolean, int param1Int1, BufferedSource param1BufferedSource, int param1Int2) throws IOException;
/*     */     void headers(boolean param1Boolean, int param1Int1, int param1Int2, List<Header> param1List);
/*     */     void rstStream(int param1Int, ErrorCode param1ErrorCode);
/*     */     void settings(boolean param1Boolean, Settings param1Settings);
/*     */     void ackSettings();
/*     */     void ping(boolean param1Boolean, int param1Int1, int param1Int2);
/*     */     void goAway(int param1Int, ErrorCode param1ErrorCode, ByteString param1ByteString);
/*     */     void windowUpdate(int param1Int, long param1Long);
/*     */     void priority(int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean);
/*     */     void pushPromise(int param1Int1, int param1Int2, List<Header> param1List) throws IOException;
/*     */     void alternateService(int param1Int1, String param1String1, ByteString param1ByteString, String param1String2, int param1Int2, long param1Long); }
/*     */   static final class ContinuationSource implements Source { private final BufferedSource source; int length;
/*     */     byte flags;
/*     */     
/*     */     public ContinuationSource(BufferedSource source) {
/* 358 */       this.source = source;
/*     */     }
/*     */     int streamId; int left; short padding;
/*     */     public long read(Buffer sink, long byteCount) throws IOException {
/* 362 */       while (this.left == 0) {
/* 363 */         this.source.skip(this.padding);
/* 364 */         this.padding = 0;
/* 365 */         if ((this.flags & 0x4) != 0) return -1L; 
/* 366 */         readContinuationHeader();
/*     */       } 
/*     */ 
/*     */       
/* 370 */       long read = this.source.read(sink, Math.min(byteCount, this.left));
/* 371 */       if (read == -1L) return -1L; 
/* 372 */       this.left = (int)(this.left - read);
/* 373 */       return read;
/*     */     }
/*     */     
/*     */     public Timeout timeout() {
/* 377 */       return this.source.timeout();
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {}
/*     */     
/*     */     private void readContinuationHeader() throws IOException {
/* 384 */       int previousStreamId = this.streamId;
/*     */       
/* 386 */       this.length = this.left = Http2Reader.readMedium(this.source);
/* 387 */       byte type = (byte)(this.source.readByte() & 0xFF);
/* 388 */       this.flags = (byte)(this.source.readByte() & 0xFF);
/* 389 */       if (Http2Reader.logger.isLoggable(Level.FINE)) Http2Reader.logger.fine(Http2.frameLog(true, this.streamId, this.length, type, this.flags)); 
/* 390 */       this.streamId = this.source.readInt() & Integer.MAX_VALUE;
/* 391 */       if (type != 9) throw Http2.ioException("%s != TYPE_CONTINUATION", new Object[] { Byte.valueOf(type) }); 
/* 392 */       if (this.streamId != previousStreamId) throw Http2.ioException("TYPE_CONTINUATION streamId changed", new Object[0]); 
/*     */     } }
/*     */ 
/*     */   
/*     */   static int readMedium(BufferedSource source) throws IOException {
/* 397 */     return (source.readByte() & 0xFF) << 16 | (source
/* 398 */       .readByte() & 0xFF) << 8 | source
/* 399 */       .readByte() & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   static int lengthWithoutPadding(int length, byte flags, short padding) throws IOException {
/* 404 */     if ((flags & 0x8) != 0) length--; 
/* 405 */     if (padding > length) {
/* 406 */       throw Http2.ioException("PROTOCOL_ERROR padding %s > remaining length %s", new Object[] { Short.valueOf(padding), Integer.valueOf(length) });
/*     */     }
/* 408 */     return (short)(length - padding);
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http2\Http2Reader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */