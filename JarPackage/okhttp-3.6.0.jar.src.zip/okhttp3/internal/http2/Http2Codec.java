/*     */ package okhttp3.internal.http2;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.Headers;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.Protocol;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.Response;
/*     */ import okhttp3.ResponseBody;
/*     */ import okhttp3.internal.Internal;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.connection.StreamAllocation;
/*     */ import okhttp3.internal.http.HttpCodec;
/*     */ import okhttp3.internal.http.RealResponseBody;
/*     */ import okhttp3.internal.http.RequestLine;
/*     */ import okhttp3.internal.http.StatusLine;
/*     */ import okio.ByteString;
/*     */ import okio.ForwardingSource;
/*     */ import okio.Okio;
/*     */ import okio.Sink;
/*     */ import okio.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Codec
/*     */   implements HttpCodec
/*     */ {
/*  52 */   private static final ByteString CONNECTION = ByteString.encodeUtf8("connection");
/*  53 */   private static final ByteString HOST = ByteString.encodeUtf8("host");
/*  54 */   private static final ByteString KEEP_ALIVE = ByteString.encodeUtf8("keep-alive");
/*  55 */   private static final ByteString PROXY_CONNECTION = ByteString.encodeUtf8("proxy-connection");
/*  56 */   private static final ByteString TRANSFER_ENCODING = ByteString.encodeUtf8("transfer-encoding");
/*  57 */   private static final ByteString TE = ByteString.encodeUtf8("te");
/*  58 */   private static final ByteString ENCODING = ByteString.encodeUtf8("encoding");
/*  59 */   private static final ByteString UPGRADE = ByteString.encodeUtf8("upgrade");
/*     */ 
/*     */   
/*  62 */   private static final List<ByteString> HTTP_2_SKIPPED_REQUEST_HEADERS = Util.immutableList((Object[])new ByteString[] { CONNECTION, HOST, KEEP_ALIVE, PROXY_CONNECTION, TE, TRANSFER_ENCODING, ENCODING, UPGRADE, Header.TARGET_METHOD, Header.TARGET_PATH, Header.TARGET_SCHEME, Header.TARGET_AUTHORITY });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private static final List<ByteString> HTTP_2_SKIPPED_RESPONSE_HEADERS = Util.immutableList((Object[])new ByteString[] { CONNECTION, HOST, KEEP_ALIVE, PROXY_CONNECTION, TE, TRANSFER_ENCODING, ENCODING, UPGRADE });
/*     */ 
/*     */   
/*     */   private final OkHttpClient client;
/*     */ 
/*     */   
/*     */   final StreamAllocation streamAllocation;
/*     */ 
/*     */   
/*     */   private final Http2Connection connection;
/*     */ 
/*     */   
/*     */   private Http2Stream stream;
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Codec(OkHttpClient client, StreamAllocation streamAllocation, Http2Connection connection) {
/*  92 */     this.client = client;
/*  93 */     this.streamAllocation = streamAllocation;
/*  94 */     this.connection = connection;
/*     */   }
/*     */   
/*     */   public Sink createRequestBody(Request request, long contentLength) {
/*  98 */     return this.stream.getSink();
/*     */   }
/*     */   
/*     */   public void writeRequestHeaders(Request request) throws IOException {
/* 102 */     if (this.stream != null)
/*     */       return; 
/* 104 */     boolean hasRequestBody = (request.body() != null);
/* 105 */     List<Header> requestHeaders = http2HeadersList(request);
/* 106 */     this.stream = this.connection.newStream(requestHeaders, hasRequestBody);
/* 107 */     this.stream.readTimeout().timeout(this.client.readTimeoutMillis(), TimeUnit.MILLISECONDS);
/* 108 */     this.stream.writeTimeout().timeout(this.client.writeTimeoutMillis(), TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */   public void flushRequest() throws IOException {
/* 112 */     this.connection.flush();
/*     */   }
/*     */   
/*     */   public void finishRequest() throws IOException {
/* 116 */     this.stream.getSink().close();
/*     */   }
/*     */   
/*     */   public Response.Builder readResponseHeaders(boolean expectContinue) throws IOException {
/* 120 */     List<Header> headers = this.stream.takeResponseHeaders();
/* 121 */     Response.Builder responseBuilder = readHttp2HeadersList(headers);
/* 122 */     if (expectContinue && Internal.instance.code(responseBuilder) == 100) {
/* 123 */       return null;
/*     */     }
/* 125 */     return responseBuilder;
/*     */   }
/*     */   
/*     */   public static List<Header> http2HeadersList(Request request) {
/* 129 */     Headers headers = request.headers();
/* 130 */     List<Header> result = new ArrayList<>(headers.size() + 4);
/* 131 */     result.add(new Header(Header.TARGET_METHOD, request.method()));
/* 132 */     result.add(new Header(Header.TARGET_PATH, RequestLine.requestPath(request.url())));
/* 133 */     String host = request.header("Host");
/* 134 */     if (host != null) {
/* 135 */       result.add(new Header(Header.TARGET_AUTHORITY, host));
/*     */     }
/* 137 */     result.add(new Header(Header.TARGET_SCHEME, request.url().scheme()));
/*     */     
/* 139 */     for (int i = 0, size = headers.size(); i < size; i++) {
/*     */       
/* 141 */       ByteString name = ByteString.encodeUtf8(headers.name(i).toLowerCase(Locale.US));
/* 142 */       if (!HTTP_2_SKIPPED_REQUEST_HEADERS.contains(name)) {
/* 143 */         result.add(new Header(name, headers.value(i)));
/*     */       }
/*     */     } 
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Response.Builder readHttp2HeadersList(List<Header> headerBlock) throws IOException {
/* 151 */     StatusLine statusLine = null;
/* 152 */     Headers.Builder headersBuilder = new Headers.Builder();
/* 153 */     for (int i = 0, size = headerBlock.size(); i < size; i++) {
/* 154 */       Header header = headerBlock.get(i);
/*     */ 
/*     */ 
/*     */       
/* 158 */       if (header == null) {
/* 159 */         if (statusLine != null && statusLine.code == 100) {
/* 160 */           statusLine = null;
/* 161 */           headersBuilder = new Headers.Builder();
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 166 */         ByteString name = header.name;
/* 167 */         String value = header.value.utf8();
/* 168 */         if (name.equals(Header.RESPONSE_STATUS)) {
/* 169 */           statusLine = StatusLine.parse("HTTP/1.1 " + value);
/* 170 */         } else if (!HTTP_2_SKIPPED_RESPONSE_HEADERS.contains(name)) {
/* 171 */           Internal.instance.addLenient(headersBuilder, name.utf8(), value);
/*     */         } 
/*     */       } 
/* 174 */     }  if (statusLine == null) throw new ProtocolException("Expected ':status' header not present");
/*     */     
/* 176 */     return (new Response.Builder())
/* 177 */       .protocol(Protocol.HTTP_2)
/* 178 */       .code(statusLine.code)
/* 179 */       .message(statusLine.message)
/* 180 */       .headers(headersBuilder.build());
/*     */   }
/*     */   
/*     */   public ResponseBody openResponseBody(Response response) throws IOException {
/* 184 */     StreamFinishingSource streamFinishingSource = new StreamFinishingSource(this.stream.getSource());
/* 185 */     return (ResponseBody)new RealResponseBody(response.headers(), Okio.buffer((Source)streamFinishingSource));
/*     */   }
/*     */   
/*     */   public void cancel() {
/* 189 */     if (this.stream != null) this.stream.closeLater(ErrorCode.CANCEL); 
/*     */   }
/*     */   
/*     */   class StreamFinishingSource extends ForwardingSource {
/*     */     public StreamFinishingSource(Source delegate) {
/* 194 */       super(delegate);
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 198 */       Http2Codec.this.streamAllocation.streamFinished(false, Http2Codec.this);
/* 199 */       super.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http2\Http2Codec.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */