/*    */ package okhttp3.internal.http2;
/*    */ 
/*    */ import java.util.concurrent.CountDownLatch;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Ping
/*    */ {
/* 25 */   private final CountDownLatch latch = new CountDownLatch(1);
/* 26 */   private long sent = -1L;
/* 27 */   private long received = -1L;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void send() {
/* 33 */     if (this.sent != -1L) throw new IllegalStateException(); 
/* 34 */     this.sent = System.nanoTime();
/*    */   }
/*    */   
/*    */   void receive() {
/* 38 */     if (this.received != -1L || this.sent == -1L) throw new IllegalStateException(); 
/* 39 */     this.received = System.nanoTime();
/* 40 */     this.latch.countDown();
/*    */   }
/*    */   
/*    */   void cancel() {
/* 44 */     if (this.received != -1L || this.sent == -1L) throw new IllegalStateException(); 
/* 45 */     this.received = this.sent - 1L;
/* 46 */     this.latch.countDown();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long roundTripTime() throws InterruptedException {
/* 54 */     this.latch.await();
/* 55 */     return this.received - this.sent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long roundTripTime(long timeout, TimeUnit unit) throws InterruptedException {
/* 63 */     if (this.latch.await(timeout, unit)) {
/* 64 */       return this.received - this.sent;
/*    */     }
/* 66 */     return -2L;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http2\Ping.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */