/*    */ package okhttp3.internal.cache2;
/*    */ 
/*    */ import java.io.EOFException;
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.FileChannel;
/*    */ import okio.Buffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FileOperator
/*    */ {
/*    */   private static final int BUFFER_SIZE = 8192;
/* 40 */   private final byte[] byteArray = new byte[8192];
/* 41 */   private final ByteBuffer byteBuffer = ByteBuffer.wrap(this.byteArray);
/*    */   private final FileChannel fileChannel;
/*    */   
/*    */   public FileOperator(FileChannel fileChannel) {
/* 45 */     this.fileChannel = fileChannel;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(long pos, Buffer source, long byteCount) throws IOException {
/* 50 */     if (byteCount < 0L || byteCount > source.size()) throw new IndexOutOfBoundsException();
/*    */     
/* 52 */     while (byteCount > 0L) {
/*    */       
/*    */       try {
/* 55 */         int toWrite = (int)Math.min(8192L, byteCount);
/* 56 */         source.read(this.byteArray, 0, toWrite);
/* 57 */         this.byteBuffer.limit(toWrite);
/*    */ 
/*    */         
/*    */         do {
/* 61 */           int bytesWritten = this.fileChannel.write(this.byteBuffer, pos);
/* 62 */           pos += bytesWritten;
/* 63 */         } while (this.byteBuffer.hasRemaining());
/*    */         
/* 65 */         byteCount -= toWrite;
/*    */       } finally {
/* 67 */         this.byteBuffer.clear();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void read(long pos, Buffer sink, long byteCount) throws IOException {
/* 78 */     if (byteCount < 0L) throw new IndexOutOfBoundsException();
/*    */     
/* 80 */     while (byteCount > 0L) {
/*    */       
/*    */       try {
/* 83 */         this.byteBuffer.limit((int)Math.min(8192L, byteCount));
/* 84 */         if (this.fileChannel.read(this.byteBuffer, pos) == -1) throw new EOFException(); 
/* 85 */         int bytesRead = this.byteBuffer.position();
/*    */ 
/*    */         
/* 88 */         sink.write(this.byteArray, 0, bytesRead);
/* 89 */         pos += bytesRead;
/* 90 */         byteCount -= bytesRead;
/*    */       } finally {
/* 92 */         this.byteBuffer.clear();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\cache2\FileOperator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */