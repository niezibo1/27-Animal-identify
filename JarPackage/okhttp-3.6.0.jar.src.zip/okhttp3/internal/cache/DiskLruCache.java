/*      */ package okhttp3.internal.cache;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.Flushable;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.LinkedBlockingQueue;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import okhttp3.internal.Util;
/*      */ import okhttp3.internal.io.FileSystem;
/*      */ import okhttp3.internal.platform.Platform;
/*      */ import okio.BufferedSink;
/*      */ import okio.BufferedSource;
/*      */ import okio.Okio;
/*      */ import okio.Sink;
/*      */ import okio.Source;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class DiskLruCache
/*      */   implements Closeable, Flushable
/*      */ {
/*      */   static final String JOURNAL_FILE = "journal";
/*      */   static final String JOURNAL_FILE_TEMP = "journal.tmp";
/*      */   static final String JOURNAL_FILE_BACKUP = "journal.bkp";
/*      */   static final String MAGIC = "libcore.io.DiskLruCache";
/*      */   static final String VERSION_1 = "1";
/*      */   static final long ANY_SEQUENCE_NUMBER = -1L;
/*   93 */   static final Pattern LEGAL_KEY_PATTERN = Pattern.compile("[a-z0-9_-]{1,120}");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String CLEAN = "CLEAN";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DIRTY = "DIRTY";
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String REMOVE = "REMOVE";
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String READ = "READ";
/*      */ 
/*      */ 
/*      */   
/*      */   final FileSystem fileSystem;
/*      */ 
/*      */ 
/*      */   
/*      */   final File directory;
/*      */ 
/*      */ 
/*      */   
/*      */   private final File journalFile;
/*      */ 
/*      */ 
/*      */   
/*      */   private final File journalFileTmp;
/*      */ 
/*      */ 
/*      */   
/*      */   private final File journalFileBackup;
/*      */ 
/*      */ 
/*      */   
/*      */   private final int appVersion;
/*      */ 
/*      */ 
/*      */   
/*      */   private long maxSize;
/*      */ 
/*      */ 
/*      */   
/*      */   final int valueCount;
/*      */ 
/*      */ 
/*      */   
/*  147 */   private long size = 0L;
/*      */   BufferedSink journalWriter;
/*  149 */   final LinkedHashMap<String, Entry> lruEntries = new LinkedHashMap<>(0, 0.75F, true);
/*      */ 
/*      */   
/*      */   int redundantOpCount;
/*      */   
/*      */   boolean hasJournalErrors;
/*      */   
/*      */   boolean initialized;
/*      */   
/*      */   boolean closed;
/*      */   
/*      */   boolean mostRecentTrimFailed;
/*      */   
/*      */   boolean mostRecentRebuildFailed;
/*      */   
/*  164 */   private long nextSequenceNumber = 0L;
/*      */   
/*      */   private final Executor executor;
/*      */   
/*  168 */   private final Runnable cleanupRunnable = new Runnable() {
/*      */       public void run() {
/*  170 */         synchronized (DiskLruCache.this) {
/*  171 */           if (((!DiskLruCache.this.initialized ? 1 : 0) | DiskLruCache.this.closed) != 0) {
/*      */             return;
/*      */           }
/*      */           
/*      */           try {
/*  176 */             DiskLruCache.this.trimToSize();
/*  177 */           } catch (IOException ignored) {
/*  178 */             DiskLruCache.this.mostRecentTrimFailed = true;
/*      */           } 
/*      */           
/*      */           try {
/*  182 */             if (DiskLruCache.this.journalRebuildRequired()) {
/*  183 */               DiskLruCache.this.rebuildJournal();
/*  184 */               DiskLruCache.this.redundantOpCount = 0;
/*      */             } 
/*  186 */           } catch (IOException e) {
/*  187 */             DiskLruCache.this.mostRecentRebuildFailed = true;
/*  188 */             DiskLruCache.this.journalWriter = Okio.buffer(Okio.blackhole());
/*      */           } 
/*      */         } 
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*      */   DiskLruCache(FileSystem fileSystem, File directory, int appVersion, int valueCount, long maxSize, Executor executor) {
/*  196 */     this.fileSystem = fileSystem;
/*  197 */     this.directory = directory;
/*  198 */     this.appVersion = appVersion;
/*  199 */     this.journalFile = new File(directory, "journal");
/*  200 */     this.journalFileTmp = new File(directory, "journal.tmp");
/*  201 */     this.journalFileBackup = new File(directory, "journal.bkp");
/*  202 */     this.valueCount = valueCount;
/*  203 */     this.maxSize = maxSize;
/*  204 */     this.executor = executor;
/*      */   }
/*      */   
/*      */   public synchronized void initialize() throws IOException {
/*  208 */     assert Thread.holdsLock(this);
/*      */     
/*  210 */     if (this.initialized) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  215 */     if (this.fileSystem.exists(this.journalFileBackup))
/*      */     {
/*  217 */       if (this.fileSystem.exists(this.journalFile)) {
/*  218 */         this.fileSystem.delete(this.journalFileBackup);
/*      */       } else {
/*  220 */         this.fileSystem.rename(this.journalFileBackup, this.journalFile);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  225 */     if (this.fileSystem.exists(this.journalFile)) {
/*      */       try {
/*  227 */         readJournal();
/*  228 */         processJournal();
/*  229 */         this.initialized = true;
/*      */         return;
/*  231 */       } catch (IOException journalIsCorrupt) {
/*  232 */         Platform.get().log(5, "DiskLruCache " + this.directory + " is corrupt: " + journalIsCorrupt
/*  233 */             .getMessage() + ", removing", journalIsCorrupt);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  239 */           delete();
/*      */         } finally {
/*  241 */           this.closed = false;
/*      */         } 
/*      */       } 
/*      */     }
/*  245 */     rebuildJournal();
/*      */     
/*  247 */     this.initialized = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DiskLruCache create(FileSystem fileSystem, File directory, int appVersion, int valueCount, long maxSize) {
/*  260 */     if (maxSize <= 0L) {
/*  261 */       throw new IllegalArgumentException("maxSize <= 0");
/*      */     }
/*  263 */     if (valueCount <= 0) {
/*  264 */       throw new IllegalArgumentException("valueCount <= 0");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  269 */     Executor executor = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<>(), Util.threadFactory("OkHttp DiskLruCache", true));
/*      */     
/*  271 */     return new DiskLruCache(fileSystem, directory, appVersion, valueCount, maxSize, executor);
/*      */   }
/*      */   
/*      */   private void readJournal() throws IOException {
/*  275 */     BufferedSource source = Okio.buffer(this.fileSystem.source(this.journalFile));
/*      */     try {
/*  277 */       String magic = source.readUtf8LineStrict();
/*  278 */       String version = source.readUtf8LineStrict();
/*  279 */       String appVersionString = source.readUtf8LineStrict();
/*  280 */       String valueCountString = source.readUtf8LineStrict();
/*  281 */       String blank = source.readUtf8LineStrict();
/*  282 */       if (!"libcore.io.DiskLruCache".equals(magic) || 
/*  283 */         !"1".equals(version) || 
/*  284 */         !Integer.toString(this.appVersion).equals(appVersionString) || 
/*  285 */         !Integer.toString(this.valueCount).equals(valueCountString) || 
/*  286 */         !"".equals(blank)) {
/*  287 */         throw new IOException("unexpected journal header: [" + magic + ", " + version + ", " + valueCountString + ", " + blank + "]");
/*      */       }
/*      */ 
/*      */       
/*  291 */       int lineCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  309 */       Util.closeQuietly((Closeable)source);
/*      */     } 
/*      */   }
/*      */   
/*      */   private BufferedSink newJournalWriter() throws FileNotFoundException {
/*  314 */     Sink fileSink = this.fileSystem.appendingSink(this.journalFile);
/*  315 */     FaultHidingSink faultHidingSink = new FaultHidingSink(fileSink) {
/*      */         protected void onException(IOException e) {
/*  317 */           assert Thread.holdsLock(DiskLruCache.this);
/*  318 */           DiskLruCache.this.hasJournalErrors = true;
/*      */         }
/*      */       };
/*  321 */     return Okio.buffer((Sink)faultHidingSink);
/*      */   }
/*      */   private void readJournalLine(String line) throws IOException {
/*      */     String key;
/*  325 */     int firstSpace = line.indexOf(' ');
/*  326 */     if (firstSpace == -1) {
/*  327 */       throw new IOException("unexpected journal line: " + line);
/*      */     }
/*      */     
/*  330 */     int keyBegin = firstSpace + 1;
/*  331 */     int secondSpace = line.indexOf(' ', keyBegin);
/*      */     
/*  333 */     if (secondSpace == -1) {
/*  334 */       key = line.substring(keyBegin);
/*  335 */       if (firstSpace == "REMOVE".length() && line.startsWith("REMOVE")) {
/*  336 */         this.lruEntries.remove(key);
/*      */         return;
/*      */       } 
/*      */     } else {
/*  340 */       key = line.substring(keyBegin, secondSpace);
/*      */     } 
/*      */     
/*  343 */     Entry entry = this.lruEntries.get(key);
/*  344 */     if (entry == null) {
/*  345 */       entry = new Entry(key);
/*  346 */       this.lruEntries.put(key, entry);
/*      */     } 
/*      */     
/*  349 */     if (secondSpace != -1 && firstSpace == "CLEAN".length() && line.startsWith("CLEAN")) {
/*  350 */       String[] parts = line.substring(secondSpace + 1).split(" ");
/*  351 */       entry.readable = true;
/*  352 */       entry.currentEditor = null;
/*  353 */       entry.setLengths(parts);
/*  354 */     } else if (secondSpace == -1 && firstSpace == "DIRTY".length() && line.startsWith("DIRTY")) {
/*  355 */       entry.currentEditor = new Editor(entry);
/*  356 */     } else if (secondSpace != -1 || firstSpace != "READ".length() || !line.startsWith("READ")) {
/*      */ 
/*      */       
/*  359 */       throw new IOException("unexpected journal line: " + line);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processJournal() throws IOException {
/*  368 */     this.fileSystem.delete(this.journalFileTmp);
/*  369 */     for (Iterator<Entry> i = this.lruEntries.values().iterator(); i.hasNext(); ) {
/*  370 */       Entry entry = i.next();
/*  371 */       if (entry.currentEditor == null) {
/*  372 */         for (int j = 0; j < this.valueCount; j++)
/*  373 */           this.size += entry.lengths[j]; 
/*      */         continue;
/*      */       } 
/*  376 */       entry.currentEditor = null;
/*  377 */       for (int t = 0; t < this.valueCount; t++) {
/*  378 */         this.fileSystem.delete(entry.cleanFiles[t]);
/*  379 */         this.fileSystem.delete(entry.dirtyFiles[t]);
/*      */       } 
/*  381 */       i.remove();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void rebuildJournal() throws IOException {
/*  391 */     if (this.journalWriter != null) {
/*  392 */       this.journalWriter.close();
/*      */     }
/*      */     
/*  395 */     BufferedSink writer = Okio.buffer(this.fileSystem.sink(this.journalFileTmp));
/*      */     try {
/*  397 */       writer.writeUtf8("libcore.io.DiskLruCache").writeByte(10);
/*  398 */       writer.writeUtf8("1").writeByte(10);
/*  399 */       writer.writeDecimalLong(this.appVersion).writeByte(10);
/*  400 */       writer.writeDecimalLong(this.valueCount).writeByte(10);
/*  401 */       writer.writeByte(10);
/*      */       
/*  403 */       for (Entry entry : this.lruEntries.values()) {
/*  404 */         if (entry.currentEditor != null) {
/*  405 */           writer.writeUtf8("DIRTY").writeByte(32);
/*  406 */           writer.writeUtf8(entry.key);
/*  407 */           writer.writeByte(10); continue;
/*      */         } 
/*  409 */         writer.writeUtf8("CLEAN").writeByte(32);
/*  410 */         writer.writeUtf8(entry.key);
/*  411 */         entry.writeLengths(writer);
/*  412 */         writer.writeByte(10);
/*      */       } 
/*      */     } finally {
/*      */       
/*  416 */       writer.close();
/*      */     } 
/*      */     
/*  419 */     if (this.fileSystem.exists(this.journalFile)) {
/*  420 */       this.fileSystem.rename(this.journalFile, this.journalFileBackup);
/*      */     }
/*  422 */     this.fileSystem.rename(this.journalFileTmp, this.journalFile);
/*  423 */     this.fileSystem.delete(this.journalFileBackup);
/*      */     
/*  425 */     this.journalWriter = newJournalWriter();
/*  426 */     this.hasJournalErrors = false;
/*  427 */     this.mostRecentRebuildFailed = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Snapshot get(String key) throws IOException {
/*  435 */     initialize();
/*      */     
/*  437 */     checkNotClosed();
/*  438 */     validateKey(key);
/*  439 */     Entry entry = this.lruEntries.get(key);
/*  440 */     if (entry == null || !entry.readable) return null;
/*      */     
/*  442 */     Snapshot snapshot = entry.snapshot();
/*  443 */     if (snapshot == null) return null;
/*      */     
/*  445 */     this.redundantOpCount++;
/*  446 */     this.journalWriter.writeUtf8("READ").writeByte(32).writeUtf8(key).writeByte(10);
/*  447 */     if (journalRebuildRequired()) {
/*  448 */       this.executor.execute(this.cleanupRunnable);
/*      */     }
/*      */     
/*  451 */     return snapshot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Editor edit(String key) throws IOException {
/*  458 */     return edit(key, -1L);
/*      */   }
/*      */   
/*      */   synchronized Editor edit(String key, long expectedSequenceNumber) throws IOException {
/*  462 */     initialize();
/*      */     
/*  464 */     checkNotClosed();
/*  465 */     validateKey(key);
/*  466 */     Entry entry = this.lruEntries.get(key);
/*  467 */     if (expectedSequenceNumber != -1L && (entry == null || entry.sequenceNumber != expectedSequenceNumber))
/*      */     {
/*  469 */       return null;
/*      */     }
/*  471 */     if (entry != null && entry.currentEditor != null) {
/*  472 */       return null;
/*      */     }
/*  474 */     if (this.mostRecentTrimFailed || this.mostRecentRebuildFailed) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  480 */       this.executor.execute(this.cleanupRunnable);
/*  481 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  485 */     this.journalWriter.writeUtf8("DIRTY").writeByte(32).writeUtf8(key).writeByte(10);
/*  486 */     this.journalWriter.flush();
/*      */     
/*  488 */     if (this.hasJournalErrors) {
/*  489 */       return null;
/*      */     }
/*      */     
/*  492 */     if (entry == null) {
/*  493 */       entry = new Entry(key);
/*  494 */       this.lruEntries.put(key, entry);
/*      */     } 
/*  496 */     Editor editor = new Editor(entry);
/*  497 */     entry.currentEditor = editor;
/*  498 */     return editor;
/*      */   }
/*      */ 
/*      */   
/*      */   public File getDirectory() {
/*  503 */     return this.directory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long getMaxSize() {
/*  510 */     return this.maxSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaxSize(long maxSize) {
/*  518 */     this.maxSize = maxSize;
/*  519 */     if (this.initialized) {
/*  520 */       this.executor.execute(this.cleanupRunnable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long size() throws IOException {
/*  529 */     initialize();
/*  530 */     return this.size;
/*      */   }
/*      */   
/*      */   synchronized void completeEdit(Editor editor, boolean success) throws IOException {
/*  534 */     Entry entry = editor.entry;
/*  535 */     if (entry.currentEditor != editor) {
/*  536 */       throw new IllegalStateException();
/*      */     }
/*      */ 
/*      */     
/*  540 */     if (success && !entry.readable) {
/*  541 */       for (int j = 0; j < this.valueCount; j++) {
/*  542 */         if (!editor.written[j]) {
/*  543 */           editor.abort();
/*  544 */           throw new IllegalStateException("Newly created entry didn't create value for index " + j);
/*      */         } 
/*  546 */         if (!this.fileSystem.exists(entry.dirtyFiles[j])) {
/*  547 */           editor.abort();
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     }
/*  553 */     for (int i = 0; i < this.valueCount; i++) {
/*  554 */       File dirty = entry.dirtyFiles[i];
/*  555 */       if (success) {
/*  556 */         if (this.fileSystem.exists(dirty)) {
/*  557 */           File clean = entry.cleanFiles[i];
/*  558 */           this.fileSystem.rename(dirty, clean);
/*  559 */           long oldLength = entry.lengths[i];
/*  560 */           long newLength = this.fileSystem.size(clean);
/*  561 */           entry.lengths[i] = newLength;
/*  562 */           this.size = this.size - oldLength + newLength;
/*      */         } 
/*      */       } else {
/*  565 */         this.fileSystem.delete(dirty);
/*      */       } 
/*      */     } 
/*      */     
/*  569 */     this.redundantOpCount++;
/*  570 */     entry.currentEditor = null;
/*  571 */     if (entry.readable | success) {
/*  572 */       entry.readable = true;
/*  573 */       this.journalWriter.writeUtf8("CLEAN").writeByte(32);
/*  574 */       this.journalWriter.writeUtf8(entry.key);
/*  575 */       entry.writeLengths(this.journalWriter);
/*  576 */       this.journalWriter.writeByte(10);
/*  577 */       if (success) {
/*  578 */         entry.sequenceNumber = this.nextSequenceNumber++;
/*      */       }
/*      */     } else {
/*  581 */       this.lruEntries.remove(entry.key);
/*  582 */       this.journalWriter.writeUtf8("REMOVE").writeByte(32);
/*  583 */       this.journalWriter.writeUtf8(entry.key);
/*  584 */       this.journalWriter.writeByte(10);
/*      */     } 
/*  586 */     this.journalWriter.flush();
/*      */     
/*  588 */     if (this.size > this.maxSize || journalRebuildRequired()) {
/*  589 */       this.executor.execute(this.cleanupRunnable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean journalRebuildRequired() {
/*  598 */     int redundantOpCompactThreshold = 2000;
/*  599 */     return (this.redundantOpCount >= 2000 && this.redundantOpCount >= this.lruEntries
/*  600 */       .size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean remove(String key) throws IOException {
/*  610 */     initialize();
/*      */     
/*  612 */     checkNotClosed();
/*  613 */     validateKey(key);
/*  614 */     Entry entry = this.lruEntries.get(key);
/*  615 */     if (entry == null) return false; 
/*  616 */     boolean removed = removeEntry(entry);
/*  617 */     if (removed && this.size <= this.maxSize) this.mostRecentTrimFailed = false; 
/*  618 */     return removed;
/*      */   }
/*      */   
/*      */   boolean removeEntry(Entry entry) throws IOException {
/*  622 */     if (entry.currentEditor != null) {
/*  623 */       entry.currentEditor.detach();
/*      */     }
/*      */     
/*  626 */     for (int i = 0; i < this.valueCount; i++) {
/*  627 */       this.fileSystem.delete(entry.cleanFiles[i]);
/*  628 */       this.size -= entry.lengths[i];
/*  629 */       entry.lengths[i] = 0L;
/*      */     } 
/*      */     
/*  632 */     this.redundantOpCount++;
/*  633 */     this.journalWriter.writeUtf8("REMOVE").writeByte(32).writeUtf8(entry.key).writeByte(10);
/*  634 */     this.lruEntries.remove(entry.key);
/*      */     
/*  636 */     if (journalRebuildRequired()) {
/*  637 */       this.executor.execute(this.cleanupRunnable);
/*      */     }
/*      */     
/*  640 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean isClosed() {
/*  645 */     return this.closed;
/*      */   }
/*      */   
/*      */   private synchronized void checkNotClosed() {
/*  649 */     if (isClosed()) {
/*  650 */       throw new IllegalStateException("cache is closed");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void flush() throws IOException {
/*  656 */     if (!this.initialized)
/*      */       return; 
/*  658 */     checkNotClosed();
/*  659 */     trimToSize();
/*  660 */     this.journalWriter.flush();
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void close() throws IOException {
/*  665 */     if (!this.initialized || this.closed) {
/*  666 */       this.closed = true;
/*      */       
/*      */       return;
/*      */     } 
/*  670 */     for (Entry entry : (Entry[])this.lruEntries.values().toArray((Object[])new Entry[this.lruEntries.size()])) {
/*  671 */       if (entry.currentEditor != null) {
/*  672 */         entry.currentEditor.abort();
/*      */       }
/*      */     } 
/*  675 */     trimToSize();
/*  676 */     this.journalWriter.close();
/*  677 */     this.journalWriter = null;
/*  678 */     this.closed = true;
/*      */   }
/*      */   
/*      */   void trimToSize() throws IOException {
/*  682 */     while (this.size > this.maxSize) {
/*  683 */       Entry toEvict = this.lruEntries.values().iterator().next();
/*  684 */       removeEntry(toEvict);
/*      */     } 
/*  686 */     this.mostRecentTrimFailed = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void delete() throws IOException {
/*  694 */     close();
/*  695 */     this.fileSystem.deleteContents(this.directory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void evictAll() throws IOException {
/*  703 */     initialize();
/*      */     
/*  705 */     for (Entry entry : (Entry[])this.lruEntries.values().toArray((Object[])new Entry[this.lruEntries.size()])) {
/*  706 */       removeEntry(entry);
/*      */     }
/*  708 */     this.mostRecentTrimFailed = false;
/*      */   }
/*      */   
/*      */   private void validateKey(String key) {
/*  712 */     Matcher matcher = LEGAL_KEY_PATTERN.matcher(key);
/*  713 */     if (!matcher.matches()) {
/*  714 */       throw new IllegalArgumentException("keys must match regex [a-z0-9_-]{1,120}: \"" + key + "\"");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Iterator<Snapshot> snapshots() throws IOException {
/*  735 */     initialize();
/*  736 */     return new Iterator<Snapshot>()
/*      */       {
/*  738 */         final Iterator<DiskLruCache.Entry> delegate = (new ArrayList<>(DiskLruCache.this.lruEntries.values())).iterator();
/*      */ 
/*      */         
/*      */         DiskLruCache.Snapshot nextSnapshot;
/*      */         
/*      */         DiskLruCache.Snapshot removeSnapshot;
/*      */ 
/*      */         
/*      */         public boolean hasNext() {
/*  747 */           if (this.nextSnapshot != null) return true;
/*      */           
/*  749 */           synchronized (DiskLruCache.this) {
/*      */             
/*  751 */             if (DiskLruCache.this.closed) return false;
/*      */             
/*  753 */             while (this.delegate.hasNext()) {
/*  754 */               DiskLruCache.Entry entry = this.delegate.next();
/*  755 */               DiskLruCache.Snapshot snapshot = entry.snapshot();
/*  756 */               if (snapshot == null)
/*  757 */                 continue;  this.nextSnapshot = snapshot;
/*  758 */               return true;
/*      */             } 
/*      */           } 
/*      */           
/*  762 */           return false;
/*      */         }
/*      */         
/*      */         public DiskLruCache.Snapshot next() {
/*  766 */           if (!hasNext()) throw new NoSuchElementException(); 
/*  767 */           this.removeSnapshot = this.nextSnapshot;
/*  768 */           this.nextSnapshot = null;
/*  769 */           return this.removeSnapshot;
/*      */         }
/*      */         
/*      */         public void remove() {
/*  773 */           if (this.removeSnapshot == null) throw new IllegalStateException("remove() before next()"); 
/*      */           try {
/*  775 */             DiskLruCache.this.remove(this.removeSnapshot.key);
/*  776 */           } catch (IOException iOException) {
/*      */ 
/*      */           
/*      */           } finally {
/*  780 */             this.removeSnapshot = null;
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public final class Snapshot
/*      */     implements Closeable {
/*      */     private final String key;
/*      */     private final long sequenceNumber;
/*      */     private final Source[] sources;
/*      */     private final long[] lengths;
/*      */     
/*      */     Snapshot(String key, long sequenceNumber, Source[] sources, long[] lengths) {
/*  794 */       this.key = key;
/*  795 */       this.sequenceNumber = sequenceNumber;
/*  796 */       this.sources = sources;
/*  797 */       this.lengths = lengths;
/*      */     }
/*      */     
/*      */     public String key() {
/*  801 */       return this.key;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DiskLruCache.Editor edit() throws IOException {
/*  809 */       return DiskLruCache.this.edit(this.key, this.sequenceNumber);
/*      */     }
/*      */ 
/*      */     
/*      */     public Source getSource(int index) {
/*  814 */       return this.sources[index];
/*      */     }
/*      */ 
/*      */     
/*      */     public long getLength(int index) {
/*  819 */       return this.lengths[index];
/*      */     }
/*      */     
/*      */     public void close() {
/*  823 */       for (Source in : this.sources) {
/*  824 */         Util.closeQuietly((Closeable)in);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public final class Editor
/*      */   {
/*      */     final DiskLruCache.Entry entry;
/*      */     final boolean[] written;
/*      */     private boolean done;
/*      */     
/*      */     Editor(DiskLruCache.Entry entry) {
/*  836 */       this.entry = entry;
/*  837 */       this.written = entry.readable ? null : new boolean[DiskLruCache.this.valueCount];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void detach() {
/*  847 */       if (this.entry.currentEditor == this) {
/*  848 */         for (int i = 0; i < DiskLruCache.this.valueCount; i++) {
/*      */           try {
/*  850 */             DiskLruCache.this.fileSystem.delete(this.entry.dirtyFiles[i]);
/*  851 */           } catch (IOException iOException) {}
/*      */         } 
/*      */ 
/*      */         
/*  855 */         this.entry.currentEditor = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Source newSource(int index) {
/*  864 */       synchronized (DiskLruCache.this) {
/*  865 */         if (this.done) {
/*  866 */           throw new IllegalStateException();
/*      */         }
/*  868 */         if (!this.entry.readable || this.entry.currentEditor != this) {
/*  869 */           return null;
/*      */         }
/*      */         try {
/*  872 */           return DiskLruCache.this.fileSystem.source(this.entry.cleanFiles[index]);
/*  873 */         } catch (FileNotFoundException e) {
/*  874 */           return null;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Sink newSink(int index) {
/*  885 */       synchronized (DiskLruCache.this) {
/*  886 */         Sink sink; if (this.done) {
/*  887 */           throw new IllegalStateException();
/*      */         }
/*  889 */         if (this.entry.currentEditor != this) {
/*  890 */           return Okio.blackhole();
/*      */         }
/*  892 */         if (!this.entry.readable) {
/*  893 */           this.written[index] = true;
/*      */         }
/*  895 */         File dirtyFile = this.entry.dirtyFiles[index];
/*      */         
/*      */         try {
/*  898 */           sink = DiskLruCache.this.fileSystem.sink(dirtyFile);
/*  899 */         } catch (FileNotFoundException e) {
/*  900 */           return Okio.blackhole();
/*      */         } 
/*  902 */         return (Sink)new FaultHidingSink(sink) {
/*      */             protected void onException(IOException e) {
/*  904 */               synchronized (DiskLruCache.this) {
/*  905 */                 DiskLruCache.Editor.this.detach();
/*      */               } 
/*      */             }
/*      */           };
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void commit() throws IOException {
/*  917 */       synchronized (DiskLruCache.this) {
/*  918 */         if (this.done) {
/*  919 */           throw new IllegalStateException();
/*      */         }
/*  921 */         if (this.entry.currentEditor == this) {
/*  922 */           DiskLruCache.this.completeEdit(this, true);
/*      */         }
/*  924 */         this.done = true;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void abort() throws IOException {
/*  933 */       synchronized (DiskLruCache.this) {
/*  934 */         if (this.done) {
/*  935 */           throw new IllegalStateException();
/*      */         }
/*  937 */         if (this.entry.currentEditor == this) {
/*  938 */           DiskLruCache.this.completeEdit(this, false);
/*      */         }
/*  940 */         this.done = true;
/*      */       } 
/*      */     }
/*      */     
/*      */     public void abortUnlessCommitted() {
/*  945 */       synchronized (DiskLruCache.this) {
/*  946 */         if (!this.done && this.entry.currentEditor == this) {
/*      */           try {
/*  948 */             DiskLruCache.this.completeEdit(this, false);
/*  949 */           } catch (IOException iOException) {}
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final class Entry
/*      */   {
/*      */     final String key;
/*      */     
/*      */     final long[] lengths;
/*      */     
/*      */     final File[] cleanFiles;
/*      */     
/*      */     final File[] dirtyFiles;
/*      */     
/*      */     boolean readable;
/*      */     
/*      */     DiskLruCache.Editor currentEditor;
/*      */     
/*      */     long sequenceNumber;
/*      */ 
/*      */     
/*      */     Entry(String key) {
/*  974 */       this.key = key;
/*      */       
/*  976 */       this.lengths = new long[DiskLruCache.this.valueCount];
/*  977 */       this.cleanFiles = new File[DiskLruCache.this.valueCount];
/*  978 */       this.dirtyFiles = new File[DiskLruCache.this.valueCount];
/*      */ 
/*      */       
/*  981 */       StringBuilder fileBuilder = (new StringBuilder(key)).append('.');
/*  982 */       int truncateTo = fileBuilder.length();
/*  983 */       for (int i = 0; i < DiskLruCache.this.valueCount; i++) {
/*  984 */         fileBuilder.append(i);
/*  985 */         this.cleanFiles[i] = new File(DiskLruCache.this.directory, fileBuilder.toString());
/*  986 */         fileBuilder.append(".tmp");
/*  987 */         this.dirtyFiles[i] = new File(DiskLruCache.this.directory, fileBuilder.toString());
/*  988 */         fileBuilder.setLength(truncateTo);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void setLengths(String[] strings) throws IOException {
/*  994 */       if (strings.length != DiskLruCache.this.valueCount) {
/*  995 */         throw invalidLengths(strings);
/*      */       }
/*      */       
/*      */       try {
/*  999 */         for (int i = 0; i < strings.length; i++) {
/* 1000 */           this.lengths[i] = Long.parseLong(strings[i]);
/*      */         }
/* 1002 */       } catch (NumberFormatException e) {
/* 1003 */         throw invalidLengths(strings);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void writeLengths(BufferedSink writer) throws IOException {
/* 1009 */       for (long length : this.lengths) {
/* 1010 */         writer.writeByte(32).writeDecimalLong(length);
/*      */       }
/*      */     }
/*      */     
/*      */     private IOException invalidLengths(String[] strings) throws IOException {
/* 1015 */       throw new IOException("unexpected journal line: " + Arrays.toString(strings));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DiskLruCache.Snapshot snapshot() {
/* 1024 */       if (!Thread.holdsLock(DiskLruCache.this)) throw new AssertionError();
/*      */       
/* 1026 */       Source[] sources = new Source[DiskLruCache.this.valueCount];
/* 1027 */       long[] lengths = (long[])this.lengths.clone();
/*      */       try {
/* 1029 */         for (int i = 0; i < DiskLruCache.this.valueCount; i++) {
/* 1030 */           sources[i] = DiskLruCache.this.fileSystem.source(this.cleanFiles[i]);
/*      */         }
/* 1032 */         return new DiskLruCache.Snapshot(this.key, this.sequenceNumber, sources, lengths);
/* 1033 */       } catch (FileNotFoundException e) {
/*      */         
/* 1035 */         for (int i = 0; i < DiskLruCache.this.valueCount && 
/* 1036 */           sources[i] != null; i++) {
/* 1037 */           Util.closeQuietly((Closeable)sources[i]);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1045 */           DiskLruCache.this.removeEntry(this);
/* 1046 */         } catch (IOException iOException) {}
/*      */         
/* 1048 */         return null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\cache\DiskLruCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */