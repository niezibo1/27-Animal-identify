package okhttp3.internal.cache;

import java.io.IOException;
import okio.Sink;

public interface CacheRequest {
  Sink body() throws IOException;
  
  void abort();
}


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\cache\CacheRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */