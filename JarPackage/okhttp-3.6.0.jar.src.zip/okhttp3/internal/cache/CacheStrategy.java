/*     */ package okhttp3.internal.cache;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.CacheControl;
/*     */ import okhttp3.Headers;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.Response;
/*     */ import okhttp3.internal.Internal;
/*     */ import okhttp3.internal.http.HttpDate;
/*     */ import okhttp3.internal.http.HttpHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CacheStrategy
/*     */ {
/*     */   public final Request networkRequest;
/*     */   public final Response cacheResponse;
/*     */   
/*     */   CacheStrategy(Request networkRequest, Response cacheResponse) {
/*  57 */     this.networkRequest = networkRequest;
/*  58 */     this.cacheResponse = cacheResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCacheable(Response response, Request request) {
/*  65 */     switch (response.code()) {
/*     */       case 200:
/*     */       case 203:
/*     */       case 204:
/*     */       case 300:
/*     */       case 301:
/*     */       case 308:
/*     */       case 404:
/*     */       case 405:
/*     */       case 410:
/*     */       case 414:
/*     */       case 501:
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 302:
/*     */       case 307:
/*  85 */         if (response.header("Expires") != null || response
/*  86 */           .cacheControl().maxAgeSeconds() != -1 || response
/*  87 */           .cacheControl().isPublic() || response
/*  88 */           .cacheControl().isPrivate()) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/*  95 */         return false;
/*     */     } 
/*     */ 
/*     */     
/*  99 */     return (!response.cacheControl().noStore() && !request.cacheControl().noStore());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Factory
/*     */   {
/*     */     final long nowMillis;
/*     */ 
/*     */     
/*     */     final Request request;
/*     */ 
/*     */     
/*     */     final Response cacheResponse;
/*     */ 
/*     */     
/*     */     private Date servedDate;
/*     */ 
/*     */     
/*     */     private String servedDateString;
/*     */ 
/*     */     
/*     */     private Date lastModified;
/*     */ 
/*     */     
/*     */     private String lastModifiedString;
/*     */ 
/*     */     
/*     */     private Date expires;
/*     */ 
/*     */     
/*     */     private long sentRequestMillis;
/*     */ 
/*     */     
/*     */     private long receivedResponseMillis;
/*     */     
/*     */     private String etag;
/*     */     
/* 137 */     private int ageSeconds = -1;
/*     */     
/*     */     public Factory(long nowMillis, Request request, Response cacheResponse) {
/* 140 */       this.nowMillis = nowMillis;
/* 141 */       this.request = request;
/* 142 */       this.cacheResponse = cacheResponse;
/*     */       
/* 144 */       if (cacheResponse != null) {
/* 145 */         this.sentRequestMillis = cacheResponse.sentRequestAtMillis();
/* 146 */         this.receivedResponseMillis = cacheResponse.receivedResponseAtMillis();
/* 147 */         Headers headers = cacheResponse.headers();
/* 148 */         for (int i = 0, size = headers.size(); i < size; i++) {
/* 149 */           String fieldName = headers.name(i);
/* 150 */           String value = headers.value(i);
/* 151 */           if ("Date".equalsIgnoreCase(fieldName)) {
/* 152 */             this.servedDate = HttpDate.parse(value);
/* 153 */             this.servedDateString = value;
/* 154 */           } else if ("Expires".equalsIgnoreCase(fieldName)) {
/* 155 */             this.expires = HttpDate.parse(value);
/* 156 */           } else if ("Last-Modified".equalsIgnoreCase(fieldName)) {
/* 157 */             this.lastModified = HttpDate.parse(value);
/* 158 */             this.lastModifiedString = value;
/* 159 */           } else if ("ETag".equalsIgnoreCase(fieldName)) {
/* 160 */             this.etag = value;
/* 161 */           } else if ("Age".equalsIgnoreCase(fieldName)) {
/* 162 */             this.ageSeconds = HttpHeaders.parseSeconds(value, -1);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CacheStrategy get() {
/* 172 */       CacheStrategy candidate = getCandidate();
/*     */       
/* 174 */       if (candidate.networkRequest != null && this.request.cacheControl().onlyIfCached())
/*     */       {
/* 176 */         return new CacheStrategy(null, null);
/*     */       }
/*     */       
/* 179 */       return candidate;
/*     */     }
/*     */ 
/*     */     
/*     */     private CacheStrategy getCandidate() {
/*     */       String conditionName, conditionValue;
/* 185 */       if (this.cacheResponse == null) {
/* 186 */         return new CacheStrategy(this.request, null);
/*     */       }
/*     */ 
/*     */       
/* 190 */       if (this.request.isHttps() && this.cacheResponse.handshake() == null) {
/* 191 */         return new CacheStrategy(this.request, null);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       if (!CacheStrategy.isCacheable(this.cacheResponse, this.request)) {
/* 198 */         return new CacheStrategy(this.request, null);
/*     */       }
/*     */       
/* 201 */       CacheControl requestCaching = this.request.cacheControl();
/* 202 */       if (requestCaching.noCache() || hasConditions(this.request)) {
/* 203 */         return new CacheStrategy(this.request, null);
/*     */       }
/*     */       
/* 206 */       long ageMillis = cacheResponseAge();
/* 207 */       long freshMillis = computeFreshnessLifetime();
/*     */       
/* 209 */       if (requestCaching.maxAgeSeconds() != -1) {
/* 210 */         freshMillis = Math.min(freshMillis, TimeUnit.SECONDS.toMillis(requestCaching.maxAgeSeconds()));
/*     */       }
/*     */       
/* 213 */       long minFreshMillis = 0L;
/* 214 */       if (requestCaching.minFreshSeconds() != -1) {
/* 215 */         minFreshMillis = TimeUnit.SECONDS.toMillis(requestCaching.minFreshSeconds());
/*     */       }
/*     */       
/* 218 */       long maxStaleMillis = 0L;
/* 219 */       CacheControl responseCaching = this.cacheResponse.cacheControl();
/* 220 */       if (!responseCaching.mustRevalidate() && requestCaching.maxStaleSeconds() != -1) {
/* 221 */         maxStaleMillis = TimeUnit.SECONDS.toMillis(requestCaching.maxStaleSeconds());
/*     */       }
/*     */       
/* 224 */       if (!responseCaching.noCache() && ageMillis + minFreshMillis < freshMillis + maxStaleMillis) {
/* 225 */         Response.Builder builder = this.cacheResponse.newBuilder();
/* 226 */         if (ageMillis + minFreshMillis >= freshMillis) {
/* 227 */           builder.addHeader("Warning", "110 HttpURLConnection \"Response is stale\"");
/*     */         }
/* 229 */         long oneDayMillis = 86400000L;
/* 230 */         if (ageMillis > oneDayMillis && isFreshnessLifetimeHeuristic()) {
/* 231 */           builder.addHeader("Warning", "113 HttpURLConnection \"Heuristic expiration\"");
/*     */         }
/* 233 */         return new CacheStrategy(null, builder.build());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 240 */       if (this.etag != null) {
/* 241 */         conditionName = "If-None-Match";
/* 242 */         conditionValue = this.etag;
/* 243 */       } else if (this.lastModified != null) {
/* 244 */         conditionName = "If-Modified-Since";
/* 245 */         conditionValue = this.lastModifiedString;
/* 246 */       } else if (this.servedDate != null) {
/* 247 */         conditionName = "If-Modified-Since";
/* 248 */         conditionValue = this.servedDateString;
/*     */       } else {
/* 250 */         return new CacheStrategy(this.request, null);
/*     */       } 
/*     */       
/* 253 */       Headers.Builder conditionalRequestHeaders = this.request.headers().newBuilder();
/* 254 */       Internal.instance.addLenient(conditionalRequestHeaders, conditionName, conditionValue);
/*     */ 
/*     */ 
/*     */       
/* 258 */       Request conditionalRequest = this.request.newBuilder().headers(conditionalRequestHeaders.build()).build();
/* 259 */       return new CacheStrategy(conditionalRequest, this.cacheResponse);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private long computeFreshnessLifetime() {
/* 267 */       CacheControl responseCaching = this.cacheResponse.cacheControl();
/* 268 */       if (responseCaching.maxAgeSeconds() != -1)
/* 269 */         return TimeUnit.SECONDS.toMillis(responseCaching.maxAgeSeconds()); 
/* 270 */       if (this.expires != null) {
/*     */         
/* 272 */         long servedMillis = (this.servedDate != null) ? this.servedDate.getTime() : this.receivedResponseMillis;
/*     */         
/* 274 */         long delta = this.expires.getTime() - servedMillis;
/* 275 */         return (delta > 0L) ? delta : 0L;
/* 276 */       }  if (this.lastModified != null && this.cacheResponse
/* 277 */         .request().url().query() == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 283 */         long servedMillis = (this.servedDate != null) ? this.servedDate.getTime() : this.sentRequestMillis;
/*     */         
/* 285 */         long delta = servedMillis - this.lastModified.getTime();
/* 286 */         return (delta > 0L) ? (delta / 10L) : 0L;
/*     */       } 
/* 288 */       return 0L;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private long cacheResponseAge() {
/* 297 */       long apparentReceivedAge = (this.servedDate != null) ? Math.max(0L, this.receivedResponseMillis - this.servedDate.getTime()) : 0L;
/*     */ 
/*     */       
/* 300 */       long receivedAge = (this.ageSeconds != -1) ? Math.max(apparentReceivedAge, TimeUnit.SECONDS.toMillis(this.ageSeconds)) : apparentReceivedAge;
/*     */       
/* 302 */       long responseDuration = this.receivedResponseMillis - this.sentRequestMillis;
/* 303 */       long residentDuration = this.nowMillis - this.receivedResponseMillis;
/* 304 */       return receivedAge + responseDuration + residentDuration;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isFreshnessLifetimeHeuristic() {
/* 312 */       return (this.cacheResponse.cacheControl().maxAgeSeconds() == -1 && this.expires == null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean hasConditions(Request request) {
/* 321 */       return (request.header("If-Modified-Since") != null || request.header("If-None-Match") != null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\cache\CacheStrategy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */