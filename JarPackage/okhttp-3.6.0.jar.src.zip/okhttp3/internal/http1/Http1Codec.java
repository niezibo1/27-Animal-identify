/*     */ package okhttp3.internal.http1;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.Headers;
/*     */ import okhttp3.HttpUrl;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.Response;
/*     */ import okhttp3.ResponseBody;
/*     */ import okhttp3.internal.Internal;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.connection.RealConnection;
/*     */ import okhttp3.internal.connection.StreamAllocation;
/*     */ import okhttp3.internal.http.HttpCodec;
/*     */ import okhttp3.internal.http.HttpHeaders;
/*     */ import okhttp3.internal.http.RealResponseBody;
/*     */ import okhttp3.internal.http.RequestLine;
/*     */ import okhttp3.internal.http.StatusLine;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSink;
/*     */ import okio.BufferedSource;
/*     */ import okio.ForwardingTimeout;
/*     */ import okio.Okio;
/*     */ import okio.Sink;
/*     */ import okio.Source;
/*     */ import okio.Timeout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http1Codec
/*     */   implements HttpCodec
/*     */ {
/*     */   private static final int STATE_IDLE = 0;
/*     */   private static final int STATE_OPEN_REQUEST_BODY = 1;
/*     */   private static final int STATE_WRITING_REQUEST_BODY = 2;
/*     */   private static final int STATE_READ_RESPONSE_HEADERS = 3;
/*     */   private static final int STATE_OPEN_RESPONSE_BODY = 4;
/*     */   private static final int STATE_READING_RESPONSE_BODY = 5;
/*     */   private static final int STATE_CLOSED = 6;
/*     */   final OkHttpClient client;
/*     */   final StreamAllocation streamAllocation;
/*     */   final BufferedSource source;
/*     */   final BufferedSink sink;
/*  85 */   int state = 0;
/*     */ 
/*     */   
/*     */   public Http1Codec(OkHttpClient client, StreamAllocation streamAllocation, BufferedSource source, BufferedSink sink) {
/*  89 */     this.client = client;
/*  90 */     this.streamAllocation = streamAllocation;
/*  91 */     this.source = source;
/*  92 */     this.sink = sink;
/*     */   }
/*     */   
/*     */   public Sink createRequestBody(Request request, long contentLength) {
/*  96 */     if ("chunked".equalsIgnoreCase(request.header("Transfer-Encoding")))
/*     */     {
/*  98 */       return newChunkedSink();
/*     */     }
/*     */     
/* 101 */     if (contentLength != -1L)
/*     */     {
/* 103 */       return newFixedLengthSink(contentLength);
/*     */     }
/*     */     
/* 106 */     throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 111 */     RealConnection connection = this.streamAllocation.connection();
/* 112 */     if (connection != null) connection.cancel();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeRequestHeaders(Request request) throws IOException {
/* 126 */     String requestLine = RequestLine.get(request, this.streamAllocation
/* 127 */         .connection().route().proxy().type());
/* 128 */     writeRequest(request.headers(), requestLine);
/*     */   }
/*     */   
/*     */   public ResponseBody openResponseBody(Response response) throws IOException {
/* 132 */     Source source = getTransferStream(response);
/* 133 */     return (ResponseBody)new RealResponseBody(response.headers(), Okio.buffer(source));
/*     */   }
/*     */   
/*     */   private Source getTransferStream(Response response) throws IOException {
/* 137 */     if (!HttpHeaders.hasBody(response)) {
/* 138 */       return newFixedLengthSource(0L);
/*     */     }
/*     */     
/* 141 */     if ("chunked".equalsIgnoreCase(response.header("Transfer-Encoding"))) {
/* 142 */       return newChunkedSource(response.request().url());
/*     */     }
/*     */     
/* 145 */     long contentLength = HttpHeaders.contentLength(response);
/* 146 */     if (contentLength != -1L) {
/* 147 */       return newFixedLengthSource(contentLength);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     return newUnknownLengthSource();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 158 */     return (this.state == 6);
/*     */   }
/*     */   
/*     */   public void flushRequest() throws IOException {
/* 162 */     this.sink.flush();
/*     */   }
/*     */   
/*     */   public void finishRequest() throws IOException {
/* 166 */     this.sink.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeRequest(Headers headers, String requestLine) throws IOException {
/* 171 */     if (this.state != 0) throw new IllegalStateException("state: " + this.state); 
/* 172 */     this.sink.writeUtf8(requestLine).writeUtf8("\r\n");
/* 173 */     for (int i = 0, size = headers.size(); i < size; i++) {
/* 174 */       this.sink.writeUtf8(headers.name(i))
/* 175 */         .writeUtf8(": ")
/* 176 */         .writeUtf8(headers.value(i))
/* 177 */         .writeUtf8("\r\n");
/*     */     }
/* 179 */     this.sink.writeUtf8("\r\n");
/* 180 */     this.state = 1;
/*     */   }
/*     */   
/*     */   public Response.Builder readResponseHeaders(boolean expectContinue) throws IOException {
/* 184 */     if (this.state != 1 && this.state != 3) {
/* 185 */       throw new IllegalStateException("state: " + this.state);
/*     */     }
/*     */     
/*     */     try {
/* 189 */       StatusLine statusLine = StatusLine.parse(this.source.readUtf8LineStrict());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       Response.Builder responseBuilder = (new Response.Builder()).protocol(statusLine.protocol).code(statusLine.code).message(statusLine.message).headers(readHeaders());
/*     */       
/* 197 */       if (expectContinue && statusLine.code == 100) {
/* 198 */         return null;
/*     */       }
/*     */       
/* 201 */       this.state = 4;
/* 202 */       return responseBuilder;
/* 203 */     } catch (EOFException e) {
/*     */       
/* 205 */       IOException exception = new IOException("unexpected end of stream on " + this.streamAllocation);
/* 206 */       exception.initCause(e);
/* 207 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Headers readHeaders() throws IOException {
/* 213 */     Headers.Builder headers = new Headers.Builder();
/*     */     String line;
/* 215 */     while ((line = this.source.readUtf8LineStrict()).length() != 0) {
/* 216 */       Internal.instance.addLenient(headers, line);
/*     */     }
/* 218 */     return headers.build();
/*     */   }
/*     */   
/*     */   public Sink newChunkedSink() {
/* 222 */     if (this.state != 1) throw new IllegalStateException("state: " + this.state); 
/* 223 */     this.state = 2;
/* 224 */     return new ChunkedSink();
/*     */   }
/*     */   
/*     */   public Sink newFixedLengthSink(long contentLength) {
/* 228 */     if (this.state != 1) throw new IllegalStateException("state: " + this.state); 
/* 229 */     this.state = 2;
/* 230 */     return new FixedLengthSink(contentLength);
/*     */   }
/*     */   
/*     */   public Source newFixedLengthSource(long length) throws IOException {
/* 234 */     if (this.state != 4) throw new IllegalStateException("state: " + this.state); 
/* 235 */     this.state = 5;
/* 236 */     return new FixedLengthSource(length);
/*     */   }
/*     */   
/*     */   public Source newChunkedSource(HttpUrl url) throws IOException {
/* 240 */     if (this.state != 4) throw new IllegalStateException("state: " + this.state); 
/* 241 */     this.state = 5;
/* 242 */     return new ChunkedSource(url);
/*     */   }
/*     */   
/*     */   public Source newUnknownLengthSource() throws IOException {
/* 246 */     if (this.state != 4) throw new IllegalStateException("state: " + this.state); 
/* 247 */     if (this.streamAllocation == null) throw new IllegalStateException("streamAllocation == null"); 
/* 248 */     this.state = 5;
/* 249 */     this.streamAllocation.noNewStreams();
/* 250 */     return new UnknownLengthSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void detachTimeout(ForwardingTimeout timeout) {
/* 259 */     Timeout oldDelegate = timeout.delegate();
/* 260 */     timeout.setDelegate(Timeout.NONE);
/* 261 */     oldDelegate.clearDeadline();
/* 262 */     oldDelegate.clearTimeout();
/*     */   }
/*     */   
/*     */   private final class FixedLengthSink
/*     */     implements Sink {
/* 267 */     private final ForwardingTimeout timeout = new ForwardingTimeout(Http1Codec.this.sink.timeout());
/*     */     private boolean closed;
/*     */     private long bytesRemaining;
/*     */     
/*     */     FixedLengthSink(long bytesRemaining) {
/* 272 */       this.bytesRemaining = bytesRemaining;
/*     */     }
/*     */     
/*     */     public Timeout timeout() {
/* 276 */       return (Timeout)this.timeout;
/*     */     }
/*     */     
/*     */     public void write(Buffer source, long byteCount) throws IOException {
/* 280 */       if (this.closed) throw new IllegalStateException("closed"); 
/* 281 */       Util.checkOffsetAndCount(source.size(), 0L, byteCount);
/* 282 */       if (byteCount > this.bytesRemaining) {
/* 283 */         throw new ProtocolException("expected " + this.bytesRemaining + " bytes but received " + byteCount);
/*     */       }
/*     */       
/* 286 */       Http1Codec.this.sink.write(source, byteCount);
/* 287 */       this.bytesRemaining -= byteCount;
/*     */     }
/*     */     
/*     */     public void flush() throws IOException {
/* 291 */       if (this.closed)
/* 292 */         return;  Http1Codec.this.sink.flush();
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 296 */       if (this.closed)
/* 297 */         return;  this.closed = true;
/* 298 */       if (this.bytesRemaining > 0L) throw new ProtocolException("unexpected end of stream"); 
/* 299 */       Http1Codec.this.detachTimeout(this.timeout);
/* 300 */       Http1Codec.this.state = 3;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ChunkedSink
/*     */     implements Sink
/*     */   {
/* 309 */     private final ForwardingTimeout timeout = new ForwardingTimeout(Http1Codec.this.sink.timeout());
/*     */ 
/*     */     
/*     */     private boolean closed;
/*     */ 
/*     */     
/*     */     public Timeout timeout() {
/* 316 */       return (Timeout)this.timeout;
/*     */     }
/*     */     
/*     */     public void write(Buffer source, long byteCount) throws IOException {
/* 320 */       if (this.closed) throw new IllegalStateException("closed"); 
/* 321 */       if (byteCount == 0L)
/*     */         return; 
/* 323 */       Http1Codec.this.sink.writeHexadecimalUnsignedLong(byteCount);
/* 324 */       Http1Codec.this.sink.writeUtf8("\r\n");
/* 325 */       Http1Codec.this.sink.write(source, byteCount);
/* 326 */       Http1Codec.this.sink.writeUtf8("\r\n");
/*     */     }
/*     */     
/*     */     public synchronized void flush() throws IOException {
/* 330 */       if (this.closed)
/* 331 */         return;  Http1Codec.this.sink.flush();
/*     */     }
/*     */     
/*     */     public synchronized void close() throws IOException {
/* 335 */       if (this.closed)
/* 336 */         return;  this.closed = true;
/* 337 */       Http1Codec.this.sink.writeUtf8("0\r\n\r\n");
/* 338 */       Http1Codec.this.detachTimeout(this.timeout);
/* 339 */       Http1Codec.this.state = 3;
/*     */     }
/*     */   }
/*     */   
/*     */   private abstract class AbstractSource implements Source {
/* 344 */     protected final ForwardingTimeout timeout = new ForwardingTimeout(Http1Codec.this.source.timeout());
/*     */     protected boolean closed;
/*     */     
/*     */     public Timeout timeout() {
/* 348 */       return (Timeout)this.timeout;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final void endOfInput(boolean reuseConnection) throws IOException {
/* 356 */       if (Http1Codec.this.state == 6)
/* 357 */         return;  if (Http1Codec.this.state != 5) throw new IllegalStateException("state: " + Http1Codec.this.state);
/*     */       
/* 359 */       Http1Codec.this.detachTimeout(this.timeout);
/*     */       
/* 361 */       Http1Codec.this.state = 6;
/* 362 */       if (Http1Codec.this.streamAllocation != null)
/* 363 */         Http1Codec.this.streamAllocation.streamFinished(!reuseConnection, Http1Codec.this); 
/*     */     }
/*     */     
/*     */     private AbstractSource() {}
/*     */   }
/*     */   
/*     */   private class FixedLengthSource extends AbstractSource {
/*     */     private long bytesRemaining;
/*     */     
/*     */     public FixedLengthSource(long length) throws IOException {
/* 373 */       this.bytesRemaining = length;
/* 374 */       if (this.bytesRemaining == 0L) {
/* 375 */         endOfInput(true);
/*     */       }
/*     */     }
/*     */     
/*     */     public long read(Buffer sink, long byteCount) throws IOException {
/* 380 */       if (byteCount < 0L) throw new IllegalArgumentException("byteCount < 0: " + byteCount); 
/* 381 */       if (this.closed) throw new IllegalStateException("closed"); 
/* 382 */       if (this.bytesRemaining == 0L) return -1L;
/*     */       
/* 384 */       long read = Http1Codec.this.source.read(sink, Math.min(this.bytesRemaining, byteCount));
/* 385 */       if (read == -1L) {
/* 386 */         endOfInput(false);
/* 387 */         throw new ProtocolException("unexpected end of stream");
/*     */       } 
/*     */       
/* 390 */       this.bytesRemaining -= read;
/* 391 */       if (this.bytesRemaining == 0L) {
/* 392 */         endOfInput(true);
/*     */       }
/* 394 */       return read;
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 398 */       if (this.closed)
/*     */         return; 
/* 400 */       if (this.bytesRemaining != 0L && !Util.discard(this, 100, TimeUnit.MILLISECONDS)) {
/* 401 */         endOfInput(false);
/*     */       }
/*     */       
/* 404 */       this.closed = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ChunkedSource
/*     */     extends AbstractSource {
/*     */     private static final long NO_CHUNK_YET = -1L;
/*     */     private final HttpUrl url;
/* 412 */     private long bytesRemainingInChunk = -1L;
/*     */     private boolean hasMoreChunks = true;
/*     */     
/*     */     ChunkedSource(HttpUrl url) {
/* 416 */       this.url = url;
/*     */     }
/*     */     
/*     */     public long read(Buffer sink, long byteCount) throws IOException {
/* 420 */       if (byteCount < 0L) throw new IllegalArgumentException("byteCount < 0: " + byteCount); 
/* 421 */       if (this.closed) throw new IllegalStateException("closed"); 
/* 422 */       if (!this.hasMoreChunks) return -1L;
/*     */       
/* 424 */       if (this.bytesRemainingInChunk == 0L || this.bytesRemainingInChunk == -1L) {
/* 425 */         readChunkSize();
/* 426 */         if (!this.hasMoreChunks) return -1L;
/*     */       
/*     */       } 
/* 429 */       long read = Http1Codec.this.source.read(sink, Math.min(byteCount, this.bytesRemainingInChunk));
/* 430 */       if (read == -1L) {
/* 431 */         endOfInput(false);
/* 432 */         throw new ProtocolException("unexpected end of stream");
/*     */       } 
/* 434 */       this.bytesRemainingInChunk -= read;
/* 435 */       return read;
/*     */     }
/*     */ 
/*     */     
/*     */     private void readChunkSize() throws IOException {
/* 440 */       if (this.bytesRemainingInChunk != -1L) {
/* 441 */         Http1Codec.this.source.readUtf8LineStrict();
/*     */       }
/*     */       try {
/* 444 */         this.bytesRemainingInChunk = Http1Codec.this.source.readHexadecimalUnsignedLong();
/* 445 */         String extensions = Http1Codec.this.source.readUtf8LineStrict().trim();
/* 446 */         if (this.bytesRemainingInChunk < 0L || (!extensions.isEmpty() && !extensions.startsWith(";"))) {
/* 447 */           throw new ProtocolException("expected chunk size and optional extensions but was \"" + this.bytesRemainingInChunk + extensions + "\"");
/*     */         }
/*     */       }
/* 450 */       catch (NumberFormatException e) {
/* 451 */         throw new ProtocolException(e.getMessage());
/*     */       } 
/* 453 */       if (this.bytesRemainingInChunk == 0L) {
/* 454 */         this.hasMoreChunks = false;
/* 455 */         HttpHeaders.receiveHeaders(Http1Codec.this.client.cookieJar(), this.url, Http1Codec.this.readHeaders());
/* 456 */         endOfInput(true);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 461 */       if (this.closed)
/* 462 */         return;  if (this.hasMoreChunks && !Util.discard(this, 100, TimeUnit.MILLISECONDS)) {
/* 463 */         endOfInput(false);
/*     */       }
/* 465 */       this.closed = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class UnknownLengthSource
/*     */     extends AbstractSource
/*     */   {
/*     */     private boolean inputExhausted;
/*     */ 
/*     */     
/*     */     public long read(Buffer sink, long byteCount) throws IOException {
/* 478 */       if (byteCount < 0L) throw new IllegalArgumentException("byteCount < 0: " + byteCount); 
/* 479 */       if (this.closed) throw new IllegalStateException("closed"); 
/* 480 */       if (this.inputExhausted) return -1L;
/*     */       
/* 482 */       long read = Http1Codec.this.source.read(sink, byteCount);
/* 483 */       if (read == -1L) {
/* 484 */         this.inputExhausted = true;
/* 485 */         endOfInput(true);
/* 486 */         return -1L;
/*     */       } 
/* 488 */       return read;
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 492 */       if (this.closed)
/* 493 */         return;  if (!this.inputExhausted) {
/* 494 */         endOfInput(false);
/*     */       }
/* 496 */       this.closed = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\http1\Http1Codec.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */