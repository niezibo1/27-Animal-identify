/*    */ package okhttp3.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Version
/*    */ {
/*    */   public static String userAgent() {
/* 20 */     return "okhttp/3.6.0";
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\Version.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */