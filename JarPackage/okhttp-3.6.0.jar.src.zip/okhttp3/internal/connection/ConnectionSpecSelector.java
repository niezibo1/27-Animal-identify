/*     */ package okhttp3.internal.connection;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.UnknownServiceException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import okhttp3.ConnectionSpec;
/*     */ import okhttp3.internal.Internal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectionSpecSelector
/*     */ {
/*     */   private final List<ConnectionSpec> connectionSpecs;
/*     */   private int nextModeIndex;
/*     */   private boolean isFallbackPossible;
/*     */   private boolean isFallback;
/*     */   
/*     */   public ConnectionSpecSelector(List<ConnectionSpec> connectionSpecs) {
/*  45 */     this.nextModeIndex = 0;
/*  46 */     this.connectionSpecs = connectionSpecs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionSpec configureSecureSocket(SSLSocket sslSocket) throws IOException {
/*  56 */     ConnectionSpec tlsConfiguration = null;
/*  57 */     for (int i = this.nextModeIndex, size = this.connectionSpecs.size(); i < size; i++) {
/*  58 */       ConnectionSpec connectionSpec = this.connectionSpecs.get(i);
/*  59 */       if (connectionSpec.isCompatible(sslSocket)) {
/*  60 */         tlsConfiguration = connectionSpec;
/*  61 */         this.nextModeIndex = i + 1;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  66 */     if (tlsConfiguration == null)
/*     */     {
/*     */ 
/*     */       
/*  70 */       throw new UnknownServiceException("Unable to find acceptable protocols. isFallback=" + this.isFallback + ", modes=" + this.connectionSpecs + ", supported protocols=" + 
/*     */ 
/*     */           
/*  73 */           Arrays.toString(sslSocket.getEnabledProtocols()));
/*     */     }
/*     */     
/*  76 */     this.isFallbackPossible = isFallbackPossible(sslSocket);
/*     */     
/*  78 */     Internal.instance.apply(tlsConfiguration, sslSocket, this.isFallback);
/*     */     
/*  80 */     return tlsConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean connectionFailed(IOException e) {
/*  92 */     this.isFallback = true;
/*     */     
/*  94 */     if (!this.isFallbackPossible) {
/*  95 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  99 */     if (e instanceof java.net.ProtocolException) {
/* 100 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     if (e instanceof java.io.InterruptedIOException) {
/* 107 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (e instanceof javax.net.ssl.SSLHandshakeException)
/*     */     {
/*     */       
/* 115 */       if (e.getCause() instanceof java.security.cert.CertificateException) {
/* 116 */         return false;
/*     */       }
/*     */     }
/* 119 */     if (e instanceof javax.net.ssl.SSLPeerUnverifiedException)
/*     */     {
/* 121 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 126 */     return (e instanceof javax.net.ssl.SSLHandshakeException || e instanceof javax.net.ssl.SSLProtocolException);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFallbackPossible(SSLSocket socket) {
/* 135 */     for (int i = this.nextModeIndex; i < this.connectionSpecs.size(); i++) {
/* 136 */       if (((ConnectionSpec)this.connectionSpecs.get(i)).isCompatible(socket)) {
/* 137 */         return true;
/*     */       }
/*     */     } 
/* 140 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\connection\ConnectionSpecSelector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */