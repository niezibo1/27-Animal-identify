/*     */ package okhttp3.internal.connection;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.SocketException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import okhttp3.Address;
/*     */ import okhttp3.HttpUrl;
/*     */ import okhttp3.Route;
/*     */ import okhttp3.internal.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RouteSelector
/*     */ {
/*     */   private final Address address;
/*     */   private final RouteDatabase routeDatabase;
/*     */   private Proxy lastProxy;
/*     */   private InetSocketAddress lastInetSocketAddress;
/*  46 */   private List<Proxy> proxies = Collections.emptyList();
/*     */   
/*     */   private int nextProxyIndex;
/*     */   
/*  50 */   private List<InetSocketAddress> inetSocketAddresses = Collections.emptyList();
/*     */   
/*     */   private int nextInetSocketAddressIndex;
/*     */   
/*  54 */   private final List<Route> postponedRoutes = new ArrayList<>();
/*     */   
/*     */   public RouteSelector(Address address, RouteDatabase routeDatabase) {
/*  57 */     this.address = address;
/*  58 */     this.routeDatabase = routeDatabase;
/*     */     
/*  60 */     resetNextProxy(address.url(), address.proxy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  67 */     return (hasNextInetSocketAddress() || 
/*  68 */       hasNextProxy() || 
/*  69 */       hasNextPostponed());
/*     */   }
/*     */ 
/*     */   
/*     */   public Route next() throws IOException {
/*  74 */     if (!hasNextInetSocketAddress()) {
/*  75 */       if (!hasNextProxy()) {
/*  76 */         if (!hasNextPostponed()) {
/*  77 */           throw new NoSuchElementException();
/*     */         }
/*  79 */         return nextPostponed();
/*     */       } 
/*  81 */       this.lastProxy = nextProxy();
/*     */     } 
/*  83 */     this.lastInetSocketAddress = nextInetSocketAddress();
/*     */     
/*  85 */     Route route = new Route(this.address, this.lastProxy, this.lastInetSocketAddress);
/*  86 */     if (this.routeDatabase.shouldPostpone(route)) {
/*  87 */       this.postponedRoutes.add(route);
/*     */       
/*  89 */       return next();
/*     */     } 
/*     */     
/*  92 */     return route;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectFailed(Route failedRoute, IOException failure) {
/* 100 */     if (failedRoute.proxy().type() != Proxy.Type.DIRECT && this.address.proxySelector() != null)
/*     */     {
/* 102 */       this.address.proxySelector().connectFailed(this.address
/* 103 */           .url().uri(), failedRoute.proxy().address(), failure);
/*     */     }
/*     */     
/* 106 */     this.routeDatabase.failed(failedRoute);
/*     */   }
/*     */ 
/*     */   
/*     */   private void resetNextProxy(HttpUrl url, Proxy proxy) {
/* 111 */     if (proxy != null) {
/*     */       
/* 113 */       this.proxies = Collections.singletonList(proxy);
/*     */     } else {
/*     */       
/* 116 */       List<Proxy> proxiesOrNull = this.address.proxySelector().select(url.uri());
/* 117 */       this
/*     */         
/* 119 */         .proxies = (proxiesOrNull != null && !proxiesOrNull.isEmpty()) ? Util.immutableList(proxiesOrNull) : Util.immutableList((Object[])new Proxy[] { Proxy.NO_PROXY });
/*     */     } 
/* 121 */     this.nextProxyIndex = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasNextProxy() {
/* 126 */     return (this.nextProxyIndex < this.proxies.size());
/*     */   }
/*     */ 
/*     */   
/*     */   private Proxy nextProxy() throws IOException {
/* 131 */     if (!hasNextProxy()) {
/* 132 */       throw new SocketException("No route to " + this.address.url().host() + "; exhausted proxy configurations: " + this.proxies);
/*     */     }
/*     */     
/* 135 */     Proxy result = this.proxies.get(this.nextProxyIndex++);
/* 136 */     resetNextInetSocketAddress(result);
/* 137 */     return result;
/*     */   }
/*     */   
/*     */   private void resetNextInetSocketAddress(Proxy proxy) throws IOException {
/*     */     String socketHost;
/*     */     int socketPort;
/* 143 */     this.inetSocketAddresses = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/* 147 */     if (proxy.type() == Proxy.Type.DIRECT || proxy.type() == Proxy.Type.SOCKS) {
/* 148 */       socketHost = this.address.url().host();
/* 149 */       socketPort = this.address.url().port();
/*     */     } else {
/* 151 */       SocketAddress proxyAddress = proxy.address();
/* 152 */       if (!(proxyAddress instanceof InetSocketAddress)) {
/* 153 */         throw new IllegalArgumentException("Proxy.address() is not an InetSocketAddress: " + proxyAddress
/* 154 */             .getClass());
/*     */       }
/* 156 */       InetSocketAddress proxySocketAddress = (InetSocketAddress)proxyAddress;
/* 157 */       socketHost = getHostString(proxySocketAddress);
/* 158 */       socketPort = proxySocketAddress.getPort();
/*     */     } 
/*     */     
/* 161 */     if (socketPort < 1 || socketPort > 65535) {
/* 162 */       throw new SocketException("No route to " + socketHost + ":" + socketPort + "; port is out of range");
/*     */     }
/*     */ 
/*     */     
/* 166 */     if (proxy.type() == Proxy.Type.SOCKS) {
/* 167 */       this.inetSocketAddresses.add(InetSocketAddress.createUnresolved(socketHost, socketPort));
/*     */     } else {
/*     */       
/* 170 */       List<InetAddress> addresses = this.address.dns().lookup(socketHost);
/* 171 */       for (int i = 0, size = addresses.size(); i < size; i++) {
/* 172 */         InetAddress inetAddress = addresses.get(i);
/* 173 */         this.inetSocketAddresses.add(new InetSocketAddress(inetAddress, socketPort));
/*     */       } 
/*     */     } 
/*     */     
/* 177 */     this.nextInetSocketAddressIndex = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getHostString(InetSocketAddress socketAddress) {
/* 186 */     InetAddress address = socketAddress.getAddress();
/* 187 */     if (address == null)
/*     */     {
/*     */ 
/*     */       
/* 191 */       return socketAddress.getHostName();
/*     */     }
/*     */ 
/*     */     
/* 195 */     return address.getHostAddress();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasNextInetSocketAddress() {
/* 200 */     return (this.nextInetSocketAddressIndex < this.inetSocketAddresses.size());
/*     */   }
/*     */ 
/*     */   
/*     */   private InetSocketAddress nextInetSocketAddress() throws IOException {
/* 205 */     if (!hasNextInetSocketAddress()) {
/* 206 */       throw new SocketException("No route to " + this.address.url().host() + "; exhausted inet socket addresses: " + this.inetSocketAddresses);
/*     */     }
/*     */     
/* 209 */     return this.inetSocketAddresses.get(this.nextInetSocketAddressIndex++);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasNextPostponed() {
/* 214 */     return !this.postponedRoutes.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   private Route nextPostponed() {
/* 219 */     return this.postponedRoutes.remove(0);
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\connection\RouteSelector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */