/*     */ package okhttp3.internal.connection;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.Reference;
/*     */ import java.net.ConnectException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.Proxy;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.net.UnknownServiceException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import okhttp3.Address;
/*     */ import okhttp3.CertificatePinner;
/*     */ import okhttp3.Connection;
/*     */ import okhttp3.ConnectionPool;
/*     */ import okhttp3.ConnectionSpec;
/*     */ import okhttp3.Handshake;
/*     */ import okhttp3.HttpUrl;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.Protocol;
/*     */ import okhttp3.Request;
/*     */ import okhttp3.Response;
/*     */ import okhttp3.Route;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.Version;
/*     */ import okhttp3.internal.http.HttpCodec;
/*     */ import okhttp3.internal.http.HttpHeaders;
/*     */ import okhttp3.internal.http1.Http1Codec;
/*     */ import okhttp3.internal.http2.ErrorCode;
/*     */ import okhttp3.internal.http2.Http2Codec;
/*     */ import okhttp3.internal.http2.Http2Connection;
/*     */ import okhttp3.internal.http2.Http2Stream;
/*     */ import okhttp3.internal.platform.Platform;
/*     */ import okhttp3.internal.tls.OkHostnameVerifier;
/*     */ import okhttp3.internal.ws.RealWebSocket;
/*     */ import okio.BufferedSink;
/*     */ import okio.BufferedSource;
/*     */ import okio.Okio;
/*     */ import okio.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RealConnection
/*     */   extends Http2Connection.Listener
/*     */   implements Connection
/*     */ {
/*     */   private final ConnectionPool connectionPool;
/*     */   private final Route route;
/*     */   private Socket rawSocket;
/*     */   private Socket socket;
/*     */   private Handshake handshake;
/*     */   private Protocol protocol;
/*     */   private Http2Connection http2Connection;
/*     */   private BufferedSource source;
/*     */   private BufferedSink sink;
/*     */   public boolean noNewStreams;
/*     */   public int successCount;
/* 100 */   public int allocationLimit = 1;
/*     */ 
/*     */   
/* 103 */   public final List<Reference<StreamAllocation>> allocations = new ArrayList<>();
/*     */ 
/*     */   
/* 106 */   public long idleAtNanos = Long.MAX_VALUE;
/*     */   
/*     */   public RealConnection(ConnectionPool connectionPool, Route route) {
/* 109 */     this.connectionPool = connectionPool;
/* 110 */     this.route = route;
/*     */   }
/*     */ 
/*     */   
/*     */   public static RealConnection testConnection(ConnectionPool connectionPool, Route route, Socket socket, long idleAtNanos) {
/* 115 */     RealConnection result = new RealConnection(connectionPool, route);
/* 116 */     result.socket = socket;
/* 117 */     result.idleAtNanos = idleAtNanos;
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect(int connectTimeout, int readTimeout, int writeTimeout, boolean connectionRetryEnabled) {
/* 123 */     if (this.protocol != null) throw new IllegalStateException("already connected");
/*     */     
/* 125 */     RouteException routeException = null;
/* 126 */     List<ConnectionSpec> connectionSpecs = this.route.address().connectionSpecs();
/* 127 */     ConnectionSpecSelector connectionSpecSelector = new ConnectionSpecSelector(connectionSpecs);
/*     */     
/* 129 */     if (this.route.address().sslSocketFactory() == null) {
/* 130 */       if (!connectionSpecs.contains(ConnectionSpec.CLEARTEXT)) {
/* 131 */         throw new RouteException(new UnknownServiceException("CLEARTEXT communication not enabled for client"));
/*     */       }
/*     */       
/* 134 */       String host = this.route.address().url().host();
/* 135 */       if (!Platform.get().isCleartextTrafficPermitted(host)) {
/* 136 */         throw new RouteException(new UnknownServiceException("CLEARTEXT communication to " + host + " not permitted by network security policy"));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     while (true) {
/*     */       try {
/* 143 */         if (this.route.requiresTunnel()) {
/* 144 */           connectTunnel(connectTimeout, readTimeout, writeTimeout);
/*     */         } else {
/* 146 */           connectSocket(connectTimeout, readTimeout);
/*     */         } 
/* 148 */         establishProtocol(connectionSpecSelector);
/*     */         break;
/* 150 */       } catch (IOException e) {
/* 151 */         Util.closeQuietly(this.socket);
/* 152 */         Util.closeQuietly(this.rawSocket);
/* 153 */         this.socket = null;
/* 154 */         this.rawSocket = null;
/* 155 */         this.source = null;
/* 156 */         this.sink = null;
/* 157 */         this.handshake = null;
/* 158 */         this.protocol = null;
/* 159 */         this.http2Connection = null;
/*     */         
/* 161 */         if (routeException == null) {
/* 162 */           routeException = new RouteException(e);
/*     */         } else {
/* 164 */           routeException.addConnectException(e);
/*     */         } 
/*     */         
/* 167 */         if (!connectionRetryEnabled || !connectionSpecSelector.connectionFailed(e)) {
/* 168 */           throw routeException;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 173 */     if (this.http2Connection != null) {
/* 174 */       synchronized (this.connectionPool) {
/* 175 */         this.allocationLimit = this.http2Connection.maxConcurrentStreams();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void connectTunnel(int connectTimeout, int readTimeout, int writeTimeout) throws IOException {
/* 186 */     Request tunnelRequest = createTunnelRequest();
/* 187 */     HttpUrl url = tunnelRequest.url();
/* 188 */     int attemptedConnections = 0;
/* 189 */     int maxAttempts = 21;
/*     */     while (true) {
/* 191 */       if (++attemptedConnections > maxAttempts) {
/* 192 */         throw new ProtocolException("Too many tunnel connections attempted: " + maxAttempts);
/*     */       }
/*     */       
/* 195 */       connectSocket(connectTimeout, readTimeout);
/* 196 */       tunnelRequest = createTunnel(readTimeout, writeTimeout, tunnelRequest, url);
/*     */       
/* 198 */       if (tunnelRequest == null) {
/*     */         break;
/*     */       }
/*     */       
/* 202 */       Util.closeQuietly(this.rawSocket);
/* 203 */       this.rawSocket = null;
/* 204 */       this.sink = null;
/* 205 */       this.source = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void connectSocket(int connectTimeout, int readTimeout) throws IOException {
/* 211 */     Proxy proxy = this.route.proxy();
/* 212 */     Address address = this.route.address();
/*     */     
/* 214 */     this
/* 215 */       .rawSocket = (proxy.type() == Proxy.Type.DIRECT || proxy.type() == Proxy.Type.HTTP) ? address.socketFactory().createSocket() : new Socket(proxy);
/*     */ 
/*     */     
/* 218 */     this.rawSocket.setSoTimeout(readTimeout);
/*     */     try {
/* 220 */       Platform.get().connectSocket(this.rawSocket, this.route.socketAddress(), connectTimeout);
/* 221 */     } catch (ConnectException e) {
/* 222 */       ConnectException ce = new ConnectException("Failed to connect to " + this.route.socketAddress());
/* 223 */       ce.initCause(e);
/* 224 */       throw ce;
/*     */     } 
/* 226 */     this.source = Okio.buffer(Okio.source(this.rawSocket));
/* 227 */     this.sink = Okio.buffer(Okio.sink(this.rawSocket));
/*     */   }
/*     */   
/*     */   private void establishProtocol(ConnectionSpecSelector connectionSpecSelector) throws IOException {
/* 231 */     if (this.route.address().sslSocketFactory() == null) {
/* 232 */       this.protocol = Protocol.HTTP_1_1;
/* 233 */       this.socket = this.rawSocket;
/*     */       
/*     */       return;
/*     */     } 
/* 237 */     connectTls(connectionSpecSelector);
/*     */     
/* 239 */     if (this.protocol == Protocol.HTTP_2) {
/* 240 */       this.socket.setSoTimeout(0);
/* 241 */       this
/*     */ 
/*     */         
/* 244 */         .http2Connection = (new Http2Connection.Builder(true)).socket(this.socket, this.route.address().url().host(), this.source, this.sink).listener(this).build();
/* 245 */       this.http2Connection.start();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void connectTls(ConnectionSpecSelector connectionSpecSelector) throws IOException {
/* 250 */     Address address = this.route.address();
/* 251 */     SSLSocketFactory sslSocketFactory = address.sslSocketFactory();
/* 252 */     boolean success = false;
/* 253 */     SSLSocket sslSocket = null;
/*     */     
/*     */     try {
/* 256 */       sslSocket = (SSLSocket)sslSocketFactory.createSocket(this.rawSocket, address
/* 257 */           .url().host(), address.url().port(), true);
/*     */ 
/*     */       
/* 260 */       ConnectionSpec connectionSpec = connectionSpecSelector.configureSecureSocket(sslSocket);
/* 261 */       if (connectionSpec.supportsTlsExtensions()) {
/* 262 */         Platform.get().configureTlsExtensions(sslSocket, address
/* 263 */             .url().host(), address.protocols());
/*     */       }
/*     */ 
/*     */       
/* 267 */       sslSocket.startHandshake();
/* 268 */       Handshake unverifiedHandshake = Handshake.get(sslSocket.getSession());
/*     */ 
/*     */       
/* 271 */       if (!address.hostnameVerifier().verify(address.url().host(), sslSocket.getSession())) {
/* 272 */         X509Certificate cert = unverifiedHandshake.peerCertificates().get(0);
/* 273 */         throw new SSLPeerUnverifiedException("Hostname " + address.url().host() + " not verified:\n    certificate: " + 
/* 274 */             CertificatePinner.pin(cert) + "\n    DN: " + cert
/* 275 */             .getSubjectDN().getName() + "\n    subjectAltNames: " + 
/* 276 */             OkHostnameVerifier.allSubjectAltNames(cert));
/*     */       } 
/*     */ 
/*     */       
/* 280 */       address.certificatePinner().check(address.url().host(), unverifiedHandshake
/* 281 */           .peerCertificates());
/*     */ 
/*     */ 
/*     */       
/* 285 */       String maybeProtocol = connectionSpec.supportsTlsExtensions() ? Platform.get().getSelectedProtocol(sslSocket) : null;
/*     */       
/* 287 */       this.socket = sslSocket;
/* 288 */       this.source = Okio.buffer(Okio.source(this.socket));
/* 289 */       this.sink = Okio.buffer(Okio.sink(this.socket));
/* 290 */       this.handshake = unverifiedHandshake;
/* 291 */       this
/* 292 */         .protocol = (maybeProtocol != null) ? Protocol.get(maybeProtocol) : Protocol.HTTP_1_1;
/*     */       
/* 294 */       success = true;
/* 295 */     } catch (AssertionError e) {
/* 296 */       if (Util.isAndroidGetsocknameError(e)) throw new IOException(e); 
/* 297 */       throw e;
/*     */     } finally {
/* 299 */       if (sslSocket != null) {
/* 300 */         Platform.get().afterHandshake(sslSocket);
/*     */       }
/* 302 */       if (!success) {
/* 303 */         Util.closeQuietly(sslSocket);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Request createTunnel(int readTimeout, int writeTimeout, Request tunnelRequest, HttpUrl url) throws IOException {
/*     */     Response response;
/* 315 */     String requestLine = "CONNECT " + Util.hostHeader(url, true) + " HTTP/1.1";
/*     */     while (true) {
/* 317 */       Http1Codec tunnelConnection = new Http1Codec(null, null, this.source, this.sink);
/* 318 */       this.source.timeout().timeout(readTimeout, TimeUnit.MILLISECONDS);
/* 319 */       this.sink.timeout().timeout(writeTimeout, TimeUnit.MILLISECONDS);
/* 320 */       tunnelConnection.writeRequest(tunnelRequest.headers(), requestLine);
/* 321 */       tunnelConnection.finishRequest();
/*     */ 
/*     */       
/* 324 */       response = tunnelConnection.readResponseHeaders(false).request(tunnelRequest).build();
/*     */ 
/*     */       
/* 327 */       long contentLength = HttpHeaders.contentLength(response);
/* 328 */       if (contentLength == -1L) {
/* 329 */         contentLength = 0L;
/*     */       }
/* 331 */       Source body = tunnelConnection.newFixedLengthSource(contentLength);
/* 332 */       Util.skipAll(body, 2147483647, TimeUnit.MILLISECONDS);
/* 333 */       body.close();
/*     */       
/* 335 */       switch (response.code()) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 200:
/* 341 */           if (!this.source.buffer().exhausted() || !this.sink.buffer().exhausted()) {
/* 342 */             throw new IOException("TLS tunnel buffered too many bytes!");
/*     */           }
/* 344 */           return null;
/*     */         
/*     */         case 407:
/* 347 */           tunnelRequest = this.route.address().proxyAuthenticator().authenticate(this.route, response);
/* 348 */           if (tunnelRequest == null) throw new IOException("Failed to authenticate with proxy");
/*     */           
/* 350 */           if ("close".equalsIgnoreCase(response.header("Connection")))
/* 351 */             return tunnelRequest; 
/*     */           continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 356 */     throw new IOException("Unexpected response code for CONNECT: " + response
/* 357 */         .code());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Request createTunnelRequest() {
/* 368 */     return (new Request.Builder())
/* 369 */       .url(this.route.address().url())
/* 370 */       .header("Host", Util.hostHeader(this.route.address().url(), true))
/* 371 */       .header("Proxy-Connection", "Keep-Alive")
/* 372 */       .header("User-Agent", Version.userAgent())
/* 373 */       .build();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEligible(Address address) {
/* 378 */     return (this.allocations.size() < this.allocationLimit && address
/* 379 */       .equals(route().address()) && !this.noNewStreams);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpCodec newCodec(OkHttpClient client, StreamAllocation streamAllocation) throws SocketException {
/* 385 */     if (this.http2Connection != null) {
/* 386 */       return (HttpCodec)new Http2Codec(client, streamAllocation, this.http2Connection);
/*     */     }
/* 388 */     this.socket.setSoTimeout(client.readTimeoutMillis());
/* 389 */     this.source.timeout().timeout(client.readTimeoutMillis(), TimeUnit.MILLISECONDS);
/* 390 */     this.sink.timeout().timeout(client.writeTimeoutMillis(), TimeUnit.MILLISECONDS);
/* 391 */     return (HttpCodec)new Http1Codec(client, streamAllocation, this.source, this.sink);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealWebSocket.Streams newWebSocketStreams(final StreamAllocation streamAllocation) {
/* 396 */     return new RealWebSocket.Streams(true, this.source, this.sink) {
/*     */         public void close() throws IOException {
/* 398 */           streamAllocation.streamFinished(true, streamAllocation.codec());
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public Route route() {
/* 404 */     return this.route;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 409 */     Util.closeQuietly(this.rawSocket);
/*     */   }
/*     */   
/*     */   public Socket socket() {
/* 413 */     return this.socket;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHealthy(boolean doExtensiveChecks) {
/* 418 */     if (this.socket.isClosed() || this.socket.isInputShutdown() || this.socket.isOutputShutdown()) {
/* 419 */       return false;
/*     */     }
/*     */     
/* 422 */     if (this.http2Connection != null) {
/* 423 */       return !this.http2Connection.isShutdown();
/*     */     }
/*     */     
/* 426 */     if (doExtensiveChecks) {
/*     */       try {
/* 428 */         int readTimeout = this.socket.getSoTimeout();
/*     */         try {
/* 430 */           this.socket.setSoTimeout(1);
/* 431 */           if (this.source.exhausted()) {
/* 432 */             return false;
/*     */           }
/* 434 */           return true;
/*     */         } finally {
/* 436 */           this.socket.setSoTimeout(readTimeout);
/*     */         } 
/* 438 */       } catch (SocketTimeoutException socketTimeoutException) {
/*     */       
/* 440 */       } catch (IOException e) {
/* 441 */         return false;
/*     */       } 
/*     */     }
/*     */     
/* 445 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStream(Http2Stream stream) throws IOException {
/* 450 */     stream.close(ErrorCode.REFUSED_STREAM);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSettings(Http2Connection connection) {
/* 455 */     synchronized (this.connectionPool) {
/* 456 */       this.allocationLimit = connection.maxConcurrentStreams();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Handshake handshake() {
/* 461 */     return this.handshake;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMultiplexed() {
/* 469 */     return (this.http2Connection != null);
/*     */   }
/*     */   
/*     */   public Protocol protocol() {
/* 473 */     return this.protocol;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 477 */     return "Connection{" + this.route
/* 478 */       .address().url().host() + ":" + this.route.address().url().port() + ", proxy=" + this.route
/*     */       
/* 480 */       .proxy() + " hostAddress=" + this.route
/*     */       
/* 482 */       .socketAddress() + " cipherSuite=" + ((this.handshake != null) ? (String)this.handshake
/*     */       
/* 484 */       .cipherSuite() : "none") + " protocol=" + this.protocol + '}';
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\connection\RealConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */