/*     */ package okhttp3.internal.connection;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.Socket;
/*     */ import okhttp3.Address;
/*     */ import okhttp3.ConnectionPool;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.Route;
/*     */ import okhttp3.internal.Internal;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.http.HttpCodec;
/*     */ import okhttp3.internal.http2.ErrorCode;
/*     */ import okhttp3.internal.http2.StreamResetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StreamAllocation
/*     */ {
/*     */   public final Address address;
/*     */   private Route route;
/*     */   private final ConnectionPool connectionPool;
/*     */   private final Object callStackTrace;
/*     */   private final RouteSelector routeSelector;
/*     */   private int refusedStreamCount;
/*     */   private RealConnection connection;
/*     */   private boolean released;
/*     */   private boolean canceled;
/*     */   private HttpCodec codec;
/*     */   
/*     */   public StreamAllocation(ConnectionPool connectionPool, Address address, Object callStackTrace) {
/*  87 */     this.connectionPool = connectionPool;
/*  88 */     this.address = address;
/*  89 */     this.routeSelector = new RouteSelector(address, routeDatabase());
/*  90 */     this.callStackTrace = callStackTrace;
/*     */   }
/*     */   
/*     */   public HttpCodec newStream(OkHttpClient client, boolean doExtensiveHealthChecks) {
/*  94 */     int connectTimeout = client.connectTimeoutMillis();
/*  95 */     int readTimeout = client.readTimeoutMillis();
/*  96 */     int writeTimeout = client.writeTimeoutMillis();
/*  97 */     boolean connectionRetryEnabled = client.retryOnConnectionFailure();
/*     */     
/*     */     try {
/* 100 */       RealConnection resultConnection = findHealthyConnection(connectTimeout, readTimeout, writeTimeout, connectionRetryEnabled, doExtensiveHealthChecks);
/*     */       
/* 102 */       HttpCodec resultCodec = resultConnection.newCodec(client, this);
/*     */       
/* 104 */       synchronized (this.connectionPool) {
/* 105 */         this.codec = resultCodec;
/* 106 */         return resultCodec;
/*     */       } 
/* 108 */     } catch (IOException e) {
/* 109 */       throw new RouteException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RealConnection findHealthyConnection(int connectTimeout, int readTimeout, int writeTimeout, boolean connectionRetryEnabled, boolean doExtensiveHealthChecks) throws IOException {
/*     */     RealConnection candidate;
/*     */     while (true) {
/* 121 */       candidate = findConnection(connectTimeout, readTimeout, writeTimeout, connectionRetryEnabled);
/*     */ 
/*     */ 
/*     */       
/* 125 */       synchronized (this.connectionPool) {
/* 126 */         if (candidate.successCount == 0) {
/* 127 */           return candidate;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 133 */       if (!candidate.isHealthy(doExtensiveHealthChecks)) {
/* 134 */         noNewStreams(); continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 138 */     return candidate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RealConnection findConnection(int connectTimeout, int readTimeout, int writeTimeout, boolean connectionRetryEnabled) throws IOException {
/*     */     Route selectedRoute;
/*     */     RealConnection result;
/* 149 */     synchronized (this.connectionPool) {
/* 150 */       if (this.released) throw new IllegalStateException("released"); 
/* 151 */       if (this.codec != null) throw new IllegalStateException("codec != null"); 
/* 152 */       if (this.canceled) throw new IOException("Canceled");
/*     */ 
/*     */       
/* 155 */       RealConnection allocatedConnection = this.connection;
/* 156 */       if (allocatedConnection != null && !allocatedConnection.noNewStreams) {
/* 157 */         return allocatedConnection;
/*     */       }
/*     */ 
/*     */       
/* 161 */       Internal.instance.get(this.connectionPool, this.address, this);
/* 162 */       if (this.connection != null) {
/* 163 */         return this.connection;
/*     */       }
/*     */       
/* 166 */       selectedRoute = this.route;
/*     */     } 
/*     */ 
/*     */     
/* 170 */     if (selectedRoute == null) {
/* 171 */       selectedRoute = this.routeSelector.next();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     synchronized (this.connectionPool) {
/* 178 */       this.route = selectedRoute;
/* 179 */       this.refusedStreamCount = 0;
/* 180 */       result = new RealConnection(this.connectionPool, selectedRoute);
/* 181 */       acquire(result);
/* 182 */       if (this.canceled) throw new IOException("Canceled");
/*     */     
/*     */     } 
/*     */     
/* 186 */     result.connect(connectTimeout, readTimeout, writeTimeout, connectionRetryEnabled);
/* 187 */     routeDatabase().connected(result.route());
/*     */     
/* 189 */     Socket socket = null;
/* 190 */     synchronized (this.connectionPool) {
/*     */       
/* 192 */       Internal.instance.put(this.connectionPool, result);
/*     */ 
/*     */ 
/*     */       
/* 196 */       if (result.isMultiplexed()) {
/* 197 */         socket = Internal.instance.deduplicate(this.connectionPool, this.address, this);
/* 198 */         result = this.connection;
/*     */       } 
/*     */     } 
/* 201 */     Util.closeQuietly(socket);
/*     */     
/* 203 */     return result;
/*     */   }
/*     */   
/*     */   public void streamFinished(boolean noNewStreams, HttpCodec codec) {
/*     */     Socket socket;
/* 208 */     synchronized (this.connectionPool) {
/* 209 */       if (codec == null || codec != this.codec) {
/* 210 */         throw new IllegalStateException("expected " + this.codec + " but was " + codec);
/*     */       }
/* 212 */       if (!noNewStreams) {
/* 213 */         this.connection.successCount++;
/*     */       }
/* 215 */       socket = deallocate(noNewStreams, false, true);
/*     */     } 
/* 217 */     Util.closeQuietly(socket);
/*     */   }
/*     */   
/*     */   public HttpCodec codec() {
/* 221 */     synchronized (this.connectionPool) {
/* 222 */       return this.codec;
/*     */     } 
/*     */   }
/*     */   
/*     */   private RouteDatabase routeDatabase() {
/* 227 */     return Internal.instance.routeDatabase(this.connectionPool);
/*     */   }
/*     */   
/*     */   public synchronized RealConnection connection() {
/* 231 */     return this.connection;
/*     */   }
/*     */   
/*     */   public void release() {
/*     */     Socket socket;
/* 236 */     synchronized (this.connectionPool) {
/* 237 */       socket = deallocate(false, true, false);
/*     */     } 
/* 239 */     Util.closeQuietly(socket);
/*     */   }
/*     */ 
/*     */   
/*     */   public void noNewStreams() {
/*     */     Socket socket;
/* 245 */     synchronized (this.connectionPool) {
/* 246 */       socket = deallocate(true, false, false);
/*     */     } 
/* 248 */     Util.closeQuietly(socket);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Socket deallocate(boolean noNewStreams, boolean released, boolean streamFinished) {
/* 259 */     assert Thread.holdsLock(this.connectionPool);
/*     */     
/* 261 */     if (streamFinished) {
/* 262 */       this.codec = null;
/*     */     }
/* 264 */     if (released) {
/* 265 */       this.released = true;
/*     */     }
/* 267 */     Socket socket = null;
/* 268 */     if (this.connection != null) {
/* 269 */       if (noNewStreams) {
/* 270 */         this.connection.noNewStreams = true;
/*     */       }
/* 272 */       if (this.codec == null && (this.released || this.connection.noNewStreams)) {
/* 273 */         release(this.connection);
/* 274 */         if (this.connection.allocations.isEmpty()) {
/* 275 */           this.connection.idleAtNanos = System.nanoTime();
/* 276 */           if (Internal.instance.connectionBecameIdle(this.connectionPool, this.connection)) {
/* 277 */             socket = this.connection.socket();
/*     */           }
/*     */         } 
/* 280 */         this.connection = null;
/*     */       } 
/*     */     } 
/* 283 */     return socket;
/*     */   }
/*     */   
/*     */   public void cancel() {
/*     */     HttpCodec codecToCancel;
/*     */     RealConnection connectionToCancel;
/* 289 */     synchronized (this.connectionPool) {
/* 290 */       this.canceled = true;
/* 291 */       codecToCancel = this.codec;
/* 292 */       connectionToCancel = this.connection;
/*     */     } 
/* 294 */     if (codecToCancel != null) {
/* 295 */       codecToCancel.cancel();
/* 296 */     } else if (connectionToCancel != null) {
/* 297 */       connectionToCancel.cancel();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void streamFailed(IOException e) {
/*     */     Socket socket;
/* 303 */     boolean noNewStreams = false;
/*     */     
/* 305 */     synchronized (this.connectionPool) {
/* 306 */       if (e instanceof StreamResetException) {
/* 307 */         StreamResetException streamResetException = (StreamResetException)e;
/* 308 */         if (streamResetException.errorCode == ErrorCode.REFUSED_STREAM) {
/* 309 */           this.refusedStreamCount++;
/*     */         }
/*     */ 
/*     */         
/* 313 */         if (streamResetException.errorCode != ErrorCode.REFUSED_STREAM || this.refusedStreamCount > 1) {
/* 314 */           noNewStreams = true;
/* 315 */           this.route = null;
/*     */         } 
/* 317 */       } else if (this.connection != null && (
/* 318 */         !this.connection.isMultiplexed() || e instanceof okhttp3.internal.http2.ConnectionShutdownException)) {
/* 319 */         noNewStreams = true;
/*     */ 
/*     */         
/* 322 */         if (this.connection.successCount == 0) {
/* 323 */           if (this.route != null && e != null) {
/* 324 */             this.routeSelector.connectFailed(this.route, e);
/*     */           }
/* 326 */           this.route = null;
/*     */         } 
/*     */       } 
/* 329 */       socket = deallocate(noNewStreams, false, true);
/*     */     } 
/*     */     
/* 332 */     Util.closeQuietly(socket);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acquire(RealConnection connection) {
/* 340 */     assert Thread.holdsLock(this.connectionPool);
/* 341 */     if (this.connection != null) throw new IllegalStateException();
/*     */     
/* 343 */     this.connection = connection;
/* 344 */     connection.allocations.add(new StreamAllocationReference(this, this.callStackTrace));
/*     */   }
/*     */ 
/*     */   
/*     */   private void release(RealConnection connection) {
/* 349 */     for (int i = 0, size = connection.allocations.size(); i < size; i++) {
/* 350 */       Reference<StreamAllocation> reference = connection.allocations.get(i);
/* 351 */       if (reference.get() == this) {
/* 352 */         connection.allocations.remove(i);
/*     */         return;
/*     */       } 
/*     */     } 
/* 356 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Socket releaseAndAcquire(RealConnection newConnection) {
/* 368 */     assert Thread.holdsLock(this.connectionPool);
/* 369 */     if (this.codec != null || this.connection.allocations.size() != 1) throw new IllegalStateException();
/*     */ 
/*     */     
/* 372 */     Reference<StreamAllocation> onlyAllocation = this.connection.allocations.get(0);
/* 373 */     Socket socket = deallocate(true, false, false);
/*     */ 
/*     */     
/* 376 */     this.connection = newConnection;
/* 377 */     newConnection.allocations.add(onlyAllocation);
/*     */     
/* 379 */     return socket;
/*     */   }
/*     */   
/*     */   public boolean hasMoreRoutes() {
/* 383 */     return (this.route != null || this.routeSelector.hasNext());
/*     */   }
/*     */   
/*     */   public String toString() {
/* 387 */     RealConnection connection = connection();
/* 388 */     return (connection != null) ? connection.toString() : this.address.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class StreamAllocationReference
/*     */     extends WeakReference<StreamAllocation>
/*     */   {
/*     */     public final Object callStackTrace;
/*     */ 
/*     */     
/*     */     StreamAllocationReference(StreamAllocation referent, Object callStackTrace) {
/* 399 */       super(referent);
/* 400 */       this.callStackTrace = callStackTrace;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\connection\StreamAllocation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */