/*    */ package okhttp3.internal.connection;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RouteException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final Method addSuppressedExceptionMethod;
/*    */   private IOException lastException;
/*    */   
/*    */   static {
/*    */     Method m;
/*    */     try {
/* 32 */       m = Throwable.class.getDeclaredMethod("addSuppressed", new Class[] { Throwable.class });
/* 33 */     } catch (Exception e) {
/* 34 */       m = null;
/*    */     } 
/* 36 */     addSuppressedExceptionMethod = m;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RouteException(IOException cause) {
/* 42 */     super(cause);
/* 43 */     this.lastException = cause;
/*    */   }
/*    */   
/*    */   public IOException getLastConnectException() {
/* 47 */     return this.lastException;
/*    */   }
/*    */   
/*    */   public void addConnectException(IOException e) {
/* 51 */     addSuppressedIfPossible(e, this.lastException);
/* 52 */     this.lastException = e;
/*    */   }
/*    */   
/*    */   private void addSuppressedIfPossible(IOException e, IOException suppressed) {
/* 56 */     if (addSuppressedExceptionMethod != null)
/*    */       try {
/* 58 */         addSuppressedExceptionMethod.invoke(e, new Object[] { suppressed });
/* 59 */       } catch (InvocationTargetException|IllegalAccessException invocationTargetException) {} 
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\connection\RouteException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */