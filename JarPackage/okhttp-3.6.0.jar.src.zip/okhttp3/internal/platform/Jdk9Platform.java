/*    */ package okhttp3.internal.platform;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.List;
/*    */ import javax.net.ssl.SSLParameters;
/*    */ import javax.net.ssl.SSLSocket;
/*    */ import javax.net.ssl.SSLSocketFactory;
/*    */ import javax.net.ssl.X509TrustManager;
/*    */ import okhttp3.Protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Jdk9Platform
/*    */   extends Platform
/*    */ {
/*    */   final Method setProtocolMethod;
/*    */   final Method getProtocolMethod;
/*    */   
/*    */   public Jdk9Platform(Method setProtocolMethod, Method getProtocolMethod) {
/* 35 */     this.setProtocolMethod = setProtocolMethod;
/* 36 */     this.getProtocolMethod = getProtocolMethod;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void configureTlsExtensions(SSLSocket sslSocket, String hostname, List<Protocol> protocols) {
/*    */     try {
/* 43 */       SSLParameters sslParameters = sslSocket.getSSLParameters();
/*    */       
/* 45 */       List<String> names = alpnProtocolNames(protocols);
/*    */       
/* 47 */       this.setProtocolMethod.invoke(sslParameters, new Object[] { names
/* 48 */             .toArray(new String[names.size()]) });
/*    */       
/* 50 */       sslSocket.setSSLParameters(sslParameters);
/* 51 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 52 */       throw new AssertionError();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSelectedProtocol(SSLSocket socket) {
/*    */     try {
/* 59 */       String protocol = (String)this.getProtocolMethod.invoke(socket, new Object[0]);
/*    */ 
/*    */ 
/*    */       
/* 63 */       if (protocol == null || protocol.equals("")) {
/* 64 */         return null;
/*    */       }
/*    */       
/* 67 */       return protocol;
/* 68 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 69 */       throw new AssertionError();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public X509TrustManager trustManager(SSLSocketFactory sslSocketFactory) {
/* 78 */     throw new UnsupportedOperationException("clientBuilder.sslSocketFactory(SSLSocketFactory) not supported on JDK 9+");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Jdk9Platform buildIfSupported() {
/*    */     try {
/* 86 */       Method setProtocolMethod = SSLParameters.class.getMethod("setApplicationProtocols", new Class[] { String[].class });
/* 87 */       Method getProtocolMethod = SSLSocket.class.getMethod("getApplicationProtocol", new Class[0]);
/*    */       
/* 89 */       return new Jdk9Platform(setProtocolMethod, getProtocolMethod);
/* 90 */     } catch (NoSuchMethodException noSuchMethodException) {
/*    */ 
/*    */ 
/*    */       
/* 94 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\platform\Jdk9Platform.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */