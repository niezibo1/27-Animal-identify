/*     */ package okhttp3.internal.platform;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import okhttp3.Protocol;
/*     */ import okhttp3.internal.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JdkWithJettyBootPlatform
/*     */   extends Platform
/*     */ {
/*     */   private final Method putMethod;
/*     */   private final Method getMethod;
/*     */   private final Method removeMethod;
/*     */   private final Class<?> clientProviderClass;
/*     */   private final Class<?> serverProviderClass;
/*     */   
/*     */   public JdkWithJettyBootPlatform(Method putMethod, Method getMethod, Method removeMethod, Class<?> clientProviderClass, Class<?> serverProviderClass) {
/*  39 */     this.putMethod = putMethod;
/*  40 */     this.getMethod = getMethod;
/*  41 */     this.removeMethod = removeMethod;
/*  42 */     this.clientProviderClass = clientProviderClass;
/*  43 */     this.serverProviderClass = serverProviderClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureTlsExtensions(SSLSocket sslSocket, String hostname, List<Protocol> protocols) {
/*  48 */     List<String> names = alpnProtocolNames(protocols);
/*     */     
/*     */     try {
/*  51 */       Object provider = Proxy.newProxyInstance(Platform.class.getClassLoader(), new Class[] { this.clientProviderClass, this.serverProviderClass }, new JettyNegoProvider(names));
/*     */       
/*  53 */       this.putMethod.invoke(null, new Object[] { sslSocket, provider });
/*  54 */     } catch (InvocationTargetException|IllegalAccessException e) {
/*  55 */       throw new AssertionError(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void afterHandshake(SSLSocket sslSocket) {
/*     */     try {
/*  61 */       this.removeMethod.invoke(null, new Object[] { sslSocket });
/*  62 */     } catch (IllegalAccessException|InvocationTargetException ignored) {
/*  63 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSelectedProtocol(SSLSocket socket) {
/*     */     try {
/*  70 */       JettyNegoProvider provider = (JettyNegoProvider)Proxy.getInvocationHandler(this.getMethod.invoke(null, new Object[] { socket }));
/*  71 */       if (!provider.unsupported && provider.selected == null) {
/*  72 */         Platform.get().log(4, "ALPN callback dropped: HTTP/2 is disabled. Is alpn-boot on the boot class path?", null);
/*     */         
/*  74 */         return null;
/*     */       } 
/*  76 */       return provider.unsupported ? null : provider.selected;
/*  77 */     } catch (InvocationTargetException|IllegalAccessException e) {
/*  78 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Platform buildIfSupported() {
/*     */     try {
/*  85 */       String negoClassName = "org.eclipse.jetty.alpn.ALPN";
/*  86 */       Class<?> negoClass = Class.forName(negoClassName);
/*  87 */       Class<?> providerClass = Class.forName(negoClassName + "$Provider");
/*  88 */       Class<?> clientProviderClass = Class.forName(negoClassName + "$ClientProvider");
/*  89 */       Class<?> serverProviderClass = Class.forName(negoClassName + "$ServerProvider");
/*  90 */       Method putMethod = negoClass.getMethod("put", new Class[] { SSLSocket.class, providerClass });
/*  91 */       Method getMethod = negoClass.getMethod("get", new Class[] { SSLSocket.class });
/*  92 */       Method removeMethod = negoClass.getMethod("remove", new Class[] { SSLSocket.class });
/*  93 */       return new JdkWithJettyBootPlatform(putMethod, getMethod, removeMethod, clientProviderClass, serverProviderClass);
/*     */     }
/*  95 */     catch (ClassNotFoundException|NoSuchMethodException classNotFoundException) {
/*     */ 
/*     */       
/*  98 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class JettyNegoProvider
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final List<String> protocols;
/*     */     
/*     */     boolean unsupported;
/*     */     
/*     */     String selected;
/*     */ 
/*     */     
/*     */     public JettyNegoProvider(List<String> protocols) {
/* 114 */       this.protocols = protocols;
/*     */     }
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 118 */       String arrayOfString[], methodName = method.getName();
/* 119 */       Class<?> returnType = method.getReturnType();
/* 120 */       if (args == null) {
/* 121 */         arrayOfString = Util.EMPTY_STRING_ARRAY;
/*     */       }
/* 123 */       if (methodName.equals("supports") && boolean.class == returnType)
/* 124 */         return Boolean.valueOf(true); 
/* 125 */       if (methodName.equals("unsupported") && void.class == returnType) {
/* 126 */         this.unsupported = true;
/* 127 */         return null;
/* 128 */       }  if (methodName.equals("protocols") && arrayOfString.length == 0)
/* 129 */         return this.protocols; 
/* 130 */       if ((methodName.equals("selectProtocol") || methodName.equals("select")) && String.class == returnType && arrayOfString.length == 1 && arrayOfString[0] instanceof List) {
/*     */         
/* 132 */         List<String> peerProtocols = (List<String>)arrayOfString[0];
/*     */         
/* 134 */         for (int i = 0, size = peerProtocols.size(); i < size; i++) {
/* 135 */           if (this.protocols.contains(peerProtocols.get(i))) {
/* 136 */             return this.selected = peerProtocols.get(i);
/*     */           }
/*     */         } 
/* 139 */         return this.selected = this.protocols.get(0);
/* 140 */       }  if ((methodName.equals("protocolSelected") || methodName.equals("selected")) && arrayOfString.length == 1) {
/*     */         
/* 142 */         this.selected = arrayOfString[0];
/* 143 */         return null;
/*     */       } 
/* 145 */       return method.invoke(this, (Object[])arrayOfString);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\platform\JdkWithJettyBootPlatform.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */