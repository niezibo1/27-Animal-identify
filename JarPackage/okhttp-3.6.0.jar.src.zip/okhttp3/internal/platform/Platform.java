/*     */ package okhttp3.internal.platform;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ import okhttp3.OkHttpClient;
/*     */ import okhttp3.Protocol;
/*     */ import okhttp3.internal.tls.BasicCertificateChainCleaner;
/*     */ import okhttp3.internal.tls.CertificateChainCleaner;
/*     */ import okhttp3.internal.tls.TrustRootIndex;
/*     */ import okio.Buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Platform
/*     */ {
/*  73 */   private static final Platform PLATFORM = findPlatform();
/*     */   public static final int INFO = 4;
/*     */   public static final int WARN = 5;
/*  76 */   private static final Logger logger = Logger.getLogger(OkHttpClient.class.getName());
/*     */   
/*     */   public static Platform get() {
/*  79 */     return PLATFORM;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/*  84 */     return "OkHttp";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509TrustManager trustManager(SSLSocketFactory sslSocketFactory) {
/*     */     try {
/*  92 */       Class<?> sslContextClass = Class.forName("sun.security.ssl.SSLContextImpl");
/*  93 */       Object context = readFieldOrNull(sslSocketFactory, sslContextClass, "context");
/*  94 */       if (context == null) return null; 
/*  95 */       return readFieldOrNull(context, X509TrustManager.class, "trustManager");
/*  96 */     } catch (ClassNotFoundException e) {
/*  97 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureTlsExtensions(SSLSocket sslSocket, String hostname, List<Protocol> protocols) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterHandshake(SSLSocket sslSocket) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSelectedProtocol(SSLSocket socket) {
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connectSocket(Socket socket, InetSocketAddress address, int connectTimeout) throws IOException {
/* 124 */     socket.connect(address, connectTimeout);
/*     */   }
/*     */   
/*     */   public void log(int level, String message, Throwable t) {
/* 128 */     Level logLevel = (level == 5) ? Level.WARNING : Level.INFO;
/* 129 */     logger.log(logLevel, message, t);
/*     */   }
/*     */   
/*     */   public boolean isCleartextTrafficPermitted(String hostname) {
/* 133 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getStackTraceForCloseable(String closer) {
/* 142 */     if (logger.isLoggable(Level.FINE)) {
/* 143 */       return new Throwable(closer);
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */   
/*     */   public void logCloseableLeak(String message, Object stackTrace) {
/* 149 */     if (stackTrace == null) {
/* 150 */       message = message + " To see where this was allocated, set the OkHttpClient logger level to FINE: Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.FINE);";
/*     */     }
/*     */     
/* 153 */     log(5, message, (Throwable)stackTrace);
/*     */   }
/*     */   
/*     */   public static List<String> alpnProtocolNames(List<Protocol> protocols) {
/* 157 */     List<String> names = new ArrayList<>(protocols.size());
/* 158 */     for (int i = 0, size = protocols.size(); i < size; i++) {
/* 159 */       Protocol protocol = protocols.get(i);
/* 160 */       if (protocol != Protocol.HTTP_1_0)
/* 161 */         names.add(protocol.toString()); 
/*     */     } 
/* 163 */     return names;
/*     */   }
/*     */   
/*     */   public CertificateChainCleaner buildCertificateChainCleaner(X509TrustManager trustManager) {
/* 167 */     return (CertificateChainCleaner)new BasicCertificateChainCleaner(TrustRootIndex.get(trustManager));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Platform findPlatform() {
/* 172 */     Platform android = AndroidPlatform.buildIfSupported();
/*     */     
/* 174 */     if (android != null) {
/* 175 */       return android;
/*     */     }
/*     */     
/* 178 */     Platform jdk9 = Jdk9Platform.buildIfSupported();
/*     */     
/* 180 */     if (jdk9 != null) {
/* 181 */       return jdk9;
/*     */     }
/*     */     
/* 184 */     Platform jdkWithJettyBoot = JdkWithJettyBootPlatform.buildIfSupported();
/*     */     
/* 186 */     if (jdkWithJettyBoot != null) {
/* 187 */       return jdkWithJettyBoot;
/*     */     }
/*     */ 
/*     */     
/* 191 */     return new Platform();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] concatLengthPrefixed(List<Protocol> protocols) {
/* 199 */     Buffer result = new Buffer();
/* 200 */     for (int i = 0, size = protocols.size(); i < size; i++) {
/* 201 */       Protocol protocol = protocols.get(i);
/* 202 */       if (protocol != Protocol.HTTP_1_0) {
/* 203 */         result.writeByte(protocol.toString().length());
/* 204 */         result.writeUtf8(protocol.toString());
/*     */       } 
/* 206 */     }  return result.readByteArray();
/*     */   }
/*     */   
/*     */   static <T> T readFieldOrNull(Object instance, Class<T> fieldType, String fieldName) {
/* 210 */     for (Class<?> c = instance.getClass(); c != Object.class; c = c.getSuperclass()) {
/*     */       
/* 212 */       try { Field field = c.getDeclaredField(fieldName);
/* 213 */         field.setAccessible(true);
/* 214 */         Object value = field.get(instance);
/* 215 */         if (value == null || !fieldType.isInstance(value)) return null; 
/* 216 */         return fieldType.cast(value); }
/* 217 */       catch (NoSuchFieldException noSuchFieldException) {  }
/* 218 */       catch (IllegalAccessException e)
/* 219 */       { throw new AssertionError(); }
/*     */     
/*     */     } 
/*     */ 
/*     */     
/* 224 */     if (!fieldName.equals("delegate")) {
/* 225 */       Object delegate = readFieldOrNull(instance, Object.class, "delegate");
/* 226 */       if (delegate != null) return readFieldOrNull(delegate, fieldType, fieldName);
/*     */     
/*     */     } 
/* 229 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\platform\Platform.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */