/*     */ package okhttp3.internal.platform;
/*     */ 
/*     */ import android.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ import okhttp3.Protocol;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.tls.CertificateChainCleaner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AndroidPlatform
/*     */   extends Platform
/*     */ {
/*     */   private static final int MAX_LOG_LENGTH = 4000;
/*     */   private final Class<?> sslParametersClass;
/*     */   private final OptionalMethod<Socket> setUseSessionTickets;
/*     */   private final OptionalMethod<Socket> setHostname;
/*     */   private final OptionalMethod<Socket> getAlpnSelectedProtocol;
/*     */   private final OptionalMethod<Socket> setAlpnProtocols;
/*  48 */   private final CloseGuard closeGuard = CloseGuard.get();
/*     */ 
/*     */ 
/*     */   
/*     */   public AndroidPlatform(Class<?> sslParametersClass, OptionalMethod<Socket> setUseSessionTickets, OptionalMethod<Socket> setHostname, OptionalMethod<Socket> getAlpnSelectedProtocol, OptionalMethod<Socket> setAlpnProtocols) {
/*  53 */     this.sslParametersClass = sslParametersClass;
/*  54 */     this.setUseSessionTickets = setUseSessionTickets;
/*  55 */     this.setHostname = setHostname;
/*  56 */     this.getAlpnSelectedProtocol = getAlpnSelectedProtocol;
/*  57 */     this.setAlpnProtocols = setAlpnProtocols;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connectSocket(Socket socket, InetSocketAddress address, int connectTimeout) throws IOException {
/*     */     try {
/*  63 */       socket.connect(address, connectTimeout);
/*  64 */     } catch (AssertionError e) {
/*  65 */       if (Util.isAndroidGetsocknameError(e)) throw new IOException(e); 
/*  66 */       throw e;
/*  67 */     } catch (SecurityException e) {
/*     */ 
/*     */       
/*  70 */       IOException ioException = new IOException("Exception in connect");
/*  71 */       ioException.initCause(e);
/*  72 */       throw ioException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public X509TrustManager trustManager(SSLSocketFactory sslSocketFactory) {
/*  77 */     Object context = readFieldOrNull(sslSocketFactory, this.sslParametersClass, "sslParameters");
/*  78 */     if (context == null) {
/*     */       
/*     */       try {
/*     */         
/*  82 */         Class<?> gmsSslParametersClass = Class.forName("com.google.android.gms.org.conscrypt.SSLParametersImpl", false, sslSocketFactory
/*     */             
/*  84 */             .getClass().getClassLoader());
/*  85 */         context = readFieldOrNull(sslSocketFactory, gmsSslParametersClass, "sslParameters");
/*  86 */       } catch (ClassNotFoundException e) {
/*  87 */         return super.trustManager(sslSocketFactory);
/*     */       } 
/*     */     }
/*     */     
/*  91 */     X509TrustManager x509TrustManager = readFieldOrNull(context, X509TrustManager.class, "x509TrustManager");
/*     */     
/*  93 */     if (x509TrustManager != null) return x509TrustManager;
/*     */     
/*  95 */     return readFieldOrNull(context, X509TrustManager.class, "trustManager");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureTlsExtensions(SSLSocket sslSocket, String hostname, List<Protocol> protocols) {
/* 101 */     if (hostname != null) {
/* 102 */       this.setUseSessionTickets.invokeOptionalWithoutCheckedException(sslSocket, new Object[] { Boolean.valueOf(true) });
/* 103 */       this.setHostname.invokeOptionalWithoutCheckedException(sslSocket, new Object[] { hostname });
/*     */     } 
/*     */ 
/*     */     
/* 107 */     if (this.setAlpnProtocols != null && this.setAlpnProtocols.isSupported(sslSocket)) {
/* 108 */       Object[] parameters = { concatLengthPrefixed(protocols) };
/* 109 */       this.setAlpnProtocols.invokeWithoutCheckedException(sslSocket, parameters);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getSelectedProtocol(SSLSocket socket) {
/* 114 */     if (this.getAlpnSelectedProtocol == null) return null; 
/* 115 */     if (!this.getAlpnSelectedProtocol.isSupported(socket)) return null;
/*     */     
/* 117 */     byte[] alpnResult = (byte[])this.getAlpnSelectedProtocol.invokeWithoutCheckedException(socket, new Object[0]);
/* 118 */     return (alpnResult != null) ? new String(alpnResult, Util.UTF_8) : null;
/*     */   }
/*     */   
/*     */   public void log(int level, String message, Throwable t) {
/* 122 */     int logLevel = (level == 5) ? 5 : 3;
/* 123 */     if (t != null) message = message + '\n' + Log.getStackTraceString(t);
/*     */ 
/*     */     
/* 126 */     for (int i = 0, length = message.length(); i < length; ) {
/* 127 */       int newline = message.indexOf('\n', i);
/* 128 */       newline = (newline != -1) ? newline : length;
/*     */       while (true) {
/* 130 */         int end = Math.min(newline, i + 4000);
/* 131 */         Log.println(logLevel, "OkHttp", message.substring(i, end));
/* 132 */         i = end;
/* 133 */         if (i >= newline)
/*     */           i++; 
/*     */       } 
/*     */     } 
/*     */   } public Object getStackTraceForCloseable(String closer) {
/* 138 */     return this.closeGuard.createAndOpen(closer);
/*     */   }
/*     */   
/*     */   public void logCloseableLeak(String message, Object stackTrace) {
/* 142 */     boolean reported = this.closeGuard.warnIfOpen(stackTrace);
/* 143 */     if (!reported)
/*     */     {
/* 145 */       log(5, message, (Throwable)null);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCleartextTrafficPermitted(String hostname) {
/*     */     try {
/* 151 */       Class<?> networkPolicyClass = Class.forName("android.security.NetworkSecurityPolicy");
/* 152 */       Method getInstanceMethod = networkPolicyClass.getMethod("getInstance", new Class[0]);
/* 153 */       Object networkSecurityPolicy = getInstanceMethod.invoke(null, new Object[0]);
/*     */       
/* 155 */       Method isCleartextTrafficPermittedMethod = networkPolicyClass.getMethod("isCleartextTrafficPermitted", new Class[] { String.class });
/* 156 */       return ((Boolean)isCleartextTrafficPermittedMethod.invoke(networkSecurityPolicy, new Object[] { hostname })).booleanValue();
/* 157 */     } catch (ClassNotFoundException|NoSuchMethodException e) {
/* 158 */       return super.isCleartextTrafficPermitted(hostname);
/* 159 */     } catch (IllegalAccessException|IllegalArgumentException|InvocationTargetException e) {
/* 160 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */   
/*     */   public CertificateChainCleaner buildCertificateChainCleaner(X509TrustManager trustManager) {
/*     */     try {
/* 166 */       Class<?> extensionsClass = Class.forName("android.net.http.X509TrustManagerExtensions");
/* 167 */       Constructor<?> constructor = extensionsClass.getConstructor(new Class[] { X509TrustManager.class });
/* 168 */       Object extensions = constructor.newInstance(new Object[] { trustManager });
/* 169 */       Method checkServerTrusted = extensionsClass.getMethod("checkServerTrusted", new Class[] { X509Certificate[].class, String.class, String.class });
/*     */       
/* 171 */       return new AndroidCertificateChainCleaner(extensions, checkServerTrusted);
/* 172 */     } catch (Exception e) {
/* 173 */       return super.buildCertificateChainCleaner(trustManager);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Platform buildIfSupported() {
/*     */     try {
/*     */       Class<?> sslParametersClass;
/*     */       try {
/* 182 */         sslParametersClass = Class.forName("com.android.org.conscrypt.SSLParametersImpl");
/* 183 */       } catch (ClassNotFoundException e) {
/*     */         
/* 185 */         sslParametersClass = Class.forName("org.apache.harmony.xnet.provider.jsse.SSLParametersImpl");
/*     */       } 
/*     */ 
/*     */       
/* 189 */       OptionalMethod<Socket> setUseSessionTickets = new OptionalMethod<>(null, "setUseSessionTickets", new Class[] { boolean.class });
/*     */       
/* 191 */       OptionalMethod<Socket> setHostname = new OptionalMethod<>(null, "setHostname", new Class[] { String.class });
/*     */       
/* 193 */       OptionalMethod<Socket> getAlpnSelectedProtocol = null;
/* 194 */       OptionalMethod<Socket> setAlpnProtocols = null;
/*     */ 
/*     */       
/*     */       try {
/* 198 */         Class.forName("android.net.Network");
/* 199 */         getAlpnSelectedProtocol = new OptionalMethod<>(byte[].class, "getAlpnSelectedProtocol", new Class[0]);
/* 200 */         setAlpnProtocols = new OptionalMethod<>(null, "setAlpnProtocols", new Class[] { byte[].class });
/* 201 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */       
/* 204 */       return new AndroidPlatform(sslParametersClass, setUseSessionTickets, setHostname, getAlpnSelectedProtocol, setAlpnProtocols);
/*     */     }
/* 206 */     catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */ 
/*     */       
/* 210 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static final class AndroidCertificateChainCleaner
/*     */     extends CertificateChainCleaner
/*     */   {
/*     */     private final Object x509TrustManagerExtensions;
/*     */     
/*     */     private final Method checkServerTrusted;
/*     */     
/*     */     AndroidCertificateChainCleaner(Object x509TrustManagerExtensions, Method checkServerTrusted) {
/* 223 */       this.x509TrustManagerExtensions = x509TrustManagerExtensions;
/* 224 */       this.checkServerTrusted = checkServerTrusted;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Certificate> clean(List<Certificate> chain, String hostname) throws SSLPeerUnverifiedException {
/*     */       try {
/* 231 */         X509Certificate[] certificates = chain.<X509Certificate>toArray(new X509Certificate[chain.size()]);
/* 232 */         return (List<Certificate>)this.checkServerTrusted.invoke(this.x509TrustManagerExtensions, new Object[] { certificates, "RSA", hostname });
/*     */       }
/* 234 */       catch (InvocationTargetException e) {
/* 235 */         SSLPeerUnverifiedException exception = new SSLPeerUnverifiedException(e.getMessage());
/* 236 */         exception.initCause(e);
/* 237 */         throw exception;
/* 238 */       } catch (IllegalAccessException e) {
/* 239 */         throw new AssertionError(e);
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean equals(Object other) {
/* 244 */       return other instanceof AndroidCertificateChainCleaner;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 248 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class CloseGuard
/*     */   {
/*     */     private final Method getMethod;
/*     */     
/*     */     private final Method openMethod;
/*     */     
/*     */     private final Method warnIfOpenMethod;
/*     */ 
/*     */     
/*     */     CloseGuard(Method getMethod, Method openMethod, Method warnIfOpenMethod) {
/* 263 */       this.getMethod = getMethod;
/* 264 */       this.openMethod = openMethod;
/* 265 */       this.warnIfOpenMethod = warnIfOpenMethod;
/*     */     }
/*     */     
/*     */     Object createAndOpen(String closer) {
/* 269 */       if (this.getMethod != null) {
/*     */         try {
/* 271 */           Object closeGuardInstance = this.getMethod.invoke(null, new Object[0]);
/* 272 */           this.openMethod.invoke(closeGuardInstance, new Object[] { closer });
/* 273 */           return closeGuardInstance;
/* 274 */         } catch (Exception exception) {}
/*     */       }
/*     */       
/* 277 */       return null;
/*     */     }
/*     */     
/*     */     boolean warnIfOpen(Object closeGuardInstance) {
/* 281 */       boolean reported = false;
/* 282 */       if (closeGuardInstance != null) {
/*     */         try {
/* 284 */           this.warnIfOpenMethod.invoke(closeGuardInstance, new Object[0]);
/* 285 */           reported = true;
/* 286 */         } catch (Exception exception) {}
/*     */       }
/*     */       
/* 289 */       return reported;
/*     */     }
/*     */ 
/*     */     
/*     */     static CloseGuard get() {
/*     */       Method getMethod;
/*     */       Method openMethod;
/*     */       Method warnIfOpenMethod;
/*     */       try {
/* 298 */         Class<?> closeGuardClass = Class.forName("dalvik.system.CloseGuard");
/* 299 */         getMethod = closeGuardClass.getMethod("get", new Class[0]);
/* 300 */         openMethod = closeGuardClass.getMethod("open", new Class[] { String.class });
/* 301 */         warnIfOpenMethod = closeGuardClass.getMethod("warnIfOpen", new Class[0]);
/* 302 */       } catch (Exception ignored) {
/* 303 */         getMethod = null;
/* 304 */         openMethod = null;
/* 305 */         warnIfOpenMethod = null;
/*     */       } 
/* 307 */       return new CloseGuard(getMethod, openMethod, warnIfOpenMethod);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\internal\platform\AndroidPlatform.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */