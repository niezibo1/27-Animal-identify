/*    */ package okhttp3;
/*    */ 
/*    */ import okhttp3.internal.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Challenge
/*    */ {
/*    */   private final String scheme;
/*    */   private final String realm;
/*    */   
/*    */   public Challenge(String scheme, String realm) {
/* 26 */     this.scheme = scheme;
/* 27 */     this.realm = realm;
/*    */   }
/*    */ 
/*    */   
/*    */   public String scheme() {
/* 32 */     return this.scheme;
/*    */   }
/*    */ 
/*    */   
/*    */   public String realm() {
/* 37 */     return this.realm;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 41 */     return (o instanceof Challenge && 
/* 42 */       Util.equal(this.scheme, ((Challenge)o).scheme) && 
/* 43 */       Util.equal(this.realm, ((Challenge)o).realm));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 47 */     int result = 29;
/* 48 */     result = 31 * result + ((this.realm != null) ? this.realm.hashCode() : 0);
/* 49 */     result = 31 * result + ((this.scheme != null) ? this.scheme.hashCode() : 0);
/* 50 */     return result;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 54 */     return this.scheme + " realm=\"" + this.realm + "\"";
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Challenge.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */