/*     */ package okhttp3;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import okhttp3.internal.Util;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSink;
/*     */ import okio.ByteString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MultipartBody
/*     */   extends RequestBody
/*     */ {
/*  34 */   public static final MediaType MIXED = MediaType.parse("multipart/mixed");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   public static final MediaType ALTERNATIVE = MediaType.parse("multipart/alternative");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final MediaType DIGEST = MediaType.parse("multipart/digest");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final MediaType PARALLEL = MediaType.parse("multipart/parallel");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public static final MediaType FORM = MediaType.parse("multipart/form-data");
/*     */   
/*  63 */   private static final byte[] COLONSPACE = new byte[] { 58, 32 };
/*  64 */   private static final byte[] CRLF = new byte[] { 13, 10 };
/*  65 */   private static final byte[] DASHDASH = new byte[] { 45, 45 };
/*     */   
/*     */   private final ByteString boundary;
/*     */   private final MediaType originalType;
/*     */   private final MediaType contentType;
/*     */   private final List<Part> parts;
/*  71 */   private long contentLength = -1L;
/*     */   
/*     */   MultipartBody(ByteString boundary, MediaType type, List<Part> parts) {
/*  74 */     this.boundary = boundary;
/*  75 */     this.originalType = type;
/*  76 */     this.contentType = MediaType.parse(type + "; boundary=" + boundary.utf8());
/*  77 */     this.parts = Util.immutableList(parts);
/*     */   }
/*     */   
/*     */   public MediaType type() {
/*  81 */     return this.originalType;
/*     */   }
/*     */   
/*     */   public String boundary() {
/*  85 */     return this.boundary.utf8();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  90 */     return this.parts.size();
/*     */   }
/*     */   
/*     */   public List<Part> parts() {
/*  94 */     return this.parts;
/*     */   }
/*     */   
/*     */   public Part part(int index) {
/*  98 */     return this.parts.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaType contentType() {
/* 103 */     return this.contentType;
/*     */   }
/*     */   
/*     */   public long contentLength() throws IOException {
/* 107 */     long result = this.contentLength;
/* 108 */     if (result != -1L) return result; 
/* 109 */     return this.contentLength = writeOrCountBytes(null, true);
/*     */   }
/*     */   
/*     */   public void writeTo(BufferedSink sink) throws IOException {
/* 113 */     writeOrCountBytes(sink, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long writeOrCountBytes(BufferedSink sink, boolean countBytes) throws IOException {
/*     */     Buffer buffer1;
/* 123 */     long byteCount = 0L;
/*     */     
/* 125 */     Buffer byteCountBuffer = null;
/* 126 */     if (countBytes) {
/* 127 */       buffer1 = byteCountBuffer = new Buffer();
/*     */     }
/*     */     
/* 130 */     for (int p = 0, partCount = this.parts.size(); p < partCount; p++) {
/* 131 */       Part part = this.parts.get(p);
/* 132 */       Headers headers = part.headers;
/* 133 */       RequestBody body = part.body;
/*     */       
/* 135 */       buffer1.write(DASHDASH);
/* 136 */       buffer1.write(this.boundary);
/* 137 */       buffer1.write(CRLF);
/*     */       
/* 139 */       if (headers != null) {
/* 140 */         for (int h = 0, headerCount = headers.size(); h < headerCount; h++) {
/* 141 */           buffer1.writeUtf8(headers.name(h))
/* 142 */             .write(COLONSPACE)
/* 143 */             .writeUtf8(headers.value(h))
/* 144 */             .write(CRLF);
/*     */         }
/*     */       }
/*     */       
/* 148 */       MediaType contentType = body.contentType();
/* 149 */       if (contentType != null) {
/* 150 */         buffer1.writeUtf8("Content-Type: ")
/* 151 */           .writeUtf8(contentType.toString())
/* 152 */           .write(CRLF);
/*     */       }
/*     */       
/* 155 */       long contentLength = body.contentLength();
/* 156 */       if (contentLength != -1L) {
/* 157 */         buffer1.writeUtf8("Content-Length: ")
/* 158 */           .writeDecimalLong(contentLength)
/* 159 */           .write(CRLF);
/* 160 */       } else if (countBytes) {
/*     */         
/* 162 */         byteCountBuffer.clear();
/* 163 */         return -1L;
/*     */       } 
/*     */       
/* 166 */       buffer1.write(CRLF);
/*     */       
/* 168 */       if (countBytes) {
/* 169 */         byteCount += contentLength;
/*     */       } else {
/* 171 */         body.writeTo((BufferedSink)buffer1);
/*     */       } 
/*     */       
/* 174 */       buffer1.write(CRLF);
/*     */     } 
/*     */     
/* 177 */     buffer1.write(DASHDASH);
/* 178 */     buffer1.write(this.boundary);
/* 179 */     buffer1.write(DASHDASH);
/* 180 */     buffer1.write(CRLF);
/*     */     
/* 182 */     if (countBytes) {
/* 183 */       byteCount += byteCountBuffer.size();
/* 184 */       byteCountBuffer.clear();
/*     */     } 
/*     */     
/* 187 */     return byteCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static StringBuilder appendQuotedString(StringBuilder target, String key) {
/* 201 */     target.append('"');
/* 202 */     for (int i = 0, len = key.length(); i < len; i++) {
/* 203 */       char ch = key.charAt(i);
/* 204 */       switch (ch) {
/*     */         case '\n':
/* 206 */           target.append("%0A");
/*     */           break;
/*     */         case '\r':
/* 209 */           target.append("%0D");
/*     */           break;
/*     */         case '"':
/* 212 */           target.append("%22");
/*     */           break;
/*     */         default:
/* 215 */           target.append(ch);
/*     */           break;
/*     */       } 
/*     */     } 
/* 219 */     target.append('"');
/* 220 */     return target;
/*     */   }
/*     */   public static final class Part { final Headers headers;
/*     */     
/*     */     public static Part create(RequestBody body) {
/* 225 */       return create(null, body);
/*     */     }
/*     */     final RequestBody body;
/*     */     public static Part create(Headers headers, RequestBody body) {
/* 229 */       if (body == null) {
/* 230 */         throw new NullPointerException("body == null");
/*     */       }
/* 232 */       if (headers != null && headers.get("Content-Type") != null) {
/* 233 */         throw new IllegalArgumentException("Unexpected header: Content-Type");
/*     */       }
/* 235 */       if (headers != null && headers.get("Content-Length") != null) {
/* 236 */         throw new IllegalArgumentException("Unexpected header: Content-Length");
/*     */       }
/* 238 */       return new Part(headers, body);
/*     */     }
/*     */     
/*     */     public static Part createFormData(String name, String value) {
/* 242 */       return createFormData(name, null, RequestBody.create((MediaType)null, value));
/*     */     }
/*     */     
/*     */     public static Part createFormData(String name, String filename, RequestBody body) {
/* 246 */       if (name == null) {
/* 247 */         throw new NullPointerException("name == null");
/*     */       }
/* 249 */       StringBuilder disposition = new StringBuilder("form-data; name=");
/* 250 */       MultipartBody.appendQuotedString(disposition, name);
/*     */       
/* 252 */       if (filename != null) {
/* 253 */         disposition.append("; filename=");
/* 254 */         MultipartBody.appendQuotedString(disposition, filename);
/*     */       } 
/*     */       
/* 257 */       return create(Headers.of(new String[] { "Content-Disposition", disposition.toString() }, ), body);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Part(Headers headers, RequestBody body) {
/* 264 */       this.headers = headers;
/* 265 */       this.body = body;
/*     */     }
/*     */     
/*     */     public Headers headers() {
/* 269 */       return this.headers;
/*     */     }
/*     */     
/*     */     public RequestBody body() {
/* 273 */       return this.body;
/*     */     } }
/*     */ 
/*     */   
/*     */   public static final class Builder {
/*     */     private final ByteString boundary;
/* 279 */     private MediaType type = MultipartBody.MIXED;
/* 280 */     private final List<MultipartBody.Part> parts = new ArrayList<>();
/*     */     
/*     */     public Builder() {
/* 283 */       this(UUID.randomUUID().toString());
/*     */     }
/*     */     
/*     */     public Builder(String boundary) {
/* 287 */       this.boundary = ByteString.encodeUtf8(boundary);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setType(MediaType type) {
/* 295 */       if (type == null) {
/* 296 */         throw new NullPointerException("type == null");
/*     */       }
/* 298 */       if (!type.type().equals("multipart")) {
/* 299 */         throw new IllegalArgumentException("multipart != " + type);
/*     */       }
/* 301 */       this.type = type;
/* 302 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addPart(RequestBody body) {
/* 307 */       return addPart(MultipartBody.Part.create(body));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addPart(Headers headers, RequestBody body) {
/* 312 */       return addPart(MultipartBody.Part.create(headers, body));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addFormDataPart(String name, String value) {
/* 317 */       return addPart(MultipartBody.Part.createFormData(name, value));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addFormDataPart(String name, String filename, RequestBody body) {
/* 322 */       return addPart(MultipartBody.Part.createFormData(name, filename, body));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addPart(MultipartBody.Part part) {
/* 327 */       if (part == null) throw new NullPointerException("part == null"); 
/* 328 */       this.parts.add(part);
/* 329 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public MultipartBody build() {
/* 334 */       if (this.parts.isEmpty()) {
/* 335 */         throw new IllegalStateException("Multipart body must have at least one part.");
/*     */       }
/* 337 */       return new MultipartBody(this.boundary, this.type, this.parts);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\MultipartBody.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */