package okhttp3;

import java.io.IOException;

public interface Callback {
  void onFailure(Call paramCall, IOException paramIOException);
  
  void onResponse(Call paramCall, Response paramResponse) throws IOException;
}


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Callback.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */