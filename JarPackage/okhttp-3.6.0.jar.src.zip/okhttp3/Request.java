/*     */ package okhttp3;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.http.HttpMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Request
/*     */ {
/*     */   final HttpUrl url;
/*     */   final String method;
/*     */   final Headers headers;
/*     */   final RequestBody body;
/*     */   final Object tag;
/*     */   private volatile CacheControl cacheControl;
/*     */   
/*     */   Request(Builder builder) {
/*  37 */     this.url = builder.url;
/*  38 */     this.method = builder.method;
/*  39 */     this.headers = builder.headers.build();
/*  40 */     this.body = builder.body;
/*  41 */     this.tag = (builder.tag != null) ? builder.tag : this;
/*     */   }
/*     */   
/*     */   public HttpUrl url() {
/*  45 */     return this.url;
/*     */   }
/*     */   
/*     */   public String method() {
/*  49 */     return this.method;
/*     */   }
/*     */   
/*     */   public Headers headers() {
/*  53 */     return this.headers;
/*     */   }
/*     */   
/*     */   public String header(String name) {
/*  57 */     return this.headers.get(name);
/*     */   }
/*     */   
/*     */   public List<String> headers(String name) {
/*  61 */     return this.headers.values(name);
/*     */   }
/*     */   
/*     */   public RequestBody body() {
/*  65 */     return this.body;
/*     */   }
/*     */   
/*     */   public Object tag() {
/*  69 */     return this.tag;
/*     */   }
/*     */   
/*     */   public Builder newBuilder() {
/*  73 */     return new Builder(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl cacheControl() {
/*  81 */     CacheControl result = this.cacheControl;
/*  82 */     return (result != null) ? result : (this.cacheControl = CacheControl.parse(this.headers));
/*     */   }
/*     */   
/*     */   public boolean isHttps() {
/*  86 */     return this.url.isHttps();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  90 */     return "Request{method=" + this.method + ", url=" + this.url + ", tag=" + ((this.tag != this) ? (String)this.tag : null) + '}';
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     HttpUrl url;
/*     */     
/*     */     String method;
/*     */     
/*     */     Headers.Builder headers;
/*     */     
/*     */     RequestBody body;
/*     */     
/*     */     Object tag;
/*     */     
/*     */     public Builder() {
/* 107 */       this.method = "GET";
/* 108 */       this.headers = new Headers.Builder();
/*     */     }
/*     */     
/*     */     Builder(Request request) {
/* 112 */       this.url = request.url;
/* 113 */       this.method = request.method;
/* 114 */       this.body = request.body;
/* 115 */       this.tag = request.tag;
/* 116 */       this.headers = request.headers.newBuilder();
/*     */     }
/*     */     
/*     */     public Builder url(HttpUrl url) {
/* 120 */       if (url == null) throw new NullPointerException("url == null"); 
/* 121 */       this.url = url;
/* 122 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder url(String url) {
/* 132 */       if (url == null) throw new NullPointerException("url == null");
/*     */ 
/*     */       
/* 135 */       if (url.regionMatches(true, 0, "ws:", 0, 3)) {
/* 136 */         url = "http:" + url.substring(3);
/* 137 */       } else if (url.regionMatches(true, 0, "wss:", 0, 4)) {
/* 138 */         url = "https:" + url.substring(4);
/*     */       } 
/*     */       
/* 141 */       HttpUrl parsed = HttpUrl.parse(url);
/* 142 */       if (parsed == null) throw new IllegalArgumentException("unexpected url: " + url); 
/* 143 */       return url(parsed);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder url(URL url) {
/* 153 */       if (url == null) throw new NullPointerException("url == null"); 
/* 154 */       HttpUrl parsed = HttpUrl.get(url);
/* 155 */       if (parsed == null) throw new IllegalArgumentException("unexpected url: " + url); 
/* 156 */       return url(parsed);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder header(String name, String value) {
/* 164 */       this.headers.set(name, value);
/* 165 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addHeader(String name, String value) {
/* 176 */       this.headers.add(name, value);
/* 177 */       return this;
/*     */     }
/*     */     
/*     */     public Builder removeHeader(String name) {
/* 181 */       this.headers.removeAll(name);
/* 182 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder headers(Headers headers) {
/* 187 */       this.headers = headers.newBuilder();
/* 188 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder cacheControl(CacheControl cacheControl) {
/* 197 */       String value = cacheControl.toString();
/* 198 */       if (value.isEmpty()) return removeHeader("Cache-Control"); 
/* 199 */       return header("Cache-Control", value);
/*     */     }
/*     */     
/*     */     public Builder get() {
/* 203 */       return method("GET", null);
/*     */     }
/*     */     
/*     */     public Builder head() {
/* 207 */       return method("HEAD", null);
/*     */     }
/*     */     
/*     */     public Builder post(RequestBody body) {
/* 211 */       return method("POST", body);
/*     */     }
/*     */     
/*     */     public Builder delete(RequestBody body) {
/* 215 */       return method("DELETE", body);
/*     */     }
/*     */     
/*     */     public Builder delete() {
/* 219 */       return delete(Util.EMPTY_REQUEST);
/*     */     }
/*     */     
/*     */     public Builder put(RequestBody body) {
/* 223 */       return method("PUT", body);
/*     */     }
/*     */     
/*     */     public Builder patch(RequestBody body) {
/* 227 */       return method("PATCH", body);
/*     */     }
/*     */     
/*     */     public Builder method(String method, RequestBody body) {
/* 231 */       if (method == null) throw new NullPointerException("method == null"); 
/* 232 */       if (method.length() == 0) throw new IllegalArgumentException("method.length() == 0"); 
/* 233 */       if (body != null && !HttpMethod.permitsRequestBody(method)) {
/* 234 */         throw new IllegalArgumentException("method " + method + " must not have a request body.");
/*     */       }
/* 236 */       if (body == null && HttpMethod.requiresRequestBody(method)) {
/* 237 */         throw new IllegalArgumentException("method " + method + " must have a request body.");
/*     */       }
/* 239 */       this.method = method;
/* 240 */       this.body = body;
/* 241 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder tag(Object tag) {
/* 249 */       this.tag = tag;
/* 250 */       return this;
/*     */     }
/*     */     
/*     */     public Request build() {
/* 254 */       if (this.url == null) throw new IllegalStateException("url == null"); 
/* 255 */       return new Request(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Request.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */