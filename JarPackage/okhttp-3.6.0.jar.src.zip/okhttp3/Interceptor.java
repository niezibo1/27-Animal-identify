package okhttp3;

import java.io.IOException;

public interface Interceptor {
  Response intercept(Chain paramChain) throws IOException;
  
  public static interface Chain {
    Request request();
    
    Response proceed(Request param1Request) throws IOException;
    
    Connection connection();
  }
}


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Interceptor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */