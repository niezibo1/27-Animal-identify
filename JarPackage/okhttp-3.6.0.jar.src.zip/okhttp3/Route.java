/*     */ package okhttp3;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Route
/*     */ {
/*     */   final Address address;
/*     */   final Proxy proxy;
/*     */   final InetSocketAddress inetSocketAddress;
/*     */   
/*     */   public Route(Address address, Proxy proxy, InetSocketAddress inetSocketAddress) {
/*  42 */     if (address == null) {
/*  43 */       throw new NullPointerException("address == null");
/*     */     }
/*  45 */     if (proxy == null) {
/*  46 */       throw new NullPointerException("proxy == null");
/*     */     }
/*  48 */     if (inetSocketAddress == null) {
/*  49 */       throw new NullPointerException("inetSocketAddress == null");
/*     */     }
/*  51 */     this.address = address;
/*  52 */     this.proxy = proxy;
/*  53 */     this.inetSocketAddress = inetSocketAddress;
/*     */   }
/*     */   
/*     */   public Address address() {
/*  57 */     return this.address;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Proxy proxy() {
/*  67 */     return this.proxy;
/*     */   }
/*     */   
/*     */   public InetSocketAddress socketAddress() {
/*  71 */     return this.inetSocketAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresTunnel() {
/*  79 */     return (this.address.sslSocketFactory != null && this.proxy.type() == Proxy.Type.HTTP);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  83 */     if (obj instanceof Route) {
/*  84 */       Route other = (Route)obj;
/*  85 */       return (this.address.equals(other.address) && this.proxy
/*  86 */         .equals(other.proxy) && this.inetSocketAddress
/*  87 */         .equals(other.inetSocketAddress));
/*     */     } 
/*  89 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  93 */     int result = 17;
/*  94 */     result = 31 * result + this.address.hashCode();
/*  95 */     result = 31 * result + this.proxy.hashCode();
/*  96 */     result = 31 * result + this.inetSocketAddress.hashCode();
/*  97 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 101 */     return "Route{" + this.inetSocketAddress + "}";
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Route.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */