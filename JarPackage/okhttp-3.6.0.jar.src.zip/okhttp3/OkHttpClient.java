/*     */ package okhttp3;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.Proxy;
/*     */ import java.net.ProxySelector;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ import okhttp3.internal.Internal;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.cache.InternalCache;
/*     */ import okhttp3.internal.connection.RealConnection;
/*     */ import okhttp3.internal.connection.RouteDatabase;
/*     */ import okhttp3.internal.connection.StreamAllocation;
/*     */ import okhttp3.internal.platform.Platform;
/*     */ import okhttp3.internal.tls.CertificateChainCleaner;
/*     */ import okhttp3.internal.tls.OkHostnameVerifier;
/*     */ import okhttp3.internal.ws.RealWebSocket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OkHttpClient
/*     */   implements Cloneable, Call.Factory, WebSocket.Factory
/*     */ {
/* 122 */   static final List<Protocol> DEFAULT_PROTOCOLS = Util.immutableList((Object[])new Protocol[] { Protocol.HTTP_2, Protocol.HTTP_1_1 });
/*     */ 
/*     */   
/* 125 */   static final List<ConnectionSpec> DEFAULT_CONNECTION_SPECS = Util.immutableList((Object[])new ConnectionSpec[] { ConnectionSpec.MODERN_TLS, ConnectionSpec.COMPATIBLE_TLS, ConnectionSpec.CLEARTEXT });
/*     */   final Dispatcher dispatcher;
/*     */   
/*     */   static {
/* 129 */     Internal.instance = new Internal() {
/*     */         public void addLenient(Headers.Builder builder, String line) {
/* 131 */           builder.addLenient(line);
/*     */         }
/*     */         
/*     */         public void addLenient(Headers.Builder builder, String name, String value) {
/* 135 */           builder.addLenient(name, value);
/*     */         }
/*     */         
/*     */         public void setCache(OkHttpClient.Builder builder, InternalCache internalCache) {
/* 139 */           builder.setInternalCache(internalCache);
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean connectionBecameIdle(ConnectionPool pool, RealConnection connection) {
/* 144 */           return pool.connectionBecameIdle(connection);
/*     */         }
/*     */ 
/*     */         
/*     */         public RealConnection get(ConnectionPool pool, Address address, StreamAllocation streamAllocation) {
/* 149 */           return pool.get(address, streamAllocation);
/*     */         }
/*     */ 
/*     */         
/*     */         public Socket deduplicate(ConnectionPool pool, Address address, StreamAllocation streamAllocation) {
/* 154 */           return pool.deduplicate(address, streamAllocation);
/*     */         }
/*     */         
/*     */         public void put(ConnectionPool pool, RealConnection connection) {
/* 158 */           pool.put(connection);
/*     */         }
/*     */         
/*     */         public RouteDatabase routeDatabase(ConnectionPool connectionPool) {
/* 162 */           return connectionPool.routeDatabase;
/*     */         }
/*     */         
/*     */         public int code(Response.Builder responseBuilder) {
/* 166 */           return responseBuilder.code;
/*     */         }
/*     */ 
/*     */         
/*     */         public void apply(ConnectionSpec tlsConfiguration, SSLSocket sslSocket, boolean isFallback) {
/* 171 */           tlsConfiguration.apply(sslSocket, isFallback);
/*     */         }
/*     */ 
/*     */         
/*     */         public HttpUrl getHttpUrlChecked(String url) throws MalformedURLException, UnknownHostException {
/* 176 */           return HttpUrl.getChecked(url);
/*     */         }
/*     */         
/*     */         public StreamAllocation streamAllocation(Call call) {
/* 180 */           return ((RealCall)call).streamAllocation();
/*     */         }
/*     */         
/*     */         public Call newWebSocketCall(OkHttpClient client, Request originalRequest) {
/* 184 */           return new RealCall(client, originalRequest, true);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   final Proxy proxy;
/*     */   final List<Protocol> protocols;
/*     */   final List<ConnectionSpec> connectionSpecs;
/*     */   final List<Interceptor> interceptors;
/*     */   final List<Interceptor> networkInterceptors;
/*     */   final ProxySelector proxySelector;
/*     */   final CookieJar cookieJar;
/*     */   final Cache cache;
/*     */   final InternalCache internalCache;
/*     */   final SocketFactory socketFactory;
/*     */   final SSLSocketFactory sslSocketFactory;
/*     */   final CertificateChainCleaner certificateChainCleaner;
/*     */   final HostnameVerifier hostnameVerifier;
/*     */   final CertificatePinner certificatePinner;
/*     */   final Authenticator proxyAuthenticator;
/*     */   final Authenticator authenticator;
/*     */   final ConnectionPool connectionPool;
/*     */   final Dns dns;
/*     */   final boolean followSslRedirects;
/*     */   final boolean followRedirects;
/*     */   final boolean retryOnConnectionFailure;
/*     */   final int connectTimeout;
/*     */   final int readTimeout;
/*     */   final int writeTimeout;
/*     */   final int pingInterval;
/*     */   
/*     */   public OkHttpClient() {
/* 217 */     this(new Builder());
/*     */   }
/*     */   
/*     */   OkHttpClient(Builder builder) {
/* 221 */     this.dispatcher = builder.dispatcher;
/* 222 */     this.proxy = builder.proxy;
/* 223 */     this.protocols = builder.protocols;
/* 224 */     this.connectionSpecs = builder.connectionSpecs;
/* 225 */     this.interceptors = Util.immutableList(builder.interceptors);
/* 226 */     this.networkInterceptors = Util.immutableList(builder.networkInterceptors);
/* 227 */     this.proxySelector = builder.proxySelector;
/* 228 */     this.cookieJar = builder.cookieJar;
/* 229 */     this.cache = builder.cache;
/* 230 */     this.internalCache = builder.internalCache;
/* 231 */     this.socketFactory = builder.socketFactory;
/*     */     
/* 233 */     boolean isTLS = false;
/* 234 */     for (ConnectionSpec spec : this.connectionSpecs) {
/* 235 */       isTLS = (isTLS || spec.isTls());
/*     */     }
/*     */     
/* 238 */     if (builder.sslSocketFactory != null || !isTLS) {
/* 239 */       this.sslSocketFactory = builder.sslSocketFactory;
/* 240 */       this.certificateChainCleaner = builder.certificateChainCleaner;
/*     */     } else {
/* 242 */       X509TrustManager trustManager = systemDefaultTrustManager();
/* 243 */       this.sslSocketFactory = systemDefaultSslSocketFactory(trustManager);
/* 244 */       this.certificateChainCleaner = CertificateChainCleaner.get(trustManager);
/*     */     } 
/*     */     
/* 247 */     this.hostnameVerifier = builder.hostnameVerifier;
/* 248 */     this.certificatePinner = builder.certificatePinner.withCertificateChainCleaner(this.certificateChainCleaner);
/*     */     
/* 250 */     this.proxyAuthenticator = builder.proxyAuthenticator;
/* 251 */     this.authenticator = builder.authenticator;
/* 252 */     this.connectionPool = builder.connectionPool;
/* 253 */     this.dns = builder.dns;
/* 254 */     this.followSslRedirects = builder.followSslRedirects;
/* 255 */     this.followRedirects = builder.followRedirects;
/* 256 */     this.retryOnConnectionFailure = builder.retryOnConnectionFailure;
/* 257 */     this.connectTimeout = builder.connectTimeout;
/* 258 */     this.readTimeout = builder.readTimeout;
/* 259 */     this.writeTimeout = builder.writeTimeout;
/* 260 */     this.pingInterval = builder.pingInterval;
/*     */   }
/*     */   
/*     */   private X509TrustManager systemDefaultTrustManager() {
/*     */     try {
/* 265 */       TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(
/* 266 */           TrustManagerFactory.getDefaultAlgorithm());
/* 267 */       trustManagerFactory.init((KeyStore)null);
/* 268 */       TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
/* 269 */       if (trustManagers.length != 1 || !(trustManagers[0] instanceof X509TrustManager)) {
/* 270 */         throw new IllegalStateException("Unexpected default trust managers:" + 
/* 271 */             Arrays.toString(trustManagers));
/*     */       }
/* 273 */       return (X509TrustManager)trustManagers[0];
/* 274 */     } catch (GeneralSecurityException e) {
/* 275 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */   
/*     */   private SSLSocketFactory systemDefaultSslSocketFactory(X509TrustManager trustManager) {
/*     */     try {
/* 281 */       SSLContext sslContext = SSLContext.getInstance("TLS");
/* 282 */       sslContext.init(null, new TrustManager[] { trustManager }, null);
/* 283 */       return sslContext.getSocketFactory();
/* 284 */     } catch (GeneralSecurityException e) {
/* 285 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int connectTimeoutMillis() {
/* 291 */     return this.connectTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readTimeoutMillis() {
/* 296 */     return this.readTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public int writeTimeoutMillis() {
/* 301 */     return this.writeTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public int pingIntervalMillis() {
/* 306 */     return this.pingInterval;
/*     */   }
/*     */   
/*     */   public Proxy proxy() {
/* 310 */     return this.proxy;
/*     */   }
/*     */   
/*     */   public ProxySelector proxySelector() {
/* 314 */     return this.proxySelector;
/*     */   }
/*     */   
/*     */   public CookieJar cookieJar() {
/* 318 */     return this.cookieJar;
/*     */   }
/*     */   
/*     */   public Cache cache() {
/* 322 */     return this.cache;
/*     */   }
/*     */   
/*     */   InternalCache internalCache() {
/* 326 */     return (this.cache != null) ? this.cache.internalCache : this.internalCache;
/*     */   }
/*     */   
/*     */   public Dns dns() {
/* 330 */     return this.dns;
/*     */   }
/*     */   
/*     */   public SocketFactory socketFactory() {
/* 334 */     return this.socketFactory;
/*     */   }
/*     */   
/*     */   public SSLSocketFactory sslSocketFactory() {
/* 338 */     return this.sslSocketFactory;
/*     */   }
/*     */   
/*     */   public HostnameVerifier hostnameVerifier() {
/* 342 */     return this.hostnameVerifier;
/*     */   }
/*     */   
/*     */   public CertificatePinner certificatePinner() {
/* 346 */     return this.certificatePinner;
/*     */   }
/*     */   
/*     */   public Authenticator authenticator() {
/* 350 */     return this.authenticator;
/*     */   }
/*     */   
/*     */   public Authenticator proxyAuthenticator() {
/* 354 */     return this.proxyAuthenticator;
/*     */   }
/*     */   
/*     */   public ConnectionPool connectionPool() {
/* 358 */     return this.connectionPool;
/*     */   }
/*     */   
/*     */   public boolean followSslRedirects() {
/* 362 */     return this.followSslRedirects;
/*     */   }
/*     */   
/*     */   public boolean followRedirects() {
/* 366 */     return this.followRedirects;
/*     */   }
/*     */   
/*     */   public boolean retryOnConnectionFailure() {
/* 370 */     return this.retryOnConnectionFailure;
/*     */   }
/*     */   
/*     */   public Dispatcher dispatcher() {
/* 374 */     return this.dispatcher;
/*     */   }
/*     */   
/*     */   public List<Protocol> protocols() {
/* 378 */     return this.protocols;
/*     */   }
/*     */   
/*     */   public List<ConnectionSpec> connectionSpecs() {
/* 382 */     return this.connectionSpecs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Interceptor> interceptors() {
/* 391 */     return this.interceptors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Interceptor> networkInterceptors() {
/* 400 */     return this.networkInterceptors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call newCall(Request request) {
/* 407 */     return new RealCall(this, request, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSocket newWebSocket(Request request, WebSocketListener listener) {
/* 414 */     RealWebSocket webSocket = new RealWebSocket(request, listener, new SecureRandom());
/* 415 */     webSocket.connect(this);
/* 416 */     return (WebSocket)webSocket;
/*     */   }
/*     */   
/*     */   public Builder newBuilder() {
/* 420 */     return new Builder(this);
/*     */   }
/*     */   
/*     */   public static final class Builder {
/*     */     Dispatcher dispatcher;
/*     */     Proxy proxy;
/*     */     List<Protocol> protocols;
/*     */     List<ConnectionSpec> connectionSpecs;
/* 428 */     final List<Interceptor> interceptors = new ArrayList<>();
/* 429 */     final List<Interceptor> networkInterceptors = new ArrayList<>();
/*     */     ProxySelector proxySelector;
/*     */     CookieJar cookieJar;
/*     */     Cache cache;
/*     */     InternalCache internalCache;
/*     */     SocketFactory socketFactory;
/*     */     SSLSocketFactory sslSocketFactory;
/*     */     CertificateChainCleaner certificateChainCleaner;
/*     */     HostnameVerifier hostnameVerifier;
/*     */     CertificatePinner certificatePinner;
/*     */     Authenticator proxyAuthenticator;
/*     */     Authenticator authenticator;
/*     */     ConnectionPool connectionPool;
/*     */     Dns dns;
/*     */     boolean followSslRedirects;
/*     */     boolean followRedirects;
/*     */     boolean retryOnConnectionFailure;
/*     */     int connectTimeout;
/*     */     int readTimeout;
/*     */     int writeTimeout;
/*     */     int pingInterval;
/*     */     
/*     */     public Builder() {
/* 452 */       this.dispatcher = new Dispatcher();
/* 453 */       this.protocols = OkHttpClient.DEFAULT_PROTOCOLS;
/* 454 */       this.connectionSpecs = OkHttpClient.DEFAULT_CONNECTION_SPECS;
/* 455 */       this.proxySelector = ProxySelector.getDefault();
/* 456 */       this.cookieJar = CookieJar.NO_COOKIES;
/* 457 */       this.socketFactory = SocketFactory.getDefault();
/* 458 */       this.hostnameVerifier = (HostnameVerifier)OkHostnameVerifier.INSTANCE;
/* 459 */       this.certificatePinner = CertificatePinner.DEFAULT;
/* 460 */       this.proxyAuthenticator = Authenticator.NONE;
/* 461 */       this.authenticator = Authenticator.NONE;
/* 462 */       this.connectionPool = new ConnectionPool();
/* 463 */       this.dns = Dns.SYSTEM;
/* 464 */       this.followSslRedirects = true;
/* 465 */       this.followRedirects = true;
/* 466 */       this.retryOnConnectionFailure = true;
/* 467 */       this.connectTimeout = 10000;
/* 468 */       this.readTimeout = 10000;
/* 469 */       this.writeTimeout = 10000;
/* 470 */       this.pingInterval = 0;
/*     */     }
/*     */     
/*     */     Builder(OkHttpClient okHttpClient) {
/* 474 */       this.dispatcher = okHttpClient.dispatcher;
/* 475 */       this.proxy = okHttpClient.proxy;
/* 476 */       this.protocols = okHttpClient.protocols;
/* 477 */       this.connectionSpecs = okHttpClient.connectionSpecs;
/* 478 */       this.interceptors.addAll(okHttpClient.interceptors);
/* 479 */       this.networkInterceptors.addAll(okHttpClient.networkInterceptors);
/* 480 */       this.proxySelector = okHttpClient.proxySelector;
/* 481 */       this.cookieJar = okHttpClient.cookieJar;
/* 482 */       this.internalCache = okHttpClient.internalCache;
/* 483 */       this.cache = okHttpClient.cache;
/* 484 */       this.socketFactory = okHttpClient.socketFactory;
/* 485 */       this.sslSocketFactory = okHttpClient.sslSocketFactory;
/* 486 */       this.certificateChainCleaner = okHttpClient.certificateChainCleaner;
/* 487 */       this.hostnameVerifier = okHttpClient.hostnameVerifier;
/* 488 */       this.certificatePinner = okHttpClient.certificatePinner;
/* 489 */       this.proxyAuthenticator = okHttpClient.proxyAuthenticator;
/* 490 */       this.authenticator = okHttpClient.authenticator;
/* 491 */       this.connectionPool = okHttpClient.connectionPool;
/* 492 */       this.dns = okHttpClient.dns;
/* 493 */       this.followSslRedirects = okHttpClient.followSslRedirects;
/* 494 */       this.followRedirects = okHttpClient.followRedirects;
/* 495 */       this.retryOnConnectionFailure = okHttpClient.retryOnConnectionFailure;
/* 496 */       this.connectTimeout = okHttpClient.connectTimeout;
/* 497 */       this.readTimeout = okHttpClient.readTimeout;
/* 498 */       this.writeTimeout = okHttpClient.writeTimeout;
/* 499 */       this.pingInterval = okHttpClient.pingInterval;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder connectTimeout(long timeout, TimeUnit unit) {
/* 508 */       this.connectTimeout = checkDuration("timeout", timeout, unit);
/* 509 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder readTimeout(long timeout, TimeUnit unit) {
/* 517 */       this.readTimeout = checkDuration("timeout", timeout, unit);
/* 518 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder writeTimeout(long timeout, TimeUnit unit) {
/* 526 */       this.writeTimeout = checkDuration("timeout", timeout, unit);
/* 527 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder pingInterval(long interval, TimeUnit unit) {
/* 539 */       this.pingInterval = checkDuration("interval", interval, unit);
/* 540 */       return this;
/*     */     }
/*     */     
/*     */     private static int checkDuration(String name, long duration, TimeUnit unit) {
/* 544 */       if (duration < 0L) throw new IllegalArgumentException(name + " < 0"); 
/* 545 */       if (unit == null) throw new NullPointerException("unit == null"); 
/* 546 */       long millis = unit.toMillis(duration);
/* 547 */       if (millis > 2147483647L) throw new IllegalArgumentException(name + " too large."); 
/* 548 */       if (millis == 0L && duration > 0L) throw new IllegalArgumentException(name + " too small."); 
/* 549 */       return (int)millis;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder proxy(Proxy proxy) {
/* 558 */       this.proxy = proxy;
/* 559 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder proxySelector(ProxySelector proxySelector) {
/* 571 */       this.proxySelector = proxySelector;
/* 572 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder cookieJar(CookieJar cookieJar) {
/* 582 */       if (cookieJar == null) throw new NullPointerException("cookieJar == null"); 
/* 583 */       this.cookieJar = cookieJar;
/* 584 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     void setInternalCache(InternalCache internalCache) {
/* 589 */       this.internalCache = internalCache;
/* 590 */       this.cache = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder cache(Cache cache) {
/* 595 */       this.cache = cache;
/* 596 */       this.internalCache = null;
/* 597 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder dns(Dns dns) {
/* 606 */       if (dns == null) throw new NullPointerException("dns == null"); 
/* 607 */       this.dns = dns;
/* 608 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder socketFactory(SocketFactory socketFactory) {
/* 620 */       if (socketFactory == null) throw new NullPointerException("socketFactory == null"); 
/* 621 */       this.socketFactory = socketFactory;
/* 622 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder sslSocketFactory(SSLSocketFactory sslSocketFactory) {
/* 635 */       if (sslSocketFactory == null) throw new NullPointerException("sslSocketFactory == null"); 
/* 636 */       X509TrustManager trustManager = Platform.get().trustManager(sslSocketFactory);
/* 637 */       if (trustManager == null) {
/* 638 */         throw new IllegalStateException("Unable to extract the trust manager on " + Platform.get() + ", sslSocketFactory is " + sslSocketFactory
/* 639 */             .getClass());
/*     */       }
/* 641 */       this.sslSocketFactory = sslSocketFactory;
/* 642 */       this.certificateChainCleaner = CertificateChainCleaner.get(trustManager);
/* 643 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder sslSocketFactory(SSLSocketFactory sslSocketFactory, X509TrustManager trustManager) {
/* 678 */       if (sslSocketFactory == null) throw new NullPointerException("sslSocketFactory == null"); 
/* 679 */       if (trustManager == null) throw new NullPointerException("trustManager == null"); 
/* 680 */       this.sslSocketFactory = sslSocketFactory;
/* 681 */       this.certificateChainCleaner = CertificateChainCleaner.get(trustManager);
/* 682 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder hostnameVerifier(HostnameVerifier hostnameVerifier) {
/* 692 */       if (hostnameVerifier == null) throw new NullPointerException("hostnameVerifier == null"); 
/* 693 */       this.hostnameVerifier = hostnameVerifier;
/* 694 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder certificatePinner(CertificatePinner certificatePinner) {
/* 703 */       if (certificatePinner == null) throw new NullPointerException("certificatePinner == null"); 
/* 704 */       this.certificatePinner = certificatePinner;
/* 705 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder authenticator(Authenticator authenticator) {
/* 715 */       if (authenticator == null) throw new NullPointerException("authenticator == null"); 
/* 716 */       this.authenticator = authenticator;
/* 717 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder proxyAuthenticator(Authenticator proxyAuthenticator) {
/* 727 */       if (proxyAuthenticator == null) throw new NullPointerException("proxyAuthenticator == null"); 
/* 728 */       this.proxyAuthenticator = proxyAuthenticator;
/* 729 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder connectionPool(ConnectionPool connectionPool) {
/* 738 */       if (connectionPool == null) throw new NullPointerException("connectionPool == null"); 
/* 739 */       this.connectionPool = connectionPool;
/* 740 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder followSslRedirects(boolean followProtocolRedirects) {
/* 750 */       this.followSslRedirects = followProtocolRedirects;
/* 751 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder followRedirects(boolean followRedirects) {
/* 756 */       this.followRedirects = followRedirects;
/* 757 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder retryOnConnectionFailure(boolean retryOnConnectionFailure) {
/* 779 */       this.retryOnConnectionFailure = retryOnConnectionFailure;
/* 780 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder dispatcher(Dispatcher dispatcher) {
/* 787 */       if (dispatcher == null) throw new IllegalArgumentException("dispatcher == null"); 
/* 788 */       this.dispatcher = dispatcher;
/* 789 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder protocols(List<Protocol> protocols) {
/* 821 */       protocols = new ArrayList<>(protocols);
/*     */ 
/*     */       
/* 824 */       if (!protocols.contains(Protocol.HTTP_1_1)) {
/* 825 */         throw new IllegalArgumentException("protocols doesn't contain http/1.1: " + protocols);
/*     */       }
/* 827 */       if (protocols.contains(Protocol.HTTP_1_0)) {
/* 828 */         throw new IllegalArgumentException("protocols must not contain http/1.0: " + protocols);
/*     */       }
/* 830 */       if (protocols.contains(null)) {
/* 831 */         throw new IllegalArgumentException("protocols must not contain null");
/*     */       }
/*     */ 
/*     */       
/* 835 */       if (protocols.contains(Protocol.SPDY_3)) {
/* 836 */         protocols.remove(Protocol.SPDY_3);
/*     */       }
/*     */ 
/*     */       
/* 840 */       this.protocols = Collections.unmodifiableList(protocols);
/* 841 */       return this;
/*     */     }
/*     */     
/*     */     public Builder connectionSpecs(List<ConnectionSpec> connectionSpecs) {
/* 845 */       this.connectionSpecs = Util.immutableList(connectionSpecs);
/* 846 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Interceptor> interceptors() {
/* 855 */       return this.interceptors;
/*     */     }
/*     */     
/*     */     public Builder addInterceptor(Interceptor interceptor) {
/* 859 */       this.interceptors.add(interceptor);
/* 860 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Interceptor> networkInterceptors() {
/* 869 */       return this.networkInterceptors;
/*     */     }
/*     */     
/*     */     public Builder addNetworkInterceptor(Interceptor interceptor) {
/* 873 */       this.networkInterceptors.add(interceptor);
/* 874 */       return this;
/*     */     }
/*     */     
/*     */     public OkHttpClient build() {
/* 878 */       return new OkHttpClient(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\OkHttpClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */