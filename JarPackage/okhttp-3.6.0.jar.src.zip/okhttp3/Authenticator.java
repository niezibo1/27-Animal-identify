/*    */ package okhttp3;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Authenticator
/*    */ {
/* 63 */   public static final Authenticator NONE = new Authenticator() {
/*    */       public Request authenticate(Route route, Response response) {
/* 65 */         return null;
/*    */       }
/*    */     };
/*    */   
/*    */   Request authenticate(Route paramRoute, Response paramResponse) throws IOException;
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Authenticator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */