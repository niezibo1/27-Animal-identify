package okhttp3;

import java.net.Socket;

public interface Connection {
  Route route();
  
  Socket socket();
  
  Handshake handshake();
  
  Protocol protocol();
}


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Connection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */