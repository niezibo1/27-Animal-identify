package okhttp3;

import okio.ByteString;

public interface WebSocket {
  Request request();
  
  long queueSize();
  
  boolean send(String paramString);
  
  boolean send(ByteString paramByteString);
  
  boolean close(int paramInt, String paramString);
  
  void cancel();
  
  public static interface Factory {
    WebSocket newWebSocket(Request param1Request, WebSocketListener param1WebSocketListener);
  }
}


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\WebSocket.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */