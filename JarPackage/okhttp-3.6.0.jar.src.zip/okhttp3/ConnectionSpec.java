/*     */ package okhttp3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import okhttp3.internal.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectionSpec
/*     */ {
/*  45 */   private static final CipherSuite[] APPROVED_CIPHER_SUITES = new CipherSuite[] { CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA, CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA, CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA, CipherSuite.TLS_RSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_RSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_RSA_WITH_AES_128_CBC_SHA, CipherSuite.TLS_RSA_WITH_AES_256_CBC_SHA, CipherSuite.TLS_RSA_WITH_3DES_EDE_CBC_SHA };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static final ConnectionSpec MODERN_TLS = (new Builder(true))
/*  69 */     .cipherSuites(APPROVED_CIPHER_SUITES)
/*  70 */     .tlsVersions(new TlsVersion[] { TlsVersion.TLS_1_3, TlsVersion.TLS_1_2, TlsVersion.TLS_1_1, TlsVersion.TLS_1_0
/*  71 */       }).supportsTlsExtensions(true)
/*  72 */     .build();
/*     */ 
/*     */   
/*  75 */   public static final ConnectionSpec COMPATIBLE_TLS = (new Builder(MODERN_TLS))
/*  76 */     .tlsVersions(new TlsVersion[] { TlsVersion.TLS_1_0
/*  77 */       }).supportsTlsExtensions(true)
/*  78 */     .build();
/*     */ 
/*     */   
/*  81 */   public static final ConnectionSpec CLEARTEXT = (new Builder(false)).build();
/*     */   
/*     */   final boolean tls;
/*     */   final boolean supportsTlsExtensions;
/*     */   final String[] cipherSuites;
/*     */   final String[] tlsVersions;
/*     */   
/*     */   ConnectionSpec(Builder builder) {
/*  89 */     this.tls = builder.tls;
/*  90 */     this.cipherSuites = builder.cipherSuites;
/*  91 */     this.tlsVersions = builder.tlsVersions;
/*  92 */     this.supportsTlsExtensions = builder.supportsTlsExtensions;
/*     */   }
/*     */   
/*     */   public boolean isTls() {
/*  96 */     return this.tls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CipherSuite> cipherSuites() {
/* 104 */     if (this.cipherSuites == null) return null;
/*     */     
/* 106 */     List<CipherSuite> result = new ArrayList<>(this.cipherSuites.length);
/* 107 */     for (String cipherSuite : this.cipherSuites) {
/* 108 */       result.add(CipherSuite.forJavaName(cipherSuite));
/*     */     }
/* 110 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TlsVersion> tlsVersions() {
/* 118 */     if (this.tlsVersions == null) return null;
/*     */     
/* 120 */     List<TlsVersion> result = new ArrayList<>(this.tlsVersions.length);
/* 121 */     for (String tlsVersion : this.tlsVersions) {
/* 122 */       result.add(TlsVersion.forJavaName(tlsVersion));
/*     */     }
/* 124 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */   
/*     */   public boolean supportsTlsExtensions() {
/* 128 */     return this.supportsTlsExtensions;
/*     */   }
/*     */ 
/*     */   
/*     */   void apply(SSLSocket sslSocket, boolean isFallback) {
/* 133 */     ConnectionSpec specToApply = supportedSpec(sslSocket, isFallback);
/*     */     
/* 135 */     if (specToApply.tlsVersions != null) {
/* 136 */       sslSocket.setEnabledProtocols(specToApply.tlsVersions);
/*     */     }
/* 138 */     if (specToApply.cipherSuites != null) {
/* 139 */       sslSocket.setEnabledCipherSuites(specToApply.cipherSuites);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConnectionSpec supportedSpec(SSLSocket sslSocket, boolean isFallback) {
/* 150 */     String[] cipherSuitesIntersection = (this.cipherSuites != null) ? (String[])Util.intersect(String.class, (Object[])this.cipherSuites, (Object[])sslSocket.getEnabledCipherSuites()) : sslSocket.getEnabledCipherSuites();
/*     */ 
/*     */     
/* 153 */     String[] tlsVersionsIntersection = (this.tlsVersions != null) ? (String[])Util.intersect(String.class, (Object[])this.tlsVersions, (Object[])sslSocket.getEnabledProtocols()) : sslSocket.getEnabledProtocols();
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (isFallback && Util.indexOf((Object[])sslSocket.getSupportedCipherSuites(), "TLS_FALLBACK_SCSV") != -1) {
/* 158 */       cipherSuitesIntersection = Util.concat(cipherSuitesIntersection, "TLS_FALLBACK_SCSV");
/*     */     }
/*     */     
/* 161 */     return (new Builder(this))
/* 162 */       .cipherSuites(cipherSuitesIntersection)
/* 163 */       .tlsVersions(tlsVersionsIntersection)
/* 164 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatible(SSLSocket socket) {
/* 179 */     if (!this.tls) {
/* 180 */       return false;
/*     */     }
/*     */     
/* 183 */     if (this.tlsVersions != null && 
/* 184 */       !nonEmptyIntersection(this.tlsVersions, socket.getEnabledProtocols())) {
/* 185 */       return false;
/*     */     }
/*     */     
/* 188 */     if (this.cipherSuites != null && 
/* 189 */       !nonEmptyIntersection(this.cipherSuites, socket.getEnabledCipherSuites())) {
/* 190 */       return false;
/*     */     }
/*     */     
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean nonEmptyIntersection(String[] a, String[] b) {
/* 202 */     if (a == null || b == null || a.length == 0 || b.length == 0) {
/* 203 */       return false;
/*     */     }
/* 205 */     for (String toFind : a) {
/* 206 */       if (Util.indexOf((Object[])b, toFind) != -1) {
/* 207 */         return true;
/*     */       }
/*     */     } 
/* 210 */     return false;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 214 */     if (!(other instanceof ConnectionSpec)) return false; 
/* 215 */     if (other == this) return true;
/*     */     
/* 217 */     ConnectionSpec that = (ConnectionSpec)other;
/* 218 */     if (this.tls != that.tls) return false;
/*     */     
/* 220 */     if (this.tls) {
/* 221 */       if (!Arrays.equals((Object[])this.cipherSuites, (Object[])that.cipherSuites)) return false; 
/* 222 */       if (!Arrays.equals((Object[])this.tlsVersions, (Object[])that.tlsVersions)) return false; 
/* 223 */       if (this.supportsTlsExtensions != that.supportsTlsExtensions) return false;
/*     */     
/*     */     } 
/* 226 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 230 */     int result = 17;
/* 231 */     if (this.tls) {
/* 232 */       result = 31 * result + Arrays.hashCode((Object[])this.cipherSuites);
/* 233 */       result = 31 * result + Arrays.hashCode((Object[])this.tlsVersions);
/* 234 */       result = 31 * result + (this.supportsTlsExtensions ? 0 : 1);
/*     */     } 
/* 236 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 240 */     if (!this.tls) {
/* 241 */       return "ConnectionSpec()";
/*     */     }
/*     */     
/* 244 */     String cipherSuitesString = (this.cipherSuites != null) ? cipherSuites().toString() : "[all enabled]";
/* 245 */     String tlsVersionsString = (this.tlsVersions != null) ? tlsVersions().toString() : "[all enabled]";
/* 246 */     return "ConnectionSpec(cipherSuites=" + cipherSuitesString + ", tlsVersions=" + tlsVersionsString + ", supportsTlsExtensions=" + this.supportsTlsExtensions + ")";
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     boolean tls;
/*     */     
/*     */     String[] cipherSuites;
/*     */     
/*     */     String[] tlsVersions;
/*     */     boolean supportsTlsExtensions;
/*     */     
/*     */     Builder(boolean tls) {
/* 260 */       this.tls = tls;
/*     */     }
/*     */     
/*     */     public Builder(ConnectionSpec connectionSpec) {
/* 264 */       this.tls = connectionSpec.tls;
/* 265 */       this.cipherSuites = connectionSpec.cipherSuites;
/* 266 */       this.tlsVersions = connectionSpec.tlsVersions;
/* 267 */       this.supportsTlsExtensions = connectionSpec.supportsTlsExtensions;
/*     */     }
/*     */     
/*     */     public Builder allEnabledCipherSuites() {
/* 271 */       if (!this.tls) throw new IllegalStateException("no cipher suites for cleartext connections"); 
/* 272 */       this.cipherSuites = null;
/* 273 */       return this;
/*     */     }
/*     */     
/*     */     public Builder cipherSuites(CipherSuite... cipherSuites) {
/* 277 */       if (!this.tls) throw new IllegalStateException("no cipher suites for cleartext connections");
/*     */       
/* 279 */       String[] strings = new String[cipherSuites.length];
/* 280 */       for (int i = 0; i < cipherSuites.length; i++) {
/* 281 */         strings[i] = (cipherSuites[i]).javaName;
/*     */       }
/* 283 */       return cipherSuites(strings);
/*     */     }
/*     */     
/*     */     public Builder cipherSuites(String... cipherSuites) {
/* 287 */       if (!this.tls) throw new IllegalStateException("no cipher suites for cleartext connections");
/*     */       
/* 289 */       if (cipherSuites.length == 0) {
/* 290 */         throw new IllegalArgumentException("At least one cipher suite is required");
/*     */       }
/*     */       
/* 293 */       this.cipherSuites = (String[])cipherSuites.clone();
/* 294 */       return this;
/*     */     }
/*     */     
/*     */     public Builder allEnabledTlsVersions() {
/* 298 */       if (!this.tls) throw new IllegalStateException("no TLS versions for cleartext connections"); 
/* 299 */       this.tlsVersions = null;
/* 300 */       return this;
/*     */     }
/*     */     
/*     */     public Builder tlsVersions(TlsVersion... tlsVersions) {
/* 304 */       if (!this.tls) throw new IllegalStateException("no TLS versions for cleartext connections");
/*     */       
/* 306 */       String[] strings = new String[tlsVersions.length];
/* 307 */       for (int i = 0; i < tlsVersions.length; i++) {
/* 308 */         strings[i] = (tlsVersions[i]).javaName;
/*     */       }
/*     */       
/* 311 */       return tlsVersions(strings);
/*     */     }
/*     */     
/*     */     public Builder tlsVersions(String... tlsVersions) {
/* 315 */       if (!this.tls) throw new IllegalStateException("no TLS versions for cleartext connections");
/*     */       
/* 317 */       if (tlsVersions.length == 0) {
/* 318 */         throw new IllegalArgumentException("At least one TLS version is required");
/*     */       }
/*     */       
/* 321 */       this.tlsVersions = (String[])tlsVersions.clone();
/* 322 */       return this;
/*     */     }
/*     */     
/*     */     public Builder supportsTlsExtensions(boolean supportsTlsExtensions) {
/* 326 */       if (!this.tls) throw new IllegalStateException("no TLS extensions for cleartext connections"); 
/* 327 */       this.supportsTlsExtensions = supportsTlsExtensions;
/* 328 */       return this;
/*     */     }
/*     */     
/*     */     public ConnectionSpec build() {
/* 332 */       return new ConnectionSpec(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\ConnectionSpec.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */