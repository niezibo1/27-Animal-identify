/*     */ package okhttp3;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.Flushable;
/*     */ import java.io.IOException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.cache.CacheRequest;
/*     */ import okhttp3.internal.cache.CacheStrategy;
/*     */ import okhttp3.internal.cache.DiskLruCache;
/*     */ import okhttp3.internal.cache.InternalCache;
/*     */ import okhttp3.internal.http.HttpHeaders;
/*     */ import okhttp3.internal.http.HttpMethod;
/*     */ import okhttp3.internal.http.StatusLine;
/*     */ import okhttp3.internal.io.FileSystem;
/*     */ import okhttp3.internal.platform.Platform;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSink;
/*     */ import okio.BufferedSource;
/*     */ import okio.ByteString;
/*     */ import okio.ForwardingSink;
/*     */ import okio.ForwardingSource;
/*     */ import okio.Okio;
/*     */ import okio.Sink;
/*     */ import okio.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Cache
/*     */   implements Closeable, Flushable
/*     */ {
/*     */   private static final int VERSION = 201105;
/*     */   private static final int ENTRY_METADATA = 0;
/*     */   private static final int ENTRY_BODY = 1;
/*     */   private static final int ENTRY_COUNT = 2;
/*     */   
/* 142 */   final InternalCache internalCache = new InternalCache() {
/*     */       public Response get(Request request) throws IOException {
/* 144 */         return Cache.this.get(request);
/*     */       }
/*     */       
/*     */       public CacheRequest put(Response response) throws IOException {
/* 148 */         return Cache.this.put(response);
/*     */       }
/*     */       
/*     */       public void remove(Request request) throws IOException {
/* 152 */         Cache.this.remove(request);
/*     */       }
/*     */       
/*     */       public void update(Response cached, Response network) {
/* 156 */         Cache.this.update(cached, network);
/*     */       }
/*     */       
/*     */       public void trackConditionalCacheHit() {
/* 160 */         Cache.this.trackConditionalCacheHit();
/*     */       }
/*     */       
/*     */       public void trackResponse(CacheStrategy cacheStrategy) {
/* 164 */         Cache.this.trackResponse(cacheStrategy);
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   final DiskLruCache cache;
/*     */   
/*     */   int writeSuccessCount;
/*     */   int writeAbortCount;
/*     */   private int networkCount;
/*     */   private int hitCount;
/*     */   private int requestCount;
/*     */   
/*     */   public Cache(File directory, long maxSize) {
/* 178 */     this(directory, maxSize, FileSystem.SYSTEM);
/*     */   }
/*     */   
/*     */   Cache(File directory, long maxSize, FileSystem fileSystem) {
/* 182 */     this.cache = DiskLruCache.create(fileSystem, directory, 201105, 2, maxSize);
/*     */   }
/*     */   
/*     */   public static String key(HttpUrl url) {
/* 186 */     return ByteString.encodeUtf8(url.toString()).md5().hex();
/*     */   } Response get(Request request) {
/*     */     DiskLruCache.Snapshot snapshot;
/*     */     Entry entry;
/* 190 */     String key = key(request.url());
/*     */ 
/*     */     
/*     */     try {
/* 194 */       snapshot = this.cache.get(key);
/* 195 */       if (snapshot == null) {
/* 196 */         return null;
/*     */       }
/* 198 */     } catch (IOException e) {
/*     */       
/* 200 */       return null;
/*     */     } 
/*     */     
/*     */     try {
/* 204 */       entry = new Entry(snapshot.getSource(0));
/* 205 */     } catch (IOException e) {
/* 206 */       Util.closeQuietly((Closeable)snapshot);
/* 207 */       return null;
/*     */     } 
/*     */     
/* 210 */     Response response = entry.response(snapshot);
/*     */     
/* 212 */     if (!entry.matches(request, response)) {
/* 213 */       Util.closeQuietly(response.body());
/* 214 */       return null;
/*     */     } 
/*     */     
/* 217 */     return response;
/*     */   }
/*     */   
/*     */   CacheRequest put(Response response) {
/* 221 */     String requestMethod = response.request().method();
/*     */     
/* 223 */     if (HttpMethod.invalidatesCache(response.request().method())) {
/*     */       try {
/* 225 */         remove(response.request());
/* 226 */       } catch (IOException iOException) {}
/*     */ 
/*     */       
/* 229 */       return null;
/*     */     } 
/* 231 */     if (!requestMethod.equals("GET"))
/*     */     {
/*     */ 
/*     */       
/* 235 */       return null;
/*     */     }
/*     */     
/* 238 */     if (HttpHeaders.hasVaryAll(response)) {
/* 239 */       return null;
/*     */     }
/*     */     
/* 242 */     Entry entry = new Entry(response);
/* 243 */     DiskLruCache.Editor editor = null;
/*     */     try {
/* 245 */       editor = this.cache.edit(key(response.request().url()));
/* 246 */       if (editor == null) {
/* 247 */         return null;
/*     */       }
/* 249 */       entry.writeTo(editor);
/* 250 */       return new CacheRequestImpl(editor);
/* 251 */     } catch (IOException e) {
/* 252 */       abortQuietly(editor);
/* 253 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   void remove(Request request) throws IOException {
/* 258 */     this.cache.remove(key(request.url()));
/*     */   }
/*     */   
/*     */   void update(Response cached, Response network) {
/* 262 */     Entry entry = new Entry(network);
/* 263 */     DiskLruCache.Snapshot snapshot = ((CacheResponseBody)cached.body()).snapshot;
/* 264 */     DiskLruCache.Editor editor = null;
/*     */     try {
/* 266 */       editor = snapshot.edit();
/* 267 */       if (editor != null) {
/* 268 */         entry.writeTo(editor);
/* 269 */         editor.commit();
/*     */       } 
/* 271 */     } catch (IOException e) {
/* 272 */       abortQuietly(editor);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void abortQuietly(DiskLruCache.Editor editor) {
/*     */     try {
/* 279 */       if (editor != null) {
/* 280 */         editor.abort();
/*     */       }
/* 282 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() throws IOException {
/* 298 */     this.cache.initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() throws IOException {
/* 306 */     this.cache.delete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void evictAll() throws IOException {
/* 314 */     this.cache.evictAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<String> urls() throws IOException {
/* 327 */     return new Iterator<String>() {
/* 328 */         final Iterator<DiskLruCache.Snapshot> delegate = Cache.this.cache.snapshots();
/*     */         
/*     */         String nextUrl;
/*     */         boolean canRemove;
/*     */         
/*     */         public boolean hasNext() {
/* 334 */           if (this.nextUrl != null) return true;
/*     */           
/* 336 */           this.canRemove = false;
/* 337 */           while (this.delegate.hasNext()) {
/* 338 */             DiskLruCache.Snapshot snapshot = this.delegate.next();
/*     */             try {
/* 340 */               BufferedSource metadata = Okio.buffer(snapshot.getSource(0));
/* 341 */               this.nextUrl = metadata.readUtf8LineStrict();
/* 342 */               return true;
/* 343 */             } catch (IOException iOException) {
/*     */ 
/*     */             
/*     */             } finally {
/* 347 */               snapshot.close();
/*     */             } 
/*     */           } 
/*     */           
/* 351 */           return false;
/*     */         }
/*     */         
/*     */         public String next() {
/* 355 */           if (!hasNext()) throw new NoSuchElementException(); 
/* 356 */           String result = this.nextUrl;
/* 357 */           this.nextUrl = null;
/* 358 */           this.canRemove = true;
/* 359 */           return result;
/*     */         }
/*     */         
/*     */         public void remove() {
/* 363 */           if (!this.canRemove) throw new IllegalStateException("remove() before next()"); 
/* 364 */           this.delegate.remove();
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public synchronized int writeAbortCount() {
/* 370 */     return this.writeAbortCount;
/*     */   }
/*     */   
/*     */   public synchronized int writeSuccessCount() {
/* 374 */     return this.writeSuccessCount;
/*     */   }
/*     */   
/*     */   public long size() throws IOException {
/* 378 */     return this.cache.size();
/*     */   }
/*     */   
/*     */   public long maxSize() {
/* 382 */     return this.cache.getMaxSize();
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 386 */     this.cache.flush();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 390 */     this.cache.close();
/*     */   }
/*     */   
/*     */   public File directory() {
/* 394 */     return this.cache.getDirectory();
/*     */   }
/*     */   
/*     */   public boolean isClosed() {
/* 398 */     return this.cache.isClosed();
/*     */   }
/*     */   
/*     */   synchronized void trackResponse(CacheStrategy cacheStrategy) {
/* 402 */     this.requestCount++;
/*     */     
/* 404 */     if (cacheStrategy.networkRequest != null) {
/*     */       
/* 406 */       this.networkCount++;
/* 407 */     } else if (cacheStrategy.cacheResponse != null) {
/*     */       
/* 409 */       this.hitCount++;
/*     */     } 
/*     */   }
/*     */   
/*     */   synchronized void trackConditionalCacheHit() {
/* 414 */     this.hitCount++;
/*     */   }
/*     */   
/*     */   public synchronized int networkCount() {
/* 418 */     return this.networkCount;
/*     */   }
/*     */   
/*     */   public synchronized int hitCount() {
/* 422 */     return this.hitCount;
/*     */   }
/*     */   
/*     */   public synchronized int requestCount() {
/* 426 */     return this.requestCount;
/*     */   }
/*     */   
/*     */   private final class CacheRequestImpl implements CacheRequest {
/*     */     private final DiskLruCache.Editor editor;
/*     */     private Sink cacheOut;
/*     */     private Sink body;
/*     */     boolean done;
/*     */     
/*     */     public CacheRequestImpl(final DiskLruCache.Editor editor) {
/* 436 */       this.editor = editor;
/* 437 */       this.cacheOut = editor.newSink(1);
/* 438 */       this.body = (Sink)new ForwardingSink(this.cacheOut) {
/*     */           public void close() throws IOException {
/* 440 */             synchronized (Cache.this) {
/* 441 */               if (Cache.CacheRequestImpl.this.done) {
/*     */                 return;
/*     */               }
/* 444 */               Cache.CacheRequestImpl.this.done = true;
/* 445 */               Cache.this.writeSuccessCount++;
/*     */             } 
/* 447 */             super.close();
/* 448 */             editor.commit();
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     public void abort() {
/* 454 */       synchronized (Cache.this) {
/* 455 */         if (this.done) {
/*     */           return;
/*     */         }
/* 458 */         this.done = true;
/* 459 */         Cache.this.writeAbortCount++;
/*     */       } 
/* 461 */       Util.closeQuietly((Closeable)this.cacheOut);
/*     */       try {
/* 463 */         this.editor.abort();
/* 464 */       } catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */     
/*     */     public Sink body() {
/* 469 */       return this.body;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class Entry
/*     */   {
/* 475 */     private static final String SENT_MILLIS = Platform.get().getPrefix() + "-Sent-Millis";
/*     */ 
/*     */     
/* 478 */     private static final String RECEIVED_MILLIS = Platform.get().getPrefix() + "-Received-Millis";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String url;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Headers varyHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String requestMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Protocol protocol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int code;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String message;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Headers responseHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Handshake handshake;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final long sentRequestMillis;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final long receivedResponseMillis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Entry(Source in) throws IOException {
/*     */       try {
/* 541 */         BufferedSource source = Okio.buffer(in);
/* 542 */         this.url = source.readUtf8LineStrict();
/* 543 */         this.requestMethod = source.readUtf8LineStrict();
/* 544 */         Headers.Builder varyHeadersBuilder = new Headers.Builder();
/* 545 */         int varyRequestHeaderLineCount = Cache.readInt(source);
/* 546 */         for (int i = 0; i < varyRequestHeaderLineCount; i++) {
/* 547 */           varyHeadersBuilder.addLenient(source.readUtf8LineStrict());
/*     */         }
/* 549 */         this.varyHeaders = varyHeadersBuilder.build();
/*     */         
/* 551 */         StatusLine statusLine = StatusLine.parse(source.readUtf8LineStrict());
/* 552 */         this.protocol = statusLine.protocol;
/* 553 */         this.code = statusLine.code;
/* 554 */         this.message = statusLine.message;
/* 555 */         Headers.Builder responseHeadersBuilder = new Headers.Builder();
/* 556 */         int responseHeaderLineCount = Cache.readInt(source);
/* 557 */         for (int j = 0; j < responseHeaderLineCount; j++) {
/* 558 */           responseHeadersBuilder.addLenient(source.readUtf8LineStrict());
/*     */         }
/* 560 */         String sendRequestMillisString = responseHeadersBuilder.get(SENT_MILLIS);
/* 561 */         String receivedResponseMillisString = responseHeadersBuilder.get(RECEIVED_MILLIS);
/* 562 */         responseHeadersBuilder.removeAll(SENT_MILLIS);
/* 563 */         responseHeadersBuilder.removeAll(RECEIVED_MILLIS);
/* 564 */         this
/* 565 */           .sentRequestMillis = (sendRequestMillisString != null) ? Long.parseLong(sendRequestMillisString) : 0L;
/*     */         
/* 567 */         this
/* 568 */           .receivedResponseMillis = (receivedResponseMillisString != null) ? Long.parseLong(receivedResponseMillisString) : 0L;
/*     */         
/* 570 */         this.responseHeaders = responseHeadersBuilder.build();
/*     */         
/* 572 */         if (isHttps()) {
/* 573 */           String blank = source.readUtf8LineStrict();
/* 574 */           if (blank.length() > 0) {
/* 575 */             throw new IOException("expected \"\" but was \"" + blank + "\"");
/*     */           }
/* 577 */           String cipherSuiteString = source.readUtf8LineStrict();
/* 578 */           CipherSuite cipherSuite = CipherSuite.forJavaName(cipherSuiteString);
/* 579 */           List<Certificate> peerCertificates = readCertificateList(source);
/* 580 */           List<Certificate> localCertificates = readCertificateList(source);
/*     */           
/* 582 */           TlsVersion tlsVersion = !source.exhausted() ? TlsVersion.forJavaName(source.readUtf8LineStrict()) : null;
/*     */           
/* 584 */           this.handshake = Handshake.get(tlsVersion, cipherSuite, peerCertificates, localCertificates);
/*     */         } else {
/* 586 */           this.handshake = null;
/*     */         } 
/*     */       } finally {
/* 589 */         in.close();
/*     */       } 
/*     */     }
/*     */     
/*     */     public Entry(Response response) {
/* 594 */       this.url = response.request().url().toString();
/* 595 */       this.varyHeaders = HttpHeaders.varyHeaders(response);
/* 596 */       this.requestMethod = response.request().method();
/* 597 */       this.protocol = response.protocol();
/* 598 */       this.code = response.code();
/* 599 */       this.message = response.message();
/* 600 */       this.responseHeaders = response.headers();
/* 601 */       this.handshake = response.handshake();
/* 602 */       this.sentRequestMillis = response.sentRequestAtMillis();
/* 603 */       this.receivedResponseMillis = response.receivedResponseAtMillis();
/*     */     }
/*     */     
/*     */     public void writeTo(DiskLruCache.Editor editor) throws IOException {
/* 607 */       BufferedSink sink = Okio.buffer(editor.newSink(0));
/*     */       
/* 609 */       sink.writeUtf8(this.url)
/* 610 */         .writeByte(10);
/* 611 */       sink.writeUtf8(this.requestMethod)
/* 612 */         .writeByte(10);
/* 613 */       sink.writeDecimalLong(this.varyHeaders.size())
/* 614 */         .writeByte(10); int i, size;
/* 615 */       for (i = 0, size = this.varyHeaders.size(); i < size; i++) {
/* 616 */         sink.writeUtf8(this.varyHeaders.name(i))
/* 617 */           .writeUtf8(": ")
/* 618 */           .writeUtf8(this.varyHeaders.value(i))
/* 619 */           .writeByte(10);
/*     */       }
/*     */       
/* 622 */       sink.writeUtf8((new StatusLine(this.protocol, this.code, this.message)).toString())
/* 623 */         .writeByte(10);
/* 624 */       sink.writeDecimalLong((this.responseHeaders.size() + 2))
/* 625 */         .writeByte(10);
/* 626 */       for (i = 0, size = this.responseHeaders.size(); i < size; i++) {
/* 627 */         sink.writeUtf8(this.responseHeaders.name(i))
/* 628 */           .writeUtf8(": ")
/* 629 */           .writeUtf8(this.responseHeaders.value(i))
/* 630 */           .writeByte(10);
/*     */       }
/* 632 */       sink.writeUtf8(SENT_MILLIS)
/* 633 */         .writeUtf8(": ")
/* 634 */         .writeDecimalLong(this.sentRequestMillis)
/* 635 */         .writeByte(10);
/* 636 */       sink.writeUtf8(RECEIVED_MILLIS)
/* 637 */         .writeUtf8(": ")
/* 638 */         .writeDecimalLong(this.receivedResponseMillis)
/* 639 */         .writeByte(10);
/*     */       
/* 641 */       if (isHttps()) {
/* 642 */         sink.writeByte(10);
/* 643 */         sink.writeUtf8(this.handshake.cipherSuite().javaName())
/* 644 */           .writeByte(10);
/* 645 */         writeCertList(sink, this.handshake.peerCertificates());
/* 646 */         writeCertList(sink, this.handshake.localCertificates());
/*     */         
/* 648 */         if (this.handshake.tlsVersion() != null) {
/* 649 */           sink.writeUtf8(this.handshake.tlsVersion().javaName())
/* 650 */             .writeByte(10);
/*     */         }
/*     */       } 
/* 653 */       sink.close();
/*     */     }
/*     */     
/*     */     private boolean isHttps() {
/* 657 */       return this.url.startsWith("https://");
/*     */     }
/*     */     
/*     */     private List<Certificate> readCertificateList(BufferedSource source) throws IOException {
/* 661 */       int length = Cache.readInt(source);
/* 662 */       if (length == -1) return Collections.emptyList();
/*     */       
/*     */       try {
/* 665 */         CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
/* 666 */         List<Certificate> result = new ArrayList<>(length);
/* 667 */         for (int i = 0; i < length; i++) {
/* 668 */           String line = source.readUtf8LineStrict();
/* 669 */           Buffer bytes = new Buffer();
/* 670 */           bytes.write(ByteString.decodeBase64(line));
/* 671 */           result.add(certificateFactory.generateCertificate(bytes.inputStream()));
/*     */         } 
/* 673 */         return result;
/* 674 */       } catch (CertificateException e) {
/* 675 */         throw new IOException(e.getMessage());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void writeCertList(BufferedSink sink, List<Certificate> certificates) throws IOException {
/*     */       try {
/* 682 */         sink.writeDecimalLong(certificates.size())
/* 683 */           .writeByte(10);
/* 684 */         for (int i = 0, size = certificates.size(); i < size; i++) {
/* 685 */           byte[] bytes = ((Certificate)certificates.get(i)).getEncoded();
/* 686 */           String line = ByteString.of(bytes).base64();
/* 687 */           sink.writeUtf8(line)
/* 688 */             .writeByte(10);
/*     */         } 
/* 690 */       } catch (CertificateEncodingException e) {
/* 691 */         throw new IOException(e.getMessage());
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean matches(Request request, Response response) {
/* 696 */       return (this.url.equals(request.url().toString()) && this.requestMethod
/* 697 */         .equals(request.method()) && 
/* 698 */         HttpHeaders.varyMatches(response, this.varyHeaders, request));
/*     */     }
/*     */     
/*     */     public Response response(DiskLruCache.Snapshot snapshot) {
/* 702 */       String contentType = this.responseHeaders.get("Content-Type");
/* 703 */       String contentLength = this.responseHeaders.get("Content-Length");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 708 */       Request cacheRequest = (new Request.Builder()).url(this.url).method(this.requestMethod, null).headers(this.varyHeaders).build();
/* 709 */       return (new Response.Builder())
/* 710 */         .request(cacheRequest)
/* 711 */         .protocol(this.protocol)
/* 712 */         .code(this.code)
/* 713 */         .message(this.message)
/* 714 */         .headers(this.responseHeaders)
/* 715 */         .body(new Cache.CacheResponseBody(snapshot, contentType, contentLength))
/* 716 */         .handshake(this.handshake)
/* 717 */         .sentRequestAtMillis(this.sentRequestMillis)
/* 718 */         .receivedResponseAtMillis(this.receivedResponseMillis)
/* 719 */         .build();
/*     */     }
/*     */   }
/*     */   
/*     */   static int readInt(BufferedSource source) throws IOException {
/*     */     try {
/* 725 */       long result = source.readDecimalLong();
/* 726 */       String line = source.readUtf8LineStrict();
/* 727 */       if (result < 0L || result > 2147483647L || !line.isEmpty()) {
/* 728 */         throw new IOException("expected an int but was \"" + result + line + "\"");
/*     */       }
/* 730 */       return (int)result;
/* 731 */     } catch (NumberFormatException e) {
/* 732 */       throw new IOException(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class CacheResponseBody
/*     */     extends ResponseBody {
/*     */     final DiskLruCache.Snapshot snapshot;
/*     */     private final BufferedSource bodySource;
/*     */     private final String contentType;
/*     */     private final String contentLength;
/*     */     
/*     */     public CacheResponseBody(final DiskLruCache.Snapshot snapshot, String contentType, String contentLength) {
/* 744 */       this.snapshot = snapshot;
/* 745 */       this.contentType = contentType;
/* 746 */       this.contentLength = contentLength;
/*     */       
/* 748 */       Source source = snapshot.getSource(1);
/* 749 */       this.bodySource = Okio.buffer((Source)new ForwardingSource(source) {
/*     */             public void close() throws IOException {
/* 751 */               snapshot.close();
/* 752 */               super.close();
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*     */     public MediaType contentType() {
/* 758 */       return (this.contentType != null) ? MediaType.parse(this.contentType) : null;
/*     */     }
/*     */     
/*     */     public long contentLength() {
/*     */       try {
/* 763 */         return (this.contentLength != null) ? Long.parseLong(this.contentLength) : -1L;
/* 764 */       } catch (NumberFormatException e) {
/* 765 */         return -1L;
/*     */       } 
/*     */     }
/*     */     
/*     */     public BufferedSource source() {
/* 770 */       return this.bodySource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Cache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */