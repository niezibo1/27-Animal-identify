/*     */ package okhttp3;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import okhttp3.internal.http.HttpHeaders;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Response
/*     */   implements Closeable
/*     */ {
/*     */   final Request request;
/*     */   final Protocol protocol;
/*     */   final int code;
/*     */   final String message;
/*     */   final Handshake handshake;
/*     */   final Headers headers;
/*     */   final ResponseBody body;
/*     */   final Response networkResponse;
/*     */   final Response cacheResponse;
/*     */   final Response priorResponse;
/*     */   final long sentRequestAtMillis;
/*     */   final long receivedResponseAtMillis;
/*     */   private volatile CacheControl cacheControl;
/*     */   
/*     */   Response(Builder builder) {
/*  59 */     this.request = builder.request;
/*  60 */     this.protocol = builder.protocol;
/*  61 */     this.code = builder.code;
/*  62 */     this.message = builder.message;
/*  63 */     this.handshake = builder.handshake;
/*  64 */     this.headers = builder.headers.build();
/*  65 */     this.body = builder.body;
/*  66 */     this.networkResponse = builder.networkResponse;
/*  67 */     this.cacheResponse = builder.cacheResponse;
/*  68 */     this.priorResponse = builder.priorResponse;
/*  69 */     this.sentRequestAtMillis = builder.sentRequestAtMillis;
/*  70 */     this.receivedResponseAtMillis = builder.receivedResponseAtMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request request() {
/*  85 */     return this.request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Protocol protocol() {
/*  92 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   
/*     */   public int code() {
/*  97 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSuccessful() {
/* 105 */     return (this.code >= 200 && this.code < 300);
/*     */   }
/*     */ 
/*     */   
/*     */   public String message() {
/* 110 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Handshake handshake() {
/* 118 */     return this.handshake;
/*     */   }
/*     */   
/*     */   public List<String> headers(String name) {
/* 122 */     return this.headers.values(name);
/*     */   }
/*     */   
/*     */   public String header(String name) {
/* 126 */     return header(name, null);
/*     */   }
/*     */   
/*     */   public String header(String name, String defaultValue) {
/* 130 */     String result = this.headers.get(name);
/* 131 */     return (result != null) ? result : defaultValue;
/*     */   }
/*     */   
/*     */   public Headers headers() {
/* 135 */     return this.headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResponseBody peekBody(long byteCount) throws IOException {
/*     */     Buffer result;
/* 150 */     BufferedSource source = this.body.source();
/* 151 */     source.request(byteCount);
/* 152 */     Buffer copy = source.buffer().clone();
/*     */ 
/*     */ 
/*     */     
/* 156 */     if (copy.size() > byteCount) {
/* 157 */       result = new Buffer();
/* 158 */       result.write(copy, byteCount);
/* 159 */       copy.clear();
/*     */     } else {
/* 161 */       result = copy;
/*     */     } 
/*     */     
/* 164 */     return ResponseBody.create(this.body.contentType(), result.size(), (BufferedSource)result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResponseBody body() {
/* 176 */     return this.body;
/*     */   }
/*     */   
/*     */   public Builder newBuilder() {
/* 180 */     return new Builder(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRedirect() {
/* 185 */     switch (this.code) {
/*     */       case 300:
/*     */       case 301:
/*     */       case 302:
/*     */       case 303:
/*     */       case 307:
/*     */       case 308:
/* 192 */         return true;
/*     */     } 
/* 194 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response networkResponse() {
/* 204 */     return this.networkResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response cacheResponse() {
/* 213 */     return this.cacheResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response priorResponse() {
/* 223 */     return this.priorResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Challenge> challenges() {
/*     */     String responseField;
/* 234 */     if (this.code == 401) {
/* 235 */       responseField = "WWW-Authenticate";
/* 236 */     } else if (this.code == 407) {
/* 237 */       responseField = "Proxy-Authenticate";
/*     */     } else {
/* 239 */       return Collections.emptyList();
/*     */     } 
/* 241 */     return HttpHeaders.parseChallenges(headers(), responseField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl cacheControl() {
/* 249 */     CacheControl result = this.cacheControl;
/* 250 */     return (result != null) ? result : (this.cacheControl = CacheControl.parse(this.headers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long sentRequestAtMillis() {
/* 259 */     return this.sentRequestAtMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long receivedResponseAtMillis() {
/* 268 */     return this.receivedResponseAtMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 273 */     this.body.close();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 277 */     return "Response{protocol=" + this.protocol + ", code=" + this.code + ", message=" + this.message + ", url=" + this.request
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 284 */       .url() + '}';
/*     */   }
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     Request request;
/*     */     Protocol protocol;
/* 291 */     int code = -1;
/*     */     String message;
/*     */     Handshake handshake;
/*     */     Headers.Builder headers;
/*     */     ResponseBody body;
/*     */     Response networkResponse;
/*     */     Response cacheResponse;
/*     */     Response priorResponse;
/*     */     long sentRequestAtMillis;
/*     */     long receivedResponseAtMillis;
/*     */     
/*     */     public Builder() {
/* 303 */       this.headers = new Headers.Builder();
/*     */     }
/*     */     
/*     */     Builder(Response response) {
/* 307 */       this.request = response.request;
/* 308 */       this.protocol = response.protocol;
/* 309 */       this.code = response.code;
/* 310 */       this.message = response.message;
/* 311 */       this.handshake = response.handshake;
/* 312 */       this.headers = response.headers.newBuilder();
/* 313 */       this.body = response.body;
/* 314 */       this.networkResponse = response.networkResponse;
/* 315 */       this.cacheResponse = response.cacheResponse;
/* 316 */       this.priorResponse = response.priorResponse;
/* 317 */       this.sentRequestAtMillis = response.sentRequestAtMillis;
/* 318 */       this.receivedResponseAtMillis = response.receivedResponseAtMillis;
/*     */     }
/*     */     
/*     */     public Builder request(Request request) {
/* 322 */       this.request = request;
/* 323 */       return this;
/*     */     }
/*     */     
/*     */     public Builder protocol(Protocol protocol) {
/* 327 */       this.protocol = protocol;
/* 328 */       return this;
/*     */     }
/*     */     
/*     */     public Builder code(int code) {
/* 332 */       this.code = code;
/* 333 */       return this;
/*     */     }
/*     */     
/*     */     public Builder message(String message) {
/* 337 */       this.message = message;
/* 338 */       return this;
/*     */     }
/*     */     
/*     */     public Builder handshake(Handshake handshake) {
/* 342 */       this.handshake = handshake;
/* 343 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder header(String name, String value) {
/* 351 */       this.headers.set(name, value);
/* 352 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addHeader(String name, String value) {
/* 360 */       this.headers.add(name, value);
/* 361 */       return this;
/*     */     }
/*     */     
/*     */     public Builder removeHeader(String name) {
/* 365 */       this.headers.removeAll(name);
/* 366 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder headers(Headers headers) {
/* 371 */       this.headers = headers.newBuilder();
/* 372 */       return this;
/*     */     }
/*     */     
/*     */     public Builder body(ResponseBody body) {
/* 376 */       this.body = body;
/* 377 */       return this;
/*     */     }
/*     */     
/*     */     public Builder networkResponse(Response networkResponse) {
/* 381 */       if (networkResponse != null) checkSupportResponse("networkResponse", networkResponse); 
/* 382 */       this.networkResponse = networkResponse;
/* 383 */       return this;
/*     */     }
/*     */     
/*     */     public Builder cacheResponse(Response cacheResponse) {
/* 387 */       if (cacheResponse != null) checkSupportResponse("cacheResponse", cacheResponse); 
/* 388 */       this.cacheResponse = cacheResponse;
/* 389 */       return this;
/*     */     }
/*     */     
/*     */     private void checkSupportResponse(String name, Response response) {
/* 393 */       if (response.body != null)
/* 394 */         throw new IllegalArgumentException(name + ".body != null"); 
/* 395 */       if (response.networkResponse != null)
/* 396 */         throw new IllegalArgumentException(name + ".networkResponse != null"); 
/* 397 */       if (response.cacheResponse != null)
/* 398 */         throw new IllegalArgumentException(name + ".cacheResponse != null"); 
/* 399 */       if (response.priorResponse != null) {
/* 400 */         throw new IllegalArgumentException(name + ".priorResponse != null");
/*     */       }
/*     */     }
/*     */     
/*     */     public Builder priorResponse(Response priorResponse) {
/* 405 */       if (priorResponse != null) checkPriorResponse(priorResponse); 
/* 406 */       this.priorResponse = priorResponse;
/* 407 */       return this;
/*     */     }
/*     */     
/*     */     private void checkPriorResponse(Response response) {
/* 411 */       if (response.body != null) {
/* 412 */         throw new IllegalArgumentException("priorResponse.body != null");
/*     */       }
/*     */     }
/*     */     
/*     */     public Builder sentRequestAtMillis(long sentRequestAtMillis) {
/* 417 */       this.sentRequestAtMillis = sentRequestAtMillis;
/* 418 */       return this;
/*     */     }
/*     */     
/*     */     public Builder receivedResponseAtMillis(long receivedResponseAtMillis) {
/* 422 */       this.receivedResponseAtMillis = receivedResponseAtMillis;
/* 423 */       return this;
/*     */     }
/*     */     
/*     */     public Response build() {
/* 427 */       if (this.request == null) throw new IllegalStateException("request == null"); 
/* 428 */       if (this.protocol == null) throw new IllegalStateException("protocol == null"); 
/* 429 */       if (this.code < 0) throw new IllegalStateException("code < 0: " + this.code); 
/* 430 */       return new Response(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Response.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */