/*     */ package okhttp3;
/*     */ 
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.internal.http.HttpHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CacheControl
/*     */ {
/*  18 */   public static final CacheControl FORCE_NETWORK = (new Builder()).noCache().build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  25 */   public static final CacheControl FORCE_CACHE = (new Builder())
/*  26 */     .onlyIfCached()
/*  27 */     .maxStale(2147483647, TimeUnit.SECONDS)
/*  28 */     .build();
/*     */   
/*     */   private final boolean noCache;
/*     */   
/*     */   private final boolean noStore;
/*     */   
/*     */   private final int maxAgeSeconds;
/*     */   
/*     */   private final int sMaxAgeSeconds;
/*     */   private final boolean isPrivate;
/*     */   private final boolean isPublic;
/*     */   private final boolean mustRevalidate;
/*     */   private final int maxStaleSeconds;
/*     */   private final int minFreshSeconds;
/*     */   private final boolean onlyIfCached;
/*     */   private final boolean noTransform;
/*     */   String headerValue;
/*     */   
/*     */   private CacheControl(boolean noCache, boolean noStore, int maxAgeSeconds, int sMaxAgeSeconds, boolean isPrivate, boolean isPublic, boolean mustRevalidate, int maxStaleSeconds, int minFreshSeconds, boolean onlyIfCached, boolean noTransform, String headerValue) {
/*  47 */     this.noCache = noCache;
/*  48 */     this.noStore = noStore;
/*  49 */     this.maxAgeSeconds = maxAgeSeconds;
/*  50 */     this.sMaxAgeSeconds = sMaxAgeSeconds;
/*  51 */     this.isPrivate = isPrivate;
/*  52 */     this.isPublic = isPublic;
/*  53 */     this.mustRevalidate = mustRevalidate;
/*  54 */     this.maxStaleSeconds = maxStaleSeconds;
/*  55 */     this.minFreshSeconds = minFreshSeconds;
/*  56 */     this.onlyIfCached = onlyIfCached;
/*  57 */     this.noTransform = noTransform;
/*  58 */     this.headerValue = headerValue;
/*     */   }
/*     */   
/*     */   CacheControl(Builder builder) {
/*  62 */     this.noCache = builder.noCache;
/*  63 */     this.noStore = builder.noStore;
/*  64 */     this.maxAgeSeconds = builder.maxAgeSeconds;
/*  65 */     this.sMaxAgeSeconds = -1;
/*  66 */     this.isPrivate = false;
/*  67 */     this.isPublic = false;
/*  68 */     this.mustRevalidate = false;
/*  69 */     this.maxStaleSeconds = builder.maxStaleSeconds;
/*  70 */     this.minFreshSeconds = builder.minFreshSeconds;
/*  71 */     this.onlyIfCached = builder.onlyIfCached;
/*  72 */     this.noTransform = builder.noTransform;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean noCache() {
/*  83 */     return this.noCache;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean noStore() {
/*  88 */     return this.noStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxAgeSeconds() {
/*  95 */     return this.maxAgeSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sMaxAgeSeconds() {
/* 103 */     return this.sMaxAgeSeconds;
/*     */   }
/*     */   
/*     */   public boolean isPrivate() {
/* 107 */     return this.isPrivate;
/*     */   }
/*     */   
/*     */   public boolean isPublic() {
/* 111 */     return this.isPublic;
/*     */   }
/*     */   
/*     */   public boolean mustRevalidate() {
/* 115 */     return this.mustRevalidate;
/*     */   }
/*     */   
/*     */   public int maxStaleSeconds() {
/* 119 */     return this.maxStaleSeconds;
/*     */   }
/*     */   
/*     */   public int minFreshSeconds() {
/* 123 */     return this.minFreshSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onlyIfCached() {
/* 133 */     return this.onlyIfCached;
/*     */   }
/*     */   
/*     */   public boolean noTransform() {
/* 137 */     return this.noTransform;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CacheControl parse(Headers headers) {
/* 145 */     boolean noCache = false;
/* 146 */     boolean noStore = false;
/* 147 */     int maxAgeSeconds = -1;
/* 148 */     int sMaxAgeSeconds = -1;
/* 149 */     boolean isPrivate = false;
/* 150 */     boolean isPublic = false;
/* 151 */     boolean mustRevalidate = false;
/* 152 */     int maxStaleSeconds = -1;
/* 153 */     int minFreshSeconds = -1;
/* 154 */     boolean onlyIfCached = false;
/* 155 */     boolean noTransform = false;
/*     */     
/* 157 */     boolean canUseHeaderValue = true;
/* 158 */     String headerValue = null;
/*     */     
/* 160 */     for (int i = 0, size = headers.size(); i < size; i++) {
/* 161 */       String name = headers.name(i);
/* 162 */       String value = headers.value(i);
/*     */       
/* 164 */       if (name.equalsIgnoreCase("Cache-Control")) {
/* 165 */         if (headerValue != null) {
/*     */           
/* 167 */           canUseHeaderValue = false;
/*     */         } else {
/* 169 */           headerValue = value;
/*     */         } 
/* 171 */       } else if (name.equalsIgnoreCase("Pragma")) {
/*     */         
/* 173 */         canUseHeaderValue = false;
/*     */       } else {
/*     */         continue;
/*     */       } 
/*     */       
/* 178 */       int pos = 0;
/* 179 */       while (pos < value.length()) {
/* 180 */         String parameter; int tokenStart = pos;
/* 181 */         pos = HttpHeaders.skipUntil(value, pos, "=,;");
/* 182 */         String directive = value.substring(tokenStart, pos).trim();
/*     */ 
/*     */         
/* 185 */         if (pos == value.length() || value.charAt(pos) == ',' || value.charAt(pos) == ';') {
/* 186 */           pos++;
/* 187 */           parameter = null;
/*     */         } else {
/* 189 */           pos++;
/* 190 */           pos = HttpHeaders.skipWhitespace(value, pos);
/*     */ 
/*     */           
/* 193 */           if (pos < value.length() && value.charAt(pos) == '"') {
/*     */             
/* 195 */             int parameterStart = ++pos;
/* 196 */             pos = HttpHeaders.skipUntil(value, pos, "\"");
/* 197 */             parameter = value.substring(parameterStart, pos);
/* 198 */             pos++;
/*     */           }
/*     */           else {
/*     */             
/* 202 */             int parameterStart = pos;
/* 203 */             pos = HttpHeaders.skipUntil(value, pos, ",;");
/* 204 */             parameter = value.substring(parameterStart, pos).trim();
/*     */           } 
/*     */         } 
/*     */         
/* 208 */         if ("no-cache".equalsIgnoreCase(directive)) {
/* 209 */           noCache = true; continue;
/* 210 */         }  if ("no-store".equalsIgnoreCase(directive)) {
/* 211 */           noStore = true; continue;
/* 212 */         }  if ("max-age".equalsIgnoreCase(directive)) {
/* 213 */           maxAgeSeconds = HttpHeaders.parseSeconds(parameter, -1); continue;
/* 214 */         }  if ("s-maxage".equalsIgnoreCase(directive)) {
/* 215 */           sMaxAgeSeconds = HttpHeaders.parseSeconds(parameter, -1); continue;
/* 216 */         }  if ("private".equalsIgnoreCase(directive)) {
/* 217 */           isPrivate = true; continue;
/* 218 */         }  if ("public".equalsIgnoreCase(directive)) {
/* 219 */           isPublic = true; continue;
/* 220 */         }  if ("must-revalidate".equalsIgnoreCase(directive)) {
/* 221 */           mustRevalidate = true; continue;
/* 222 */         }  if ("max-stale".equalsIgnoreCase(directive)) {
/* 223 */           maxStaleSeconds = HttpHeaders.parseSeconds(parameter, 2147483647); continue;
/* 224 */         }  if ("min-fresh".equalsIgnoreCase(directive)) {
/* 225 */           minFreshSeconds = HttpHeaders.parseSeconds(parameter, -1); continue;
/* 226 */         }  if ("only-if-cached".equalsIgnoreCase(directive)) {
/* 227 */           onlyIfCached = true; continue;
/* 228 */         }  if ("no-transform".equalsIgnoreCase(directive)) {
/* 229 */           noTransform = true;
/*     */         }
/*     */       } 
/*     */       continue;
/*     */     } 
/* 234 */     if (!canUseHeaderValue) {
/* 235 */       headerValue = null;
/*     */     }
/* 237 */     return new CacheControl(noCache, noStore, maxAgeSeconds, sMaxAgeSeconds, isPrivate, isPublic, mustRevalidate, maxStaleSeconds, minFreshSeconds, onlyIfCached, noTransform, headerValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 242 */     String result = this.headerValue;
/* 243 */     return (result != null) ? result : (this.headerValue = headerValue());
/*     */   }
/*     */   
/*     */   private String headerValue() {
/* 247 */     StringBuilder result = new StringBuilder();
/* 248 */     if (this.noCache) result.append("no-cache, "); 
/* 249 */     if (this.noStore) result.append("no-store, "); 
/* 250 */     if (this.maxAgeSeconds != -1) result.append("max-age=").append(this.maxAgeSeconds).append(", "); 
/* 251 */     if (this.sMaxAgeSeconds != -1) result.append("s-maxage=").append(this.sMaxAgeSeconds).append(", "); 
/* 252 */     if (this.isPrivate) result.append("private, "); 
/* 253 */     if (this.isPublic) result.append("public, "); 
/* 254 */     if (this.mustRevalidate) result.append("must-revalidate, "); 
/* 255 */     if (this.maxStaleSeconds != -1) result.append("max-stale=").append(this.maxStaleSeconds).append(", "); 
/* 256 */     if (this.minFreshSeconds != -1) result.append("min-fresh=").append(this.minFreshSeconds).append(", "); 
/* 257 */     if (this.onlyIfCached) result.append("only-if-cached, "); 
/* 258 */     if (this.noTransform) result.append("no-transform, "); 
/* 259 */     if (result.length() == 0) return ""; 
/* 260 */     result.delete(result.length() - 2, result.length());
/* 261 */     return result.toString();
/*     */   }
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     boolean noCache;
/*     */     boolean noStore;
/* 268 */     int maxAgeSeconds = -1;
/* 269 */     int maxStaleSeconds = -1;
/* 270 */     int minFreshSeconds = -1;
/*     */     
/*     */     boolean onlyIfCached;
/*     */     boolean noTransform;
/*     */     
/*     */     public Builder noCache() {
/* 276 */       this.noCache = true;
/* 277 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder noStore() {
/* 282 */       this.noStore = true;
/* 283 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxAge(int maxAge, TimeUnit timeUnit) {
/* 294 */       if (maxAge < 0) throw new IllegalArgumentException("maxAge < 0: " + maxAge); 
/* 295 */       long maxAgeSecondsLong = timeUnit.toSeconds(maxAge);
/* 296 */       this.maxAgeSeconds = (maxAgeSecondsLong > 2147483647L) ? Integer.MAX_VALUE : (int)maxAgeSecondsLong;
/*     */ 
/*     */       
/* 299 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxStale(int maxStale, TimeUnit timeUnit) {
/* 310 */       if (maxStale < 0) throw new IllegalArgumentException("maxStale < 0: " + maxStale); 
/* 311 */       long maxStaleSecondsLong = timeUnit.toSeconds(maxStale);
/* 312 */       this.maxStaleSeconds = (maxStaleSecondsLong > 2147483647L) ? Integer.MAX_VALUE : (int)maxStaleSecondsLong;
/*     */ 
/*     */       
/* 315 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder minFresh(int minFresh, TimeUnit timeUnit) {
/* 327 */       if (minFresh < 0) throw new IllegalArgumentException("minFresh < 0: " + minFresh); 
/* 328 */       long minFreshSecondsLong = timeUnit.toSeconds(minFresh);
/* 329 */       this.minFreshSeconds = (minFreshSecondsLong > 2147483647L) ? Integer.MAX_VALUE : (int)minFreshSecondsLong;
/*     */ 
/*     */       
/* 332 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder onlyIfCached() {
/* 340 */       this.onlyIfCached = true;
/* 341 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder noTransform() {
/* 346 */       this.noTransform = true;
/* 347 */       return this;
/*     */     }
/*     */     
/*     */     public CacheControl build() {
/* 351 */       return new CacheControl(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\CacheControl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */