/*    */ package okhttp3;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Protocol
/*    */ {
/* 33 */   HTTP_1_0("http/1.0"),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   HTTP_1_1("http/1.1"),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   SPDY_3("spdy/3.1"),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   HTTP_2("h2");
/*    */   
/*    */   private final String protocol;
/*    */   
/*    */   Protocol(String protocol) {
/* 67 */     this.protocol = protocol;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Protocol get(String protocol) throws IOException {
/* 77 */     if (protocol.equals(HTTP_1_0.protocol)) return HTTP_1_0; 
/* 78 */     if (protocol.equals(HTTP_1_1.protocol)) return HTTP_1_1; 
/* 79 */     if (protocol.equals(HTTP_2.protocol)) return HTTP_2; 
/* 80 */     if (protocol.equals(SPDY_3.protocol)) return SPDY_3; 
/* 81 */     throw new IOException("Unexpected protocol: " + protocol);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return this.protocol;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Protocol.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */