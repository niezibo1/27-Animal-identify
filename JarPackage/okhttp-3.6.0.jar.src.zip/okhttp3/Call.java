package okhttp3;

import java.io.IOException;

public interface Call extends Cloneable {
  Request request();
  
  Response execute() throws IOException;
  
  void enqueue(Callback paramCallback);
  
  void cancel();
  
  boolean isExecuted();
  
  boolean isCanceled();
  
  Call clone();
  
  public static interface Factory {
    Call newCall(Request param1Request);
  }
}


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Call.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */