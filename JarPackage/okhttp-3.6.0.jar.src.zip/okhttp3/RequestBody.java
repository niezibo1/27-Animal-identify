/*     */ package okhttp3;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import okhttp3.internal.Util;
/*     */ import okio.BufferedSink;
/*     */ import okio.ByteString;
/*     */ import okio.Okio;
/*     */ import okio.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestBody
/*     */ {
/*     */   public abstract MediaType contentType();
/*     */   
/*     */   public long contentLength() throws IOException {
/*  36 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void writeTo(BufferedSink paramBufferedSink) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public static RequestBody create(MediaType contentType, String content) {
/*  47 */     Charset charset = Util.UTF_8;
/*  48 */     if (contentType != null) {
/*  49 */       charset = contentType.charset();
/*  50 */       if (charset == null) {
/*  51 */         charset = Util.UTF_8;
/*  52 */         contentType = MediaType.parse(contentType + "; charset=utf-8");
/*     */       } 
/*     */     } 
/*  55 */     byte[] bytes = content.getBytes(charset);
/*  56 */     return create(contentType, bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public static RequestBody create(final MediaType contentType, final ByteString content) {
/*  61 */     return new RequestBody() {
/*     */         public MediaType contentType() {
/*  63 */           return contentType;
/*     */         }
/*     */         
/*     */         public long contentLength() throws IOException {
/*  67 */           return content.size();
/*     */         }
/*     */         
/*     */         public void writeTo(BufferedSink sink) throws IOException {
/*  71 */           sink.write(content);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static RequestBody create(MediaType contentType, byte[] content) {
/*  78 */     return create(contentType, content, 0, content.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static RequestBody create(final MediaType contentType, final byte[] content, final int offset, final int byteCount) {
/*  84 */     if (content == null) throw new NullPointerException("content == null"); 
/*  85 */     Util.checkOffsetAndCount(content.length, offset, byteCount);
/*  86 */     return new RequestBody() {
/*     */         public MediaType contentType() {
/*  88 */           return contentType;
/*     */         }
/*     */         
/*     */         public long contentLength() {
/*  92 */           return byteCount;
/*     */         }
/*     */         
/*     */         public void writeTo(BufferedSink sink) throws IOException {
/*  96 */           sink.write(content, offset, byteCount);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static RequestBody create(final MediaType contentType, final File file) {
/* 103 */     if (file == null) throw new NullPointerException("content == null");
/*     */     
/* 105 */     return new RequestBody() {
/*     */         public MediaType contentType() {
/* 107 */           return contentType;
/*     */         }
/*     */         
/*     */         public long contentLength() {
/* 111 */           return file.length();
/*     */         }
/*     */         
/*     */         public void writeTo(BufferedSink sink) throws IOException {
/* 115 */           Source source = null;
/*     */           try {
/* 117 */             source = Okio.source(file);
/* 118 */             sink.writeAll(source);
/*     */           } finally {
/* 120 */             Util.closeQuietly((Closeable)source);
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\RequestBody.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */