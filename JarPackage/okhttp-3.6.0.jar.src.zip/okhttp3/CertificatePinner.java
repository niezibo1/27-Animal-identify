/*     */ package okhttp3;
/*     */ 
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.tls.CertificateChainCleaner;
/*     */ import okio.ByteString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CertificatePinner
/*     */ {
/* 128 */   public static final CertificatePinner DEFAULT = (new Builder()).build();
/*     */   
/*     */   private final Set<Pin> pins;
/*     */   private final CertificateChainCleaner certificateChainCleaner;
/*     */   
/*     */   CertificatePinner(Set<Pin> pins, CertificateChainCleaner certificateChainCleaner) {
/* 134 */     this.pins = pins;
/* 135 */     this.certificateChainCleaner = certificateChainCleaner;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 139 */     if (other == this) return true; 
/* 140 */     return (other instanceof CertificatePinner && 
/* 141 */       Util.equal(this.certificateChainCleaner, ((CertificatePinner)other).certificateChainCleaner) && this.pins
/* 142 */       .equals(((CertificatePinner)other).pins));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 146 */     int result = (this.certificateChainCleaner != null) ? this.certificateChainCleaner.hashCode() : 0;
/* 147 */     result = 31 * result + this.pins.hashCode();
/* 148 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void check(String hostname, List<Certificate> peerCertificates) throws SSLPeerUnverifiedException {
/* 161 */     List<Pin> pins = findMatchingPins(hostname);
/* 162 */     if (pins.isEmpty())
/*     */       return; 
/* 164 */     if (this.certificateChainCleaner != null) {
/* 165 */       peerCertificates = this.certificateChainCleaner.clean(peerCertificates, hostname);
/*     */     }
/*     */     
/* 168 */     for (int c = 0, certsSize = peerCertificates.size(); c < certsSize; c++) {
/* 169 */       X509Certificate x509Certificate = (X509Certificate)peerCertificates.get(c);
/*     */ 
/*     */       
/* 172 */       ByteString sha1 = null;
/* 173 */       ByteString sha256 = null;
/*     */       
/* 175 */       for (int k = 0, m = pins.size(); k < m; k++) {
/* 176 */         Pin pin = pins.get(k);
/* 177 */         if (pin.hashAlgorithm.equals("sha256/"))
/* 178 */         { if (sha256 == null) sha256 = sha256(x509Certificate); 
/* 179 */           if (pin.hash.equals(sha256))
/* 180 */             return;  } else if (pin.hashAlgorithm.equals("sha1/"))
/* 181 */         { if (sha1 == null) sha1 = sha1(x509Certificate); 
/* 182 */           if (pin.hash.equals(sha1))
/*     */             return;  }
/* 184 */         else { throw new AssertionError(); }
/*     */       
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     StringBuilder message = (new StringBuilder()).append("Certificate pinning failure!").append("\n  Peer certificate chain:");
/* 193 */     for (int i = 0, j = peerCertificates.size(); i < j; i++) {
/* 194 */       X509Certificate x509Certificate = (X509Certificate)peerCertificates.get(i);
/* 195 */       message.append("\n    ").append(pin(x509Certificate))
/* 196 */         .append(": ").append(x509Certificate.getSubjectDN().getName());
/*     */     } 
/* 198 */     message.append("\n  Pinned certificates for ").append(hostname).append(":");
/* 199 */     for (int p = 0, pinsSize = pins.size(); p < pinsSize; p++) {
/* 200 */       Pin pin = pins.get(p);
/* 201 */       message.append("\n    ").append(pin);
/*     */     } 
/* 203 */     throw new SSLPeerUnverifiedException(message.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void check(String hostname, Certificate... peerCertificates) throws SSLPeerUnverifiedException {
/* 209 */     check(hostname, Arrays.asList(peerCertificates));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Pin> findMatchingPins(String hostname) {
/* 217 */     List<Pin> result = Collections.emptyList();
/* 218 */     for (Pin pin : this.pins) {
/* 219 */       if (pin.matches(hostname)) {
/* 220 */         if (result.isEmpty()) result = new ArrayList<>(); 
/* 221 */         result.add(pin);
/*     */       } 
/*     */     } 
/* 224 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   CertificatePinner withCertificateChainCleaner(CertificateChainCleaner certificateChainCleaner) {
/* 229 */     return Util.equal(this.certificateChainCleaner, certificateChainCleaner) ? this : new CertificatePinner(this.pins, certificateChainCleaner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String pin(Certificate certificate) {
/* 241 */     if (!(certificate instanceof X509Certificate)) {
/* 242 */       throw new IllegalArgumentException("Certificate pinning requires X509 certificates");
/*     */     }
/* 244 */     return "sha256/" + sha256((X509Certificate)certificate).base64();
/*     */   }
/*     */   
/*     */   static ByteString sha1(X509Certificate x509Certificate) {
/* 248 */     return ByteString.of(x509Certificate.getPublicKey().getEncoded()).sha1();
/*     */   }
/*     */   
/*     */   static ByteString sha256(X509Certificate x509Certificate) {
/* 252 */     return ByteString.of(x509Certificate.getPublicKey().getEncoded()).sha256();
/*     */   }
/*     */ 
/*     */   
/*     */   static final class Pin
/*     */   {
/*     */     private static final String WILDCARD = "*.";
/*     */     
/*     */     final String pattern;
/*     */     
/*     */     final String canonicalHostname;
/*     */     final String hashAlgorithm;
/*     */     final ByteString hash;
/*     */     
/*     */     Pin(String pattern, String pin) {
/* 267 */       this.pattern = pattern;
/* 268 */       this
/*     */         
/* 270 */         .canonicalHostname = pattern.startsWith("*.") ? HttpUrl.parse("http://" + pattern.substring("*.".length())).host() : HttpUrl.parse("http://" + pattern).host();
/* 271 */       if (pin.startsWith("sha1/")) {
/* 272 */         this.hashAlgorithm = "sha1/";
/* 273 */         this.hash = ByteString.decodeBase64(pin.substring("sha1/".length()));
/* 274 */       } else if (pin.startsWith("sha256/")) {
/* 275 */         this.hashAlgorithm = "sha256/";
/* 276 */         this.hash = ByteString.decodeBase64(pin.substring("sha256/".length()));
/*     */       } else {
/* 278 */         throw new IllegalArgumentException("pins must start with 'sha256/' or 'sha1/': " + pin);
/*     */       } 
/*     */       
/* 281 */       if (this.hash == null) {
/* 282 */         throw new IllegalArgumentException("pins must be base64: " + pin);
/*     */       }
/*     */     }
/*     */     
/*     */     boolean matches(String hostname) {
/* 287 */       if (this.pattern.startsWith("*.")) {
/* 288 */         int firstDot = hostname.indexOf('.');
/* 289 */         return hostname.regionMatches(false, firstDot + 1, this.canonicalHostname, 0, this.canonicalHostname
/* 290 */             .length());
/*     */       } 
/*     */       
/* 293 */       return hostname.equals(this.canonicalHostname);
/*     */     }
/*     */     
/*     */     public boolean equals(Object other) {
/* 297 */       return (other instanceof Pin && this.pattern
/* 298 */         .equals(((Pin)other).pattern) && this.hashAlgorithm
/* 299 */         .equals(((Pin)other).hashAlgorithm) && this.hash
/* 300 */         .equals(((Pin)other).hash));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 304 */       int result = 17;
/* 305 */       result = 31 * result + this.pattern.hashCode();
/* 306 */       result = 31 * result + this.hashAlgorithm.hashCode();
/* 307 */       result = 31 * result + this.hash.hashCode();
/* 308 */       return result;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 312 */       return this.hashAlgorithm + this.hash.base64();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class Builder
/*     */   {
/* 318 */     private final List<CertificatePinner.Pin> pins = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder add(String pattern, String... pins) {
/* 328 */       if (pattern == null) throw new NullPointerException("pattern == null");
/*     */       
/* 330 */       for (String pin : pins) {
/* 331 */         this.pins.add(new CertificatePinner.Pin(pattern, pin));
/*     */       }
/*     */       
/* 334 */       return this;
/*     */     }
/*     */     
/*     */     public CertificatePinner build() {
/* 338 */       return new CertificatePinner(new LinkedHashSet<>(this.pins), null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\CertificatePinner.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */