/*     */ package okhttp3;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import okhttp3.internal.NamedRunnable;
/*     */ import okhttp3.internal.cache.CacheInterceptor;
/*     */ import okhttp3.internal.connection.ConnectInterceptor;
/*     */ import okhttp3.internal.connection.StreamAllocation;
/*     */ import okhttp3.internal.http.BridgeInterceptor;
/*     */ import okhttp3.internal.http.CallServerInterceptor;
/*     */ import okhttp3.internal.http.RealInterceptorChain;
/*     */ import okhttp3.internal.http.RetryAndFollowUpInterceptor;
/*     */ import okhttp3.internal.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RealCall
/*     */   implements Call
/*     */ {
/*     */   final OkHttpClient client;
/*     */   final RetryAndFollowUpInterceptor retryAndFollowUpInterceptor;
/*     */   final Request originalRequest;
/*     */   final boolean forWebSocket;
/*     */   private boolean executed;
/*     */   
/*     */   RealCall(OkHttpClient client, Request originalRequest, boolean forWebSocket) {
/*  45 */     this.client = client;
/*  46 */     this.originalRequest = originalRequest;
/*  47 */     this.forWebSocket = forWebSocket;
/*  48 */     this.retryAndFollowUpInterceptor = new RetryAndFollowUpInterceptor(client, forWebSocket);
/*     */   }
/*     */   
/*     */   public Request request() {
/*  52 */     return this.originalRequest;
/*     */   }
/*     */   
/*     */   public Response execute() throws IOException {
/*  56 */     synchronized (this) {
/*  57 */       if (this.executed) throw new IllegalStateException("Already Executed"); 
/*  58 */       this.executed = true;
/*     */     } 
/*  60 */     captureCallStackTrace();
/*     */     try {
/*  62 */       this.client.dispatcher().executed(this);
/*  63 */       Response result = getResponseWithInterceptorChain();
/*  64 */       if (result == null) throw new IOException("Canceled"); 
/*  65 */       return result;
/*     */     } finally {
/*  67 */       this.client.dispatcher().finished(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void captureCallStackTrace() {
/*  72 */     Object callStackTrace = Platform.get().getStackTraceForCloseable("response.body().close()");
/*  73 */     this.retryAndFollowUpInterceptor.setCallStackTrace(callStackTrace);
/*     */   }
/*     */   
/*     */   public void enqueue(Callback responseCallback) {
/*  77 */     synchronized (this) {
/*  78 */       if (this.executed) throw new IllegalStateException("Already Executed"); 
/*  79 */       this.executed = true;
/*     */     } 
/*  81 */     captureCallStackTrace();
/*  82 */     this.client.dispatcher().enqueue(new AsyncCall(responseCallback));
/*     */   }
/*     */   
/*     */   public void cancel() {
/*  86 */     this.retryAndFollowUpInterceptor.cancel();
/*     */   }
/*     */   
/*     */   public synchronized boolean isExecuted() {
/*  90 */     return this.executed;
/*     */   }
/*     */   
/*     */   public boolean isCanceled() {
/*  94 */     return this.retryAndFollowUpInterceptor.isCanceled();
/*     */   }
/*     */ 
/*     */   
/*     */   public RealCall clone() {
/*  99 */     return new RealCall(this.client, this.originalRequest, this.forWebSocket);
/*     */   }
/*     */   
/*     */   StreamAllocation streamAllocation() {
/* 103 */     return this.retryAndFollowUpInterceptor.streamAllocation();
/*     */   }
/*     */   
/*     */   final class AsyncCall extends NamedRunnable {
/*     */     private final Callback responseCallback;
/*     */     
/*     */     AsyncCall(Callback responseCallback) {
/* 110 */       super("OkHttp %s", new Object[] { this$0.redactedUrl() });
/* 111 */       this.responseCallback = responseCallback;
/*     */     }
/*     */     
/*     */     String host() {
/* 115 */       return RealCall.this.originalRequest.url().host();
/*     */     }
/*     */     
/*     */     Request request() {
/* 119 */       return RealCall.this.originalRequest;
/*     */     }
/*     */     
/*     */     RealCall get() {
/* 123 */       return RealCall.this;
/*     */     }
/*     */     
/*     */     protected void execute() {
/* 127 */       boolean signalledCallback = false;
/*     */       try {
/* 129 */         Response response = RealCall.this.getResponseWithInterceptorChain();
/* 130 */         if (RealCall.this.retryAndFollowUpInterceptor.isCanceled()) {
/* 131 */           signalledCallback = true;
/* 132 */           this.responseCallback.onFailure(RealCall.this, new IOException("Canceled"));
/*     */         } else {
/* 134 */           signalledCallback = true;
/* 135 */           this.responseCallback.onResponse(RealCall.this, response);
/*     */         } 
/* 137 */       } catch (IOException e) {
/* 138 */         if (signalledCallback) {
/*     */           
/* 140 */           Platform.get().log(4, "Callback failure for " + RealCall.this.toLoggableString(), e);
/*     */         } else {
/* 142 */           this.responseCallback.onFailure(RealCall.this, e);
/*     */         } 
/*     */       } finally {
/* 145 */         RealCall.this.client.dispatcher().finished(this);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toLoggableString() {
/* 155 */     return (isCanceled() ? "canceled " : "") + (this.forWebSocket ? "web socket" : "call") + " to " + 
/*     */       
/* 157 */       redactedUrl();
/*     */   }
/*     */   
/*     */   String redactedUrl() {
/* 161 */     return this.originalRequest.url().redact();
/*     */   }
/*     */ 
/*     */   
/*     */   Response getResponseWithInterceptorChain() throws IOException {
/* 166 */     List<Interceptor> interceptors = new ArrayList<>();
/* 167 */     interceptors.addAll(this.client.interceptors());
/* 168 */     interceptors.add(this.retryAndFollowUpInterceptor);
/* 169 */     interceptors.add(new BridgeInterceptor(this.client.cookieJar()));
/* 170 */     interceptors.add(new CacheInterceptor(this.client.internalCache()));
/* 171 */     interceptors.add(new ConnectInterceptor(this.client));
/* 172 */     if (!this.forWebSocket) {
/* 173 */       interceptors.addAll(this.client.networkInterceptors());
/*     */     }
/* 175 */     interceptors.add(new CallServerInterceptor(this.forWebSocket));
/*     */     
/* 177 */     RealInterceptorChain realInterceptorChain = new RealInterceptorChain(interceptors, null, null, null, 0, this.originalRequest);
/*     */     
/* 179 */     return realInterceptorChain.proceed(this.originalRequest);
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\RealCall.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */