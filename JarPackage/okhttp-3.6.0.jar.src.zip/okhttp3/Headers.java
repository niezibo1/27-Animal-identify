/*     */ package okhttp3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.http.HttpDate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Headers
/*     */ {
/*     */   private final String[] namesAndValues;
/*     */   
/*     */   Headers(Builder builder) {
/*  53 */     this.namesAndValues = builder.namesAndValues.<String>toArray(new String[builder.namesAndValues.size()]);
/*     */   }
/*     */   
/*     */   private Headers(String[] namesAndValues) {
/*  57 */     this.namesAndValues = namesAndValues;
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(String name) {
/*  62 */     return get(this.namesAndValues, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDate(String name) {
/*  70 */     String value = get(name);
/*  71 */     return (value != null) ? HttpDate.parse(value) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  76 */     return this.namesAndValues.length / 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String name(int index) {
/*  81 */     return this.namesAndValues[index * 2];
/*     */   }
/*     */ 
/*     */   
/*     */   public String value(int index) {
/*  86 */     return this.namesAndValues[index * 2 + 1];
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> names() {
/*  91 */     TreeSet<String> result = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
/*  92 */     for (int i = 0, size = size(); i < size; i++) {
/*  93 */       result.add(name(i));
/*     */     }
/*  95 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> values(String name) {
/* 100 */     List<String> result = null;
/* 101 */     for (int i = 0, size = size(); i < size; i++) {
/* 102 */       if (name.equalsIgnoreCase(name(i))) {
/* 103 */         if (result == null) result = new ArrayList<>(2); 
/* 104 */         result.add(value(i));
/*     */       } 
/*     */     } 
/* 107 */     return (result != null) ? 
/* 108 */       Collections.<String>unmodifiableList(result) : 
/* 109 */       Collections.<String>emptyList();
/*     */   }
/*     */   
/*     */   public Builder newBuilder() {
/* 113 */     Builder result = new Builder();
/* 114 */     Collections.addAll(result.namesAndValues, this.namesAndValues);
/* 115 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 145 */     return (other instanceof Headers && 
/* 146 */       Arrays.equals((Object[])((Headers)other).namesAndValues, (Object[])this.namesAndValues));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 150 */     return Arrays.hashCode((Object[])this.namesAndValues);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 154 */     StringBuilder result = new StringBuilder();
/* 155 */     for (int i = 0, size = size(); i < size; i++) {
/* 156 */       result.append(name(i)).append(": ").append(value(i)).append("\n");
/*     */     }
/* 158 */     return result.toString();
/*     */   }
/*     */   
/*     */   public Map<String, List<String>> toMultimap() {
/* 162 */     Map<String, List<String>> result = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/* 163 */     for (int i = 0, size = size(); i < size; i++) {
/* 164 */       String name = name(i).toLowerCase(Locale.US);
/* 165 */       List<String> values = result.get(name);
/* 166 */       if (values == null) {
/* 167 */         values = new ArrayList<>(2);
/* 168 */         result.put(name, values);
/*     */       } 
/* 170 */       values.add(value(i));
/*     */     } 
/* 172 */     return result;
/*     */   }
/*     */   
/*     */   private static String get(String[] namesAndValues, String name) {
/* 176 */     for (int i = namesAndValues.length - 2; i >= 0; i -= 2) {
/* 177 */       if (name.equalsIgnoreCase(namesAndValues[i])) {
/* 178 */         return namesAndValues[i + 1];
/*     */       }
/*     */     } 
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Headers of(String... namesAndValues) {
/* 189 */     if (namesAndValues == null) throw new NullPointerException("namesAndValues == null"); 
/* 190 */     if (namesAndValues.length % 2 != 0) {
/* 191 */       throw new IllegalArgumentException("Expected alternating header names and values");
/*     */     }
/*     */ 
/*     */     
/* 195 */     namesAndValues = (String[])namesAndValues.clone(); int i;
/* 196 */     for (i = 0; i < namesAndValues.length; i++) {
/* 197 */       if (namesAndValues[i] == null) throw new IllegalArgumentException("Headers cannot be null"); 
/* 198 */       namesAndValues[i] = namesAndValues[i].trim();
/*     */     } 
/*     */ 
/*     */     
/* 202 */     for (i = 0; i < namesAndValues.length; i += 2) {
/* 203 */       String name = namesAndValues[i];
/* 204 */       String value = namesAndValues[i + 1];
/* 205 */       if (name.length() == 0 || name.indexOf(false) != -1 || value.indexOf(false) != -1) {
/* 206 */         throw new IllegalArgumentException("Unexpected header: " + name + ": " + value);
/*     */       }
/*     */     } 
/*     */     
/* 210 */     return new Headers(namesAndValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Headers of(Map<String, String> headers) {
/* 217 */     if (headers == null) throw new NullPointerException("headers == null");
/*     */ 
/*     */     
/* 220 */     String[] namesAndValues = new String[headers.size() * 2];
/* 221 */     int i = 0;
/* 222 */     for (Map.Entry<String, String> header : headers.entrySet()) {
/* 223 */       if (header.getKey() == null || header.getValue() == null) {
/* 224 */         throw new IllegalArgumentException("Headers cannot be null");
/*     */       }
/* 226 */       String name = ((String)header.getKey()).trim();
/* 227 */       String value = ((String)header.getValue()).trim();
/* 228 */       if (name.length() == 0 || name.indexOf(false) != -1 || value.indexOf(false) != -1) {
/* 229 */         throw new IllegalArgumentException("Unexpected header: " + name + ": " + value);
/*     */       }
/* 231 */       namesAndValues[i] = name;
/* 232 */       namesAndValues[i + 1] = value;
/* 233 */       i += 2;
/*     */     } 
/*     */     
/* 236 */     return new Headers(namesAndValues);
/*     */   }
/*     */   
/*     */   public static final class Builder {
/* 240 */     final List<String> namesAndValues = new ArrayList<>(20);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Builder addLenient(String line) {
/* 247 */       int index = line.indexOf(":", 1);
/* 248 */       if (index != -1)
/* 249 */         return addLenient(line.substring(0, index), line.substring(index + 1)); 
/* 250 */       if (line.startsWith(":"))
/*     */       {
/*     */         
/* 253 */         return addLenient("", line.substring(1));
/*     */       }
/* 255 */       return addLenient("", line);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder add(String line) {
/* 261 */       int index = line.indexOf(":");
/* 262 */       if (index == -1) {
/* 263 */         throw new IllegalArgumentException("Unexpected header: " + line);
/*     */       }
/* 265 */       return add(line.substring(0, index).trim(), line.substring(index + 1));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder add(String name, String value) {
/* 270 */       checkNameAndValue(name, value);
/* 271 */       return addLenient(name, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Builder addLenient(String name, String value) {
/* 279 */       this.namesAndValues.add(name);
/* 280 */       this.namesAndValues.add(value.trim());
/* 281 */       return this;
/*     */     }
/*     */     
/*     */     public Builder removeAll(String name) {
/* 285 */       for (int i = 0; i < this.namesAndValues.size(); i += 2) {
/* 286 */         if (name.equalsIgnoreCase(this.namesAndValues.get(i))) {
/* 287 */           this.namesAndValues.remove(i);
/* 288 */           this.namesAndValues.remove(i);
/* 289 */           i -= 2;
/*     */         } 
/*     */       } 
/* 292 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder set(String name, String value) {
/* 300 */       checkNameAndValue(name, value);
/* 301 */       removeAll(name);
/* 302 */       addLenient(name, value);
/* 303 */       return this;
/*     */     }
/*     */     
/*     */     private void checkNameAndValue(String name, String value) {
/* 307 */       if (name == null) throw new NullPointerException("name == null"); 
/* 308 */       if (name.isEmpty()) throw new IllegalArgumentException("name is empty");  int i; int length;
/* 309 */       for (i = 0, length = name.length(); i < length; i++) {
/* 310 */         char c = name.charAt(i);
/* 311 */         if (c <= ' ' || c >= '')
/* 312 */           throw new IllegalArgumentException(Util.format("Unexpected char %#04x at %d in header name: %s", new Object[] {
/* 313 */                   Integer.valueOf(c), Integer.valueOf(i), name
/*     */                 })); 
/*     */       } 
/* 316 */       if (value == null) throw new NullPointerException("value == null"); 
/* 317 */       for (i = 0, length = value.length(); i < length; i++) {
/* 318 */         char c = value.charAt(i);
/* 319 */         if ((c <= '\037' && c != '\t') || c >= '') {
/* 320 */           throw new IllegalArgumentException(Util.format("Unexpected char %#04x at %d in %s value: %s", new Object[] {
/* 321 */                   Integer.valueOf(c), Integer.valueOf(i), name, value
/*     */                 }));
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public String get(String name) {
/* 328 */       for (int i = this.namesAndValues.size() - 2; i >= 0; i -= 2) {
/* 329 */         if (name.equalsIgnoreCase(this.namesAndValues.get(i))) {
/* 330 */           return this.namesAndValues.get(i + 1);
/*     */         }
/*     */       } 
/* 333 */       return null;
/*     */     }
/*     */     
/*     */     public Headers build() {
/* 337 */       return new Headers(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Headers.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */