/*     */ package okhttp3;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.internal.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Dispatcher
/*     */ {
/*  39 */   private int maxRequests = 64;
/*  40 */   private int maxRequestsPerHost = 5;
/*     */ 
/*     */   
/*     */   private Runnable idleCallback;
/*     */   
/*     */   private ExecutorService executorService;
/*     */   
/*  47 */   private final Deque<RealCall.AsyncCall> readyAsyncCalls = new ArrayDeque<>();
/*     */ 
/*     */   
/*  50 */   private final Deque<RealCall.AsyncCall> runningAsyncCalls = new ArrayDeque<>();
/*     */ 
/*     */   
/*  53 */   private final Deque<RealCall> runningSyncCalls = new ArrayDeque<>();
/*     */   
/*     */   public Dispatcher(ExecutorService executorService) {
/*  56 */     this.executorService = executorService;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dispatcher() {}
/*     */   
/*     */   public synchronized ExecutorService executorService() {
/*  63 */     if (this.executorService == null) {
/*  64 */       this
/*  65 */         .executorService = new ThreadPoolExecutor(0, 2147483647, 60L, TimeUnit.SECONDS, new SynchronousQueue<>(), Util.threadFactory("OkHttp Dispatcher", false));
/*     */     }
/*  67 */     return this.executorService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setMaxRequests(int maxRequests) {
/*  78 */     if (maxRequests < 1) {
/*  79 */       throw new IllegalArgumentException("max < 1: " + maxRequests);
/*     */     }
/*  81 */     this.maxRequests = maxRequests;
/*  82 */     promoteCalls();
/*     */   }
/*     */   
/*     */   public synchronized int getMaxRequests() {
/*  86 */     return this.maxRequests;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setMaxRequestsPerHost(int maxRequestsPerHost) {
/*  99 */     if (maxRequestsPerHost < 1) {
/* 100 */       throw new IllegalArgumentException("max < 1: " + maxRequestsPerHost);
/*     */     }
/* 102 */     this.maxRequestsPerHost = maxRequestsPerHost;
/* 103 */     promoteCalls();
/*     */   }
/*     */   
/*     */   public synchronized int getMaxRequestsPerHost() {
/* 107 */     return this.maxRequestsPerHost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setIdleCallback(Runnable idleCallback) {
/* 123 */     this.idleCallback = idleCallback;
/*     */   }
/*     */   
/*     */   synchronized void enqueue(RealCall.AsyncCall call) {
/* 127 */     if (this.runningAsyncCalls.size() < this.maxRequests && runningCallsForHost(call) < this.maxRequestsPerHost) {
/* 128 */       this.runningAsyncCalls.add(call);
/* 129 */       executorService().execute((Runnable)call);
/*     */     } else {
/* 131 */       this.readyAsyncCalls.add(call);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void cancelAll() {
/* 140 */     for (RealCall.AsyncCall call : this.readyAsyncCalls) {
/* 141 */       call.get().cancel();
/*     */     }
/*     */     
/* 144 */     for (RealCall.AsyncCall call : this.runningAsyncCalls) {
/* 145 */       call.get().cancel();
/*     */     }
/*     */     
/* 148 */     for (RealCall call : this.runningSyncCalls) {
/* 149 */       call.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   private void promoteCalls() {
/* 154 */     if (this.runningAsyncCalls.size() >= this.maxRequests)
/* 155 */       return;  if (this.readyAsyncCalls.isEmpty())
/*     */       return; 
/* 157 */     for (Iterator<RealCall.AsyncCall> i = this.readyAsyncCalls.iterator(); i.hasNext(); ) {
/* 158 */       RealCall.AsyncCall call = i.next();
/*     */       
/* 160 */       if (runningCallsForHost(call) < this.maxRequestsPerHost) {
/* 161 */         i.remove();
/* 162 */         this.runningAsyncCalls.add(call);
/* 163 */         executorService().execute((Runnable)call);
/*     */       } 
/*     */       
/* 166 */       if (this.runningAsyncCalls.size() >= this.maxRequests)
/*     */         return; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int runningCallsForHost(RealCall.AsyncCall call) {
/* 172 */     int result = 0;
/* 173 */     for (RealCall.AsyncCall c : this.runningAsyncCalls) {
/* 174 */       if (c.host().equals(call.host())) result++; 
/*     */     } 
/* 176 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void executed(RealCall call) {
/* 181 */     this.runningSyncCalls.add(call);
/*     */   }
/*     */ 
/*     */   
/*     */   void finished(RealCall.AsyncCall call) {
/* 186 */     finished(this.runningAsyncCalls, call, true);
/*     */   }
/*     */ 
/*     */   
/*     */   void finished(RealCall call) {
/* 191 */     finished(this.runningSyncCalls, call, false);
/*     */   }
/*     */   
/*     */   private <T> void finished(Deque<T> calls, T call, boolean promoteCalls) {
/*     */     int runningCallsCount;
/*     */     Runnable idleCallback;
/* 197 */     synchronized (this) {
/* 198 */       if (!calls.remove(call)) throw new AssertionError("Call wasn't in-flight!"); 
/* 199 */       if (promoteCalls) promoteCalls(); 
/* 200 */       runningCallsCount = runningCallsCount();
/* 201 */       idleCallback = this.idleCallback;
/*     */     } 
/*     */     
/* 204 */     if (runningCallsCount == 0 && idleCallback != null) {
/* 205 */       idleCallback.run();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized List<Call> queuedCalls() {
/* 211 */     List<Call> result = new ArrayList<>();
/* 212 */     for (RealCall.AsyncCall asyncCall : this.readyAsyncCalls) {
/* 213 */       result.add(asyncCall.get());
/*     */     }
/* 215 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized List<Call> runningCalls() {
/* 220 */     List<Call> result = new ArrayList<>();
/* 221 */     result.addAll((Collection)this.runningSyncCalls);
/* 222 */     for (RealCall.AsyncCall asyncCall : this.runningAsyncCalls) {
/* 223 */       result.add(asyncCall.get());
/*     */     }
/* 225 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */   
/*     */   public synchronized int queuedCallsCount() {
/* 229 */     return this.readyAsyncCalls.size();
/*     */   }
/*     */   
/*     */   public synchronized int runningCallsCount() {
/* 233 */     return this.runningAsyncCalls.size() + this.runningSyncCalls.size();
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Dispatcher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */