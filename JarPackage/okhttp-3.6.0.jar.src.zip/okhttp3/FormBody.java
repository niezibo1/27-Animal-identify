/*     */ package okhttp3;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import okhttp3.internal.Util;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormBody
/*     */   extends RequestBody
/*     */ {
/*  30 */   private static final MediaType CONTENT_TYPE = MediaType.parse("application/x-www-form-urlencoded");
/*     */   
/*     */   private final List<String> encodedNames;
/*     */   private final List<String> encodedValues;
/*     */   
/*     */   FormBody(List<String> encodedNames, List<String> encodedValues) {
/*  36 */     this.encodedNames = Util.immutableList(encodedNames);
/*  37 */     this.encodedValues = Util.immutableList(encodedValues);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  42 */     return this.encodedNames.size();
/*     */   }
/*     */   
/*     */   public String encodedName(int index) {
/*  46 */     return this.encodedNames.get(index);
/*     */   }
/*     */   
/*     */   public String name(int index) {
/*  50 */     return HttpUrl.percentDecode(encodedName(index), true);
/*     */   }
/*     */   
/*     */   public String encodedValue(int index) {
/*  54 */     return this.encodedValues.get(index);
/*     */   }
/*     */   
/*     */   public String value(int index) {
/*  58 */     return HttpUrl.percentDecode(encodedValue(index), true);
/*     */   }
/*     */   
/*     */   public MediaType contentType() {
/*  62 */     return CONTENT_TYPE;
/*     */   }
/*     */   
/*     */   public long contentLength() {
/*  66 */     return writeOrCountBytes(null, true);
/*     */   }
/*     */   
/*     */   public void writeTo(BufferedSink sink) throws IOException {
/*  70 */     writeOrCountBytes(sink, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long writeOrCountBytes(BufferedSink sink, boolean countBytes) {
/*     */     Buffer buffer;
/*  80 */     long byteCount = 0L;
/*     */ 
/*     */     
/*  83 */     if (countBytes) {
/*  84 */       buffer = new Buffer();
/*     */     } else {
/*  86 */       buffer = sink.buffer();
/*     */     } 
/*     */     
/*  89 */     for (int i = 0, size = this.encodedNames.size(); i < size; i++) {
/*  90 */       if (i > 0) buffer.writeByte(38); 
/*  91 */       buffer.writeUtf8(this.encodedNames.get(i));
/*  92 */       buffer.writeByte(61);
/*  93 */       buffer.writeUtf8(this.encodedValues.get(i));
/*     */     } 
/*     */     
/*  96 */     if (countBytes) {
/*  97 */       byteCount = buffer.size();
/*  98 */       buffer.clear();
/*     */     } 
/*     */     
/* 101 */     return byteCount;
/*     */   }
/*     */   
/*     */   public static final class Builder {
/* 105 */     private final List<String> names = new ArrayList<>();
/* 106 */     private final List<String> values = new ArrayList<>();
/*     */     
/*     */     public Builder add(String name, String value) {
/* 109 */       this.names.add(HttpUrl.canonicalize(name, " \"':;<=>@[]^`{}|/\\?#&!$(),~", false, false, true, true));
/* 110 */       this.values.add(HttpUrl.canonicalize(value, " \"':;<=>@[]^`{}|/\\?#&!$(),~", false, false, true, true));
/* 111 */       return this;
/*     */     }
/*     */     
/*     */     public Builder addEncoded(String name, String value) {
/* 115 */       this.names.add(HttpUrl.canonicalize(name, " \"':;<=>@[]^`{}|/\\?#&!$(),~", true, false, true, true));
/* 116 */       this.values.add(HttpUrl.canonicalize(value, " \"':;<=>@[]^`{}|/\\?#&!$(),~", true, false, true, true));
/* 117 */       return this;
/*     */     }
/*     */     
/*     */     public FormBody build() {
/* 121 */       return new FormBody(this.names, this.values);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\FormBody.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */