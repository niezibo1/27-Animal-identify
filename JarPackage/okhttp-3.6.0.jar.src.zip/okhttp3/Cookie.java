/*     */ package okhttp3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.http.HttpDate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Cookie
/*     */ {
/*  46 */   private static final Pattern YEAR_PATTERN = Pattern.compile("(\\d{2,4})[^\\d]*");
/*     */   
/*  48 */   private static final Pattern MONTH_PATTERN = Pattern.compile("(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*");
/*     */   
/*  50 */   private static final Pattern DAY_OF_MONTH_PATTERN = Pattern.compile("(\\d{1,2})[^\\d]*");
/*     */   
/*  52 */   private static final Pattern TIME_PATTERN = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[^\\d]*");
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final String value;
/*     */   
/*     */   private final long expiresAt;
/*     */   private final String domain;
/*     */   private final String path;
/*     */   private final boolean secure;
/*     */   private final boolean httpOnly;
/*     */   private final boolean persistent;
/*     */   private final boolean hostOnly;
/*     */   
/*     */   private Cookie(String name, String value, long expiresAt, String domain, String path, boolean secure, boolean httpOnly, boolean hostOnly, boolean persistent) {
/*  67 */     this.name = name;
/*  68 */     this.value = value;
/*  69 */     this.expiresAt = expiresAt;
/*  70 */     this.domain = domain;
/*  71 */     this.path = path;
/*  72 */     this.secure = secure;
/*  73 */     this.httpOnly = httpOnly;
/*  74 */     this.hostOnly = hostOnly;
/*  75 */     this.persistent = persistent;
/*     */   }
/*     */   
/*     */   Cookie(Builder builder) {
/*  79 */     if (builder.name == null) throw new NullPointerException("builder.name == null"); 
/*  80 */     if (builder.value == null) throw new NullPointerException("builder.value == null"); 
/*  81 */     if (builder.domain == null) throw new NullPointerException("builder.domain == null");
/*     */     
/*  83 */     this.name = builder.name;
/*  84 */     this.value = builder.value;
/*  85 */     this.expiresAt = builder.expiresAt;
/*  86 */     this.domain = builder.domain;
/*  87 */     this.path = builder.path;
/*  88 */     this.secure = builder.secure;
/*  89 */     this.httpOnly = builder.httpOnly;
/*  90 */     this.persistent = builder.persistent;
/*  91 */     this.hostOnly = builder.hostOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public String name() {
/*  96 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String value() {
/* 101 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean persistent() {
/* 106 */     return this.persistent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long expiresAt() {
/* 119 */     return this.expiresAt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hostOnly() {
/* 133 */     return this.hostOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String domain() {
/* 141 */     return this.domain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String path() {
/* 150 */     return this.path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean httpOnly() {
/* 158 */     return this.httpOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean secure() {
/* 163 */     return this.secure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(HttpUrl url) {
/* 173 */     boolean domainMatch = this.hostOnly ? url.host().equals(this.domain) : domainMatch(url, this.domain);
/* 174 */     if (!domainMatch) return false;
/*     */     
/* 176 */     if (!pathMatch(url, this.path)) return false;
/*     */     
/* 178 */     if (this.secure && !url.isHttps()) return false;
/*     */     
/* 180 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean domainMatch(HttpUrl url, String domain) {
/* 184 */     String urlHost = url.host();
/*     */     
/* 186 */     if (urlHost.equals(domain)) {
/* 187 */       return true;
/*     */     }
/*     */     
/* 190 */     if (urlHost.endsWith(domain) && urlHost
/* 191 */       .charAt(urlHost.length() - domain.length() - 1) == '.' && 
/* 192 */       !Util.verifyAsIpAddress(urlHost)) {
/* 193 */       return true;
/*     */     }
/*     */     
/* 196 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean pathMatch(HttpUrl url, String path) {
/* 200 */     String urlPath = url.encodedPath();
/*     */     
/* 202 */     if (urlPath.equals(path)) {
/* 203 */       return true;
/*     */     }
/*     */     
/* 206 */     if (urlPath.startsWith(path)) {
/* 207 */       if (path.endsWith("/")) return true; 
/* 208 */       if (urlPath.charAt(path.length()) == '/') return true;
/*     */     
/*     */     } 
/* 211 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Cookie parse(HttpUrl url, String setCookie) {
/* 219 */     return parse(System.currentTimeMillis(), url, setCookie);
/*     */   }
/*     */   
/*     */   static Cookie parse(long currentTimeMillis, HttpUrl url, String setCookie) {
/* 223 */     int pos = 0;
/* 224 */     int limit = setCookie.length();
/* 225 */     int cookiePairEnd = Util.delimiterOffset(setCookie, pos, limit, ';');
/*     */     
/* 227 */     int pairEqualsSign = Util.delimiterOffset(setCookie, pos, cookiePairEnd, '=');
/* 228 */     if (pairEqualsSign == cookiePairEnd) return null;
/*     */     
/* 230 */     String cookieName = Util.trimSubstring(setCookie, pos, pairEqualsSign);
/* 231 */     if (cookieName.isEmpty() || Util.indexOfControlOrNonAscii(cookieName) != -1) return null;
/*     */     
/* 233 */     String cookieValue = Util.trimSubstring(setCookie, pairEqualsSign + 1, cookiePairEnd);
/* 234 */     if (Util.indexOfControlOrNonAscii(cookieValue) != -1) return null;
/*     */     
/* 236 */     long expiresAt = 253402300799999L;
/* 237 */     long deltaSeconds = -1L;
/* 238 */     String domain = null;
/* 239 */     String path = null;
/* 240 */     boolean secureOnly = false;
/* 241 */     boolean httpOnly = false;
/* 242 */     boolean hostOnly = true;
/* 243 */     boolean persistent = false;
/*     */     
/* 245 */     pos = cookiePairEnd + 1;
/* 246 */     while (pos < limit) {
/* 247 */       int attributePairEnd = Util.delimiterOffset(setCookie, pos, limit, ';');
/*     */       
/* 249 */       int attributeEqualsSign = Util.delimiterOffset(setCookie, pos, attributePairEnd, '=');
/* 250 */       String attributeName = Util.trimSubstring(setCookie, pos, attributeEqualsSign);
/*     */       
/* 252 */       String attributeValue = (attributeEqualsSign < attributePairEnd) ? Util.trimSubstring(setCookie, attributeEqualsSign + 1, attributePairEnd) : "";
/*     */ 
/*     */       
/* 255 */       if (attributeName.equalsIgnoreCase("expires")) {
/*     */         try {
/* 257 */           expiresAt = parseExpires(attributeValue, 0, attributeValue.length());
/* 258 */           persistent = true;
/* 259 */         } catch (IllegalArgumentException illegalArgumentException) {}
/*     */       
/*     */       }
/* 262 */       else if (attributeName.equalsIgnoreCase("max-age")) {
/*     */         try {
/* 264 */           deltaSeconds = parseMaxAge(attributeValue);
/* 265 */           persistent = true;
/* 266 */         } catch (NumberFormatException numberFormatException) {}
/*     */       
/*     */       }
/* 269 */       else if (attributeName.equalsIgnoreCase("domain")) {
/*     */         try {
/* 271 */           domain = parseDomain(attributeValue);
/* 272 */           hostOnly = false;
/* 273 */         } catch (IllegalArgumentException illegalArgumentException) {}
/*     */       
/*     */       }
/* 276 */       else if (attributeName.equalsIgnoreCase("path")) {
/* 277 */         path = attributeValue;
/* 278 */       } else if (attributeName.equalsIgnoreCase("secure")) {
/* 279 */         secureOnly = true;
/* 280 */       } else if (attributeName.equalsIgnoreCase("httponly")) {
/* 281 */         httpOnly = true;
/*     */       } 
/*     */       
/* 284 */       pos = attributePairEnd + 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 289 */     if (deltaSeconds == Long.MIN_VALUE) {
/* 290 */       expiresAt = Long.MIN_VALUE;
/* 291 */     } else if (deltaSeconds != -1L) {
/* 292 */       long deltaMilliseconds = (deltaSeconds <= 9223372036854775L) ? (deltaSeconds * 1000L) : Long.MAX_VALUE;
/*     */ 
/*     */       
/* 295 */       expiresAt = currentTimeMillis + deltaMilliseconds;
/* 296 */       if (expiresAt < currentTimeMillis || expiresAt > 253402300799999L) {
/* 297 */         expiresAt = 253402300799999L;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 302 */     if (domain == null) {
/* 303 */       domain = url.host();
/* 304 */     } else if (!domainMatch(url, domain)) {
/* 305 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 310 */     if (path == null || !path.startsWith("/")) {
/* 311 */       String encodedPath = url.encodedPath();
/* 312 */       int lastSlash = encodedPath.lastIndexOf('/');
/* 313 */       path = (lastSlash != 0) ? encodedPath.substring(0, lastSlash) : "/";
/*     */     } 
/*     */     
/* 316 */     return new Cookie(cookieName, cookieValue, expiresAt, domain, path, secureOnly, httpOnly, hostOnly, persistent);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static long parseExpires(String s, int pos, int limit) {
/* 322 */     pos = dateCharacterOffset(s, pos, limit, false);
/*     */     
/* 324 */     int hour = -1;
/* 325 */     int minute = -1;
/* 326 */     int second = -1;
/* 327 */     int dayOfMonth = -1;
/* 328 */     int month = -1;
/* 329 */     int year = -1;
/* 330 */     Matcher matcher = TIME_PATTERN.matcher(s);
/*     */     
/* 332 */     while (pos < limit) {
/* 333 */       int end = dateCharacterOffset(s, pos + 1, limit, true);
/* 334 */       matcher.region(pos, end);
/*     */       
/* 336 */       if (hour == -1 && matcher.usePattern(TIME_PATTERN).matches()) {
/* 337 */         hour = Integer.parseInt(matcher.group(1));
/* 338 */         minute = Integer.parseInt(matcher.group(2));
/* 339 */         second = Integer.parseInt(matcher.group(3));
/* 340 */       } else if (dayOfMonth == -1 && matcher.usePattern(DAY_OF_MONTH_PATTERN).matches()) {
/* 341 */         dayOfMonth = Integer.parseInt(matcher.group(1));
/* 342 */       } else if (month == -1 && matcher.usePattern(MONTH_PATTERN).matches()) {
/* 343 */         String monthString = matcher.group(1).toLowerCase(Locale.US);
/* 344 */         month = MONTH_PATTERN.pattern().indexOf(monthString) / 4;
/* 345 */       } else if (year == -1 && matcher.usePattern(YEAR_PATTERN).matches()) {
/* 346 */         year = Integer.parseInt(matcher.group(1));
/*     */       } 
/*     */       
/* 349 */       pos = dateCharacterOffset(s, end + 1, limit, false);
/*     */     } 
/*     */ 
/*     */     
/* 353 */     if (year >= 70 && year <= 99) year += 1900; 
/* 354 */     if (year >= 0 && year <= 69) year += 2000;
/*     */ 
/*     */ 
/*     */     
/* 358 */     if (year < 1601) throw new IllegalArgumentException(); 
/* 359 */     if (month == -1) throw new IllegalArgumentException(); 
/* 360 */     if (dayOfMonth < 1 || dayOfMonth > 31) throw new IllegalArgumentException(); 
/* 361 */     if (hour < 0 || hour > 23) throw new IllegalArgumentException(); 
/* 362 */     if (minute < 0 || minute > 59) throw new IllegalArgumentException(); 
/* 363 */     if (second < 0 || second > 59) throw new IllegalArgumentException();
/*     */     
/* 365 */     Calendar calendar = new GregorianCalendar(Util.UTC);
/* 366 */     calendar.setLenient(false);
/* 367 */     calendar.set(1, year);
/* 368 */     calendar.set(2, month - 1);
/* 369 */     calendar.set(5, dayOfMonth);
/* 370 */     calendar.set(11, hour);
/* 371 */     calendar.set(12, minute);
/* 372 */     calendar.set(13, second);
/* 373 */     calendar.set(14, 0);
/* 374 */     return calendar.getTimeInMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int dateCharacterOffset(String input, int pos, int limit, boolean invert) {
/* 382 */     for (int i = pos; i < limit; i++) {
/* 383 */       int c = input.charAt(i);
/* 384 */       boolean dateCharacter = ((c < 32 && c != 9) || c >= 127 || (c >= 48 && c <= 57) || (c >= 97 && c <= 122) || (c >= 65 && c <= 90) || c == 58);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 389 */       if (dateCharacter == (!invert)) return i; 
/*     */     } 
/* 391 */     return limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long parseMaxAge(String s) {
/*     */     try {
/* 403 */       long parsed = Long.parseLong(s);
/* 404 */       return (parsed <= 0L) ? Long.MIN_VALUE : parsed;
/* 405 */     } catch (NumberFormatException e) {
/*     */       
/* 407 */       if (s.matches("-?\\d+")) {
/* 408 */         return s.startsWith("-") ? Long.MIN_VALUE : Long.MAX_VALUE;
/*     */       }
/* 410 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String parseDomain(String s) {
/* 419 */     if (s.endsWith(".")) {
/* 420 */       throw new IllegalArgumentException();
/*     */     }
/* 422 */     if (s.startsWith(".")) {
/* 423 */       s = s.substring(1);
/*     */     }
/* 425 */     String canonicalDomain = Util.domainToAscii(s);
/* 426 */     if (canonicalDomain == null) {
/* 427 */       throw new IllegalArgumentException();
/*     */     }
/* 429 */     return canonicalDomain;
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Cookie> parseAll(HttpUrl url, Headers headers) {
/* 434 */     List<String> cookieStrings = headers.values("Set-Cookie");
/* 435 */     List<Cookie> cookies = null;
/*     */     
/* 437 */     for (int i = 0, size = cookieStrings.size(); i < size; i++) {
/* 438 */       Cookie cookie = parse(url, cookieStrings.get(i));
/* 439 */       if (cookie != null) {
/* 440 */         if (cookies == null) cookies = new ArrayList<>(); 
/* 441 */         cookies.add(cookie);
/*     */       } 
/*     */     } 
/* 444 */     return (cookies != null) ? 
/* 445 */       Collections.<Cookie>unmodifiableList(cookies) : 
/* 446 */       Collections.<Cookie>emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     String name;
/*     */     
/*     */     String value;
/*     */     
/* 456 */     long expiresAt = 253402300799999L;
/*     */     String domain;
/* 458 */     String path = "/";
/*     */     boolean secure;
/*     */     boolean httpOnly;
/*     */     boolean persistent;
/*     */     boolean hostOnly;
/*     */     
/*     */     public Builder name(String name) {
/* 465 */       if (name == null) throw new NullPointerException("name == null"); 
/* 466 */       if (!name.trim().equals(name)) throw new IllegalArgumentException("name is not trimmed"); 
/* 467 */       this.name = name;
/* 468 */       return this;
/*     */     }
/*     */     
/*     */     public Builder value(String value) {
/* 472 */       if (value == null) throw new NullPointerException("value == null"); 
/* 473 */       if (!value.trim().equals(value)) throw new IllegalArgumentException("value is not trimmed"); 
/* 474 */       this.value = value;
/* 475 */       return this;
/*     */     }
/*     */     
/*     */     public Builder expiresAt(long expiresAt) {
/* 479 */       if (expiresAt <= 0L) expiresAt = Long.MIN_VALUE; 
/* 480 */       if (expiresAt > 253402300799999L) expiresAt = 253402300799999L; 
/* 481 */       this.expiresAt = expiresAt;
/* 482 */       this.persistent = true;
/* 483 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder domain(String domain) {
/* 491 */       return domain(domain, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder hostOnlyDomain(String domain) {
/* 499 */       return domain(domain, true);
/*     */     }
/*     */     
/*     */     private Builder domain(String domain, boolean hostOnly) {
/* 503 */       if (domain == null) throw new NullPointerException("domain == null"); 
/* 504 */       String canonicalDomain = Util.domainToAscii(domain);
/* 505 */       if (canonicalDomain == null) {
/* 506 */         throw new IllegalArgumentException("unexpected domain: " + domain);
/*     */       }
/* 508 */       this.domain = canonicalDomain;
/* 509 */       this.hostOnly = hostOnly;
/* 510 */       return this;
/*     */     }
/*     */     
/*     */     public Builder path(String path) {
/* 514 */       if (!path.startsWith("/")) throw new IllegalArgumentException("path must start with '/'"); 
/* 515 */       this.path = path;
/* 516 */       return this;
/*     */     }
/*     */     
/*     */     public Builder secure() {
/* 520 */       this.secure = true;
/* 521 */       return this;
/*     */     }
/*     */     
/*     */     public Builder httpOnly() {
/* 525 */       this.httpOnly = true;
/* 526 */       return this;
/*     */     }
/*     */     
/*     */     public Cookie build() {
/* 530 */       return new Cookie(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 535 */     return toString(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toString(boolean forObsoleteRfc2965) {
/* 544 */     StringBuilder result = new StringBuilder();
/* 545 */     result.append(this.name);
/* 546 */     result.append('=');
/* 547 */     result.append(this.value);
/*     */     
/* 549 */     if (this.persistent) {
/* 550 */       if (this.expiresAt == Long.MIN_VALUE) {
/* 551 */         result.append("; max-age=0");
/*     */       } else {
/* 553 */         result.append("; expires=").append(HttpDate.format(new Date(this.expiresAt)));
/*     */       } 
/*     */     }
/*     */     
/* 557 */     if (!this.hostOnly) {
/* 558 */       result.append("; domain=");
/* 559 */       if (forObsoleteRfc2965) {
/* 560 */         result.append(".");
/*     */       }
/* 562 */       result.append(this.domain);
/*     */     } 
/*     */     
/* 565 */     result.append("; path=").append(this.path);
/*     */     
/* 567 */     if (this.secure) {
/* 568 */       result.append("; secure");
/*     */     }
/*     */     
/* 571 */     if (this.httpOnly) {
/* 572 */       result.append("; httponly");
/*     */     }
/*     */     
/* 575 */     return result.toString();
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 579 */     if (!(other instanceof Cookie)) return false; 
/* 580 */     Cookie that = (Cookie)other;
/* 581 */     return (that.name.equals(this.name) && that.value
/* 582 */       .equals(this.value) && that.domain
/* 583 */       .equals(this.domain) && that.path
/* 584 */       .equals(this.path) && that.expiresAt == this.expiresAt && that.secure == this.secure && that.httpOnly == this.httpOnly && that.persistent == this.persistent && that.hostOnly == this.hostOnly);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 593 */     int hash = 17;
/* 594 */     hash = 31 * hash + this.name.hashCode();
/* 595 */     hash = 31 * hash + this.value.hashCode();
/* 596 */     hash = 31 * hash + this.domain.hashCode();
/* 597 */     hash = 31 * hash + this.path.hashCode();
/* 598 */     hash = 31 * hash + (int)(this.expiresAt ^ this.expiresAt >>> 32L);
/* 599 */     hash = 31 * hash + (this.secure ? 0 : 1);
/* 600 */     hash = 31 * hash + (this.httpOnly ? 0 : 1);
/* 601 */     hash = 31 * hash + (this.persistent ? 0 : 1);
/* 602 */     hash = 31 * hash + (this.hostOnly ? 0 : 1);
/* 603 */     return hash;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Cookie.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */