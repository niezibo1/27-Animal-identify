/*     */ package okhttp3;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.net.Socket;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import okhttp3.internal.Util;
/*     */ import okhttp3.internal.connection.RealConnection;
/*     */ import okhttp3.internal.connection.RouteDatabase;
/*     */ import okhttp3.internal.connection.StreamAllocation;
/*     */ import okhttp3.internal.platform.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectionPool
/*     */ {
/*  49 */   private static final Executor executor = new ThreadPoolExecutor(0, 2147483647, 60L, TimeUnit.SECONDS, new SynchronousQueue<>(), 
/*     */       
/*  51 */       Util.threadFactory("OkHttp ConnectionPool", true));
/*     */   
/*     */   private final int maxIdleConnections;
/*     */   private final long keepAliveDurationNs;
/*     */   
/*  56 */   private final Runnable cleanupRunnable = new Runnable() {
/*     */       public void run() {
/*     */         while (true) {
/*  59 */           long waitNanos = ConnectionPool.this.cleanup(System.nanoTime());
/*  60 */           if (waitNanos == -1L)
/*  61 */             return;  if (waitNanos > 0L) {
/*  62 */             long waitMillis = waitNanos / 1000000L;
/*  63 */             waitNanos -= waitMillis * 1000000L;
/*  64 */             synchronized (ConnectionPool.this) {
/*     */               try {
/*  66 */                 ConnectionPool.this.wait(waitMillis, (int)waitNanos);
/*  67 */               } catch (InterruptedException interruptedException) {}
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*  75 */   private final Deque<RealConnection> connections = new ArrayDeque<>();
/*  76 */   final RouteDatabase routeDatabase = new RouteDatabase();
/*     */ 
/*     */ 
/*     */   
/*     */   boolean cleanupRunning;
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionPool() {
/*  85 */     this(5, 5L, TimeUnit.MINUTES);
/*     */   }
/*     */   
/*     */   public ConnectionPool(int maxIdleConnections, long keepAliveDuration, TimeUnit timeUnit) {
/*  89 */     this.maxIdleConnections = maxIdleConnections;
/*  90 */     this.keepAliveDurationNs = timeUnit.toNanos(keepAliveDuration);
/*     */ 
/*     */     
/*  93 */     if (keepAliveDuration <= 0L) {
/*  94 */       throw new IllegalArgumentException("keepAliveDuration <= 0: " + keepAliveDuration);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized int idleConnectionCount() {
/* 100 */     int total = 0;
/* 101 */     for (RealConnection connection : this.connections) {
/* 102 */       if (connection.allocations.isEmpty()) total++; 
/*     */     } 
/* 104 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int connectionCount() {
/* 114 */     return this.connections.size();
/*     */   }
/*     */ 
/*     */   
/*     */   RealConnection get(Address address, StreamAllocation streamAllocation) {
/* 119 */     assert Thread.holdsLock(this);
/* 120 */     for (RealConnection connection : this.connections) {
/* 121 */       if (connection.isEligible(address)) {
/* 122 */         streamAllocation.acquire(connection);
/* 123 */         return connection;
/*     */       } 
/*     */     } 
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Socket deduplicate(Address address, StreamAllocation streamAllocation) {
/* 134 */     assert Thread.holdsLock(this);
/* 135 */     for (RealConnection connection : this.connections) {
/* 136 */       if (connection.isEligible(address) && connection
/* 137 */         .isMultiplexed() && connection != streamAllocation
/* 138 */         .connection()) {
/* 139 */         return streamAllocation.releaseAndAcquire(connection);
/*     */       }
/*     */     } 
/* 142 */     return null;
/*     */   }
/*     */   
/*     */   void put(RealConnection connection) {
/* 146 */     assert Thread.holdsLock(this);
/* 147 */     if (!this.cleanupRunning) {
/* 148 */       this.cleanupRunning = true;
/* 149 */       executor.execute(this.cleanupRunnable);
/*     */     } 
/* 151 */     this.connections.add(connection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean connectionBecameIdle(RealConnection connection) {
/* 159 */     assert Thread.holdsLock(this);
/* 160 */     if (connection.noNewStreams || this.maxIdleConnections == 0) {
/* 161 */       this.connections.remove(connection);
/* 162 */       return true;
/*     */     } 
/* 164 */     notifyAll();
/* 165 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void evictAll() {
/* 171 */     List<RealConnection> evictedConnections = new ArrayList<>();
/* 172 */     synchronized (this) {
/* 173 */       for (Iterator<RealConnection> i = this.connections.iterator(); i.hasNext(); ) {
/* 174 */         RealConnection connection = i.next();
/* 175 */         if (connection.allocations.isEmpty()) {
/* 176 */           connection.noNewStreams = true;
/* 177 */           evictedConnections.add(connection);
/* 178 */           i.remove();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 183 */     for (RealConnection connection : evictedConnections) {
/* 184 */       Util.closeQuietly(connection.socket());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long cleanup(long now) {
/* 196 */     int inUseConnectionCount = 0;
/* 197 */     int idleConnectionCount = 0;
/* 198 */     RealConnection longestIdleConnection = null;
/* 199 */     long longestIdleDurationNs = Long.MIN_VALUE;
/*     */ 
/*     */     
/* 202 */     synchronized (this) {
/* 203 */       for (Iterator<RealConnection> i = this.connections.iterator(); i.hasNext(); ) {
/* 204 */         RealConnection connection = i.next();
/*     */ 
/*     */         
/* 207 */         if (pruneAndGetAllocationCount(connection, now) > 0) {
/* 208 */           inUseConnectionCount++;
/*     */           
/*     */           continue;
/*     */         } 
/* 212 */         idleConnectionCount++;
/*     */ 
/*     */         
/* 215 */         long idleDurationNs = now - connection.idleAtNanos;
/* 216 */         if (idleDurationNs > longestIdleDurationNs) {
/* 217 */           longestIdleDurationNs = idleDurationNs;
/* 218 */           longestIdleConnection = connection;
/*     */         } 
/*     */       } 
/*     */       
/* 222 */       if (longestIdleDurationNs >= this.keepAliveDurationNs || idleConnectionCount > this.maxIdleConnections)
/*     */       
/*     */       { 
/*     */         
/* 226 */         this.connections.remove(longestIdleConnection); }
/* 227 */       else { if (idleConnectionCount > 0)
/*     */         {
/* 229 */           return this.keepAliveDurationNs - longestIdleDurationNs; } 
/* 230 */         if (inUseConnectionCount > 0)
/*     */         {
/* 232 */           return this.keepAliveDurationNs;
/*     */         }
/*     */         
/* 235 */         this.cleanupRunning = false;
/* 236 */         return -1L; }
/*     */     
/*     */     } 
/*     */     
/* 240 */     Util.closeQuietly(longestIdleConnection.socket());
/*     */ 
/*     */     
/* 243 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int pruneAndGetAllocationCount(RealConnection connection, long now) {
/* 253 */     List<Reference<StreamAllocation>> references = connection.allocations;
/* 254 */     for (int i = 0; i < references.size(); ) {
/* 255 */       Reference<StreamAllocation> reference = references.get(i);
/*     */       
/* 257 */       if (reference.get() != null) {
/* 258 */         i++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 263 */       StreamAllocation.StreamAllocationReference streamAllocRef = (StreamAllocation.StreamAllocationReference)reference;
/*     */       
/* 265 */       String message = "A connection to " + connection.route().address().url() + " was leaked. Did you forget to close a response body?";
/*     */       
/* 267 */       Platform.get().logCloseableLeak(message, streamAllocRef.callStackTrace);
/*     */       
/* 269 */       references.remove(i);
/* 270 */       connection.noNewStreams = true;
/*     */ 
/*     */       
/* 273 */       if (references.isEmpty()) {
/* 274 */         connection.idleAtNanos = now - this.keepAliveDurationNs;
/* 275 */         return 0;
/*     */       } 
/*     */     } 
/*     */     
/* 279 */     return references.size();
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\ConnectionPool.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */