/*    */ package okhttp3;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TlsVersion
/*    */ {
/* 23 */   TLS_1_3("TLSv1.3"),
/* 24 */   TLS_1_2("TLSv1.2"),
/* 25 */   TLS_1_1("TLSv1.1"),
/* 26 */   TLS_1_0("TLSv1"),
/* 27 */   SSL_3_0("SSLv3");
/*    */   
/*    */   final String javaName;
/*    */ 
/*    */   
/*    */   TlsVersion(String javaName) {
/* 33 */     this.javaName = javaName;
/*    */   }
/*    */   
/*    */   public static TlsVersion forJavaName(String javaName) {
/* 37 */     switch (javaName) {
/*    */       case "TLSv1.3":
/* 39 */         return TLS_1_3;
/*    */       case "TLSv1.2":
/* 41 */         return TLS_1_2;
/*    */       case "TLSv1.1":
/* 43 */         return TLS_1_1;
/*    */       case "TLSv1":
/* 45 */         return TLS_1_0;
/*    */       case "SSLv3":
/* 47 */         return SSL_3_0;
/*    */     } 
/* 49 */     throw new IllegalArgumentException("Unexpected TLS version: " + javaName);
/*    */   }
/*    */   
/*    */   public String javaName() {
/* 53 */     return this.javaName;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\TlsVersion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */