/*     */ package okhttp3;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import okhttp3.internal.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Handshake
/*     */ {
/*     */   private final TlsVersion tlsVersion;
/*     */   private final CipherSuite cipherSuite;
/*     */   private final List<Certificate> peerCertificates;
/*     */   private final List<Certificate> localCertificates;
/*     */   
/*     */   private Handshake(TlsVersion tlsVersion, CipherSuite cipherSuite, List<Certificate> peerCertificates, List<Certificate> localCertificates) {
/*  42 */     this.tlsVersion = tlsVersion;
/*  43 */     this.cipherSuite = cipherSuite;
/*  44 */     this.peerCertificates = peerCertificates;
/*  45 */     this.localCertificates = localCertificates;
/*     */   }
/*     */   public static Handshake get(SSLSession session) {
/*     */     Certificate[] peerCertificates;
/*  49 */     String cipherSuiteString = session.getCipherSuite();
/*  50 */     if (cipherSuiteString == null) throw new IllegalStateException("cipherSuite == null"); 
/*  51 */     CipherSuite cipherSuite = CipherSuite.forJavaName(cipherSuiteString);
/*     */     
/*  53 */     String tlsVersionString = session.getProtocol();
/*  54 */     if (tlsVersionString == null) throw new IllegalStateException("tlsVersion == null"); 
/*  55 */     TlsVersion tlsVersion = TlsVersion.forJavaName(tlsVersionString);
/*     */ 
/*     */     
/*     */     try {
/*  59 */       peerCertificates = session.getPeerCertificates();
/*  60 */     } catch (SSLPeerUnverifiedException ignored) {
/*  61 */       peerCertificates = null;
/*     */     } 
/*     */ 
/*     */     
/*  65 */     List<Certificate> peerCertificatesList = (peerCertificates != null) ? Util.immutableList((Object[])peerCertificates) : Collections.<Certificate>emptyList();
/*     */     
/*  67 */     Certificate[] localCertificates = session.getLocalCertificates();
/*     */ 
/*     */     
/*  70 */     List<Certificate> localCertificatesList = (localCertificates != null) ? Util.immutableList((Object[])localCertificates) : Collections.<Certificate>emptyList();
/*     */     
/*  72 */     return new Handshake(tlsVersion, cipherSuite, peerCertificatesList, localCertificatesList);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Handshake get(TlsVersion tlsVersion, CipherSuite cipherSuite, List<Certificate> peerCertificates, List<Certificate> localCertificates) {
/*  77 */     if (cipherSuite == null) throw new NullPointerException("cipherSuite == null"); 
/*  78 */     return new Handshake(tlsVersion, cipherSuite, Util.immutableList(peerCertificates), 
/*  79 */         Util.immutableList(localCertificates));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TlsVersion tlsVersion() {
/*  87 */     return this.tlsVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   public CipherSuite cipherSuite() {
/*  92 */     return this.cipherSuite;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Certificate> peerCertificates() {
/*  97 */     return this.peerCertificates;
/*     */   }
/*     */ 
/*     */   
/*     */   public Principal peerPrincipal() {
/* 102 */     return !this.peerCertificates.isEmpty() ? ((X509Certificate)this.peerCertificates
/* 103 */       .get(0)).getSubjectX500Principal() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Certificate> localCertificates() {
/* 109 */     return this.localCertificates;
/*     */   }
/*     */ 
/*     */   
/*     */   public Principal localPrincipal() {
/* 114 */     return !this.localCertificates.isEmpty() ? ((X509Certificate)this.localCertificates
/* 115 */       .get(0)).getSubjectX500Principal() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 120 */     if (!(other instanceof Handshake)) return false; 
/* 121 */     Handshake that = (Handshake)other;
/* 122 */     return (Util.equal(this.cipherSuite, that.cipherSuite) && this.cipherSuite
/* 123 */       .equals(that.cipherSuite) && this.peerCertificates
/* 124 */       .equals(that.peerCertificates) && this.localCertificates
/* 125 */       .equals(that.localCertificates));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 129 */     int result = 17;
/* 130 */     result = 31 * result + ((this.tlsVersion != null) ? this.tlsVersion.hashCode() : 0);
/* 131 */     result = 31 * result + this.cipherSuite.hashCode();
/* 132 */     result = 31 * result + this.peerCertificates.hashCode();
/* 133 */     result = 31 * result + this.localCertificates.hashCode();
/* 134 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Handshake.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */