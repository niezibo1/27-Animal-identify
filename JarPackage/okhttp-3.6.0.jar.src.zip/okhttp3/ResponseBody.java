/*     */ package okhttp3;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ import okhttp3.internal.Util;
/*     */ import okio.Buffer;
/*     */ import okio.BufferedSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResponseBody
/*     */   implements Closeable
/*     */ {
/*     */   private Reader reader;
/*     */   
/*     */   public abstract MediaType contentType();
/*     */   
/*     */   public abstract long contentLength();
/*     */   
/*     */   public final InputStream byteStream() {
/* 114 */     return source().inputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BufferedSource source();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] bytes() throws IOException {
/*     */     byte[] bytes;
/* 127 */     long contentLength = contentLength();
/* 128 */     if (contentLength > 2147483647L) {
/* 129 */       throw new IOException("Cannot buffer entire body for content length: " + contentLength);
/*     */     }
/*     */     
/* 132 */     BufferedSource source = source();
/*     */     
/*     */     try {
/* 135 */       bytes = source.readByteArray();
/*     */     } finally {
/* 137 */       Util.closeQuietly((Closeable)source);
/*     */     } 
/* 139 */     if (contentLength != -1L && contentLength != bytes.length) {
/* 140 */       throw new IOException("Content-Length (" + contentLength + ") and stream length (" + bytes.length + ") disagree");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Reader charStream() {
/* 156 */     Reader r = this.reader;
/* 157 */     return (r != null) ? r : (this.reader = new BomAwareReader(source(), charset()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String string() throws IOException {
/* 171 */     BufferedSource source = source();
/*     */     try {
/* 173 */       Charset charset = Util.bomAwareCharset(source, charset());
/* 174 */       return source.readString(charset);
/*     */     } finally {
/* 176 */       Util.closeQuietly((Closeable)source);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Charset charset() {
/* 181 */     MediaType contentType = contentType();
/* 182 */     return (contentType != null) ? contentType.charset(Util.UTF_8) : Util.UTF_8;
/*     */   }
/*     */   
/*     */   public void close() {
/* 186 */     Util.closeQuietly((Closeable)source());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResponseBody create(MediaType contentType, String content) {
/* 194 */     Charset charset = Util.UTF_8;
/* 195 */     if (contentType != null) {
/* 196 */       charset = contentType.charset();
/* 197 */       if (charset == null) {
/* 198 */         charset = Util.UTF_8;
/* 199 */         contentType = MediaType.parse(contentType + "; charset=utf-8");
/*     */       } 
/*     */     } 
/* 202 */     Buffer buffer = (new Buffer()).writeString(content, charset);
/* 203 */     return create(contentType, buffer.size(), (BufferedSource)buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public static ResponseBody create(MediaType contentType, byte[] content) {
/* 208 */     Buffer buffer = (new Buffer()).write(content);
/* 209 */     return create(contentType, content.length, (BufferedSource)buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResponseBody create(final MediaType contentType, final long contentLength, final BufferedSource content) {
/* 215 */     if (content == null) throw new NullPointerException("source == null"); 
/* 216 */     return new ResponseBody() {
/*     */         public MediaType contentType() {
/* 218 */           return contentType;
/*     */         }
/*     */         
/*     */         public long contentLength() {
/* 222 */           return contentLength;
/*     */         }
/*     */         
/*     */         public BufferedSource source() {
/* 226 */           return content;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   static final class BomAwareReader
/*     */     extends Reader {
/*     */     private final BufferedSource source;
/*     */     private final Charset charset;
/*     */     private boolean closed;
/*     */     private Reader delegate;
/*     */     
/*     */     BomAwareReader(BufferedSource source, Charset charset) {
/* 239 */       this.source = source;
/* 240 */       this.charset = charset;
/*     */     }
/*     */     
/*     */     public int read(char[] cbuf, int off, int len) throws IOException {
/* 244 */       if (this.closed) throw new IOException("Stream closed");
/*     */       
/* 246 */       Reader delegate = this.delegate;
/* 247 */       if (delegate == null) {
/* 248 */         Charset charset = Util.bomAwareCharset(this.source, this.charset);
/* 249 */         delegate = this.delegate = new InputStreamReader(this.source.inputStream(), charset);
/*     */       } 
/* 251 */       return delegate.read(cbuf, off, len);
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 255 */       this.closed = true;
/* 256 */       if (this.delegate != null) {
/* 257 */         this.delegate.close();
/*     */       } else {
/* 259 */         this.source.close();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\ResponseBody.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */