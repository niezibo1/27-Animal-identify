/*      */ package okhttp3;
/*      */ 
/*      */ import java.net.InetAddress;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import okhttp3.internal.Util;
/*      */ import okio.Buffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HttpUrl
/*      */ {
/*  285 */   private static final char[] HEX_DIGITS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */ 
/*      */   
/*      */   static final String USERNAME_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#";
/*      */ 
/*      */   
/*      */   static final String PASSWORD_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#";
/*      */ 
/*      */   
/*      */   static final String PATH_SEGMENT_ENCODE_SET = " \"<>^`{}|/\\?#";
/*      */ 
/*      */   
/*      */   static final String PATH_SEGMENT_ENCODE_SET_URI = "[]";
/*      */ 
/*      */   
/*      */   static final String QUERY_ENCODE_SET = " \"'<>#";
/*      */ 
/*      */   
/*      */   static final String QUERY_COMPONENT_ENCODE_SET = " \"'<>#&=";
/*      */ 
/*      */   
/*      */   static final String QUERY_COMPONENT_ENCODE_SET_URI = "\\^`{|}";
/*      */   
/*      */   static final String FORM_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#&!$(),~";
/*      */   
/*      */   static final String FRAGMENT_ENCODE_SET = "";
/*      */   
/*      */   static final String FRAGMENT_ENCODE_SET_URI = " \"#<>\\^`{|}";
/*      */   
/*      */   final String scheme;
/*      */   
/*      */   private final String username;
/*      */   
/*      */   private final String password;
/*      */   
/*      */   final String host;
/*      */   
/*      */   final int port;
/*      */   
/*      */   private final List<String> pathSegments;
/*      */   
/*      */   private final List<String> queryNamesAndValues;
/*      */   
/*      */   private final String fragment;
/*      */   
/*      */   private final String url;
/*      */ 
/*      */   
/*      */   HttpUrl(Builder builder) {
/*  334 */     this.scheme = builder.scheme;
/*  335 */     this.username = percentDecode(builder.encodedUsername, false);
/*  336 */     this.password = percentDecode(builder.encodedPassword, false);
/*  337 */     this.host = builder.host;
/*  338 */     this.port = builder.effectivePort();
/*  339 */     this.pathSegments = percentDecode(builder.encodedPathSegments, false);
/*  340 */     this
/*  341 */       .queryNamesAndValues = (builder.encodedQueryNamesAndValues != null) ? percentDecode(builder.encodedQueryNamesAndValues, true) : null;
/*      */     
/*  343 */     this
/*  344 */       .fragment = (builder.encodedFragment != null) ? percentDecode(builder.encodedFragment, false) : null;
/*      */     
/*  346 */     this.url = builder.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public URL url() {
/*      */     try {
/*  352 */       return new URL(this.url);
/*  353 */     } catch (MalformedURLException e) {
/*  354 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URI uri() {
/*  372 */     String uri = newBuilder().reencodeForUri().toString();
/*      */     try {
/*  374 */       return new URI(uri);
/*  375 */     } catch (URISyntaxException e) {
/*      */       
/*      */       try {
/*  378 */         String stripped = uri.replaceAll("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]", "");
/*  379 */         return URI.create(stripped);
/*  380 */       } catch (Exception e1) {
/*  381 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String scheme() {
/*  388 */     return this.scheme;
/*      */   }
/*      */   
/*      */   public boolean isHttps() {
/*  392 */     return this.scheme.equals("https");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodedUsername() {
/*  407 */     if (this.username.isEmpty()) return ""; 
/*  408 */     int usernameStart = this.scheme.length() + 3;
/*  409 */     int usernameEnd = Util.delimiterOffset(this.url, usernameStart, this.url.length(), ":@");
/*  410 */     return this.url.substring(usernameStart, usernameEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String username() {
/*  425 */     return this.username;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodedPassword() {
/*  440 */     if (this.password.isEmpty()) return ""; 
/*  441 */     int passwordStart = this.url.indexOf(':', this.scheme.length() + 3) + 1;
/*  442 */     int passwordEnd = this.url.indexOf('@');
/*  443 */     return this.url.substring(passwordStart, passwordEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String password() {
/*  458 */     return this.password;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String host() {
/*  481 */     return this.host;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int port() {
/*  497 */     return this.port;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int defaultPort(String scheme) {
/*  505 */     if (scheme.equals("http"))
/*  506 */       return 80; 
/*  507 */     if (scheme.equals("https")) {
/*  508 */       return 443;
/*      */     }
/*  510 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int pathSize() {
/*  526 */     return this.pathSegments.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodedPath() {
/*  541 */     int pathStart = this.url.indexOf('/', this.scheme.length() + 3);
/*  542 */     int pathEnd = Util.delimiterOffset(this.url, pathStart, this.url.length(), "?#");
/*  543 */     return this.url.substring(pathStart, pathEnd);
/*      */   }
/*      */   
/*      */   static void pathSegmentsToString(StringBuilder out, List<String> pathSegments) {
/*  547 */     for (int i = 0, size = pathSegments.size(); i < size; i++) {
/*  548 */       out.append('/');
/*  549 */       out.append(pathSegments.get(i));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> encodedPathSegments() {
/*  565 */     int pathStart = this.url.indexOf('/', this.scheme.length() + 3);
/*  566 */     int pathEnd = Util.delimiterOffset(this.url, pathStart, this.url.length(), "?#");
/*  567 */     List<String> result = new ArrayList<>(); int i;
/*  568 */     for (i = pathStart; i < pathEnd; ) {
/*  569 */       i++;
/*  570 */       int segmentEnd = Util.delimiterOffset(this.url, i, pathEnd, '/');
/*  571 */       result.add(this.url.substring(i, segmentEnd));
/*  572 */       i = segmentEnd;
/*      */     } 
/*  574 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> pathSegments() {
/*  589 */     return this.pathSegments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodedQuery() {
/*  608 */     if (this.queryNamesAndValues == null) return null; 
/*  609 */     int queryStart = this.url.indexOf('?') + 1;
/*  610 */     int queryEnd = Util.delimiterOffset(this.url, queryStart + 1, this.url.length(), '#');
/*  611 */     return this.url.substring(queryStart, queryEnd);
/*      */   }
/*      */   
/*      */   static void namesAndValuesToQueryString(StringBuilder out, List<String> namesAndValues) {
/*  615 */     for (int i = 0, size = namesAndValues.size(); i < size; i += 2) {
/*  616 */       String name = namesAndValues.get(i);
/*  617 */       String value = namesAndValues.get(i + 1);
/*  618 */       if (i > 0) out.append('&'); 
/*  619 */       out.append(name);
/*  620 */       if (value != null) {
/*  621 */         out.append('=');
/*  622 */         out.append(value);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static List<String> queryStringToNamesAndValues(String encodedQuery) {
/*  634 */     List<String> result = new ArrayList<>();
/*  635 */     for (int pos = 0; pos <= encodedQuery.length(); ) {
/*  636 */       int ampersandOffset = encodedQuery.indexOf('&', pos);
/*  637 */       if (ampersandOffset == -1) ampersandOffset = encodedQuery.length();
/*      */       
/*  639 */       int equalsOffset = encodedQuery.indexOf('=', pos);
/*  640 */       if (equalsOffset == -1 || equalsOffset > ampersandOffset) {
/*  641 */         result.add(encodedQuery.substring(pos, ampersandOffset));
/*  642 */         result.add(null);
/*      */       } else {
/*  644 */         result.add(encodedQuery.substring(pos, equalsOffset));
/*  645 */         result.add(encodedQuery.substring(equalsOffset + 1, ampersandOffset));
/*      */       } 
/*  647 */       pos = ampersandOffset + 1;
/*      */     } 
/*  649 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String query() {
/*  668 */     if (this.queryNamesAndValues == null) return null; 
/*  669 */     StringBuilder result = new StringBuilder();
/*  670 */     namesAndValuesToQueryString(result, this.queryNamesAndValues);
/*  671 */     return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int querySize() {
/*  689 */     return (this.queryNamesAndValues != null) ? (this.queryNamesAndValues.size() / 2) : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String queryParameter(String name) {
/*  706 */     if (this.queryNamesAndValues == null) return null; 
/*  707 */     for (int i = 0, size = this.queryNamesAndValues.size(); i < size; i += 2) {
/*  708 */       if (name.equals(this.queryNamesAndValues.get(i))) {
/*  709 */         return this.queryNamesAndValues.get(i + 1);
/*      */       }
/*      */     } 
/*  712 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> queryParameterNames() {
/*  729 */     if (this.queryNamesAndValues == null) return Collections.emptySet(); 
/*  730 */     Set<String> result = new LinkedHashSet<>();
/*  731 */     for (int i = 0, size = this.queryNamesAndValues.size(); i < size; i += 2) {
/*  732 */       result.add(this.queryNamesAndValues.get(i));
/*      */     }
/*  734 */     return Collections.unmodifiableSet(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> queryParameterValues(String name) {
/*  756 */     if (this.queryNamesAndValues == null) return Collections.emptyList(); 
/*  757 */     List<String> result = new ArrayList<>();
/*  758 */     for (int i = 0, size = this.queryNamesAndValues.size(); i < size; i += 2) {
/*  759 */       if (name.equals(this.queryNamesAndValues.get(i))) {
/*  760 */         result.add(this.queryNamesAndValues.get(i + 1));
/*      */       }
/*      */     } 
/*  763 */     return Collections.unmodifiableList(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String queryParameterName(int index) {
/*  784 */     if (this.queryNamesAndValues == null) throw new IndexOutOfBoundsException(); 
/*  785 */     return this.queryNamesAndValues.get(index * 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String queryParameterValue(int index) {
/*  806 */     if (this.queryNamesAndValues == null) throw new IndexOutOfBoundsException(); 
/*  807 */     return this.queryNamesAndValues.get(index * 2 + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodedFragment() {
/*  823 */     if (this.fragment == null) return null; 
/*  824 */     int fragmentStart = this.url.indexOf('#') + 1;
/*  825 */     return this.url.substring(fragmentStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String fragment() {
/*  841 */     return this.fragment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String redact() {
/*  850 */     return newBuilder("/...")
/*  851 */       .username("")
/*  852 */       .password("")
/*  853 */       .build()
/*  854 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpUrl resolve(String link) {
/*  862 */     Builder builder = newBuilder(link);
/*  863 */     return (builder != null) ? builder.build() : null;
/*      */   }
/*      */   
/*      */   public Builder newBuilder() {
/*  867 */     Builder result = new Builder();
/*  868 */     result.scheme = this.scheme;
/*  869 */     result.encodedUsername = encodedUsername();
/*  870 */     result.encodedPassword = encodedPassword();
/*  871 */     result.host = this.host;
/*      */     
/*  873 */     result.port = (this.port != defaultPort(this.scheme)) ? this.port : -1;
/*  874 */     result.encodedPathSegments.clear();
/*  875 */     result.encodedPathSegments.addAll(encodedPathSegments());
/*  876 */     result.encodedQuery(encodedQuery());
/*  877 */     result.encodedFragment = encodedFragment();
/*  878 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Builder newBuilder(String link) {
/*  886 */     Builder builder = new Builder();
/*  887 */     Builder.ParseResult result = builder.parse(this, link);
/*  888 */     return (result == Builder.ParseResult.SUCCESS) ? builder : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpUrl parse(String url) {
/*  896 */     Builder builder = new Builder();
/*  897 */     Builder.ParseResult result = builder.parse(null, url);
/*  898 */     return (result == Builder.ParseResult.SUCCESS) ? builder.build() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpUrl get(URL url) {
/*  906 */     return parse(url.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static HttpUrl getChecked(String url) throws MalformedURLException, UnknownHostException {
/*  917 */     Builder builder = new Builder();
/*  918 */     Builder.ParseResult result = builder.parse(null, url);
/*  919 */     switch (result) {
/*      */       case SUCCESS:
/*  921 */         return builder.build();
/*      */       case INVALID_HOST:
/*  923 */         throw new UnknownHostException("Invalid host: " + url);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  928 */     throw new MalformedURLException("Invalid URL: " + result + " for " + url);
/*      */   }
/*      */ 
/*      */   
/*      */   public static HttpUrl get(URI uri) {
/*  933 */     return parse(uri.toString());
/*      */   }
/*      */   
/*      */   public boolean equals(Object o) {
/*  937 */     return (o instanceof HttpUrl && ((HttpUrl)o).url.equals(this.url));
/*      */   }
/*      */   
/*      */   public int hashCode() {
/*  941 */     return this.url.hashCode();
/*      */   }
/*      */   
/*      */   public String toString() {
/*  945 */     return this.url;
/*      */   }
/*      */   
/*      */   public static final class Builder {
/*      */     String scheme;
/*  950 */     String encodedUsername = "";
/*  951 */     String encodedPassword = "";
/*      */     String host;
/*  953 */     int port = -1;
/*  954 */     final List<String> encodedPathSegments = new ArrayList<>();
/*      */     List<String> encodedQueryNamesAndValues;
/*      */     String encodedFragment;
/*      */     
/*      */     public Builder() {
/*  959 */       this.encodedPathSegments.add("");
/*      */     }
/*      */     
/*      */     public Builder scheme(String scheme) {
/*  963 */       if (scheme == null)
/*  964 */         throw new NullPointerException("scheme == null"); 
/*  965 */       if (scheme.equalsIgnoreCase("http")) {
/*  966 */         this.scheme = "http";
/*  967 */       } else if (scheme.equalsIgnoreCase("https")) {
/*  968 */         this.scheme = "https";
/*      */       } else {
/*  970 */         throw new IllegalArgumentException("unexpected scheme: " + scheme);
/*      */       } 
/*  972 */       return this;
/*      */     }
/*      */     
/*      */     public Builder username(String username) {
/*  976 */       if (username == null) throw new NullPointerException("username == null"); 
/*  977 */       this.encodedUsername = HttpUrl.canonicalize(username, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
/*  978 */       return this;
/*      */     }
/*      */     
/*      */     public Builder encodedUsername(String encodedUsername) {
/*  982 */       if (encodedUsername == null) throw new NullPointerException("encodedUsername == null"); 
/*  983 */       this.encodedUsername = HttpUrl.canonicalize(encodedUsername, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
/*      */       
/*  985 */       return this;
/*      */     }
/*      */     
/*      */     public Builder password(String password) {
/*  989 */       if (password == null) throw new NullPointerException("password == null"); 
/*  990 */       this.encodedPassword = HttpUrl.canonicalize(password, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
/*  991 */       return this;
/*      */     }
/*      */     
/*      */     public Builder encodedPassword(String encodedPassword) {
/*  995 */       if (encodedPassword == null) throw new NullPointerException("encodedPassword == null"); 
/*  996 */       this.encodedPassword = HttpUrl.canonicalize(encodedPassword, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
/*      */       
/*  998 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder host(String host) {
/* 1006 */       if (host == null) throw new NullPointerException("host == null"); 
/* 1007 */       String encoded = canonicalizeHost(host, 0, host.length());
/* 1008 */       if (encoded == null) throw new IllegalArgumentException("unexpected host: " + host); 
/* 1009 */       this.host = encoded;
/* 1010 */       return this;
/*      */     }
/*      */     
/*      */     public Builder port(int port) {
/* 1014 */       if (port <= 0 || port > 65535) throw new IllegalArgumentException("unexpected port: " + port); 
/* 1015 */       this.port = port;
/* 1016 */       return this;
/*      */     }
/*      */     
/*      */     int effectivePort() {
/* 1020 */       return (this.port != -1) ? this.port : HttpUrl.defaultPort(this.scheme);
/*      */     }
/*      */     
/*      */     public Builder addPathSegment(String pathSegment) {
/* 1024 */       if (pathSegment == null) throw new NullPointerException("pathSegment == null"); 
/* 1025 */       push(pathSegment, 0, pathSegment.length(), false, false);
/* 1026 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder addPathSegments(String pathSegments) {
/* 1034 */       if (pathSegments == null) throw new NullPointerException("pathSegments == null"); 
/* 1035 */       return addPathSegments(pathSegments, false);
/*      */     }
/*      */     
/*      */     public Builder addEncodedPathSegment(String encodedPathSegment) {
/* 1039 */       if (encodedPathSegment == null) {
/* 1040 */         throw new NullPointerException("encodedPathSegment == null");
/*      */       }
/* 1042 */       push(encodedPathSegment, 0, encodedPathSegment.length(), false, true);
/* 1043 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Builder addEncodedPathSegments(String encodedPathSegments) {
/* 1052 */       if (encodedPathSegments == null) {
/* 1053 */         throw new NullPointerException("encodedPathSegments == null");
/*      */       }
/* 1055 */       return addPathSegments(encodedPathSegments, true);
/*      */     }
/*      */     
/*      */     private Builder addPathSegments(String pathSegments, boolean alreadyEncoded) {
/* 1059 */       int offset = 0;
/*      */       while (true) {
/* 1061 */         int segmentEnd = Util.delimiterOffset(pathSegments, offset, pathSegments.length(), "/\\");
/* 1062 */         boolean addTrailingSlash = (segmentEnd < pathSegments.length());
/* 1063 */         push(pathSegments, offset, segmentEnd, addTrailingSlash, alreadyEncoded);
/* 1064 */         offset = segmentEnd + 1;
/* 1065 */         if (offset > pathSegments.length())
/* 1066 */           return this; 
/*      */       } 
/*      */     }
/*      */     public Builder setPathSegment(int index, String pathSegment) {
/* 1070 */       if (pathSegment == null) throw new NullPointerException("pathSegment == null"); 
/* 1071 */       String canonicalPathSegment = HttpUrl.canonicalize(pathSegment, 0, pathSegment
/* 1072 */           .length(), " \"<>^`{}|/\\?#", false, false, false, true);
/* 1073 */       if (isDot(canonicalPathSegment) || isDotDot(canonicalPathSegment)) {
/* 1074 */         throw new IllegalArgumentException("unexpected path segment: " + pathSegment);
/*      */       }
/* 1076 */       this.encodedPathSegments.set(index, canonicalPathSegment);
/* 1077 */       return this;
/*      */     }
/*      */     
/*      */     public Builder setEncodedPathSegment(int index, String encodedPathSegment) {
/* 1081 */       if (encodedPathSegment == null) {
/* 1082 */         throw new NullPointerException("encodedPathSegment == null");
/*      */       }
/* 1084 */       String canonicalPathSegment = HttpUrl.canonicalize(encodedPathSegment, 0, encodedPathSegment
/* 1085 */           .length(), " \"<>^`{}|/\\?#", true, false, false, true);
/* 1086 */       this.encodedPathSegments.set(index, canonicalPathSegment);
/* 1087 */       if (isDot(canonicalPathSegment) || isDotDot(canonicalPathSegment)) {
/* 1088 */         throw new IllegalArgumentException("unexpected path segment: " + encodedPathSegment);
/*      */       }
/* 1090 */       return this;
/*      */     }
/*      */     
/*      */     public Builder removePathSegment(int index) {
/* 1094 */       this.encodedPathSegments.remove(index);
/* 1095 */       if (this.encodedPathSegments.isEmpty()) {
/* 1096 */         this.encodedPathSegments.add("");
/*      */       }
/* 1098 */       return this;
/*      */     }
/*      */     
/*      */     public Builder encodedPath(String encodedPath) {
/* 1102 */       if (encodedPath == null) throw new NullPointerException("encodedPath == null"); 
/* 1103 */       if (!encodedPath.startsWith("/")) {
/* 1104 */         throw new IllegalArgumentException("unexpected encodedPath: " + encodedPath);
/*      */       }
/* 1106 */       resolvePath(encodedPath, 0, encodedPath.length());
/* 1107 */       return this;
/*      */     }
/*      */     
/*      */     public Builder query(String query) {
/* 1111 */       this
/* 1112 */         .encodedQueryNamesAndValues = (query != null) ? HttpUrl.queryStringToNamesAndValues(HttpUrl.canonicalize(query, " \"'<>#", false, false, true, true)) : null;
/*      */ 
/*      */       
/* 1115 */       return this;
/*      */     }
/*      */     
/*      */     public Builder encodedQuery(String encodedQuery) {
/* 1119 */       this
/* 1120 */         .encodedQueryNamesAndValues = (encodedQuery != null) ? HttpUrl.queryStringToNamesAndValues(
/* 1121 */           HttpUrl.canonicalize(encodedQuery, " \"'<>#", true, false, true, true)) : null;
/*      */       
/* 1123 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Builder addQueryParameter(String name, String value) {
/* 1128 */       if (name == null) throw new NullPointerException("name == null"); 
/* 1129 */       if (this.encodedQueryNamesAndValues == null) this.encodedQueryNamesAndValues = new ArrayList<>(); 
/* 1130 */       this.encodedQueryNamesAndValues.add(
/* 1131 */           HttpUrl.canonicalize(name, " \"'<>#&=", false, false, true, true));
/* 1132 */       this.encodedQueryNamesAndValues.add((value != null) ? 
/* 1133 */           HttpUrl.canonicalize(value, " \"'<>#&=", false, false, true, true) : null);
/*      */       
/* 1135 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public Builder addEncodedQueryParameter(String encodedName, String encodedValue) {
/* 1140 */       if (encodedName == null) throw new NullPointerException("encodedName == null"); 
/* 1141 */       if (this.encodedQueryNamesAndValues == null) this.encodedQueryNamesAndValues = new ArrayList<>(); 
/* 1142 */       this.encodedQueryNamesAndValues.add(
/* 1143 */           HttpUrl.canonicalize(encodedName, " \"'<>#&=", true, false, true, true));
/* 1144 */       this.encodedQueryNamesAndValues.add((encodedValue != null) ? 
/* 1145 */           HttpUrl.canonicalize(encodedValue, " \"'<>#&=", true, false, true, true) : null);
/*      */       
/* 1147 */       return this;
/*      */     }
/*      */     
/*      */     public Builder setQueryParameter(String name, String value) {
/* 1151 */       removeAllQueryParameters(name);
/* 1152 */       addQueryParameter(name, value);
/* 1153 */       return this;
/*      */     }
/*      */     
/*      */     public Builder setEncodedQueryParameter(String encodedName, String encodedValue) {
/* 1157 */       removeAllEncodedQueryParameters(encodedName);
/* 1158 */       addEncodedQueryParameter(encodedName, encodedValue);
/* 1159 */       return this;
/*      */     }
/*      */     
/*      */     public Builder removeAllQueryParameters(String name) {
/* 1163 */       if (name == null) throw new NullPointerException("name == null"); 
/* 1164 */       if (this.encodedQueryNamesAndValues == null) return this; 
/* 1165 */       String nameToRemove = HttpUrl.canonicalize(name, " \"'<>#&=", false, false, true, true);
/*      */       
/* 1167 */       removeAllCanonicalQueryParameters(nameToRemove);
/* 1168 */       return this;
/*      */     }
/*      */     
/*      */     public Builder removeAllEncodedQueryParameters(String encodedName) {
/* 1172 */       if (encodedName == null) throw new NullPointerException("encodedName == null"); 
/* 1173 */       if (this.encodedQueryNamesAndValues == null) return this; 
/* 1174 */       removeAllCanonicalQueryParameters(
/* 1175 */           HttpUrl.canonicalize(encodedName, " \"'<>#&=", true, false, true, true));
/* 1176 */       return this;
/*      */     }
/*      */     
/*      */     private void removeAllCanonicalQueryParameters(String canonicalName) {
/* 1180 */       for (int i = this.encodedQueryNamesAndValues.size() - 2; i >= 0; i -= 2) {
/* 1181 */         if (canonicalName.equals(this.encodedQueryNamesAndValues.get(i))) {
/* 1182 */           this.encodedQueryNamesAndValues.remove(i + 1);
/* 1183 */           this.encodedQueryNamesAndValues.remove(i);
/* 1184 */           if (this.encodedQueryNamesAndValues.isEmpty()) {
/* 1185 */             this.encodedQueryNamesAndValues = null;
/*      */             return;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public Builder fragment(String fragment) {
/* 1193 */       this
/* 1194 */         .encodedFragment = (fragment != null) ? HttpUrl.canonicalize(fragment, "", false, false, false, false) : null;
/*      */       
/* 1196 */       return this;
/*      */     }
/*      */     
/*      */     public Builder encodedFragment(String encodedFragment) {
/* 1200 */       this
/* 1201 */         .encodedFragment = (encodedFragment != null) ? HttpUrl.canonicalize(encodedFragment, "", true, false, false, false) : null;
/*      */       
/* 1203 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     Builder reencodeForUri() {
/*      */       int i;
/*      */       int size;
/* 1211 */       for (i = 0, size = this.encodedPathSegments.size(); i < size; i++) {
/* 1212 */         String pathSegment = this.encodedPathSegments.get(i);
/* 1213 */         this.encodedPathSegments.set(i, 
/* 1214 */             HttpUrl.canonicalize(pathSegment, "[]", true, true, false, true));
/*      */       } 
/* 1216 */       if (this.encodedQueryNamesAndValues != null) {
/* 1217 */         for (i = 0, size = this.encodedQueryNamesAndValues.size(); i < size; i++) {
/* 1218 */           String component = this.encodedQueryNamesAndValues.get(i);
/* 1219 */           if (component != null) {
/* 1220 */             this.encodedQueryNamesAndValues.set(i, 
/* 1221 */                 HttpUrl.canonicalize(component, "\\^`{|}", true, true, true, true));
/*      */           }
/*      */         } 
/*      */       }
/* 1225 */       if (this.encodedFragment != null) {
/* 1226 */         this.encodedFragment = HttpUrl.canonicalize(this.encodedFragment, " \"#<>\\^`{|}", true, true, false, false);
/*      */       }
/*      */       
/* 1229 */       return this;
/*      */     }
/*      */     
/*      */     public HttpUrl build() {
/* 1233 */       if (this.scheme == null) throw new IllegalStateException("scheme == null"); 
/* 1234 */       if (this.host == null) throw new IllegalStateException("host == null"); 
/* 1235 */       return new HttpUrl(this);
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1239 */       StringBuilder result = new StringBuilder();
/* 1240 */       result.append(this.scheme);
/* 1241 */       result.append("://");
/*      */       
/* 1243 */       if (!this.encodedUsername.isEmpty() || !this.encodedPassword.isEmpty()) {
/* 1244 */         result.append(this.encodedUsername);
/* 1245 */         if (!this.encodedPassword.isEmpty()) {
/* 1246 */           result.append(':');
/* 1247 */           result.append(this.encodedPassword);
/*      */         } 
/* 1249 */         result.append('@');
/*      */       } 
/*      */       
/* 1252 */       if (this.host.indexOf(':') != -1) {
/*      */         
/* 1254 */         result.append('[');
/* 1255 */         result.append(this.host);
/* 1256 */         result.append(']');
/*      */       } else {
/* 1258 */         result.append(this.host);
/*      */       } 
/*      */       
/* 1261 */       int effectivePort = effectivePort();
/* 1262 */       if (effectivePort != HttpUrl.defaultPort(this.scheme)) {
/* 1263 */         result.append(':');
/* 1264 */         result.append(effectivePort);
/*      */       } 
/*      */       
/* 1267 */       HttpUrl.pathSegmentsToString(result, this.encodedPathSegments);
/*      */       
/* 1269 */       if (this.encodedQueryNamesAndValues != null) {
/* 1270 */         result.append('?');
/* 1271 */         HttpUrl.namesAndValuesToQueryString(result, this.encodedQueryNamesAndValues);
/*      */       } 
/*      */       
/* 1274 */       if (this.encodedFragment != null) {
/* 1275 */         result.append('#');
/* 1276 */         result.append(this.encodedFragment);
/*      */       } 
/*      */       
/* 1279 */       return result.toString();
/*      */     }
/*      */     
/*      */     enum ParseResult {
/* 1283 */       SUCCESS,
/* 1284 */       MISSING_SCHEME,
/* 1285 */       UNSUPPORTED_SCHEME,
/* 1286 */       INVALID_PORT,
/* 1287 */       INVALID_HOST;
/*      */     }
/*      */     
/*      */     ParseResult parse(HttpUrl base, String input) {
/* 1291 */       int pos = Util.skipLeadingAsciiWhitespace(input, 0, input.length());
/* 1292 */       int limit = Util.skipTrailingAsciiWhitespace(input, pos, input.length());
/*      */ 
/*      */       
/* 1295 */       int schemeDelimiterOffset = schemeDelimiterOffset(input, pos, limit);
/* 1296 */       if (schemeDelimiterOffset != -1) {
/* 1297 */         if (input.regionMatches(true, pos, "https:", 0, 6)) {
/* 1298 */           this.scheme = "https";
/* 1299 */           pos += "https:".length();
/* 1300 */         } else if (input.regionMatches(true, pos, "http:", 0, 5)) {
/* 1301 */           this.scheme = "http";
/* 1302 */           pos += "http:".length();
/*      */         } else {
/* 1304 */           return ParseResult.UNSUPPORTED_SCHEME;
/*      */         } 
/* 1306 */       } else if (base != null) {
/* 1307 */         this.scheme = base.scheme;
/*      */       } else {
/* 1309 */         return ParseResult.MISSING_SCHEME;
/*      */       } 
/*      */ 
/*      */       
/* 1313 */       boolean hasUsername = false;
/* 1314 */       boolean hasPassword = false;
/* 1315 */       int slashCount = slashCount(input, pos, limit);
/* 1316 */       if (slashCount >= 2 || base == null || !base.scheme.equals(this.scheme)) {
/*      */         int componentDelimiterOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1326 */         pos += slashCount;
/*      */         
/*      */         while (true) {
/* 1329 */           componentDelimiterOffset = Util.delimiterOffset(input, pos, limit, "@/\\?#");
/*      */           
/* 1331 */           int c = (componentDelimiterOffset != limit) ? input.charAt(componentDelimiterOffset) : -1;
/*      */           
/* 1333 */           switch (c) {
/*      */             
/*      */             case 64:
/* 1336 */               if (!hasPassword) {
/* 1337 */                 int passwordColonOffset = Util.delimiterOffset(input, pos, componentDelimiterOffset, ':');
/*      */                 
/* 1339 */                 String canonicalUsername = HttpUrl.canonicalize(input, pos, passwordColonOffset, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
/*      */                 
/* 1341 */                 this.encodedUsername = hasUsername ? (this.encodedUsername + "%40" + canonicalUsername) : canonicalUsername;
/*      */ 
/*      */                 
/* 1344 */                 if (passwordColonOffset != componentDelimiterOffset) {
/* 1345 */                   hasPassword = true;
/* 1346 */                   this.encodedPassword = HttpUrl.canonicalize(input, passwordColonOffset + 1, componentDelimiterOffset, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
/*      */                 } 
/*      */                 
/* 1349 */                 hasUsername = true;
/*      */               } else {
/* 1351 */                 this.encodedPassword += "%40" + HttpUrl.canonicalize(input, pos, componentDelimiterOffset, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
/*      */               } 
/*      */               
/* 1354 */               pos = componentDelimiterOffset + 1;
/*      */             case -1:
/*      */             case 35:
/*      */             case 47:
/*      */             case 63:
/*      */             case 92:
/*      */               break;
/*      */           } 
/*      */         } 
/* 1363 */         int portColonOffset = portColonOffset(input, pos, componentDelimiterOffset);
/* 1364 */         if (portColonOffset + 1 < componentDelimiterOffset) {
/* 1365 */           this.host = canonicalizeHost(input, pos, portColonOffset);
/* 1366 */           this.port = parsePort(input, portColonOffset + 1, componentDelimiterOffset);
/* 1367 */           if (this.port == -1) return ParseResult.INVALID_PORT; 
/*      */         } else {
/* 1369 */           this.host = canonicalizeHost(input, pos, portColonOffset);
/* 1370 */           this.port = HttpUrl.defaultPort(this.scheme);
/*      */         } 
/* 1372 */         if (this.host == null) return ParseResult.INVALID_HOST; 
/* 1373 */         pos = componentDelimiterOffset;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1379 */         this.encodedUsername = base.encodedUsername();
/* 1380 */         this.encodedPassword = base.encodedPassword();
/* 1381 */         this.host = base.host;
/* 1382 */         this.port = base.port;
/* 1383 */         this.encodedPathSegments.clear();
/* 1384 */         this.encodedPathSegments.addAll(base.encodedPathSegments());
/* 1385 */         if (pos == limit || input.charAt(pos) == '#') {
/* 1386 */           encodedQuery(base.encodedQuery());
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1391 */       int pathDelimiterOffset = Util.delimiterOffset(input, pos, limit, "?#");
/* 1392 */       resolvePath(input, pos, pathDelimiterOffset);
/* 1393 */       pos = pathDelimiterOffset;
/*      */ 
/*      */       
/* 1396 */       if (pos < limit && input.charAt(pos) == '?') {
/* 1397 */         int queryDelimiterOffset = Util.delimiterOffset(input, pos, limit, '#');
/* 1398 */         this.encodedQueryNamesAndValues = HttpUrl.queryStringToNamesAndValues(HttpUrl.canonicalize(input, pos + 1, queryDelimiterOffset, " \"'<>#", true, false, true, true));
/*      */         
/* 1400 */         pos = queryDelimiterOffset;
/*      */       } 
/*      */ 
/*      */       
/* 1404 */       if (pos < limit && input.charAt(pos) == '#') {
/* 1405 */         this.encodedFragment = HttpUrl.canonicalize(input, pos + 1, limit, "", true, false, false, false);
/*      */       }
/*      */ 
/*      */       
/* 1409 */       return ParseResult.SUCCESS;
/*      */     }
/*      */ 
/*      */     
/*      */     private void resolvePath(String input, int pos, int limit) {
/* 1414 */       if (pos == limit) {
/*      */         return;
/*      */       }
/*      */       
/* 1418 */       char c = input.charAt(pos);
/* 1419 */       if (c == '/' || c == '\\') {
/*      */         
/* 1421 */         this.encodedPathSegments.clear();
/* 1422 */         this.encodedPathSegments.add("");
/* 1423 */         pos++;
/*      */       } else {
/*      */         
/* 1426 */         this.encodedPathSegments.set(this.encodedPathSegments.size() - 1, "");
/*      */       } 
/*      */ 
/*      */       
/* 1430 */       for (int i = pos; i < limit; ) {
/* 1431 */         int pathSegmentDelimiterOffset = Util.delimiterOffset(input, i, limit, "/\\");
/* 1432 */         boolean segmentHasTrailingSlash = (pathSegmentDelimiterOffset < limit);
/* 1433 */         push(input, i, pathSegmentDelimiterOffset, segmentHasTrailingSlash, true);
/* 1434 */         i = pathSegmentDelimiterOffset;
/* 1435 */         if (segmentHasTrailingSlash) i++;
/*      */       
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void push(String input, int pos, int limit, boolean addTrailingSlash, boolean alreadyEncoded) {
/* 1442 */       String segment = HttpUrl.canonicalize(input, pos, limit, " \"<>^`{}|/\\?#", alreadyEncoded, false, false, true);
/*      */       
/* 1444 */       if (isDot(segment)) {
/*      */         return;
/*      */       }
/* 1447 */       if (isDotDot(segment)) {
/* 1448 */         pop();
/*      */         return;
/*      */       } 
/* 1451 */       if (((String)this.encodedPathSegments.get(this.encodedPathSegments.size() - 1)).isEmpty()) {
/* 1452 */         this.encodedPathSegments.set(this.encodedPathSegments.size() - 1, segment);
/*      */       } else {
/* 1454 */         this.encodedPathSegments.add(segment);
/*      */       } 
/* 1456 */       if (addTrailingSlash) {
/* 1457 */         this.encodedPathSegments.add("");
/*      */       }
/*      */     }
/*      */     
/*      */     private boolean isDot(String input) {
/* 1462 */       return (input.equals(".") || input.equalsIgnoreCase("%2e"));
/*      */     }
/*      */     
/*      */     private boolean isDotDot(String input) {
/* 1466 */       return (input.equals("..") || input
/* 1467 */         .equalsIgnoreCase("%2e.") || input
/* 1468 */         .equalsIgnoreCase(".%2e") || input
/* 1469 */         .equalsIgnoreCase("%2e%2e"));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void pop() {
/* 1483 */       String removed = this.encodedPathSegments.remove(this.encodedPathSegments.size() - 1);
/*      */ 
/*      */       
/* 1486 */       if (removed.isEmpty() && !this.encodedPathSegments.isEmpty()) {
/* 1487 */         this.encodedPathSegments.set(this.encodedPathSegments.size() - 1, "");
/*      */       } else {
/* 1489 */         this.encodedPathSegments.add("");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static int schemeDelimiterOffset(String input, int pos, int limit) {
/* 1498 */       if (limit - pos < 2) return -1;
/*      */       
/* 1500 */       char c0 = input.charAt(pos);
/* 1501 */       if ((c0 < 'a' || c0 > 'z') && (c0 < 'A' || c0 > 'Z')) return -1;
/*      */       
/* 1503 */       for (int i = pos + 1; i < limit; ) {
/* 1504 */         char c = input.charAt(i);
/*      */         
/* 1506 */         if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '+' || c == '-' || c == '.') {
/*      */           i++;
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/* 1513 */         if (c == ':') {
/* 1514 */           return i;
/*      */         }
/* 1516 */         return -1;
/*      */       } 
/*      */ 
/*      */       
/* 1520 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*      */     private static int slashCount(String input, int pos, int limit) {
/* 1525 */       int slashCount = 0;
/* 1526 */       while (pos < limit) {
/* 1527 */         char c = input.charAt(pos);
/* 1528 */         if (c == '\\' || c == '/') {
/* 1529 */           slashCount++;
/* 1530 */           pos++;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1535 */       return slashCount;
/*      */     }
/*      */ 
/*      */     
/*      */     private static int portColonOffset(String input, int pos, int limit) {
/* 1540 */       for (int i = pos; i < limit; i++) {
/* 1541 */         switch (input.charAt(i)) { case '[':
/*      */             do {  }
/* 1543 */             while (++i < limit && 
/* 1544 */               input.charAt(i) != ']');
/*      */             break;
/*      */           
/*      */           case ':':
/* 1548 */             return i; }
/*      */       
/*      */       } 
/* 1551 */       return limit;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static String canonicalizeHost(String input, int pos, int limit) {
/* 1557 */       String percentDecoded = HttpUrl.percentDecode(input, pos, limit, false);
/*      */ 
/*      */       
/* 1560 */       if (percentDecoded.contains(":")) {
/*      */ 
/*      */ 
/*      */         
/* 1564 */         InetAddress inetAddress = (percentDecoded.startsWith("[") && percentDecoded.endsWith("]")) ? decodeIpv6(percentDecoded, 1, percentDecoded.length() - 1) : decodeIpv6(percentDecoded, 0, percentDecoded.length());
/* 1565 */         if (inetAddress == null) return null; 
/* 1566 */         byte[] address = inetAddress.getAddress();
/* 1567 */         if (address.length == 16) return inet6AddressToAscii(address); 
/* 1568 */         throw new AssertionError();
/*      */       } 
/*      */       
/* 1571 */       return Util.domainToAscii(percentDecoded);
/*      */     }
/*      */ 
/*      */     
/*      */     private static InetAddress decodeIpv6(String input, int pos, int limit) {
/* 1576 */       byte[] address = new byte[16];
/* 1577 */       int b = 0;
/* 1578 */       int compress = -1;
/* 1579 */       int groupOffset = -1;
/*      */       
/* 1581 */       for (int i = pos; i < limit; ) {
/* 1582 */         if (b == address.length) return null;
/*      */ 
/*      */         
/* 1585 */         if (i + 2 <= limit && input.regionMatches(i, "::", 0, 2))
/*      */         
/* 1587 */         { if (compress != -1) return null; 
/* 1588 */           i += 2;
/* 1589 */           b += 2;
/* 1590 */           compress = b;
/* 1591 */           if (i == limit)
/* 1592 */             break;  } else if (b != 0)
/*      */         
/* 1594 */         { if (input.regionMatches(i, ":", 0, 1))
/* 1595 */           { i++; }
/* 1596 */           else { if (input.regionMatches(i, ".", 0, 1)) {
/*      */               
/* 1598 */               if (!decodeIpv4Suffix(input, groupOffset, limit, address, b - 2)) return null; 
/* 1599 */               b += 2;
/*      */               break;
/*      */             } 
/* 1602 */             return null; }
/*      */            }
/*      */ 
/*      */ 
/*      */         
/* 1607 */         int value = 0;
/* 1608 */         groupOffset = i;
/* 1609 */         for (; i < limit; i++) {
/* 1610 */           char c = input.charAt(i);
/* 1611 */           int hexDigit = HttpUrl.decodeHexDigit(c);
/* 1612 */           if (hexDigit == -1)
/* 1613 */             break;  value = (value << 4) + hexDigit;
/*      */         } 
/* 1615 */         int groupLength = i - groupOffset;
/* 1616 */         if (groupLength == 0 || groupLength > 4) return null;
/*      */ 
/*      */         
/* 1619 */         address[b++] = (byte)(value >>> 8 & 0xFF);
/* 1620 */         address[b++] = (byte)(value & 0xFF);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1632 */       if (b != address.length) {
/* 1633 */         if (compress == -1) return null; 
/* 1634 */         System.arraycopy(address, compress, address, address.length - b - compress, b - compress);
/* 1635 */         Arrays.fill(address, compress, compress + address.length - b, (byte)0);
/*      */       } 
/*      */       
/*      */       try {
/* 1639 */         return InetAddress.getByAddress(address);
/* 1640 */       } catch (UnknownHostException e) {
/* 1641 */         throw new AssertionError();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean decodeIpv4Suffix(String input, int pos, int limit, byte[] address, int addressOffset) {
/* 1648 */       int b = addressOffset;
/*      */       
/* 1650 */       for (int i = pos; i < limit; ) {
/* 1651 */         if (b == address.length) return false;
/*      */ 
/*      */         
/* 1654 */         if (b != addressOffset) {
/* 1655 */           if (input.charAt(i) != '.') return false; 
/* 1656 */           i++;
/*      */         } 
/*      */ 
/*      */         
/* 1660 */         int value = 0;
/* 1661 */         int groupOffset = i;
/* 1662 */         for (; i < limit; i++) {
/* 1663 */           char c = input.charAt(i);
/* 1664 */           if (c < '0' || c > '9')
/* 1665 */             break;  if (value == 0 && groupOffset != i) return false; 
/* 1666 */           value = value * 10 + c - 48;
/* 1667 */           if (value > 255) return false; 
/*      */         } 
/* 1669 */         int groupLength = i - groupOffset;
/* 1670 */         if (groupLength == 0) return false;
/*      */ 
/*      */         
/* 1673 */         address[b++] = (byte)value;
/*      */       } 
/*      */       
/* 1676 */       if (b != addressOffset + 4) return false; 
/* 1677 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private static String inet6AddressToAscii(byte[] address) {
/* 1682 */       int longestRunOffset = -1;
/* 1683 */       int longestRunLength = 0;
/* 1684 */       for (int i = 0; i < address.length; i += 2) {
/* 1685 */         int currentRunOffset = i;
/* 1686 */         while (i < 16 && address[i] == 0 && address[i + 1] == 0) {
/* 1687 */           i += 2;
/*      */         }
/* 1689 */         int currentRunLength = i - currentRunOffset;
/* 1690 */         if (currentRunLength > longestRunLength) {
/* 1691 */           longestRunOffset = currentRunOffset;
/* 1692 */           longestRunLength = currentRunLength;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1697 */       Buffer result = new Buffer();
/* 1698 */       for (int j = 0; j < address.length; ) {
/* 1699 */         if (j == longestRunOffset) {
/* 1700 */           result.writeByte(58);
/* 1701 */           j += longestRunLength;
/* 1702 */           if (j == 16) result.writeByte(58);  continue;
/*      */         } 
/* 1704 */         if (j > 0) result.writeByte(58); 
/* 1705 */         int group = (address[j] & 0xFF) << 8 | address[j + 1] & 0xFF;
/* 1706 */         result.writeHexadecimalUnsignedLong(group);
/* 1707 */         j += 2;
/*      */       } 
/*      */       
/* 1710 */       return result.readUtf8();
/*      */     }
/*      */ 
/*      */     
/*      */     private static int parsePort(String input, int pos, int limit) {
/*      */       try {
/* 1716 */         String portString = HttpUrl.canonicalize(input, pos, limit, "", false, false, false, true);
/* 1717 */         int i = Integer.parseInt(portString);
/* 1718 */         if (i > 0 && i <= 65535) return i; 
/* 1719 */         return -1;
/* 1720 */       } catch (NumberFormatException e) {
/* 1721 */         return -1;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static String percentDecode(String encoded, boolean plusIsSpace) {
/* 1727 */     return percentDecode(encoded, 0, encoded.length(), plusIsSpace);
/*      */   }
/*      */   
/*      */   private List<String> percentDecode(List<String> list, boolean plusIsSpace) {
/* 1731 */     int size = list.size();
/* 1732 */     List<String> result = new ArrayList<>(size);
/* 1733 */     for (int i = 0; i < size; i++) {
/* 1734 */       String s = list.get(i);
/* 1735 */       result.add((s != null) ? percentDecode(s, plusIsSpace) : null);
/*      */     } 
/* 1737 */     return Collections.unmodifiableList(result);
/*      */   } enum ParseResult {
/*      */     SUCCESS, MISSING_SCHEME, UNSUPPORTED_SCHEME, INVALID_PORT, INVALID_HOST; }
/*      */   static String percentDecode(String encoded, int pos, int limit, boolean plusIsSpace) {
/* 1741 */     for (int i = pos; i < limit; i++) {
/* 1742 */       char c = encoded.charAt(i);
/* 1743 */       if (c == '%' || (c == '+' && plusIsSpace)) {
/*      */         
/* 1745 */         Buffer out = new Buffer();
/* 1746 */         out.writeUtf8(encoded, pos, i);
/* 1747 */         percentDecode(out, encoded, i, limit, plusIsSpace);
/* 1748 */         return out.readUtf8();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1753 */     return encoded.substring(pos, limit);
/*      */   }
/*      */   
/*      */   static void percentDecode(Buffer out, String encoded, int pos, int limit, boolean plusIsSpace) {
/*      */     int i;
/* 1758 */     for (i = pos; i < limit; i += Character.charCount(SYNTHETIC_LOCAL_VARIABLE_5)) {
/* 1759 */       int codePoint = encoded.codePointAt(i);
/* 1760 */       if (codePoint == 37 && i + 2 < limit) {
/* 1761 */         int d1 = decodeHexDigit(encoded.charAt(i + 1));
/* 1762 */         int d2 = decodeHexDigit(encoded.charAt(i + 2));
/* 1763 */         if (d1 != -1 && d2 != -1) {
/* 1764 */           out.writeByte((d1 << 4) + d2);
/* 1765 */           i += 2;
/*      */           continue;
/*      */         } 
/* 1768 */       } else if (codePoint == 43 && plusIsSpace) {
/* 1769 */         out.writeByte(32);
/*      */         continue;
/*      */       } 
/* 1772 */       out.writeUtf8CodePoint(codePoint);
/*      */       continue;
/*      */     } 
/*      */   }
/*      */   static boolean percentEncoded(String encoded, int pos, int limit) {
/* 1777 */     return (pos + 2 < limit && encoded
/* 1778 */       .charAt(pos) == '%' && 
/* 1779 */       decodeHexDigit(encoded.charAt(pos + 1)) != -1 && 
/* 1780 */       decodeHexDigit(encoded.charAt(pos + 2)) != -1);
/*      */   }
/*      */   
/*      */   static int decodeHexDigit(char c) {
/* 1784 */     if (c >= '0' && c <= '9') return c - 48; 
/* 1785 */     if (c >= 'a' && c <= 'f') return c - 97 + 10; 
/* 1786 */     if (c >= 'A' && c <= 'F') return c - 65 + 10; 
/* 1787 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String canonicalize(String input, int pos, int limit, String encodeSet, boolean alreadyEncoded, boolean strict, boolean plusIsSpace, boolean asciiOnly) {
/*      */     int i;
/* 1809 */     for (i = pos; i < limit; i += Character.charCount(codePoint)) {
/* 1810 */       int codePoint = input.codePointAt(i);
/* 1811 */       if (codePoint < 32 || codePoint == 127 || (codePoint >= 128 && asciiOnly) || encodeSet
/*      */ 
/*      */         
/* 1814 */         .indexOf(codePoint) != -1 || (codePoint == 37 && (!alreadyEncoded || (strict && 
/* 1815 */         !percentEncoded(input, i, limit)))) || (codePoint == 43 && plusIsSpace)) {
/*      */ 
/*      */         
/* 1818 */         Buffer out = new Buffer();
/* 1819 */         out.writeUtf8(input, pos, i);
/* 1820 */         canonicalize(out, input, i, limit, encodeSet, alreadyEncoded, strict, plusIsSpace, asciiOnly);
/*      */         
/* 1822 */         return out.readUtf8();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1827 */     return input.substring(pos, limit);
/*      */   }
/*      */ 
/*      */   
/*      */   static void canonicalize(Buffer out, String input, int pos, int limit, String encodeSet, boolean alreadyEncoded, boolean strict, boolean plusIsSpace, boolean asciiOnly) {
/* 1832 */     Buffer utf8Buffer = null;
/*      */     int i;
/* 1834 */     for (i = pos; i < limit; i += Character.charCount(codePoint)) {
/* 1835 */       int codePoint = input.codePointAt(i);
/* 1836 */       if (!alreadyEncoded || (codePoint != 9 && codePoint != 10 && codePoint != 12 && codePoint != 13))
/*      */       {
/*      */         
/* 1839 */         if (codePoint == 43 && plusIsSpace) {
/*      */           
/* 1841 */           out.writeUtf8(alreadyEncoded ? "+" : "%2B");
/* 1842 */         } else if (codePoint < 32 || codePoint == 127 || (codePoint >= 128 && asciiOnly) || encodeSet
/*      */ 
/*      */           
/* 1845 */           .indexOf(codePoint) != -1 || (codePoint == 37 && (!alreadyEncoded || (strict && 
/* 1846 */           !percentEncoded(input, i, limit))))) {
/*      */           
/* 1848 */           if (utf8Buffer == null) {
/* 1849 */             utf8Buffer = new Buffer();
/*      */           }
/* 1851 */           utf8Buffer.writeUtf8CodePoint(codePoint);
/* 1852 */           while (!utf8Buffer.exhausted()) {
/* 1853 */             int b = utf8Buffer.readByte() & 0xFF;
/* 1854 */             out.writeByte(37);
/* 1855 */             out.writeByte(HEX_DIGITS[b >> 4 & 0xF]);
/* 1856 */             out.writeByte(HEX_DIGITS[b & 0xF]);
/*      */           } 
/*      */         } else {
/*      */           
/* 1860 */           out.writeUtf8CodePoint(codePoint);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   static String canonicalize(String input, String encodeSet, boolean alreadyEncoded, boolean strict, boolean plusIsSpace, boolean asciiOnly) {
/* 1867 */     return canonicalize(input, 0, input
/* 1868 */         .length(), encodeSet, alreadyEncoded, strict, plusIsSpace, asciiOnly);
/*      */   }
/*      */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\HttpUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */