/*    */ package okhttp3;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import okio.ByteString;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Credentials
/*    */ {
/*    */   public static String basic(String userName, String password) {
/* 28 */     return basic(userName, password, Charset.forName("ISO-8859-1"));
/*    */   }
/*    */   
/*    */   public static String basic(String userName, String password, Charset charset) {
/* 32 */     String usernameAndPassword = userName + ":" + password;
/* 33 */     byte[] bytes = usernameAndPassword.getBytes(charset);
/* 34 */     String encoded = ByteString.of(bytes).base64();
/* 35 */     return "Basic " + encoded;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Credentials.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */