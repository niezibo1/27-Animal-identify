/*     */ package okhttp3;
/*     */ 
/*     */ import java.net.Proxy;
/*     */ import java.net.ProxySelector;
/*     */ import java.util.List;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import okhttp3.internal.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Address
/*     */ {
/*     */   final HttpUrl url;
/*     */   final Dns dns;
/*     */   final SocketFactory socketFactory;
/*     */   final Authenticator proxyAuthenticator;
/*     */   final List<Protocol> protocols;
/*     */   final List<ConnectionSpec> connectionSpecs;
/*     */   final ProxySelector proxySelector;
/*     */   final Proxy proxy;
/*     */   final SSLSocketFactory sslSocketFactory;
/*     */   final HostnameVerifier hostnameVerifier;
/*     */   final CertificatePinner certificatePinner;
/*     */   
/*     */   public Address(String uriHost, int uriPort, Dns dns, SocketFactory socketFactory, SSLSocketFactory sslSocketFactory, HostnameVerifier hostnameVerifier, CertificatePinner certificatePinner, Authenticator proxyAuthenticator, Proxy proxy, List<Protocol> protocols, List<ConnectionSpec> connectionSpecs, ProxySelector proxySelector) {
/*  54 */     this
/*     */ 
/*     */ 
/*     */       
/*  58 */       .url = (new HttpUrl.Builder()).scheme((sslSocketFactory != null) ? "https" : "http").host(uriHost).port(uriPort).build();
/*     */     
/*  60 */     if (dns == null) throw new NullPointerException("dns == null"); 
/*  61 */     this.dns = dns;
/*     */     
/*  63 */     if (socketFactory == null) throw new NullPointerException("socketFactory == null"); 
/*  64 */     this.socketFactory = socketFactory;
/*     */     
/*  66 */     if (proxyAuthenticator == null) {
/*  67 */       throw new NullPointerException("proxyAuthenticator == null");
/*     */     }
/*  69 */     this.proxyAuthenticator = proxyAuthenticator;
/*     */     
/*  71 */     if (protocols == null) throw new NullPointerException("protocols == null"); 
/*  72 */     this.protocols = Util.immutableList(protocols);
/*     */     
/*  74 */     if (connectionSpecs == null) throw new NullPointerException("connectionSpecs == null"); 
/*  75 */     this.connectionSpecs = Util.immutableList(connectionSpecs);
/*     */     
/*  77 */     if (proxySelector == null) throw new NullPointerException("proxySelector == null"); 
/*  78 */     this.proxySelector = proxySelector;
/*     */     
/*  80 */     this.proxy = proxy;
/*  81 */     this.sslSocketFactory = sslSocketFactory;
/*  82 */     this.hostnameVerifier = hostnameVerifier;
/*  83 */     this.certificatePinner = certificatePinner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpUrl url() {
/*  91 */     return this.url;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dns dns() {
/*  96 */     return this.dns;
/*     */   }
/*     */ 
/*     */   
/*     */   public SocketFactory socketFactory() {
/* 101 */     return this.socketFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Authenticator proxyAuthenticator() {
/* 106 */     return this.proxyAuthenticator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Protocol> protocols() {
/* 114 */     return this.protocols;
/*     */   }
/*     */   
/*     */   public List<ConnectionSpec> connectionSpecs() {
/* 118 */     return this.connectionSpecs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProxySelector proxySelector() {
/* 126 */     return this.proxySelector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Proxy proxy() {
/* 134 */     return this.proxy;
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLSocketFactory sslSocketFactory() {
/* 139 */     return this.sslSocketFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public HostnameVerifier hostnameVerifier() {
/* 144 */     return this.hostnameVerifier;
/*     */   }
/*     */ 
/*     */   
/*     */   public CertificatePinner certificatePinner() {
/* 149 */     return this.certificatePinner;
/*     */   }
/*     */   
/*     */   public boolean equals(Object other) {
/* 153 */     if (other instanceof Address) {
/* 154 */       Address that = (Address)other;
/* 155 */       return (this.url.equals(that.url) && this.dns
/* 156 */         .equals(that.dns) && this.proxyAuthenticator
/* 157 */         .equals(that.proxyAuthenticator) && this.protocols
/* 158 */         .equals(that.protocols) && this.connectionSpecs
/* 159 */         .equals(that.connectionSpecs) && this.proxySelector
/* 160 */         .equals(that.proxySelector) && 
/* 161 */         Util.equal(this.proxy, that.proxy) && 
/* 162 */         Util.equal(this.sslSocketFactory, that.sslSocketFactory) && 
/* 163 */         Util.equal(this.hostnameVerifier, that.hostnameVerifier) && 
/* 164 */         Util.equal(this.certificatePinner, that.certificatePinner));
/*     */     } 
/* 166 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 170 */     int result = 17;
/* 171 */     result = 31 * result + this.url.hashCode();
/* 172 */     result = 31 * result + this.dns.hashCode();
/* 173 */     result = 31 * result + this.proxyAuthenticator.hashCode();
/* 174 */     result = 31 * result + this.protocols.hashCode();
/* 175 */     result = 31 * result + this.connectionSpecs.hashCode();
/* 176 */     result = 31 * result + this.proxySelector.hashCode();
/* 177 */     result = 31 * result + ((this.proxy != null) ? this.proxy.hashCode() : 0);
/* 178 */     result = 31 * result + ((this.sslSocketFactory != null) ? this.sslSocketFactory.hashCode() : 0);
/* 179 */     result = 31 * result + ((this.hostnameVerifier != null) ? this.hostnameVerifier.hashCode() : 0);
/* 180 */     result = 31 * result + ((this.certificatePinner != null) ? this.certificatePinner.hashCode() : 0);
/* 181 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 187 */     StringBuilder result = (new StringBuilder()).append("Address{").append(this.url.host()).append(":").append(this.url.port());
/*     */     
/* 189 */     if (this.proxy != null) {
/* 190 */       result.append(", proxy=").append(this.proxy);
/*     */     } else {
/* 192 */       result.append(", proxySelector=").append(this.proxySelector);
/*     */     } 
/*     */     
/* 195 */     result.append("}");
/* 196 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\okhttp-3.6.0.jar!\okhttp3\Address.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */