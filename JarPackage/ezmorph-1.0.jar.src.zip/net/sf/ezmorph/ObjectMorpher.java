package net.sf.ezmorph;

public interface ObjectMorpher extends Morpher {
  Object morph(Object paramObject);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\ObjectMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */