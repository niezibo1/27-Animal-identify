/*     */ package net.sf.ezmorph.array;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.primitive.CharMorpher;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharacterObjectArrayMorpher
/*     */   extends AbstractArrayMorpher
/*     */ {
/*  34 */   private static final Class CHARACTER_OBJECT_ARRAY_CLASS = (array$Ljava$lang$Character == null) ? (array$Ljava$lang$Character = class$("[Ljava.lang.Character;")) : array$Ljava$lang$Character;
/*     */   private Character defaultValue;
/*     */   static Class array$Ljava$lang$Character;
/*     */   
/*     */   public CharacterObjectArrayMorpher() {
/*  39 */     super(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharacterObjectArrayMorpher(Character defaultValue) {
/*  44 */     super(true);
/*  45 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  50 */     if (this == obj) {
/*  51 */       return true;
/*     */     }
/*  53 */     if (obj == null) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     if (!(obj instanceof CharacterObjectArrayMorpher)) {
/*  58 */       return false;
/*     */     }
/*     */     
/*  61 */     CharacterObjectArrayMorpher other = (CharacterObjectArrayMorpher)obj;
/*  62 */     EqualsBuilder builder = new EqualsBuilder();
/*  63 */     if (isUseDefault() && other.isUseDefault()) {
/*  64 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  65 */       return builder.isEquals();
/*  66 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  67 */       return builder.isEquals();
/*     */     }
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Character getDefaultValue() {
/*  75 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  80 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  81 */     if (isUseDefault()) {
/*  82 */       builder.append(getDefaultValue());
/*     */     }
/*  84 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object array) {
/*  89 */     if (array == null) {
/*  90 */       return null;
/*     */     }
/*     */     
/*  93 */     if (CHARACTER_OBJECT_ARRAY_CLASS.isAssignableFrom(array.getClass()))
/*     */     {
/*  95 */       return array;
/*     */     }
/*     */     
/*  98 */     if (array.getClass().isArray()) {
/*     */       
/* 100 */       int length = Array.getLength(array);
/* 101 */       int dims = getDimensions(array.getClass());
/* 102 */       int[] dimensions = createDimensions(dims, length);
/* 103 */       Object result = Array.newInstance(Character.class, dimensions);
/* 104 */       if (dims == 1) {
/* 105 */         CharMorpher morpher = null;
/* 106 */         if (isUseDefault()) {
/* 107 */           if (this.defaultValue == null) {
/* 108 */             for (int i = 0; i < length; i++) {
/* 109 */               Array.set(result, i, null);
/*     */             }
/* 111 */             return result;
/*     */           } 
/* 113 */           morpher = new CharMorpher(this.defaultValue.charValue());
/*     */         } else {
/*     */           
/* 116 */           morpher = new CharMorpher();
/*     */         } 
/* 118 */         for (int index = 0; index < length; index++) {
/* 119 */           Array.set(result, index, new Character(morpher.morph(Array.get(array, index))));
/*     */         }
/*     */       } else {
/* 122 */         for (int index = 0; index < length; index++) {
/* 123 */           Array.set(result, index, morph(Array.get(array, index)));
/*     */         }
/*     */       } 
/* 126 */       return result;
/*     */     } 
/* 128 */     throw new MorphException("argument is not an array: " + array.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 134 */     return CHARACTER_OBJECT_ARRAY_CLASS;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\array\CharacterObjectArrayMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */