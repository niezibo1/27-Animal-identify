/*    */ package net.sf.ezmorph.array;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import net.sf.ezmorph.ObjectMorpher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractArrayMorpher
/*    */   implements ObjectMorpher
/*    */ {
/*    */   private boolean useDefault = false;
/*    */   
/*    */   public AbstractArrayMorpher() {}
/*    */   
/*    */   public AbstractArrayMorpher(boolean useDefault) {
/* 38 */     this.useDefault = useDefault;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isUseDefault() {
/* 46 */     return this.useDefault;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUseDefault(boolean useDefault) {
/* 54 */     this.useDefault = useDefault;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class clazz) {
/* 59 */     return clazz.isArray();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int[] createDimensions(int length, int initial) {
/* 67 */     Object dims = Array.newInstance(int.class, length);
/* 68 */     Array.set(dims, 0, new Integer(initial));
/* 69 */     return (int[])dims;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int getDimensions(Class arrayClass) {
/* 77 */     if (arrayClass == null || !arrayClass.isArray()) {
/* 78 */       return 0;
/*    */     }
/*    */     
/* 81 */     return 1 + getDimensions(arrayClass.getComponentType());
/*    */   }
/*    */   
/*    */   public abstract Object morph(Object paramObject);
/*    */   
/*    */   public abstract Class morphsTo();
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\array\AbstractArrayMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */