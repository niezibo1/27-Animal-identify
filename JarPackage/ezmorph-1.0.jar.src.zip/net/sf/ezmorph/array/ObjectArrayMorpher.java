/*     */ package net.sf.ezmorph.array;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.Morpher;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjectArrayMorpher
/*     */   extends AbstractArrayMorpher
/*     */ {
/*     */   private Morpher morpher;
/*     */   private Method morphMethod;
/*     */   private Class target;
/*     */   private Class targetArrayClass;
/*     */   
/*     */   public ObjectArrayMorpher(Morpher morpher) {
/*  41 */     super(false);
/*  42 */     setMorpher(morpher);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  47 */     if (this == obj) {
/*  48 */       return true;
/*     */     }
/*  50 */     if (obj == null) {
/*  51 */       return false;
/*     */     }
/*     */     
/*  54 */     if (!(obj instanceof ObjectArrayMorpher)) {
/*  55 */       return false;
/*     */     }
/*     */     
/*  58 */     ObjectArrayMorpher other = (ObjectArrayMorpher)obj;
/*  59 */     return this.morpher.equals(other.morpher);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  64 */     return (new HashCodeBuilder()).append(this.morpher).toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object morph(Object array) {
/*  70 */     if (array == null) {
/*  71 */       return null;
/*     */     }
/*     */     
/*  74 */     if (array.getClass().isArray()) {
/*     */       
/*  76 */       int length = Array.getLength(array);
/*  77 */       int dims = getDimensions(array.getClass());
/*  78 */       int[] dimensions = createDimensions(dims, length);
/*  79 */       Object result = Array.newInstance(this.target, dimensions);
/*     */       
/*  81 */       if (dims == 1) {
/*  82 */         for (int index = 0; index < length; index++) {
/*     */           try {
/*  84 */             Object value = Array.get(array, index);
/*  85 */             if (value != null && !supports(value.getClass())) {
/*  86 */               throw new MorphException(value.getClass() + " is not supported");
/*     */             }
/*  88 */             Object morphed = this.morphMethod.invoke(this.morpher, new Object[] { value });
/*  89 */             Array.set(result, index, morphed);
/*     */           }
/*  91 */           catch (MorphException me) {
/*  92 */             throw me;
/*     */           }
/*  94 */           catch (Exception e) {
/*  95 */             throw new MorphException(e);
/*     */           } 
/*     */         } 
/*     */       } else {
/*  99 */         for (int index = 0; index < length; index++) {
/* 100 */           Array.set(result, index, morph(Array.get(array, index)));
/*     */         }
/*     */       } 
/*     */       
/* 104 */       return result;
/*     */     } 
/* 106 */     throw new MorphException("argument is not an array: " + array.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 112 */     return this.targetArrayClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(Class clazz) {
/* 117 */     return this.morpher.supports(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setMorpher(Morpher morpher) {
/* 122 */     if (morpher == null) {
/* 123 */       throw new IllegalArgumentException("morpher can not be null");
/*     */     }
/* 125 */     if (morpher.morphsTo().isArray())
/*     */     {
/* 127 */       throw new IllegalArgumentException("morpher target class can not be an array");
/*     */     }
/* 129 */     this.morpher = morpher;
/* 130 */     this.targetArrayClass = Array.newInstance(morpher.morphsTo(), 1).getClass();
/*     */     
/* 132 */     this.target = morpher.morphsTo();
/*     */ 
/*     */     
/*     */     try {
/* 136 */       this.morphMethod = morpher.getClass().getDeclaredMethod("morph", new Class[] { Object.class });
/*     */     
/*     */     }
/* 139 */     catch (NoSuchMethodException nsme) {
/* 140 */       throw new IllegalArgumentException(nsme.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\array\ObjectArrayMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */