/*     */ package net.sf.ezmorph.array;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.primitive.BooleanMorpher;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BooleanObjectArrayMorpher
/*     */   extends AbstractArrayMorpher
/*     */ {
/*  34 */   private static final Class BOOLEAN_OBJECT_ARRAY_CLASS = (array$Ljava$lang$Boolean == null) ? (array$Ljava$lang$Boolean = class$("[Ljava.lang.Boolean;")) : array$Ljava$lang$Boolean;
/*     */   private Boolean defaultValue;
/*     */   static Class array$Ljava$lang$Boolean;
/*     */   
/*     */   public BooleanObjectArrayMorpher() {
/*  39 */     super(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanObjectArrayMorpher(Boolean defaultValue) {
/*  44 */     super(true);
/*  45 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  50 */     if (this == obj) {
/*  51 */       return true;
/*     */     }
/*  53 */     if (obj == null) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     if (!(obj instanceof BooleanObjectArrayMorpher)) {
/*  58 */       return false;
/*     */     }
/*     */     
/*  61 */     BooleanObjectArrayMorpher other = (BooleanObjectArrayMorpher)obj;
/*  62 */     EqualsBuilder builder = new EqualsBuilder();
/*  63 */     if (isUseDefault() && other.isUseDefault()) {
/*  64 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  65 */       return builder.isEquals();
/*  66 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  67 */       return builder.isEquals();
/*     */     }
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getDefaultValue() {
/*  75 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  80 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  81 */     if (isUseDefault()) {
/*  82 */       builder.append(getDefaultValue());
/*     */     }
/*  84 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object array) {
/*  89 */     if (array == null) {
/*  90 */       return null;
/*     */     }
/*     */     
/*  93 */     if (BOOLEAN_OBJECT_ARRAY_CLASS.isAssignableFrom(array.getClass()))
/*     */     {
/*  95 */       return array;
/*     */     }
/*     */     
/*  98 */     if (array.getClass().isArray()) {
/*     */       
/* 100 */       int length = Array.getLength(array);
/* 101 */       int dims = getDimensions(array.getClass());
/* 102 */       int[] dimensions = createDimensions(dims, length);
/* 103 */       Object result = Array.newInstance(Boolean.class, dimensions);
/* 104 */       if (dims == 1) {
/* 105 */         BooleanMorpher morpher = null;
/* 106 */         if (isUseDefault()) {
/* 107 */           if (this.defaultValue == null) {
/* 108 */             for (int i = 0; i < length; i++) {
/* 109 */               Array.set(result, i, null);
/*     */             }
/* 111 */             return result;
/*     */           } 
/* 113 */           morpher = new BooleanMorpher(this.defaultValue.booleanValue());
/*     */         } else {
/*     */           
/* 116 */           morpher = new BooleanMorpher();
/*     */         } 
/* 118 */         for (int index = 0; index < length; index++) {
/* 119 */           Array.set(result, index, morpher.morph(Array.get(array, index)) ? Boolean.TRUE : Boolean.FALSE);
/*     */         }
/*     */       } else {
/*     */         
/* 123 */         for (int index = 0; index < length; index++) {
/* 124 */           Array.set(result, index, morph(Array.get(array, index)));
/*     */         }
/*     */       } 
/* 127 */       return result;
/*     */     } 
/* 129 */     throw new MorphException("argument is not an array: " + array.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 135 */     return BOOLEAN_OBJECT_ARRAY_CLASS;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\array\BooleanObjectArrayMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */