/*     */ package net.sf.ezmorph.array;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.primitive.LongMorpher;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LongArrayMorpher
/*     */   extends AbstractArrayMorpher
/*     */ {
/*  34 */   private static final Class LONG_ARRAY_CLASS = (array$J == null) ? (array$J = class$("[J")) : array$J; private long defaultValue; static Class class$(String x0) { try { return Class.forName(x0); } catch (ClassNotFoundException x1) { throw new NoClassDefFoundError(x1.getMessage()); }
/*     */      }
/*     */   
/*     */   static Class array$J;
/*     */   public LongArrayMorpher() {
/*  39 */     super(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongArrayMorpher(long defaultValue) {
/*  44 */     super(true);
/*  45 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  50 */     if (this == obj) {
/*  51 */       return true;
/*     */     }
/*  53 */     if (obj == null) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     if (!(obj instanceof LongArrayMorpher)) {
/*  58 */       return false;
/*     */     }
/*     */     
/*  61 */     LongArrayMorpher other = (LongArrayMorpher)obj;
/*  62 */     EqualsBuilder builder = new EqualsBuilder();
/*  63 */     if (isUseDefault() && other.isUseDefault()) {
/*  64 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  65 */       return builder.isEquals();
/*  66 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  67 */       return builder.isEquals();
/*     */     }
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getDefaultValue() {
/*  75 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  80 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  81 */     if (isUseDefault()) {
/*  82 */       builder.append(getDefaultValue());
/*     */     }
/*  84 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object array) {
/*  89 */     if (array == null) {
/*  90 */       return null;
/*     */     }
/*     */     
/*  93 */     if (LONG_ARRAY_CLASS.isAssignableFrom(array.getClass()))
/*     */     {
/*  95 */       return array;
/*     */     }
/*     */     
/*  98 */     if (array.getClass().isArray()) {
/*     */       
/* 100 */       int length = Array.getLength(array);
/* 101 */       int dims = getDimensions(array.getClass());
/* 102 */       int[] dimensions = createDimensions(dims, length);
/* 103 */       Object result = Array.newInstance(long.class, dimensions);
/* 104 */       LongMorpher morpher = isUseDefault() ? new LongMorpher(this.defaultValue) : new LongMorpher();
/* 105 */       if (dims == 1) {
/* 106 */         for (int index = 0; index < length; index++) {
/* 107 */           Array.set(result, index, new Long(morpher.morph(Array.get(array, index))));
/*     */         }
/*     */       } else {
/* 110 */         for (int index = 0; index < length; index++) {
/* 111 */           Array.set(result, index, morph(Array.get(array, index)));
/*     */         }
/*     */       } 
/* 114 */       return result;
/*     */     } 
/* 116 */     throw new MorphException("argument is not an array: " + array.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 122 */     return LONG_ARRAY_CLASS;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\array\LongArrayMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */