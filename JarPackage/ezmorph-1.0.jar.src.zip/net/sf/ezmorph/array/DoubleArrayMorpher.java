/*     */ package net.sf.ezmorph.array;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.primitive.DoubleMorpher;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DoubleArrayMorpher
/*     */   extends AbstractArrayMorpher
/*     */ {
/*  34 */   private static final Class DOUBLE_ARRAY_CLASS = (array$D == null) ? (array$D = class$("[D")) : array$D; private double defaultValue; static Class class$(String x0) { try { return Class.forName(x0); } catch (ClassNotFoundException x1) { throw new NoClassDefFoundError(x1.getMessage()); }
/*     */      }
/*     */   
/*     */   static Class array$D;
/*     */   public DoubleArrayMorpher() {
/*  39 */     super(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleArrayMorpher(double defaultValue) {
/*  44 */     super(true);
/*  45 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  50 */     if (this == obj) {
/*  51 */       return true;
/*     */     }
/*  53 */     if (obj == null) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     if (!(obj instanceof DoubleArrayMorpher)) {
/*  58 */       return false;
/*     */     }
/*     */     
/*  61 */     DoubleArrayMorpher other = (DoubleArrayMorpher)obj;
/*  62 */     EqualsBuilder builder = new EqualsBuilder();
/*  63 */     if (isUseDefault() && other.isUseDefault()) {
/*  64 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  65 */       return builder.isEquals();
/*  66 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  67 */       return builder.isEquals();
/*     */     }
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDefaultValue() {
/*  75 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  80 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  81 */     if (isUseDefault()) {
/*  82 */       builder.append(getDefaultValue());
/*     */     }
/*  84 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object array) {
/*  89 */     if (array == null) {
/*  90 */       return null;
/*     */     }
/*     */     
/*  93 */     if (DOUBLE_ARRAY_CLASS.isAssignableFrom(array.getClass()))
/*     */     {
/*  95 */       return array;
/*     */     }
/*     */     
/*  98 */     if (array.getClass().isArray()) {
/*     */       
/* 100 */       int length = Array.getLength(array);
/* 101 */       int dims = getDimensions(array.getClass());
/* 102 */       int[] dimensions = createDimensions(dims, length);
/* 103 */       Object result = Array.newInstance(double.class, dimensions);
/* 104 */       DoubleMorpher morpher = isUseDefault() ? new DoubleMorpher(this.defaultValue) : new DoubleMorpher();
/*     */       
/* 106 */       if (dims == 1) {
/* 107 */         for (int index = 0; index < length; index++) {
/* 108 */           Array.set(result, index, new Double(morpher.morph(Array.get(array, index))));
/*     */         }
/*     */       } else {
/* 111 */         for (int index = 0; index < length; index++) {
/* 112 */           Array.set(result, index, morph(Array.get(array, index)));
/*     */         }
/*     */       } 
/* 115 */       return result;
/*     */     } 
/* 117 */     throw new MorphException("argument is not an array: " + array.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 123 */     return DOUBLE_ARRAY_CLASS;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\array\DoubleArrayMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */