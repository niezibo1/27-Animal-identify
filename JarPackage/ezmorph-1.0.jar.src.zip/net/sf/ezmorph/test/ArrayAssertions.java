/*      */ package net.sf.ezmorph.test;
/*      */ 
/*      */ import junit.framework.Assert;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ArrayAssertions
/*      */   extends Assert
/*      */ {
/*      */   public static void assertEquals(boolean[] expecteds, boolean[] actuals) {
/*   37 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(boolean[] expecteds, Object[] actuals) {
/*   49 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(byte[] expecteds, byte[] actuals) {
/*   60 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(byte[] expecteds, Object[] actuals) {
/*   71 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(char[] expecteds, char[] actuals) {
/*   82 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(char[] expecteds, Object[] actuals) {
/*   93 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(double[] expecteds, double[] actuals) {
/*  104 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(double[] expecteds, Object[] actuals) {
/*  115 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(float[] expecteds, float[] actuals) {
/*  126 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(float[] expecteds, Object[] actuals) {
/*  137 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(int[] expecteds, int[] actuals) {
/*  148 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(int[] expecteds, Object[] actuals) {
/*  159 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(long[] expecteds, long[] actuals) {
/*  170 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(long[] expecteds, Object[] actuals) {
/*  181 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, boolean[] actuals) {
/*  192 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, byte[] actuals) {
/*  203 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, char[] actuals) {
/*  214 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, double[] actuals) {
/*  225 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, float[] actuals) {
/*  236 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, int[] actuals) {
/*  247 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, long[] actuals) {
/*  258 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, Object[] actuals) {
/*  269 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object[] expecteds, short[] actuals) {
/*  280 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(short[] expecteds, Object[] actuals) {
/*  291 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(short[] expecteds, short[] actuals) {
/*  302 */     assertEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, boolean[] expecteds, boolean[] actuals) {
/*  313 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/*  316 */     String header = (message == null) ? "" : (message + ": ");
/*  317 */     if (expecteds == null) {
/*  318 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  320 */     if (actuals == null) {
/*  321 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  323 */     if (actuals.length != expecteds.length) {
/*  324 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  328 */     for (int i = 0; i < expecteds.length; i++) {
/*  329 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, boolean[] expecteds, Object[] actuals) {
/*  343 */     String header = (message == null) ? "" : (message + ": ");
/*  344 */     if (expecteds == null) {
/*  345 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  347 */     if (actuals == null) {
/*  348 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  350 */     if (actuals.length != expecteds.length) {
/*  351 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  355 */     for (int i = 0; i < expecteds.length; i++) {
/*  356 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", new Boolean(expecteds[i]), actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, byte[] expecteds, byte[] actuals) {
/*  369 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/*  372 */     String header = (message == null) ? "" : (message + ": ");
/*  373 */     if (expecteds == null) {
/*  374 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  376 */     if (actuals == null) {
/*  377 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  379 */     if (actuals.length != expecteds.length) {
/*  380 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  384 */     for (int i = 0; i < expecteds.length; i++) {
/*  385 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, byte[] expecteds, Object[] actuals) {
/*  398 */     String header = (message == null) ? "" : (message + ": ");
/*  399 */     if (expecteds == null) {
/*  400 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  402 */     if (actuals == null) {
/*  403 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  405 */     if (actuals.length != expecteds.length) {
/*  406 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  410 */     for (int i = 0; i < expecteds.length; i++) {
/*  411 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", new Byte(expecteds[i]), actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, char[] expecteds, char[] actuals) {
/*  424 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/*  427 */     String header = (message == null) ? "" : (message + ": ");
/*  428 */     if (expecteds == null) {
/*  429 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  431 */     if (actuals == null) {
/*  432 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  434 */     if (actuals.length != expecteds.length) {
/*  435 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  439 */     for (int i = 0; i < expecteds.length; i++) {
/*  440 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, char[] expecteds, Object[] actuals) {
/*  453 */     String header = (message == null) ? "" : (message + ": ");
/*  454 */     if (expecteds == null) {
/*  455 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  457 */     if (actuals == null) {
/*  458 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  460 */     if (actuals.length != expecteds.length) {
/*  461 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  465 */     for (int i = 0; i < expecteds.length; i++) {
/*  466 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", new Character(expecteds[i]), actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, double[] expecteds, double[] actuals) {
/*  479 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/*  482 */     String header = (message == null) ? "" : (message + ": ");
/*  483 */     if (expecteds == null) {
/*  484 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  486 */     if (actuals == null) {
/*  487 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  489 */     if (actuals.length != expecteds.length) {
/*  490 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  494 */     for (int i = 0; i < expecteds.length; i++) {
/*  495 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], actuals[i], 0.0D);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, double[] expecteds, Object[] actuals) {
/*  508 */     String header = (message == null) ? "" : (message + ": ");
/*  509 */     if (expecteds == null) {
/*  510 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  512 */     if (actuals == null) {
/*  513 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  515 */     if (actuals.length != expecteds.length) {
/*  516 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  520 */     for (int i = 0; i < expecteds.length; i++) {
/*  521 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", new Double(expecteds[i]), actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, float[] expecteds, float[] actuals) {
/*  534 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/*  537 */     String header = (message == null) ? "" : (message + ": ");
/*  538 */     if (expecteds == null) {
/*  539 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  541 */     if (actuals == null) {
/*  542 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  544 */     if (actuals.length != expecteds.length) {
/*  545 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  549 */     for (int i = 0; i < expecteds.length; i++) {
/*  550 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], actuals[i], 0.0F);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, float[] expecteds, Object[] actuals) {
/*  563 */     String header = (message == null) ? "" : (message + ": ");
/*  564 */     if (expecteds == null) {
/*  565 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  567 */     if (actuals == null) {
/*  568 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  570 */     if (actuals.length != expecteds.length) {
/*  571 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  575 */     for (int i = 0; i < expecteds.length; i++) {
/*  576 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", new Float(expecteds[i]), actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, int[] expecteds, int[] actuals) {
/*  589 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/*  592 */     String header = (message == null) ? "" : (message + ": ");
/*  593 */     if (expecteds == null) {
/*  594 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  596 */     if (actuals == null) {
/*  597 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  599 */     if (actuals.length != expecteds.length) {
/*  600 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  604 */     for (int i = 0; i < expecteds.length; i++) {
/*  605 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, int[] expecteds, Object[] actuals) {
/*  618 */     String header = (message == null) ? "" : (message + ": ");
/*  619 */     if (expecteds == null) {
/*  620 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  622 */     if (actuals == null) {
/*  623 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  625 */     if (actuals.length != expecteds.length) {
/*  626 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  630 */     for (int i = 0; i < expecteds.length; i++) {
/*  631 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", new Integer(expecteds[i]), actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, long[] expecteds, long[] actuals) {
/*  644 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/*  647 */     String header = (message == null) ? "" : (message + ": ");
/*  648 */     if (expecteds == null) {
/*  649 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  651 */     if (actuals == null) {
/*  652 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  654 */     if (actuals.length != expecteds.length) {
/*  655 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  659 */     for (int i = 0; i < expecteds.length; i++) {
/*  660 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, long[] expecteds, Object[] actuals) {
/*  673 */     String header = (message == null) ? "" : (message + ": ");
/*  674 */     if (expecteds == null) {
/*  675 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  677 */     if (actuals == null) {
/*  678 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  680 */     if (actuals.length != expecteds.length) {
/*  681 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  685 */     for (int i = 0; i < expecteds.length; i++) {
/*  686 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", new Long(expecteds[i]), actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, boolean[] actuals) {
/*  699 */     String header = (message == null) ? "" : (message + ": ");
/*  700 */     if (expecteds == null) {
/*  701 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  703 */     if (actuals == null) {
/*  704 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  706 */     if (actuals.length != expecteds.length) {
/*  707 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  711 */     for (int i = 0; i < expecteds.length; i++) {
/*  712 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], new Boolean(actuals[i]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, byte[] actuals) {
/*  725 */     String header = (message == null) ? "" : (message + ": ");
/*  726 */     if (expecteds == null) {
/*  727 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  729 */     if (actuals == null) {
/*  730 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  732 */     if (actuals.length != expecteds.length) {
/*  733 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  737 */     for (int i = 0; i < expecteds.length; i++) {
/*  738 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], new Byte(actuals[i]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, char[] actuals) {
/*  751 */     String header = (message == null) ? "" : (message + ": ");
/*  752 */     if (expecteds == null) {
/*  753 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  755 */     if (actuals == null) {
/*  756 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  758 */     if (actuals.length != expecteds.length) {
/*  759 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  763 */     for (int i = 0; i < expecteds.length; i++) {
/*  764 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], new Character(actuals[i]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, double[] actuals) {
/*  777 */     String header = (message == null) ? "" : (message + ": ");
/*  778 */     if (expecteds == null) {
/*  779 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  781 */     if (actuals == null) {
/*  782 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  784 */     if (actuals.length != expecteds.length) {
/*  785 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  789 */     for (int i = 0; i < expecteds.length; i++) {
/*  790 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], new Double(actuals[i]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, float[] actuals) {
/*  803 */     String header = (message == null) ? "" : (message + ": ");
/*  804 */     if (expecteds == null) {
/*  805 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  807 */     if (actuals == null) {
/*  808 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  810 */     if (actuals.length != expecteds.length) {
/*  811 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  815 */     for (int i = 0; i < expecteds.length; i++) {
/*  816 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], new Float(actuals[i]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, int[] actuals) {
/*  829 */     String header = (message == null) ? "" : (message + ": ");
/*  830 */     if (expecteds == null) {
/*  831 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  833 */     if (actuals == null) {
/*  834 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  836 */     if (actuals.length != expecteds.length) {
/*  837 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  841 */     for (int i = 0; i < expecteds.length; i++) {
/*  842 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], new Integer(actuals[i]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, long[] actuals) {
/*  855 */     String header = (message == null) ? "" : (message + ": ");
/*  856 */     if (expecteds == null) {
/*  857 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  859 */     if (actuals == null) {
/*  860 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  862 */     if (actuals.length != expecteds.length) {
/*  863 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  867 */     for (int i = 0; i < expecteds.length; i++) {
/*  868 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], new Long(actuals[i]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, Object[] actuals) {
/*  881 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/*  884 */     String header = (message == null) ? "" : (message + ": ");
/*  885 */     if (expecteds == null) {
/*  886 */       Assert.fail(header + "expected array was null");
/*      */     }
/*  888 */     if (actuals == null) {
/*  889 */       Assert.fail(header + "actual array was null");
/*      */     }
/*  891 */     if (actuals.length != expecteds.length) {
/*  892 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/*  896 */     for (int i = 0; i < expecteds.length; i++) {
/*  897 */       Object o1 = expecteds[i];
/*  898 */       Object o2 = actuals[i];
/*      */       
/*  900 */       if (o1 == null) {
/*  901 */         if (o2 == null) {
/*      */           return;
/*      */         }
/*  904 */         Assert.fail(header + "arrays first differed at element [" + i + "];");
/*      */       
/*      */       }
/*  907 */       else if (o2 == null) {
/*  908 */         Assert.fail(header + "arrays first differed at element [" + i + "];");
/*      */       } 
/*      */ 
/*      */       
/*  912 */       if (o1.getClass().isArray() && o2.getClass().isArray()) {
/*      */ 
/*      */         
/*  915 */         Class type1 = o1.getClass().getComponentType();
/*      */         
/*  917 */         Class type2 = o2.getClass().getComponentType();
/*      */         
/*  919 */         if (type1.isPrimitive()) {
/*  920 */           if (type1 == boolean.class) {
/*  921 */             if (type2 == boolean.class) {
/*  922 */               assertEquals(header + "arrays first differed at element " + i + ";", (boolean[])o1, (boolean[])o2);
/*      */             } else {
/*      */               
/*  925 */               assertEquals(header + "arrays first differed at element " + i + ";", (boolean[])o1, (Object[])o2);
/*      */             }
/*      */           
/*  928 */           } else if (type1 == byte.class) {
/*  929 */             if (type2 == byte.class) {
/*  930 */               assertEquals(header + "arrays first differed at element " + i + ";", (byte[])o1, (byte[])o2);
/*      */             } else {
/*      */               
/*  933 */               assertEquals(header + "arrays first differed at element " + i + ";", (byte[])o1, (Object[])o2);
/*      */             }
/*      */           
/*  936 */           } else if (type1 == short.class) {
/*  937 */             if (type2 == short.class) {
/*  938 */               assertEquals(header + "arrays first differed at element " + i + ";", (short[])o1, (short[])o2);
/*      */             } else {
/*      */               
/*  941 */               assertEquals(header + "arrays first differed at element " + i + ";", (short[])o1, (Object[])o2);
/*      */             }
/*      */           
/*  944 */           } else if (type1 == int.class) {
/*  945 */             if (type2 == int.class) {
/*  946 */               assertEquals(header + "arrays first differed at element " + i + ";", (int[])o1, (int[])o2);
/*      */             } else {
/*      */               
/*  949 */               assertEquals(header + "arrays first differed at element " + i + ";", (int[])o1, (Object[])o2);
/*      */             }
/*      */           
/*  952 */           } else if (type1 == long.class) {
/*  953 */             if (type2 == long.class) {
/*  954 */               assertEquals(header + "arrays first differed at element " + i + ";", (long[])o1, (long[])o2);
/*      */             } else {
/*      */               
/*  957 */               assertEquals(header + "arrays first differed at element " + i + ";", (long[])o1, (Object[])o2);
/*      */             }
/*      */           
/*  960 */           } else if (type1 == float.class) {
/*  961 */             if (type2 == float.class) {
/*  962 */               assertEquals(header + "arrays first differed at element " + i + ";", (float[])o1, (float[])o2);
/*      */             } else {
/*      */               
/*  965 */               assertEquals(header + "arrays first differed at element " + i + ";", (float[])o1, (Object[])o2);
/*      */             }
/*      */           
/*  968 */           } else if (type1 == double.class) {
/*  969 */             if (type2 == double.class) {
/*  970 */               assertEquals(header + "arrays first differed at element " + i + ";", (double[])o1, (double[])o2);
/*      */             } else {
/*      */               
/*  973 */               assertEquals(header + "arrays first differed at element " + i + ";", (double[])o1, (Object[])o2);
/*      */             }
/*      */           
/*  976 */           } else if (type1 == char.class) {
/*  977 */             if (type2 == char.class) {
/*  978 */               assertEquals(header + "arrays first differed at element " + i + ";", (char[])o1, (char[])o2);
/*      */             } else {
/*      */               
/*  981 */               assertEquals(header + "arrays first differed at element " + i + ";", (char[])o1, (Object[])o2);
/*      */             }
/*      */           
/*      */           } 
/*  985 */         } else if (type2.isPrimitive()) {
/*  986 */           if (type2 == boolean.class) {
/*  987 */             assertEquals(header + "arrays first differed at element " + i + ";", (Object[])o1, (boolean[])o2);
/*      */           }
/*  989 */           else if (type2 == byte.class) {
/*  990 */             assertEquals(header + "arrays first differed at element " + i + ";", (Object[])o1, (byte[])o2);
/*      */           }
/*  992 */           else if (type2 == short.class) {
/*  993 */             assertEquals(header + "arrays first differed at element " + i + ";", (Object[])o1, (short[])o2);
/*      */           }
/*  995 */           else if (type2 == int.class) {
/*  996 */             assertEquals(header + "arrays first differed at element " + i + ";", (Object[])o1, (int[])o2);
/*      */           }
/*  998 */           else if (type2 == long.class) {
/*  999 */             assertEquals(header + "arrays first differed at element " + i + ";", (Object[])o1, (long[])o2);
/*      */           }
/* 1001 */           else if (type2 == float.class) {
/* 1002 */             assertEquals(header + "arrays first differed at element " + i + ";", (Object[])o1, (float[])o2);
/*      */           }
/* 1004 */           else if (type2 == double.class) {
/* 1005 */             assertEquals(header + "arrays first differed at element " + i + ";", (Object[])o1, (double[])o2);
/*      */           }
/* 1007 */           else if (type2 == char.class) {
/* 1008 */             assertEquals(header + "arrays first differed at element " + i + ";", (Object[])o1, (char[])o2);
/*      */           } 
/*      */         } else {
/*      */           
/* 1012 */           Object[] expected = (Object[])o1;
/* 1013 */           Object[] actual = (Object[])o2;
/* 1014 */           assertEquals(header + "arrays first differed at element " + i + ";", expected, actual);
/*      */         } 
/*      */       } else {
/*      */         
/* 1018 */         Assert.assertEquals(header + "arrays first differed at element [" + i + "];", o1, o2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object[] expecteds, short[] actuals) {
/* 1031 */     String header = (message == null) ? "" : (message + ": ");
/* 1032 */     if (expecteds == null) {
/* 1033 */       Assert.fail(header + "expected array was null");
/*      */     }
/* 1035 */     if (actuals == null) {
/* 1036 */       Assert.fail(header + "actual array was null");
/*      */     }
/* 1038 */     if (actuals.length != expecteds.length) {
/* 1039 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/* 1043 */     for (int i = 0; i < expecteds.length; i++) {
/* 1044 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], new Short(actuals[i]));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, short[] expecteds, Object[] actuals) {
/* 1057 */     String header = (message == null) ? "" : (message + ": ");
/* 1058 */     if (expecteds == null) {
/* 1059 */       Assert.fail(header + "expected array was null");
/*      */     }
/* 1061 */     if (actuals == null) {
/* 1062 */       Assert.fail(header + "actual array was null");
/*      */     }
/* 1064 */     if (actuals.length != expecteds.length) {
/* 1065 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/* 1069 */     for (int i = 0; i < expecteds.length; i++) {
/* 1070 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", new Short(expecteds[i]), actuals[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, short[] expecteds, short[] actuals) {
/* 1083 */     if (expecteds == actuals) {
/*      */       return;
/*      */     }
/* 1086 */     String header = (message == null) ? "" : (message + ": ");
/* 1087 */     if (expecteds == null) {
/* 1088 */       Assert.fail(header + "expected array was null");
/*      */     }
/* 1090 */     if (actuals == null) {
/* 1091 */       Assert.fail(header + "actual array was null");
/*      */     }
/* 1093 */     if (actuals.length != expecteds.length) {
/* 1094 */       Assert.fail(header + "array lengths differed, expected.length=" + expecteds.length + " actual.length=" + actuals.length);
/*      */     }
/*      */ 
/*      */     
/* 1098 */     for (int i = 0; i < expecteds.length; i++)
/* 1099 */       Assert.assertEquals(header + "arrays first differed at element [" + i + "];", expecteds[i], actuals[i]); 
/*      */   }
/*      */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\test\ArrayAssertions.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */