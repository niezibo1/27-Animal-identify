/*     */ package net.sf.ezmorph;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.sf.ezmorph.object.IdentityObjectMorpher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorpherRegistry
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -4805239625300200760L;
/*  44 */   private Map morphers = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  56 */     this.morphers.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deregisterMorpher(Morpher morpher) {
/*  68 */     List registered = (List)this.morphers.get(morpher.morphsTo());
/*  69 */     if (registered != null && !registered.isEmpty()) {
/*  70 */       registered.remove(morpher);
/*  71 */       if (registered.isEmpty()) {
/*  72 */         this.morphers.remove(morpher.morphsTo());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Morpher getMorpherFor(Class clazz) {
/*  86 */     List registered = (List)this.morphers.get(clazz);
/*  87 */     if (registered == null || registered.isEmpty())
/*     */     {
/*  89 */       return (Morpher)IdentityObjectMorpher.getInstance();
/*     */     }
/*  91 */     return registered.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Morpher[] getMorphersFor(Class clazz) {
/* 105 */     List registered = (List)this.morphers.get(clazz);
/* 106 */     if (registered == null || registered.isEmpty())
/*     */     {
/* 108 */       return new Morpher[] { (Morpher)IdentityObjectMorpher.getInstance() };
/*     */     }
/* 110 */     Morpher[] morphs = new Morpher[registered.size()];
/* 111 */     int k = 0;
/* 112 */     for (Iterator i = registered.iterator(); i.hasNext();) {
/* 113 */       morphs[k++] = i.next();
/*     */     }
/* 115 */     return morphs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object morph(Class target, Object value) {
/* 131 */     Morpher morpher = getMorpherFor(target);
/* 132 */     if (morpher instanceof ObjectMorpher) {
/* 133 */       return ((ObjectMorpher)morpher).morph(value);
/*     */     }
/*     */     try {
/* 136 */       Method morphMethod = morpher.getClass().getDeclaredMethod("morph", new Class[] { Object.class });
/*     */       
/* 138 */       return morphMethod.invoke(morpher, new Object[] { value });
/*     */     }
/* 140 */     catch (Exception e) {
/* 141 */       throw new MorphException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerMorpher(Morpher morpher) {
/* 156 */     List registered = (List)this.morphers.get(morpher.morphsTo());
/* 157 */     if (registered == null) {
/* 158 */       registered = new ArrayList();
/* 159 */       this.morphers.put(morpher.morphsTo(), registered);
/*     */     } 
/* 161 */     if (!registered.contains(morpher))
/* 162 */       registered.add(morpher); 
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\MorpherRegistry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */