/*     */ package net.sf.ezmorph.bean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.MorphUtils;
/*     */ import net.sf.ezmorph.MorpherRegistry;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.beanutils.DynaClass;
/*     */ import org.apache.commons.beanutils.DynaProperty;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ import org.apache.commons.lang.builder.ToStringBuilder;
/*     */ import org.apache.commons.lang.builder.ToStringStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MorphDynaBean
/*     */   implements DynaBean, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -605547389232706344L;
/*     */   private MorphDynaClass dynaClass;
/*  45 */   private Map dynaValues = new HashMap();
/*     */   
/*     */   private MorpherRegistry morpherRegistry;
/*     */   
/*     */   public MorphDynaBean() {
/*  50 */     this(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public MorphDynaBean(MorpherRegistry morpherRegistry) {
/*  55 */     setMorpherRegistry(morpherRegistry);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String name, String key) {
/*  60 */     DynaProperty dynaProperty = getDynaProperty(name);
/*     */     
/*  62 */     Class type = dynaProperty.getType();
/*  63 */     if (!Map.class.isAssignableFrom(type)) {
/*  64 */       throw new MorphException("Non-Mapped property name: " + name + " key: " + key);
/*     */     }
/*     */     
/*  67 */     Object value = (Object)this.dynaValues.get(name);
/*  68 */     if (value == null) {
/*  69 */       value = (Object)new HashMap();
/*  70 */       this.dynaValues.put(name, value);
/*     */     } 
/*  72 */     return ((Map)value).containsKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  77 */     if (this == obj) {
/*  78 */       return true;
/*     */     }
/*     */     
/*  81 */     if (obj == null) {
/*  82 */       return false;
/*     */     }
/*     */     
/*  85 */     if (!(obj instanceof MorphDynaBean)) {
/*  86 */       return false;
/*     */     }
/*     */     
/*  89 */     MorphDynaBean other = (MorphDynaBean)obj;
/*  90 */     EqualsBuilder builder = (new EqualsBuilder()).append(this.dynaClass, other.dynaClass);
/*  91 */     DynaProperty[] props = this.dynaClass.getDynaProperties();
/*  92 */     for (int i = 0; i < props.length; i++) {
/*  93 */       DynaProperty prop = props[i];
/*  94 */       builder.append(this.dynaValues.get(prop.getName()), this.dynaValues.get(prop.getName()));
/*     */     } 
/*  96 */     return builder.isEquals();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String name) {
/* 101 */     Object value = this.dynaValues.get(name);
/*     */     
/* 103 */     if (value != null) {
/* 104 */       return value;
/*     */     }
/*     */     
/* 107 */     Class type = getDynaProperty(name).getType();
/* 108 */     if (!type.isPrimitive()) {
/* 109 */       return value;
/*     */     }
/* 111 */     return this.morpherRegistry.morph(type, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(String name, int index) {
/* 117 */     DynaProperty dynaProperty = getDynaProperty(name);
/*     */     
/* 119 */     Class type = dynaProperty.getType();
/* 120 */     if (!type.isArray() && !List.class.isAssignableFrom(type)) {
/* 121 */       throw new MorphException("Non-Indexed property name: " + name + " index: " + index);
/*     */     }
/*     */     
/* 124 */     Object value = this.dynaValues.get(name);
/*     */     
/* 126 */     if (value.getClass().isArray()) {
/*     */       
/* 128 */       value = Array.get(value, index);
/* 129 */     } else if (value instanceof List) {
/* 130 */       value = ((List)value).get(index);
/*     */     } 
/*     */     
/* 133 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(String name, String key) {
/* 138 */     DynaProperty dynaProperty = getDynaProperty(name);
/*     */     
/* 140 */     Class type = dynaProperty.getType();
/* 141 */     if (!Map.class.isAssignableFrom(type)) {
/* 142 */       throw new MorphException("Non-Mapped property name: " + name + " key: " + key);
/*     */     }
/*     */     
/* 145 */     Object value = (Object)this.dynaValues.get(name);
/* 146 */     if (value == null) {
/* 147 */       value = (Object)new HashMap();
/* 148 */       this.dynaValues.put(name, value);
/*     */     } 
/* 150 */     return ((Map)value).get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public DynaClass getDynaClass() {
/* 155 */     return this.dynaClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public MorpherRegistry getMorpherRegistry() {
/* 160 */     return this.morpherRegistry;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 165 */     HashCodeBuilder builder = (new HashCodeBuilder()).append(this.dynaClass);
/* 166 */     DynaProperty[] props = this.dynaClass.getDynaProperties();
/* 167 */     for (int i = 0; i < props.length; i++) {
/* 168 */       DynaProperty prop = props[i];
/* 169 */       builder.append(this.dynaValues.get(prop.getName()));
/*     */     } 
/* 171 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(String name, String key) {
/* 176 */     DynaProperty dynaProperty = getDynaProperty(name);
/*     */     
/* 178 */     Class type = dynaProperty.getType();
/* 179 */     if (!Map.class.isAssignableFrom(type)) {
/* 180 */       throw new MorphException("Non-Mapped property name: " + name + " key: " + key);
/*     */     }
/*     */     
/* 183 */     Object value = (Object)this.dynaValues.get(name);
/* 184 */     if (value == null) {
/* 185 */       value = (Object)new HashMap();
/* 186 */       this.dynaValues.put(name, value);
/*     */     } 
/* 188 */     ((Map)value).remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String name, int index, Object value) {
/* 193 */     DynaProperty dynaProperty = getDynaProperty(name);
/*     */     
/* 195 */     Class type = dynaProperty.getType();
/* 196 */     if (!type.isArray() && !List.class.isAssignableFrom(type)) {
/* 197 */       throw new MorphException("Non-Indexed property name: " + name + " index: " + index);
/*     */     }
/*     */     
/* 200 */     Object prop = this.dynaValues.get(name);
/* 201 */     if (prop == null) {
/* 202 */       if (List.class.isAssignableFrom(type)) {
/* 203 */         prop = new ArrayList();
/*     */       } else {
/* 205 */         prop = Array.newInstance(type.getComponentType(), index + 1);
/*     */       } 
/* 207 */       this.dynaValues.put(name, prop);
/*     */     } 
/*     */     
/* 210 */     if (prop.getClass().isArray()) {
/*     */       
/* 212 */       if (index >= Array.getLength(prop)) {
/* 213 */         Object tmp = Array.newInstance(type.getComponentType(), index + 1);
/* 214 */         System.arraycopy(prop, 0, tmp, 0, Array.getLength(prop));
/* 215 */         prop = tmp;
/* 216 */         this.dynaValues.put(name, tmp);
/*     */       } 
/* 218 */       Array.set(prop, index, value);
/* 219 */     } else if (prop instanceof List) {
/* 220 */       List l = (List)prop;
/* 221 */       if (index >= l.size()) {
/* 222 */         for (int i = l.size(); i <= index + 1; i++) {
/* 223 */           l.add(null);
/*     */         }
/*     */       }
/* 226 */       ((List)prop).set(index, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String name, Object value) {
/* 232 */     DynaProperty property = getDynaProperty(name);
/*     */     
/* 234 */     if (value == null || !isDynaAssignable(property.getType(), value.getClass())) {
/* 235 */       value = this.morpherRegistry.morph(property.getType(), value);
/*     */     }
/*     */     
/* 238 */     this.dynaValues.put(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String name, String key, Object value) {
/* 243 */     DynaProperty dynaProperty = getDynaProperty(name);
/*     */     
/* 245 */     Class type = dynaProperty.getType();
/* 246 */     if (!Map.class.isAssignableFrom(type)) {
/* 247 */       throw new MorphException("Non-Mapped property name: " + name + " key: " + key);
/*     */     }
/*     */     
/* 250 */     Object prop = (Object)this.dynaValues.get(name);
/* 251 */     if (prop == null) {
/* 252 */       prop = (Object)new HashMap();
/* 253 */       this.dynaValues.put(name, prop);
/*     */     } 
/* 255 */     ((Map)prop).put(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setDynaBeanClass(MorphDynaClass dynaClass) {
/* 260 */     if (this.dynaClass == null) {
/* 261 */       this.dynaClass = dynaClass;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMorpherRegistry(MorpherRegistry morpherRegistry) {
/* 267 */     if (morpherRegistry == null) {
/* 268 */       this.morpherRegistry = new MorpherRegistry();
/* 269 */       MorphUtils.registerStandardMorphers(this.morpherRegistry);
/*     */     } else {
/* 271 */       this.morpherRegistry = morpherRegistry;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 277 */     return (new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)).append(this.dynaValues).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected DynaProperty getDynaProperty(String name) {
/* 283 */     DynaProperty property = getDynaClass().getDynaProperty(name);
/* 284 */     if (property == null) {
/* 285 */       throw new MorphException("Unspecified property for " + name);
/*     */     }
/* 287 */     return property;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isDynaAssignable(Class dest, Class src) {
/* 292 */     boolean assignable = dest.isAssignableFrom(src);
/* 293 */     if (assignable) {
/* 294 */       return true;
/*     */     }
/* 296 */     assignable = (dest == boolean.class && src == Boolean.class) ? true : assignable;
/* 297 */     assignable = (dest == byte.class && src == Byte.class) ? true : assignable;
/* 298 */     assignable = (dest == char.class && src == Character.class) ? true : assignable;
/* 299 */     assignable = (dest == short.class && src == Short.class) ? true : assignable;
/* 300 */     assignable = (dest == int.class && src == Integer.class) ? true : assignable;
/* 301 */     assignable = (dest == long.class && src == Long.class) ? true : assignable;
/* 302 */     assignable = (dest == float.class && src == Float.class) ? true : assignable;
/* 303 */     assignable = (dest == double.class && src == Double.class) ? true : assignable;
/*     */     
/* 305 */     if (src == double.class || Double.class.isAssignableFrom(src)) {
/* 306 */       assignable = (isByte(dest) || isShort(dest) || isInteger(dest) || isLong(dest) || isFloat(dest)) ? true : assignable;
/*     */     }
/*     */     
/* 309 */     if (src == float.class || Float.class.isAssignableFrom(src)) {
/* 310 */       assignable = (isByte(dest) || isShort(dest) || isInteger(dest) || isLong(dest)) ? true : assignable;
/*     */     }
/*     */     
/* 313 */     if (src == long.class || Long.class.isAssignableFrom(src)) {
/* 314 */       assignable = (isByte(dest) || isShort(dest) || isInteger(dest)) ? true : assignable;
/*     */     }
/* 316 */     if (src == int.class || Integer.class.isAssignableFrom(src)) {
/* 317 */       assignable = (isByte(dest) || isShort(dest)) ? true : assignable;
/*     */     }
/* 319 */     if (src == short.class || Short.class.isAssignableFrom(src)) {
/* 320 */       assignable = isByte(dest) ? true : assignable;
/*     */     }
/*     */     
/* 323 */     return assignable;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isByte(Class clazz) {
/* 328 */     return (Byte.class.isAssignableFrom(clazz) || clazz == byte.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isFloat(Class clazz) {
/* 333 */     return (Float.class.isAssignableFrom(clazz) || clazz == float.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isInteger(Class clazz) {
/* 338 */     return (Integer.class.isAssignableFrom(clazz) || clazz == int.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isLong(Class clazz) {
/* 343 */     return (Long.class.isAssignableFrom(clazz) || clazz == long.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isShort(Class clazz) {
/* 348 */     return (Short.class.isAssignableFrom(clazz) || clazz == short.class);
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\bean\MorphDynaBean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */