/*     */ package net.sf.ezmorph.bean;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.MorpherRegistry;
/*     */ import net.sf.ezmorph.ObjectMorpher;
/*     */ import net.sf.ezmorph.object.IdentityObjectMorpher;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.beanutils.DynaProperty;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BeanMorpher
/*     */   implements ObjectMorpher
/*     */ {
/*  48 */   private static final Log log = LogFactory.getLog(BeanMorpher.class);
/*     */   
/*     */   private final Class beanClass;
/*     */   private boolean lenient;
/*     */   private final MorpherRegistry morpherRegistry;
/*     */   
/*     */   public BeanMorpher(Class beanClass, MorpherRegistry morpherRegistry) {
/*  55 */     this(beanClass, morpherRegistry, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanMorpher(Class beanClass, MorpherRegistry morpherRegistry, boolean lenient) {
/*  60 */     validateClass(beanClass);
/*  61 */     if (morpherRegistry == null) {
/*  62 */       throw new MorphException("morpherRegistry is null");
/*     */     }
/*  64 */     this.beanClass = beanClass;
/*  65 */     this.morpherRegistry = morpherRegistry;
/*  66 */     this.lenient = lenient;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object sourceBean) {
/*  71 */     if (sourceBean == null) {
/*  72 */       return null;
/*     */     }
/*  74 */     if (!supports(sourceBean.getClass())) {
/*  75 */       throw new MorphException("unsupported class: " + sourceBean.getClass().getName());
/*     */     }
/*     */ 
/*     */     
/*  79 */     Object targetBean = null;
/*     */     
/*     */     try {
/*  82 */       targetBean = this.beanClass.newInstance();
/*  83 */       PropertyDescriptor[] targetPds = PropertyUtils.getPropertyDescriptors(this.beanClass);
/*  84 */       int i = 0; while (true) { if (i < targetPds.length)
/*  85 */         { PropertyDescriptor targetPd = targetPds[i];
/*  86 */           String name = targetPd.getName();
/*  87 */           if (targetPd.getWriteMethod() == null)
/*  88 */           { log.info("Property '" + this.beanClass.getName() + "." + name + "' has no write method. SKIPPED.");
/*     */              }
/*     */           
/*     */           else
/*     */           
/*  93 */           { Class sourceType = null;
/*  94 */             if (sourceBean instanceof DynaBean)
/*  95 */             { DynaBean dynaBean = (DynaBean)sourceBean;
/*  96 */               DynaProperty dynaProperty = dynaBean.getDynaClass().getDynaProperty(name);
/*     */               
/*  98 */               sourceType = dynaProperty.getType(); }
/*     */             else
/* 100 */             { PropertyDescriptor sourcePd = PropertyUtils.getPropertyDescriptor(sourceBean, name);
/* 101 */               if (sourcePd.getReadMethod() == null)
/* 102 */               { log.warn("Property '" + sourceBean.getClass().getName() + "." + name + "' has no read method. SKIPPED."); }
/*     */               
/*     */               else
/*     */               
/* 106 */               { sourceType = sourcePd.getPropertyType();
/*     */ 
/*     */                 
/* 109 */                 Class targetType = targetPd.getPropertyType();
/* 110 */                 Object value = PropertyUtils.getProperty(sourceBean, name);
/* 111 */                 setProperty(targetBean, name, sourceType, targetType, value); }  i++; }  Class clazz1 = targetPd.getPropertyType(); Object object = PropertyUtils.getProperty(sourceBean, name); setProperty(targetBean, name, sourceType, clazz1, object); }  } else { break; }
/*     */          i++; }
/*     */     
/* 114 */     } catch (MorphException me) {
/* 115 */       throw me;
/*     */     }
/* 117 */     catch (Exception e) {
/* 118 */       throw new MorphException(e);
/*     */     } 
/*     */     
/* 121 */     return targetBean;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 126 */     return this.beanClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(Class clazz) {
/* 131 */     return !clazz.isArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setProperty(Object targetBean, String name, Class sourceType, Class targetType, Object value) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
/* 138 */     if (targetType.isAssignableFrom(sourceType)) {
/* 139 */       if (value == null && targetType.isPrimitive()) {
/* 140 */         value = this.morpherRegistry.morph(targetType, value);
/*     */       }
/* 142 */       PropertyUtils.setProperty(targetBean, name, value);
/*     */     }
/* 144 */     else if (targetType.equals(Object.class)) {
/*     */       
/* 146 */       PropertyUtils.setProperty(targetBean, name, value);
/*     */     }
/* 148 */     else if (value == null) {
/* 149 */       if (targetType.isPrimitive()) {
/* 150 */         PropertyUtils.setProperty(targetBean, name, this.morpherRegistry.morph(targetType, value));
/*     */       
/*     */       }
/*     */     }
/* 154 */     else if (IdentityObjectMorpher.getInstance() == this.morpherRegistry.getMorpherFor(targetType)) {
/* 155 */       if (!this.lenient) {
/* 156 */         throw new MorphException("Can't find a morpher for target class " + targetType.getName() + " (" + name + ")");
/*     */       }
/*     */       
/* 159 */       log.info("Can't find a morpher for target class " + targetType.getName() + " (" + name + ") SKIPPED");
/*     */     }
/*     */     else {
/*     */       
/* 163 */       PropertyUtils.setProperty(targetBean, name, this.morpherRegistry.morph(targetType, value));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateClass(Class clazz) {
/* 173 */     if (clazz == null)
/* 174 */       throw new MorphException("target class is null"); 
/* 175 */     if (clazz.isPrimitive())
/* 176 */       throw new MorphException("target class is a primitive"); 
/* 177 */     if (clazz.isArray())
/* 178 */       throw new MorphException("target class is an array"); 
/* 179 */     if (clazz.isInterface())
/* 180 */       throw new MorphException("target class is an interface"); 
/* 181 */     if (DynaBean.class.isAssignableFrom(clazz))
/* 182 */       throw new MorphException("target class is a DynaBean"); 
/* 183 */     if (Number.class.isAssignableFrom(clazz) || Boolean.class.isAssignableFrom(clazz) || Character.class.isAssignableFrom(clazz))
/*     */     {
/* 185 */       throw new MorphException("target class is a wrapper"); } 
/* 186 */     if (String.class.isAssignableFrom(clazz))
/* 187 */       throw new MorphException("target class is a String"); 
/* 188 */     if (Collection.class.isAssignableFrom(clazz))
/* 189 */       throw new MorphException("target class is a Collection"); 
/* 190 */     if (Map.class.isAssignableFrom(clazz))
/* 191 */       throw new MorphException("target class is a Map"); 
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\bean\BeanMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */