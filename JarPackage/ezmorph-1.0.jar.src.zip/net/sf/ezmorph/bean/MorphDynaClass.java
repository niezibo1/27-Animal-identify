/*     */ package net.sf.ezmorph.bean;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.MorphUtils;
/*     */ import net.sf.ezmorph.MorpherRegistry;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.beanutils.DynaClass;
/*     */ import org.apache.commons.beanutils.DynaProperty;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ import org.apache.commons.lang.builder.ToStringBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MorphDynaClass
/*     */   implements DynaClass, Serializable
/*     */ {
/*  42 */   private static final Comparator dynaPropertyComparator = new Comparator()
/*     */     {
/*     */       public int compare(Object a, Object b) {
/*  45 */         if (a instanceof DynaProperty && b instanceof DynaProperty) {
/*  46 */           DynaProperty p1 = (DynaProperty)a;
/*  47 */           DynaProperty p2 = (DynaProperty)b;
/*  48 */           return p1.getName().compareTo(p2.getName());
/*     */         } 
/*     */         
/*  51 */         return -1;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 689740135689363791L;
/*     */   private Map attributes;
/*     */   private Class beanClass;
/*     */   private DynaProperty[] dynaProperties;
/*     */   private String name;
/*  61 */   private Map properties = new HashMap();
/*     */   
/*     */   private Class type;
/*     */   
/*     */   public MorphDynaClass(Map attributes) {
/*  66 */     this(null, null, attributes);
/*     */   }
/*     */ 
/*     */   
/*     */   public MorphDynaClass(String name, Class type, Map attributes) {
/*  71 */     if (name == null) {
/*  72 */       name = "MorphDynaClass";
/*     */     }
/*  74 */     if (type == null) {
/*  75 */       type = MorphDynaBean.class;
/*     */     }
/*  77 */     if (!MorphDynaBean.class.isAssignableFrom(type)) {
/*  78 */       throw new MorphException("MorphDynaBean is not assignable from " + type.getName());
/*     */     }
/*  80 */     if (attributes == null || attributes.isEmpty()) {
/*  81 */       throw new MorphException("Attributes map is null or empty.");
/*     */     }
/*  83 */     this.name = name;
/*  84 */     this.type = type;
/*  85 */     this.attributes = attributes;
/*  86 */     process();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  91 */     if (this == obj) {
/*  92 */       return true;
/*     */     }
/*     */     
/*  95 */     if (obj == null) {
/*  96 */       return false;
/*     */     }
/*     */     
/*  99 */     if (!(obj instanceof MorphDynaClass)) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     MorphDynaClass other = (MorphDynaClass)obj;
/* 104 */     EqualsBuilder builder = (new EqualsBuilder()).append(this.name, other.name).append(this.type, other.type);
/*     */     
/* 106 */     if (this.dynaProperties.length != other.dynaProperties.length) {
/* 107 */       return false;
/*     */     }
/* 109 */     for (int i = 0; i < this.dynaProperties.length; i++) {
/* 110 */       DynaProperty a = this.dynaProperties[i];
/* 111 */       DynaProperty b = other.dynaProperties[i];
/* 112 */       builder.append(a.getName(), b.getName());
/* 113 */       builder.append(a.getType(), b.getType());
/*     */     } 
/* 115 */     return builder.isEquals();
/*     */   }
/*     */ 
/*     */   
/*     */   public DynaProperty[] getDynaProperties() {
/* 120 */     return this.dynaProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public DynaProperty getDynaProperty(String propertyName) {
/* 125 */     if (propertyName == null) {
/* 126 */       throw new MorphException("Unnespecified bean property name");
/*     */     }
/*     */     
/* 129 */     return (DynaProperty)this.properties.get(propertyName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 134 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 139 */     HashCodeBuilder builder = (new HashCodeBuilder()).append(this.name).append(this.type);
/*     */     
/* 141 */     for (int i = 0; i < this.dynaProperties.length; i++) {
/* 142 */       builder.append(this.dynaProperties[i].getName());
/* 143 */       builder.append(this.dynaProperties[i].getType());
/*     */     } 
/* 145 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public DynaBean newInstance() throws IllegalAccessException, InstantiationException {
/* 150 */     return newInstance(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DynaBean newInstance(MorpherRegistry morpherRegistry) throws IllegalAccessException, InstantiationException {
/* 156 */     if (morpherRegistry == null) {
/* 157 */       morpherRegistry = new MorpherRegistry();
/* 158 */       MorphUtils.registerStandardMorphers(morpherRegistry);
/*     */     } 
/* 160 */     MorphDynaBean dynaBean = getBeanClass().newInstance();
/* 161 */     dynaBean.setDynaBeanClass(this);
/* 162 */     dynaBean.setMorpherRegistry(morpherRegistry);
/* 163 */     Iterator keys = this.attributes.keySet().iterator();
/*     */     
/* 165 */     while (keys.hasNext()) {
/* 166 */       String key = keys.next();
/* 167 */       dynaBean.set(key, null);
/*     */     } 
/* 169 */     return dynaBean;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 174 */     return (new ToStringBuilder(this)).append("name", this.name).append("type", this.type).append("attributes", this.attributes).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class getBeanClass() {
/* 182 */     if (this.beanClass == null) {
/* 183 */       process();
/*     */     }
/* 185 */     return this.beanClass;
/*     */   }
/*     */ 
/*     */   
/*     */   private void process() {
/* 190 */     this.beanClass = this.type;
/*     */     
/*     */     try {
/* 193 */       Iterator entries = this.attributes.entrySet().iterator();
/*     */       
/* 195 */       this.dynaProperties = new DynaProperty[this.attributes.size()];
/* 196 */       int i = 0;
/* 197 */       while (entries.hasNext()) {
/* 198 */         Map.Entry entry = entries.next();
/* 199 */         String pname = (String)entry.getKey();
/* 200 */         Object pclass = entry.getValue();
/* 201 */         DynaProperty dynaProperty = null;
/* 202 */         if (pclass instanceof String) {
/* 203 */           Class klass = Class.forName((String)pclass);
/* 204 */           if (klass.isArray() && klass.getComponentType().isArray())
/*     */           {
/* 206 */             throw new MorphException("Multidimensional arrays are not supported");
/*     */           }
/* 208 */           dynaProperty = new DynaProperty(pname, klass);
/* 209 */         } else if (pclass instanceof Class) {
/* 210 */           Class klass = (Class)pclass;
/* 211 */           if (klass.isArray() && klass.getComponentType().isArray())
/*     */           {
/* 213 */             throw new MorphException("Multidimensional arrays are not supported");
/*     */           }
/* 215 */           dynaProperty = new DynaProperty(pname, klass);
/*     */         } else {
/* 217 */           throw new MorphException("Type must be String or Class");
/*     */         } 
/* 219 */         this.properties.put(dynaProperty.getName(), dynaProperty);
/* 220 */         this.dynaProperties[i++] = dynaProperty;
/*     */       }
/*     */     
/* 223 */     } catch (ClassNotFoundException cnfe) {
/* 224 */       throw new MorphException(cnfe);
/*     */     } 
/*     */ 
/*     */     
/* 228 */     Arrays.sort(this.dynaProperties, 0, this.dynaProperties.length, dynaPropertyComparator);
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\bean\MorphDynaClass.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */