/*     */ package net.sf.ezmorph;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import net.sf.ezmorph.array.BooleanArrayMorpher;
/*     */ import net.sf.ezmorph.array.ByteArrayMorpher;
/*     */ import net.sf.ezmorph.array.CharArrayMorpher;
/*     */ import net.sf.ezmorph.array.DoubleArrayMorpher;
/*     */ import net.sf.ezmorph.array.FloatArrayMorpher;
/*     */ import net.sf.ezmorph.array.IntArrayMorpher;
/*     */ import net.sf.ezmorph.array.LongArrayMorpher;
/*     */ import net.sf.ezmorph.array.ObjectArrayMorpher;
/*     */ import net.sf.ezmorph.array.ShortArrayMorpher;
/*     */ import net.sf.ezmorph.object.BooleanObjectMorpher;
/*     */ import net.sf.ezmorph.object.CharacterObjectMorpher;
/*     */ import net.sf.ezmorph.object.ClassMorpher;
/*     */ import net.sf.ezmorph.object.NumberMorpher;
/*     */ import net.sf.ezmorph.object.StringMorpher;
/*     */ import net.sf.ezmorph.primitive.BooleanMorpher;
/*     */ import net.sf.ezmorph.primitive.ByteMorpher;
/*     */ import net.sf.ezmorph.primitive.CharMorpher;
/*     */ import net.sf.ezmorph.primitive.DoubleMorpher;
/*     */ import net.sf.ezmorph.primitive.FloatMorpher;
/*     */ import net.sf.ezmorph.primitive.IntMorpher;
/*     */ import net.sf.ezmorph.primitive.LongMorpher;
/*     */ import net.sf.ezmorph.primitive.ShortMorpher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphUtils
/*     */ {
/*  53 */   public static final BigDecimal BIGDECIMAL_ONE = new BigDecimal("1");
/*     */   
/*  55 */   public static final BigDecimal BIGDECIMAL_ZERO = new BigDecimal("0");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerStandardMorphers(MorpherRegistry morpherRegistry) {
/*  64 */     morpherRegistry.clear();
/*  65 */     registerStandardPrimitiveMorphers(morpherRegistry);
/*  66 */     registerStandardPrimitiveArrayMorphers(morpherRegistry);
/*  67 */     registerStandardObjectMorphers(morpherRegistry);
/*  68 */     registerStandardObjectArrayMorphers(morpherRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerStandardObjectArrayMorphers(MorpherRegistry morpherRegistry) {
/*  92 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new BooleanObjectMorpher(Boolean.FALSE)));
/*     */     
/*  94 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new CharacterObjectMorpher(new Character(false))));
/*     */     
/*  96 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)StringMorpher.getInstance()));
/*  97 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new NumberMorpher(Byte.class, new Byte((byte)0))));
/*     */     
/*  99 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new NumberMorpher(Short.class, new Short((short)0))));
/*     */     
/* 101 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new NumberMorpher(Integer.class, new Integer(0))));
/*     */     
/* 103 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new NumberMorpher(Long.class, new Long(0L))));
/*     */     
/* 105 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new NumberMorpher(Float.class, new Float(0.0F))));
/*     */     
/* 107 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new NumberMorpher(Double.class, new Double(0.0D))));
/*     */     
/* 109 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new NumberMorpher(BigInteger.class, BigInteger.ZERO)));
/*     */     
/* 111 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)new NumberMorpher(BigDecimal.class, BIGDECIMAL_ZERO)));
/*     */     
/* 113 */     morpherRegistry.registerMorpher((Morpher)new ObjectArrayMorpher((Morpher)ClassMorpher.getInstance()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerStandardObjectMorphers(MorpherRegistry morpherRegistry) {
/* 136 */     morpherRegistry.registerMorpher((Morpher)new BooleanObjectMorpher(Boolean.FALSE));
/* 137 */     morpherRegistry.registerMorpher((Morpher)new CharacterObjectMorpher(new Character(false)));
/* 138 */     morpherRegistry.registerMorpher((Morpher)StringMorpher.getInstance());
/* 139 */     morpherRegistry.registerMorpher((Morpher)new NumberMorpher(Byte.class, new Byte((byte)0)));
/* 140 */     morpherRegistry.registerMorpher((Morpher)new NumberMorpher(Short.class, new Short((short)0)));
/* 141 */     morpherRegistry.registerMorpher((Morpher)new NumberMorpher(Integer.class, new Integer(0)));
/* 142 */     morpherRegistry.registerMorpher((Morpher)new NumberMorpher(Long.class, new Long(0L)));
/* 143 */     morpherRegistry.registerMorpher((Morpher)new NumberMorpher(Float.class, new Float(0.0F)));
/* 144 */     morpherRegistry.registerMorpher((Morpher)new NumberMorpher(Double.class, new Double(0.0D)));
/* 145 */     morpherRegistry.registerMorpher((Morpher)new NumberMorpher(BigInteger.class, BigInteger.ZERO));
/* 146 */     morpherRegistry.registerMorpher((Morpher)new NumberMorpher(BigDecimal.class, BIGDECIMAL_ZERO));
/*     */     
/* 148 */     morpherRegistry.registerMorpher((Morpher)ClassMorpher.getInstance());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerStandardPrimitiveArrayMorphers(MorpherRegistry morpherRegistry) {
/* 168 */     morpherRegistry.registerMorpher((Morpher)new BooleanArrayMorpher(false));
/* 169 */     morpherRegistry.registerMorpher((Morpher)new CharArrayMorpher(false));
/* 170 */     morpherRegistry.registerMorpher((Morpher)new ByteArrayMorpher((byte)0));
/* 171 */     morpherRegistry.registerMorpher((Morpher)new ShortArrayMorpher((short)0));
/* 172 */     morpherRegistry.registerMorpher((Morpher)new IntArrayMorpher(0));
/* 173 */     morpherRegistry.registerMorpher((Morpher)new LongArrayMorpher(0L));
/* 174 */     morpherRegistry.registerMorpher((Morpher)new FloatArrayMorpher(0.0F));
/* 175 */     morpherRegistry.registerMorpher((Morpher)new DoubleArrayMorpher(0.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerStandardPrimitiveMorphers(MorpherRegistry morpherRegistry) {
/* 195 */     morpherRegistry.registerMorpher((Morpher)new BooleanMorpher(false));
/* 196 */     morpherRegistry.registerMorpher((Morpher)new CharMorpher(false));
/* 197 */     morpherRegistry.registerMorpher((Morpher)new ByteMorpher((byte)0));
/* 198 */     morpherRegistry.registerMorpher((Morpher)new ShortMorpher((short)0));
/* 199 */     morpherRegistry.registerMorpher((Morpher)new IntMorpher(0));
/* 200 */     morpherRegistry.registerMorpher((Morpher)new LongMorpher(0L));
/* 201 */     morpherRegistry.registerMorpher((Morpher)new FloatMorpher(0.0F));
/* 202 */     morpherRegistry.registerMorpher((Morpher)new DoubleMorpher(0.0D));
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\MorphUtils.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */