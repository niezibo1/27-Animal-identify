/*    */ package net.sf.ezmorph.primitive;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDecimalMorpher
/*    */   extends AbstractPrimitiveMorpher
/*    */ {
/*    */   public AbstractDecimalMorpher() {}
/*    */   
/*    */   public AbstractDecimalMorpher(boolean useDefault) {
/* 33 */     super(useDefault);
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\primitive\AbstractDecimalMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */