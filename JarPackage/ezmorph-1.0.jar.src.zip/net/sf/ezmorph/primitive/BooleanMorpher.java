/*     */ package net.sf.ezmorph.primitive;
/*     */ 
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BooleanMorpher
/*     */   extends AbstractPrimitiveMorpher
/*     */ {
/*     */   private boolean defaultValue;
/*     */   
/*     */   public BooleanMorpher() {}
/*     */   
/*     */   public BooleanMorpher(boolean defaultValue) {
/*  40 */     super(true);
/*  41 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  46 */     if (this == obj) {
/*  47 */       return true;
/*     */     }
/*  49 */     if (obj == null) {
/*  50 */       return false;
/*     */     }
/*     */     
/*  53 */     if (!(obj instanceof BooleanMorpher)) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     BooleanMorpher other = (BooleanMorpher)obj;
/*  58 */     EqualsBuilder builder = new EqualsBuilder();
/*  59 */     if (isUseDefault() && other.isUseDefault()) {
/*  60 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  61 */       return builder.isEquals();
/*  62 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  63 */       return builder.isEquals();
/*     */     }
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDefaultValue() {
/*  71 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  76 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  77 */     if (isUseDefault()) {
/*  78 */       builder.append(getDefaultValue());
/*     */     }
/*  80 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean morph(Object value) {
/*  91 */     if (value == null) {
/*  92 */       if (isUseDefault()) {
/*  93 */         return this.defaultValue;
/*     */       }
/*  95 */       throw new MorphException("value is null");
/*     */     } 
/*     */ 
/*     */     
/*  99 */     if (value instanceof Boolean) {
/* 100 */       return ((Boolean)value).booleanValue();
/*     */     }
/* 102 */     String s = String.valueOf(value);
/*     */     
/* 104 */     if (s.equalsIgnoreCase("true") || s.equalsIgnoreCase("yes") || s.equalsIgnoreCase("on"))
/*     */     {
/* 106 */       return true; } 
/* 107 */     if (s.equalsIgnoreCase("false") || s.equalsIgnoreCase("no") || s.equalsIgnoreCase("off"))
/*     */     {
/* 109 */       return false; } 
/* 110 */     if (isUseDefault()) {
/* 111 */       return this.defaultValue;
/*     */     }
/*     */ 
/*     */     
/* 115 */     throw new MorphException("Can't morph value: " + value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 120 */     return boolean.class;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\primitive\BooleanMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */