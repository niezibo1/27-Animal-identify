/*     */ package net.sf.ezmorph.primitive;
/*     */ 
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ByteMorpher
/*     */   extends AbstractIntegerMorpher
/*     */ {
/*     */   private byte defaultValue;
/*     */   
/*     */   public ByteMorpher() {}
/*     */   
/*     */   public ByteMorpher(byte defaultValue) {
/*  40 */     super(true);
/*  41 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  46 */     if (this == obj) {
/*  47 */       return true;
/*     */     }
/*  49 */     if (obj == null) {
/*  50 */       return false;
/*     */     }
/*     */     
/*  53 */     if (!(obj instanceof ByteMorpher)) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     ByteMorpher other = (ByteMorpher)obj;
/*  58 */     EqualsBuilder builder = new EqualsBuilder();
/*  59 */     if (isUseDefault() && other.isUseDefault()) {
/*  60 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  61 */       return builder.isEquals();
/*  62 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  63 */       return builder.isEquals();
/*     */     }
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getDefaultValue() {
/*  71 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  76 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  77 */     if (isUseDefault()) {
/*  78 */       builder.append(getDefaultValue());
/*     */     }
/*  80 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte morph(Object value) {
/*  91 */     if (value == null) {
/*  92 */       if (isUseDefault()) {
/*  93 */         return this.defaultValue;
/*     */       }
/*  95 */       throw new MorphException("value is null");
/*     */     } 
/*     */ 
/*     */     
/*  99 */     if (value instanceof Number) {
/* 100 */       return ((Number)value).byteValue();
/*     */     }
/* 102 */     byte i = 0;
/*     */     try {
/* 104 */       i = Byte.parseByte(getIntegerValue(value));
/* 105 */       return i;
/*     */     }
/* 107 */     catch (NumberFormatException nfe) {
/* 108 */       if (isUseDefault()) {
/* 109 */         return this.defaultValue;
/*     */       }
/* 111 */       throw new MorphException(nfe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 119 */     return byte.class;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\primitive\ByteMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */