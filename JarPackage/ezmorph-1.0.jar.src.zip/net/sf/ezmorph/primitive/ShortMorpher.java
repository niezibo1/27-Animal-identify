/*     */ package net.sf.ezmorph.primitive;
/*     */ 
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ShortMorpher
/*     */   extends AbstractIntegerMorpher
/*     */ {
/*     */   private short defaultValue;
/*     */   
/*     */   public ShortMorpher() {}
/*     */   
/*     */   public ShortMorpher(short defaultValue) {
/*  39 */     super(true);
/*  40 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  45 */     if (this == obj) {
/*  46 */       return true;
/*     */     }
/*  48 */     if (obj == null) {
/*  49 */       return false;
/*     */     }
/*     */     
/*  52 */     if (!(obj instanceof ShortMorpher)) {
/*  53 */       return false;
/*     */     }
/*     */     
/*  56 */     ShortMorpher other = (ShortMorpher)obj;
/*  57 */     EqualsBuilder builder = new EqualsBuilder();
/*  58 */     if (isUseDefault() && other.isUseDefault()) {
/*  59 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  60 */       return builder.isEquals();
/*  61 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  62 */       return builder.isEquals();
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public short getDefaultValue() {
/*  70 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  75 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  76 */     if (isUseDefault()) {
/*  77 */       builder.append(getDefaultValue());
/*     */     }
/*  79 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short morph(Object value) {
/*  90 */     if (value == null) {
/*  91 */       if (isUseDefault()) {
/*  92 */         return this.defaultValue;
/*     */       }
/*  94 */       throw new MorphException("value is null");
/*     */     } 
/*     */ 
/*     */     
/*  98 */     if (value instanceof Number) {
/*  99 */       return ((Number)value).shortValue();
/*     */     }
/* 101 */     short i = 0;
/*     */     try {
/* 103 */       i = Short.parseShort(getIntegerValue(value));
/* 104 */       return i;
/*     */     }
/* 106 */     catch (NumberFormatException nfe) {
/* 107 */       if (isUseDefault()) {
/* 108 */         return this.defaultValue;
/*     */       }
/* 110 */       throw new MorphException(nfe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 118 */     return short.class;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\primitive\ShortMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */