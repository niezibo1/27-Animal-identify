/*     */ package net.sf.ezmorph.primitive;
/*     */ 
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FloatMorpher
/*     */   extends AbstractDecimalMorpher
/*     */ {
/*     */   private float defaultValue;
/*     */   
/*     */   public FloatMorpher() {}
/*     */   
/*     */   public FloatMorpher(float defaultValue) {
/*  40 */     super(true);
/*  41 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  46 */     if (this == obj) {
/*  47 */       return true;
/*     */     }
/*  49 */     if (obj == null) {
/*  50 */       return false;
/*     */     }
/*     */     
/*  53 */     if (!(obj instanceof FloatMorpher)) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     FloatMorpher other = (FloatMorpher)obj;
/*  58 */     EqualsBuilder builder = new EqualsBuilder();
/*  59 */     if (isUseDefault() && other.isUseDefault()) {
/*  60 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  61 */       return builder.isEquals();
/*  62 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  63 */       return builder.isEquals();
/*     */     }
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDefaultValue() {
/*  71 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  76 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  77 */     if (isUseDefault()) {
/*  78 */       builder.append(getDefaultValue());
/*     */     }
/*  80 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float morph(Object value) {
/*  91 */     if (value == null) {
/*  92 */       if (isUseDefault()) {
/*  93 */         return this.defaultValue;
/*     */       }
/*  95 */       throw new MorphException("value is null");
/*     */     } 
/*     */ 
/*     */     
/*  99 */     if (value instanceof Number) {
/* 100 */       return ((Number)value).floatValue();
/*     */     }
/* 102 */     float i = 0.0F;
/*     */     try {
/* 104 */       i = Float.parseFloat(String.valueOf(value));
/* 105 */       return i;
/*     */     }
/* 107 */     catch (NumberFormatException nfe) {
/* 108 */       if (isUseDefault()) {
/* 109 */         return this.defaultValue;
/*     */       }
/* 111 */       throw new MorphException(nfe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 119 */     return float.class;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\primitive\FloatMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */