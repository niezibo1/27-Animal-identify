/*    */ package net.sf.ezmorph.primitive;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractIntegerMorpher
/*    */   extends AbstractPrimitiveMorpher
/*    */ {
/*    */   public AbstractIntegerMorpher() {}
/*    */   
/*    */   public AbstractIntegerMorpher(boolean useDefault) {
/* 35 */     super(useDefault);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getIntegerValue(Object obj) {
/* 44 */     Locale defaultLocale = Locale.getDefault();
/* 45 */     String str = null;
/*    */     try {
/* 47 */       Locale.setDefault(Locale.US);
/* 48 */       str = String.valueOf(obj);
/*    */     } finally {
/*    */       
/* 51 */       Locale.setDefault(defaultLocale);
/*    */     } 
/*    */     
/* 54 */     int index = str.indexOf(".");
/* 55 */     if (index != -1) {
/* 56 */       str = str.substring(0, index);
/*    */     }
/* 58 */     return str;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\primitive\AbstractIntegerMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */