/*    */ package net.sf.ezmorph.primitive;
/*    */ 
/*    */ import net.sf.ezmorph.Morpher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPrimitiveMorpher
/*    */   implements Morpher
/*    */ {
/*    */   private boolean useDefault = false;
/*    */   
/*    */   public AbstractPrimitiveMorpher() {}
/*    */   
/*    */   public AbstractPrimitiveMorpher(boolean useDefault) {
/* 37 */     this.useDefault = useDefault;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isUseDefault() {
/* 45 */     return this.useDefault;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supports(Class clazz) {
/* 57 */     return !clazz.isArray();
/*    */   }
/*    */   
/*    */   public abstract Class morphsTo();
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\primitive\AbstractPrimitiveMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */