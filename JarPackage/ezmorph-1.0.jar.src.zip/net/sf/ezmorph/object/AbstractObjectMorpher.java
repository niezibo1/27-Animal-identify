/*    */ package net.sf.ezmorph.object;
/*    */ 
/*    */ import net.sf.ezmorph.ObjectMorpher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractObjectMorpher
/*    */   implements ObjectMorpher
/*    */ {
/*    */   private boolean useDefault;
/*    */   
/*    */   public AbstractObjectMorpher() {}
/*    */   
/*    */   public AbstractObjectMorpher(boolean useDefault) {
/* 37 */     this.useDefault = useDefault;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isUseDefault() {
/* 45 */     return this.useDefault;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUseDefault(boolean useDefault) {
/* 53 */     this.useDefault = useDefault;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supports(Class clazz) {
/* 65 */     return !clazz.isArray();
/*    */   }
/*    */   
/*    */   public abstract Object morph(Object paramObject);
/*    */   
/*    */   public abstract Class morphsTo();
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\AbstractObjectMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */