/*     */ package net.sf.ezmorph.object;
/*     */ 
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BooleanObjectMorpher
/*     */   extends AbstractObjectMorpher
/*     */ {
/*     */   private Boolean defaultValue;
/*     */   
/*     */   public BooleanObjectMorpher() {}
/*     */   
/*     */   public BooleanObjectMorpher(Boolean defaultValue) {
/*  40 */     super(true);
/*  41 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  46 */     if (this == obj) {
/*  47 */       return true;
/*     */     }
/*  49 */     if (obj == null) {
/*  50 */       return false;
/*     */     }
/*     */     
/*  53 */     if (!(obj instanceof BooleanObjectMorpher)) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     BooleanObjectMorpher other = (BooleanObjectMorpher)obj;
/*  58 */     EqualsBuilder builder = new EqualsBuilder();
/*  59 */     if (isUseDefault() && other.isUseDefault()) {
/*  60 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  61 */       return builder.isEquals();
/*  62 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  63 */       return builder.isEquals();
/*     */     }
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getDefaultValue() {
/*  71 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  76 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  77 */     if (isUseDefault()) {
/*  78 */       builder.append(getDefaultValue());
/*     */     }
/*  80 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object value) {
/*  85 */     if (value == null) {
/*  86 */       if (isUseDefault()) {
/*  87 */         return this.defaultValue;
/*     */       }
/*  89 */       throw new MorphException("value is null");
/*     */     } 
/*     */ 
/*     */     
/*  93 */     if (value instanceof Boolean) {
/*  94 */       return value;
/*     */     }
/*  96 */     String s = String.valueOf(value);
/*     */     
/*  98 */     if (s.equalsIgnoreCase("true") || s.equalsIgnoreCase("yes") || s.equalsIgnoreCase("on"))
/*     */     {
/* 100 */       return Boolean.TRUE; } 
/* 101 */     if (s.equalsIgnoreCase("false") || s.equalsIgnoreCase("no") || s.equalsIgnoreCase("off"))
/*     */     {
/* 103 */       return Boolean.FALSE; } 
/* 104 */     if (isUseDefault()) {
/* 105 */       return this.defaultValue;
/*     */     }
/*     */ 
/*     */     
/* 109 */     throw new MorphException("Can't morph value: " + value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 114 */     return Boolean.class;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\BooleanObjectMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */