/*     */ package net.sf.ezmorph.object;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import net.sf.ezmorph.primitive.ByteMorpher;
/*     */ import net.sf.ezmorph.primitive.DoubleMorpher;
/*     */ import net.sf.ezmorph.primitive.FloatMorpher;
/*     */ import net.sf.ezmorph.primitive.IntMorpher;
/*     */ import net.sf.ezmorph.primitive.LongMorpher;
/*     */ import net.sf.ezmorph.primitive.ShortMorpher;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberMorpher
/*     */   extends AbstractObjectMorpher
/*     */ {
/*     */   private Number defaultValue;
/*     */   private Class type;
/*     */   
/*     */   public NumberMorpher(Class type) {
/*  47 */     super(false);
/*     */     
/*  49 */     if (type == null) {
/*  50 */       throw new MorphException("Must specify a type");
/*     */     }
/*     */     
/*  53 */     if (type != byte.class && type != short.class && type != int.class && type != long.class && type != float.class && type != double.class && !Byte.class.isAssignableFrom(type) && !Short.class.isAssignableFrom(type) && !Integer.class.isAssignableFrom(type) && !Long.class.isAssignableFrom(type) && !Float.class.isAssignableFrom(type) && !Double.class.isAssignableFrom(type) && !BigInteger.class.isAssignableFrom(type) && !BigDecimal.class.isAssignableFrom(type))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  59 */       throw new MorphException("Must specify a Number subclass");
/*     */     }
/*     */     
/*  62 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public NumberMorpher(Class type, Number defaultValue) {
/*  67 */     super(true);
/*     */     
/*  69 */     if (type == null) {
/*  70 */       throw new MorphException("Must specify a type");
/*     */     }
/*     */     
/*  73 */     if (type != byte.class && type != short.class && type != int.class && type != long.class && type != float.class && type != double.class && !Byte.class.isAssignableFrom(type) && !Short.class.isAssignableFrom(type) && !Integer.class.isAssignableFrom(type) && !Long.class.isAssignableFrom(type) && !Float.class.isAssignableFrom(type) && !Double.class.isAssignableFrom(type) && !BigInteger.class.isAssignableFrom(type) && !BigDecimal.class.isAssignableFrom(type))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       throw new MorphException("Must specify a Number subclass");
/*     */     }
/*     */     
/*  82 */     if (defaultValue != null && !type.isInstance(defaultValue)) {
/*  83 */       throw new MorphException("Default value must be of type " + type);
/*     */     }
/*     */     
/*  86 */     this.type = type;
/*  87 */     setDefaultValue(defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  92 */     if (this == obj) {
/*  93 */       return true;
/*     */     }
/*  95 */     if (obj == null) {
/*  96 */       return false;
/*     */     }
/*     */     
/*  99 */     if (!(obj instanceof NumberMorpher)) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     NumberMorpher other = (NumberMorpher)obj;
/* 104 */     EqualsBuilder builder = new EqualsBuilder();
/* 105 */     builder.append(this.type, other.type);
/* 106 */     if (isUseDefault() && other.isUseDefault()) {
/* 107 */       builder.append(getDefaultValue(), other.getDefaultValue());
/* 108 */       return builder.isEquals();
/* 109 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/* 110 */       return builder.isEquals();
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getDefaultValue() {
/* 118 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     HashCodeBuilder builder = new HashCodeBuilder();
/* 124 */     builder.append(this.type);
/* 125 */     if (isUseDefault()) {
/* 126 */       builder.append(getDefaultValue());
/*     */     }
/* 128 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object value) {
/* 133 */     if (value != null && this.type.isAssignableFrom(value.getClass()))
/*     */     {
/* 135 */       return value;
/*     */     }
/*     */     
/* 138 */     String str = String.valueOf(value).trim();
/*     */ 
/*     */     
/* 141 */     if (!this.type.isPrimitive() && (value == null || str.length() == 0 || "null".equalsIgnoreCase(str)))
/*     */     {
/*     */       
/* 144 */       return null;
/*     */     }
/*     */     
/* 147 */     if (isDecimalNumber(this.type)) {
/* 148 */       if (Float.class.isAssignableFrom(this.type) || float.class == this.type)
/* 149 */         return morphToFloat(str); 
/* 150 */       if (Double.class.isAssignableFrom(this.type) || double.class == this.type) {
/* 151 */         return morphToDouble(str);
/*     */       }
/* 153 */       return morphToBigDecimal(str);
/*     */     } 
/*     */     
/* 156 */     if (Byte.class.isAssignableFrom(this.type) || byte.class == this.type)
/* 157 */       return morphToByte(str); 
/* 158 */     if (Short.class.isAssignableFrom(this.type) || short.class == this.type)
/* 159 */       return morphToShort(str); 
/* 160 */     if (Integer.class.isAssignableFrom(this.type) || int.class == this.type)
/* 161 */       return morphToInteger(str); 
/* 162 */     if (Long.class.isAssignableFrom(this.type) || long.class == this.type) {
/* 163 */       return morphToLong(str);
/*     */     }
/* 165 */     return morphToBigInteger(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 172 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefaultValue(Number defaultValue) {
/* 177 */     if (defaultValue != null && !this.type.isInstance(defaultValue)) {
/* 178 */       throw new MorphException("Default value must be of type " + this.type);
/*     */     }
/* 180 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isDecimalNumber(Class type) {
/* 185 */     return (Double.class.isAssignableFrom(type) || Float.class.isAssignableFrom(type) || double.class == type || float.class == type || BigDecimal.class.isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object morphToBigDecimal(String str) {
/* 191 */     Object result = null;
/* 192 */     if (isUseDefault()) {
/* 193 */       result = (new BigDecimalMorpher((BigDecimal)this.defaultValue)).morph(str);
/*     */     } else {
/* 195 */       result = new BigDecimal(str);
/*     */     } 
/* 197 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object morphToBigInteger(String str) {
/* 202 */     Object result = null;
/* 203 */     if (isUseDefault()) {
/* 204 */       result = (new BigIntegerMorpher((BigInteger)this.defaultValue)).morph(str);
/*     */     } else {
/* 206 */       result = new BigInteger(str);
/*     */     } 
/* 208 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object morphToByte(String str) {
/* 213 */     Object result = null;
/* 214 */     if (isUseDefault()) {
/* 215 */       if (this.defaultValue == null) {
/* 216 */         return null;
/*     */       }
/* 218 */       result = new Byte((new ByteMorpher(this.defaultValue.byteValue())).morph(str));
/*     */     } else {
/*     */       
/* 221 */       result = new Byte((new ByteMorpher()).morph(str));
/*     */     } 
/* 223 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object morphToDouble(String str) {
/* 228 */     Object result = null;
/* 229 */     if (isUseDefault()) {
/* 230 */       if (this.defaultValue == null) {
/* 231 */         return null;
/*     */       }
/* 233 */       result = new Double((new DoubleMorpher(this.defaultValue.doubleValue())).morph(str));
/*     */     } else {
/*     */       
/* 236 */       result = new Double((new DoubleMorpher()).morph(str));
/*     */     } 
/* 238 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object morphToFloat(String str) {
/* 243 */     Object result = null;
/* 244 */     if (isUseDefault()) {
/* 245 */       if (this.defaultValue == null) {
/* 246 */         return null;
/*     */       }
/* 248 */       result = new Float((new FloatMorpher(this.defaultValue.floatValue())).morph(str));
/*     */     } else {
/*     */       
/* 251 */       result = new Float((new FloatMorpher()).morph(str));
/*     */     } 
/* 253 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object morphToInteger(String str) {
/* 258 */     Object result = null;
/* 259 */     if (isUseDefault()) {
/* 260 */       if (this.defaultValue == null) {
/* 261 */         return null;
/*     */       }
/* 263 */       result = new Integer((new IntMorpher(this.defaultValue.intValue())).morph(str));
/*     */     } else {
/*     */       
/* 266 */       result = new Integer((new IntMorpher()).morph(str));
/*     */     } 
/* 268 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object morphToLong(String str) {
/* 273 */     Object result = null;
/* 274 */     if (isUseDefault()) {
/* 275 */       if (this.defaultValue == null) {
/* 276 */         return null;
/*     */       }
/* 278 */       result = new Long((new LongMorpher(this.defaultValue.longValue())).morph(str));
/*     */     } else {
/*     */       
/* 281 */       result = new Long((new LongMorpher()).morph(str));
/*     */     } 
/* 283 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object morphToShort(String str) {
/* 288 */     Object result = null;
/* 289 */     if (isUseDefault()) {
/* 290 */       if (this.defaultValue == null) {
/* 291 */         return null;
/*     */       }
/* 293 */       result = new Short((new ShortMorpher(this.defaultValue.shortValue())).morph(str));
/*     */     } else {
/*     */       
/* 296 */       result = new Short((new ShortMorpher()).morph(str));
/*     */     } 
/* 298 */     return result;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\NumberMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */