/*     */ package net.sf.ezmorph.object;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DateMorpher
/*     */   extends AbstractObjectMorpher
/*     */ {
/*     */   private Date defaultValue;
/*     */   private String[] formats;
/*     */   private boolean lenient;
/*     */   private Locale locale;
/*     */   
/*     */   public DateMorpher(String[] formats) {
/*  47 */     this(formats, Locale.getDefault(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public DateMorpher(String[] formats, boolean lenient) {
/*  52 */     this(formats, Locale.getDefault(), lenient);
/*     */   }
/*     */ 
/*     */   
/*     */   public DateMorpher(String[] formats, Date defaultValue) {
/*  57 */     this(formats, defaultValue, Locale.getDefault(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public DateMorpher(String[] formats, Date defaultValue, Locale locale, boolean lenient) {
/*  62 */     super(true);
/*  63 */     if (formats == null || formats.length == 0) {
/*  64 */       throw new MorphException("invalid array of formats");
/*     */     }
/*     */     
/*  67 */     this.formats = formats;
/*     */     
/*  69 */     if (locale == null) {
/*  70 */       this.locale = Locale.getDefault();
/*     */     } else {
/*  72 */       this.locale = locale;
/*     */     } 
/*     */     
/*  75 */     this.lenient = lenient;
/*  76 */     setDefaultValue(defaultValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public DateMorpher(String[] formats, Locale locale) {
/*  81 */     this(formats, locale, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public DateMorpher(String[] formats, Locale locale, boolean lenient) {
/*  86 */     if (formats == null || formats.length == 0) {
/*  87 */       throw new MorphException("invalid array of formats");
/*     */     }
/*     */     
/*  90 */     this.formats = formats;
/*     */     
/*  92 */     if (locale == null) {
/*  93 */       this.locale = Locale.getDefault();
/*     */     } else {
/*  95 */       this.locale = locale;
/*     */     } 
/*     */     
/*  98 */     this.lenient = lenient;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 103 */     if (this == obj) {
/* 104 */       return true;
/*     */     }
/* 106 */     if (obj == null) {
/* 107 */       return false;
/*     */     }
/*     */     
/* 110 */     if (!(obj instanceof DateMorpher)) {
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     DateMorpher other = (DateMorpher)obj;
/* 115 */     EqualsBuilder builder = new EqualsBuilder();
/* 116 */     builder.append((Object[])this.formats, (Object[])other.formats);
/* 117 */     builder.append(this.locale, other.locale);
/* 118 */     builder.append(this.lenient, other.lenient);
/* 119 */     if (isUseDefault() && other.isUseDefault()) {
/* 120 */       builder.append(getDefaultValue(), other.getDefaultValue());
/* 121 */       return builder.isEquals();
/* 122 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/* 123 */       return builder.isEquals();
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDefaultValue() {
/* 131 */     return (Date)this.defaultValue.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 136 */     HashCodeBuilder builder = new HashCodeBuilder();
/* 137 */     builder.append((Object[])this.formats);
/* 138 */     builder.append(this.locale);
/* 139 */     builder.append(this.lenient);
/* 140 */     if (isUseDefault()) {
/* 141 */       builder.append(getDefaultValue());
/*     */     }
/* 143 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object value) {
/* 148 */     if (value == null) {
/* 149 */       return null;
/*     */     }
/*     */     
/* 152 */     if (Date.class.isAssignableFrom(value.getClass())) {
/* 153 */       return value;
/*     */     }
/*     */     
/* 156 */     if (!supports(value.getClass())) {
/* 157 */       throw new MorphException(value.getClass() + " is not supported");
/*     */     }
/*     */     
/* 160 */     String strValue = (String)value;
/* 161 */     SimpleDateFormat dateParser = null;
/*     */     
/* 163 */     for (int i = 0; i < this.formats.length; i++) {
/* 164 */       if (dateParser == null) {
/* 165 */         dateParser = new SimpleDateFormat(this.formats[i], this.locale);
/*     */       } else {
/* 167 */         dateParser.applyPattern(this.formats[i]);
/*     */       } 
/* 169 */       dateParser.setLenient(this.lenient);
/*     */       try {
/* 171 */         return dateParser.parse(strValue.toLowerCase());
/*     */       }
/* 173 */       catch (ParseException pe) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     if (isUseDefault()) {
/* 180 */       return this.defaultValue;
/*     */     }
/* 182 */     throw new MorphException("Unable to parse the date " + value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 188 */     return Date.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefaultValue(Date defaultValue) {
/* 193 */     this.defaultValue = (Date)defaultValue.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(Class clazz) {
/* 198 */     return String.class.isAssignableFrom(clazz);
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\DateMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */