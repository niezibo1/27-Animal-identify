/*     */ package net.sf.ezmorph.object;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BigDecimalMorpher
/*     */   extends AbstractObjectMorpher
/*     */ {
/*     */   private BigDecimal defaultValue;
/*     */   
/*     */   public BigDecimalMorpher() {}
/*     */   
/*     */   public BigDecimalMorpher(BigDecimal defaultValue) {
/*  43 */     super(true);
/*  44 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  49 */     if (this == obj) {
/*  50 */       return true;
/*     */     }
/*  52 */     if (obj == null) {
/*  53 */       return false;
/*     */     }
/*     */     
/*  56 */     if (!(obj instanceof BigDecimalMorpher)) {
/*  57 */       return false;
/*     */     }
/*     */     
/*  60 */     BigDecimalMorpher other = (BigDecimalMorpher)obj;
/*  61 */     EqualsBuilder builder = new EqualsBuilder();
/*  62 */     if (isUseDefault() && other.isUseDefault()) {
/*  63 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  64 */       return builder.isEquals();
/*  65 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  66 */       return builder.isEquals();
/*     */     }
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BigDecimal getDefaultValue() {
/*  74 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  80 */     if (isUseDefault()) {
/*  81 */       builder.append(getDefaultValue());
/*     */     }
/*  83 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object value) {
/*  88 */     if (value instanceof BigDecimal) {
/*  89 */       return value;
/*     */     }
/*     */     
/*  92 */     if (value == null) {
/*  93 */       if (isUseDefault()) {
/*  94 */         return this.defaultValue;
/*     */       }
/*  96 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 100 */     if (value instanceof Number) {
/* 101 */       if (value instanceof Float) {
/* 102 */         Float f = (Float)value;
/* 103 */         if (f.isInfinite() || f.isNaN()) {
/* 104 */           throw new MorphException("BigDecimal can not be infinite or NaN");
/*     */         }
/* 106 */       } else if (value instanceof Double) {
/* 107 */         Double d = (Double)value;
/* 108 */         if (d.isInfinite() || d.isNaN()) {
/* 109 */           throw new MorphException("BigDecimal can not be infinite or NaN");
/*     */         }
/* 111 */       } else if (value instanceof BigInteger) {
/* 112 */         return new BigDecimal((BigInteger)value);
/*     */       } 
/*     */       
/* 115 */       return new BigDecimal(((Number)value).doubleValue());
/*     */     } 
/*     */     try {
/* 118 */       String str = String.valueOf(value).trim();
/*     */       
/* 120 */       if (str.length() == 0 || str.equalsIgnoreCase("null")) {
/* 121 */         return null;
/*     */       }
/* 123 */       return new BigDecimal(str);
/*     */     
/*     */     }
/* 126 */     catch (NumberFormatException nfe) {
/* 127 */       if (isUseDefault()) {
/* 128 */         return this.defaultValue;
/*     */       }
/* 130 */       throw new MorphException(nfe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 138 */     return BigDecimal.class;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\BigDecimalMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */