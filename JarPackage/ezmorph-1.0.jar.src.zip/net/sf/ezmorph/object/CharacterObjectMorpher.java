/*     */ package net.sf.ezmorph.object;
/*     */ 
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharacterObjectMorpher
/*     */   extends AbstractObjectMorpher
/*     */ {
/*     */   private Character defaultValue;
/*     */   
/*     */   public CharacterObjectMorpher() {}
/*     */   
/*     */   public CharacterObjectMorpher(Character defaultValue) {
/*  40 */     super(true);
/*  41 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  46 */     if (this == obj) {
/*  47 */       return true;
/*     */     }
/*  49 */     if (obj == null) {
/*  50 */       return false;
/*     */     }
/*     */     
/*  53 */     if (!(obj instanceof CharacterObjectMorpher)) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     CharacterObjectMorpher other = (CharacterObjectMorpher)obj;
/*  58 */     EqualsBuilder builder = new EqualsBuilder();
/*  59 */     if (isUseDefault() && other.isUseDefault()) {
/*  60 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  61 */       return builder.isEquals();
/*  62 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  63 */       return builder.isEquals();
/*     */     }
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Character getDefaultValue() {
/*  71 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  76 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  77 */     if (isUseDefault()) {
/*  78 */       builder.append(getDefaultValue());
/*     */     }
/*  80 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object value) {
/*  85 */     if (value == null) {
/*  86 */       if (isUseDefault()) {
/*  87 */         return this.defaultValue;
/*     */       }
/*  89 */       throw new MorphException("value is null");
/*     */     } 
/*     */ 
/*     */     
/*  93 */     if (value instanceof Character) {
/*  94 */       return value;
/*     */     }
/*  96 */     String s = String.valueOf(value);
/*  97 */     if (s.length() > 0) {
/*  98 */       return new Character(s.charAt(0));
/*     */     }
/* 100 */     if (isUseDefault()) {
/* 101 */       return this.defaultValue;
/*     */     }
/* 103 */     throw new MorphException("Can't morph value: " + value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 111 */     return Character.class;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\CharacterObjectMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */