/*     */ package net.sf.ezmorph.object;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Locale;
/*     */ import net.sf.ezmorph.MorphException;
/*     */ import org.apache.commons.lang.builder.EqualsBuilder;
/*     */ import org.apache.commons.lang.builder.HashCodeBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BigIntegerMorpher
/*     */   extends AbstractObjectMorpher
/*     */ {
/*     */   private BigInteger defaultValue;
/*     */   
/*     */   public BigIntegerMorpher() {}
/*     */   
/*     */   public BigIntegerMorpher(BigInteger defaultValue) {
/*  44 */     super(true);
/*  45 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  50 */     if (this == obj) {
/*  51 */       return true;
/*     */     }
/*  53 */     if (obj == null) {
/*  54 */       return false;
/*     */     }
/*     */     
/*  57 */     if (!(obj instanceof BigIntegerMorpher)) {
/*  58 */       return false;
/*     */     }
/*     */     
/*  61 */     BigIntegerMorpher other = (BigIntegerMorpher)obj;
/*  62 */     EqualsBuilder builder = new EqualsBuilder();
/*  63 */     if (isUseDefault() && other.isUseDefault()) {
/*  64 */       builder.append(getDefaultValue(), other.getDefaultValue());
/*  65 */       return builder.isEquals();
/*  66 */     }  if (!isUseDefault() && !other.isUseDefault()) {
/*  67 */       return builder.isEquals();
/*     */     }
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BigInteger getDefaultValue() {
/*  75 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  80 */     HashCodeBuilder builder = new HashCodeBuilder();
/*  81 */     if (isUseDefault()) {
/*  82 */       builder.append(getDefaultValue());
/*     */     }
/*  84 */     return builder.toHashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object morph(Object value) {
/*  89 */     if (value instanceof BigInteger) {
/*  90 */       return value;
/*     */     }
/*     */     
/*  93 */     if (value == null) {
/*  94 */       if (isUseDefault()) {
/*  95 */         return this.defaultValue;
/*     */       }
/*  97 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 101 */     if (value instanceof Number) {
/* 102 */       if (value instanceof Float) {
/* 103 */         Float f = (Float)value;
/* 104 */         if (f.isInfinite() || f.isNaN()) {
/* 105 */           throw new MorphException("BigInteger can not be infinite or NaN");
/*     */         }
/* 107 */       } else if (value instanceof Double) {
/* 108 */         Double d = (Double)value;
/* 109 */         if (d.isInfinite() || d.isNaN()) {
/* 110 */           throw new MorphException("BigInteger can not be infinite or NaN");
/*     */         }
/* 112 */       } else if (value instanceof BigDecimal) {
/* 113 */         return ((BigDecimal)value).toBigInteger();
/*     */       } 
/* 115 */       return BigInteger.valueOf(((Number)value).longValue());
/*     */     } 
/*     */     try {
/* 118 */       String str = getIntegerValue(value);
/* 119 */       if (str.length() == 0 || str.equalsIgnoreCase("null")) {
/* 120 */         return null;
/*     */       }
/* 122 */       return new BigInteger(str);
/*     */     
/*     */     }
/* 125 */     catch (NumberFormatException nfe) {
/* 126 */       if (isUseDefault()) {
/* 127 */         return this.defaultValue;
/*     */       }
/* 129 */       throw new MorphException(nfe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class morphsTo() {
/* 137 */     return BigInteger.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getIntegerValue(Object obj) {
/* 146 */     Locale defaultLocale = Locale.getDefault();
/* 147 */     String str = null;
/*     */     try {
/* 149 */       Locale.setDefault(Locale.US);
/* 150 */       str = String.valueOf(obj).trim();
/*     */     }
/*     */     finally {
/*     */       
/* 154 */       Locale.setDefault(defaultLocale);
/*     */     } 
/*     */     
/* 157 */     int index = str.indexOf(".");
/* 158 */     if (index != -1) {
/* 159 */       str = str.substring(0, index);
/*     */     }
/* 161 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\BigIntegerMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */