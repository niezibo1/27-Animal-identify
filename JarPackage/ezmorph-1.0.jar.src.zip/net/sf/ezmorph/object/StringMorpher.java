/*    */ package net.sf.ezmorph.object;
/*    */ 
/*    */ import net.sf.ezmorph.MorphException;
/*    */ import net.sf.ezmorph.ObjectMorpher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StringMorpher
/*    */   implements ObjectMorpher
/*    */ {
/* 29 */   private static final StringMorpher INSTANCE = new StringMorpher();
/*    */ 
/*    */   
/*    */   public static StringMorpher getInstance() {
/* 33 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 42 */     return (INSTANCE == obj);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 47 */     return 42 + getClass().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object morph(Object value) {
/* 52 */     if (value == null) {
/* 53 */       return null;
/*    */     }
/*    */     
/* 56 */     if (!supports(value.getClass())) {
/* 57 */       throw new MorphException("Class not supported. " + value.getClass());
/*    */     }
/*    */     
/* 60 */     if (String.class.isAssignableFrom(value.getClass())) {
/* 61 */       return value;
/*    */     }
/*    */     
/* 64 */     return String.valueOf(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class morphsTo() {
/* 69 */     return String.class;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supports(Class clazz) {
/* 81 */     return !clazz.isArray();
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\StringMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */