/*    */ package net.sf.ezmorph.object;
/*    */ 
/*    */ import net.sf.ezmorph.MorphException;
/*    */ import net.sf.ezmorph.ObjectMorpher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClassMorpher
/*    */   implements ObjectMorpher
/*    */ {
/* 29 */   private static final ClassMorpher INSTANCE = new ClassMorpher();
/*    */ 
/*    */   
/*    */   public static ClassMorpher getInstance() {
/* 33 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 42 */     return (INSTANCE == obj);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 47 */     return 42 + getClass().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object morph(Object value) {
/* 52 */     if (value == null) {
/* 53 */       return null;
/*    */     }
/*    */     
/* 56 */     if (value instanceof Class) {
/* 57 */       return value;
/*    */     }
/*    */     
/* 60 */     if ("null".equals(value)) {
/* 61 */       return null;
/*    */     }
/*    */     
/*    */     try {
/* 65 */       return Class.forName(value.toString());
/*    */     }
/* 67 */     catch (Exception e) {
/* 68 */       throw new MorphException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Class morphsTo() {
/* 74 */     return Class.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class clazz) {
/* 79 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\ClassMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */