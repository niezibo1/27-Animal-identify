/*    */ package net.sf.ezmorph.object;
/*    */ 
/*    */ import net.sf.ezmorph.ObjectMorpher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IdentityObjectMorpher
/*    */   implements ObjectMorpher
/*    */ {
/* 28 */   private static final IdentityObjectMorpher INSTANCE = new IdentityObjectMorpher();
/*    */ 
/*    */   
/*    */   public static IdentityObjectMorpher getInstance() {
/* 32 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 41 */     return (INSTANCE == obj);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 46 */     return 42 + getClass().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object morph(Object value) {
/* 51 */     return value;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class morphsTo() {
/* 56 */     return Object.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class clazz) {
/* 61 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\object\IdentityObjectMorpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */