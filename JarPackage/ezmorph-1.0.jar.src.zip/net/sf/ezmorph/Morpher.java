package net.sf.ezmorph;

public interface Morpher {
  Class morphsTo();
  
  boolean supports(Class paramClass);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\ezmorph-1.0.jar!\net\sf\ezmorph\Morpher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */