/*     */ package javax.servlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnavailableException
/*     */   extends ServletException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Servlet servlet;
/*     */   private final boolean permanent;
/*     */   private final int seconds;
/*     */   
/*     */   public UnavailableException(Servlet servlet, String msg) {
/*  64 */     super(msg);
/*  65 */     this.servlet = servlet;
/*  66 */     this.permanent = true;
/*  67 */     this.seconds = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnavailableException(int seconds, Servlet servlet, String msg) {
/*  86 */     super(msg);
/*  87 */     this.servlet = servlet;
/*  88 */     if (seconds <= 0) {
/*  89 */       this.seconds = -1;
/*     */     } else {
/*  91 */       this.seconds = seconds;
/*  92 */     }  this.permanent = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnavailableException(String msg) {
/* 103 */     super(msg);
/* 104 */     this.seconds = 0;
/* 105 */     this.servlet = null;
/* 106 */     this.permanent = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnavailableException(String msg, int seconds) {
/* 129 */     super(msg);
/*     */     
/* 131 */     if (seconds <= 0) {
/* 132 */       this.seconds = -1;
/*     */     } else {
/* 134 */       this.seconds = seconds;
/* 135 */     }  this.servlet = null;
/* 136 */     this.permanent = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPermanent() {
/* 149 */     return this.permanent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Servlet getServlet() {
/* 162 */     return this.servlet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUnavailableSeconds() {
/* 179 */     return this.permanent ? -1 : this.seconds;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\UnavailableException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */