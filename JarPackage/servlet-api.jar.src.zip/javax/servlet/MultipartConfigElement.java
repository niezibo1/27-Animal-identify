/*    */ package javax.servlet;
/*    */ 
/*    */ import javax.servlet.annotation.MultipartConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipartConfigElement
/*    */ {
/*    */   private final String location;
/*    */   private final long maxFileSize;
/*    */   private final long maxRequestSize;
/*    */   private final int fileSizeThreshold;
/*    */   
/*    */   public MultipartConfigElement(String location) {
/* 34 */     if (location != null) {
/* 35 */       this.location = location;
/*    */     } else {
/* 37 */       this.location = "";
/*    */     } 
/* 39 */     this.maxFileSize = -1L;
/* 40 */     this.maxRequestSize = -1L;
/* 41 */     this.fileSizeThreshold = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MultipartConfigElement(String location, long maxFileSize, long maxRequestSize, int fileSizeThreshold) {
/* 47 */     if (location != null) {
/* 48 */       this.location = location;
/*    */     } else {
/* 50 */       this.location = "";
/*    */     } 
/* 52 */     this.maxFileSize = maxFileSize;
/* 53 */     this.maxRequestSize = maxRequestSize;
/* 54 */     this.fileSizeThreshold = fileSizeThreshold;
/*    */   }
/*    */   
/*    */   public MultipartConfigElement(MultipartConfig annotation) {
/* 58 */     this.location = annotation.location();
/* 59 */     this.maxFileSize = annotation.maxFileSize();
/* 60 */     this.maxRequestSize = annotation.maxRequestSize();
/* 61 */     this.fileSizeThreshold = annotation.fileSizeThreshold();
/*    */   }
/*    */   
/*    */   public String getLocation() {
/* 65 */     return this.location;
/*    */   }
/*    */   
/*    */   public long getMaxFileSize() {
/* 69 */     return this.maxFileSize;
/*    */   }
/*    */   
/*    */   public long getMaxRequestSize() {
/* 73 */     return this.maxRequestSize;
/*    */   }
/*    */   
/*    */   public int getFileSizeThreshold() {
/* 77 */     return this.fileSizeThreshold;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\MultipartConfigElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */