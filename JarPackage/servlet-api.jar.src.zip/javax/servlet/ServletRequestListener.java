package javax.servlet;

import java.util.EventListener;

public interface ServletRequestListener extends EventListener {
  void requestDestroyed(ServletRequestEvent paramServletRequestEvent);
  
  void requestInitialized(ServletRequestEvent paramServletRequestEvent);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\ServletRequestListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */