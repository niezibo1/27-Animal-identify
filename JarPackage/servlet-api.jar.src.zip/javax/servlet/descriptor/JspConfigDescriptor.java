package javax.servlet.descriptor;

import java.util.Collection;

public interface JspConfigDescriptor {
  Collection<TaglibDescriptor> getTaglibs();
  
  Collection<JspPropertyGroupDescriptor> getJspPropertyGroups();
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\descriptor\JspConfigDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */