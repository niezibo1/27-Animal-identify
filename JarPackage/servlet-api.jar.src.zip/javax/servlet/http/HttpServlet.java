/*     */ package javax.servlet.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.servlet.GenericServlet;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpServlet
/*     */   extends GenericServlet
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String METHOD_DELETE = "DELETE";
/*     */   private static final String METHOD_HEAD = "HEAD";
/*     */   private static final String METHOD_GET = "GET";
/*     */   private static final String METHOD_OPTIONS = "OPTIONS";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private static final String METHOD_PUT = "PUT";
/*     */   private static final String METHOD_TRACE = "TRACE";
/*     */   private static final String HEADER_IFMODSINCE = "If-Modified-Since";
/*     */   private static final String HEADER_LASTMOD = "Last-Modified";
/*     */   private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
/*  93 */   private static ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 172 */     String protocol = req.getProtocol();
/* 173 */     String msg = lStrings.getString("http.method_get_not_supported");
/* 174 */     if (protocol.endsWith("1.1")) {
/* 175 */       resp.sendError(405, msg);
/*     */     } else {
/* 177 */       resp.sendError(400, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getLastModified(HttpServletRequest req) {
/* 204 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 242 */     NoBodyResponse response = new NoBodyResponse(resp);
/*     */     
/* 244 */     doGet(req, response);
/* 245 */     response.setContentLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 309 */     String protocol = req.getProtocol();
/* 310 */     String msg = lStrings.getString("http.method_post_not_supported");
/* 311 */     if (protocol.endsWith("1.1")) {
/* 312 */       resp.sendError(405, msg);
/*     */     } else {
/* 314 */       resp.sendError(400, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 364 */     String protocol = req.getProtocol();
/* 365 */     String msg = lStrings.getString("http.method_put_not_supported");
/* 366 */     if (protocol.endsWith("1.1")) {
/* 367 */       resp.sendError(405, msg);
/*     */     } else {
/* 369 */       resp.sendError(400, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 412 */     String protocol = req.getProtocol();
/* 413 */     String msg = lStrings.getString("http.method_delete_not_supported");
/* 414 */     if (protocol.endsWith("1.1")) {
/* 415 */       resp.sendError(405, msg);
/*     */     } else {
/* 417 */       resp.sendError(400, msg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method[] getAllDeclaredMethods(Class<?> c) {
/* 424 */     if (c.equals(HttpServlet.class)) {
/* 425 */       return null;
/*     */     }
/*     */     
/* 428 */     Method[] parentMethods = getAllDeclaredMethods(c.getSuperclass());
/* 429 */     Method[] thisMethods = c.getDeclaredMethods();
/*     */     
/* 431 */     if (parentMethods != null && parentMethods.length > 0) {
/* 432 */       Method[] allMethods = new Method[parentMethods.length + thisMethods.length];
/*     */       
/* 434 */       System.arraycopy(parentMethods, 0, allMethods, 0, parentMethods.length);
/*     */       
/* 436 */       System.arraycopy(thisMethods, 0, allMethods, parentMethods.length, thisMethods.length);
/*     */ 
/*     */       
/* 439 */       thisMethods = allMethods;
/*     */     } 
/*     */     
/* 442 */     return thisMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 481 */     Method[] methods = getAllDeclaredMethods(getClass());
/*     */     
/* 483 */     boolean ALLOW_GET = false;
/* 484 */     boolean ALLOW_HEAD = false;
/* 485 */     boolean ALLOW_POST = false;
/* 486 */     boolean ALLOW_PUT = false;
/* 487 */     boolean ALLOW_DELETE = false;
/* 488 */     boolean ALLOW_TRACE = true;
/* 489 */     boolean ALLOW_OPTIONS = true;
/*     */     
/* 491 */     for (int i = 0; i < methods.length; i++) {
/* 492 */       Method m = methods[i];
/*     */       
/* 494 */       if (m.getName().equals("doGet")) {
/* 495 */         ALLOW_GET = true;
/* 496 */         ALLOW_HEAD = true;
/*     */       } 
/* 498 */       if (m.getName().equals("doPost"))
/* 499 */         ALLOW_POST = true; 
/* 500 */       if (m.getName().equals("doPut"))
/* 501 */         ALLOW_PUT = true; 
/* 502 */       if (m.getName().equals("doDelete")) {
/* 503 */         ALLOW_DELETE = true;
/*     */       }
/*     */     } 
/* 506 */     String allow = null;
/* 507 */     if (ALLOW_GET)
/* 508 */       allow = "GET"; 
/* 509 */     if (ALLOW_HEAD)
/* 510 */       if (allow == null) { allow = "HEAD"; }
/* 511 */       else { allow = allow + ", HEAD"; }
/* 512 */         if (ALLOW_POST)
/* 513 */       if (allow == null) { allow = "POST"; }
/* 514 */       else { allow = allow + ", POST"; }
/* 515 */         if (ALLOW_PUT)
/* 516 */       if (allow == null) { allow = "PUT"; }
/* 517 */       else { allow = allow + ", PUT"; }
/* 518 */         if (ALLOW_DELETE)
/* 519 */       if (allow == null) { allow = "DELETE"; }
/* 520 */       else { allow = allow + ", DELETE"; }
/* 521 */         if (ALLOW_TRACE)
/* 522 */       if (allow == null) { allow = "TRACE"; }
/* 523 */       else { allow = allow + ", TRACE"; }
/* 524 */         if (ALLOW_OPTIONS)
/* 525 */       if (allow == null) { allow = "OPTIONS"; }
/* 526 */       else { allow = allow + ", OPTIONS"; }
/*     */        
/* 528 */     resp.setHeader("Allow", allow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doTrace(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 561 */     String CRLF = "\r\n";
/* 562 */     StringBuilder buffer = (new StringBuilder("TRACE ")).append(req.getRequestURI()).append(" ").append(req.getProtocol());
/*     */ 
/*     */     
/* 565 */     Enumeration<String> reqHeaderEnum = req.getHeaderNames();
/*     */     
/* 567 */     while (reqHeaderEnum.hasMoreElements()) {
/* 568 */       String headerName = reqHeaderEnum.nextElement();
/* 569 */       buffer.append(CRLF).append(headerName).append(": ").append(req.getHeader(headerName));
/*     */     } 
/*     */ 
/*     */     
/* 573 */     buffer.append(CRLF);
/*     */     
/* 575 */     int responseLength = buffer.length();
/*     */     
/* 577 */     resp.setContentType("message/http");
/* 578 */     resp.setContentLength(responseLength);
/* 579 */     ServletOutputStream out = resp.getOutputStream();
/* 580 */     out.print(buffer.toString());
/* 581 */     out.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
/* 614 */     String method = req.getMethod();
/*     */     
/* 616 */     if (method.equals("GET")) {
/* 617 */       long lastModified = getLastModified(req);
/* 618 */       if (lastModified == -1L) {
/*     */ 
/*     */         
/* 621 */         doGet(req, resp);
/*     */       } else {
/*     */         long l;
/*     */         try {
/* 625 */           l = req.getDateHeader("If-Modified-Since");
/* 626 */         } catch (IllegalArgumentException iae) {
/*     */           
/* 628 */           l = -1L;
/*     */         } 
/* 630 */         if (l < lastModified / 1000L * 1000L) {
/*     */ 
/*     */ 
/*     */           
/* 634 */           maybeSetLastModified(resp, lastModified);
/* 635 */           doGet(req, resp);
/*     */         } else {
/* 637 */           resp.setStatus(304);
/*     */         }
/*     */       
/*     */       } 
/* 641 */     } else if (method.equals("HEAD")) {
/* 642 */       long lastModified = getLastModified(req);
/* 643 */       maybeSetLastModified(resp, lastModified);
/* 644 */       doHead(req, resp);
/*     */     }
/* 646 */     else if (method.equals("POST")) {
/* 647 */       doPost(req, resp);
/*     */     }
/* 649 */     else if (method.equals("PUT")) {
/* 650 */       doPut(req, resp);
/*     */     }
/* 652 */     else if (method.equals("DELETE")) {
/* 653 */       doDelete(req, resp);
/*     */     }
/* 655 */     else if (method.equals("OPTIONS")) {
/* 656 */       doOptions(req, resp);
/*     */     }
/* 658 */     else if (method.equals("TRACE")) {
/* 659 */       doTrace(req, resp);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 667 */       String errMsg = lStrings.getString("http.method_not_implemented");
/* 668 */       Object[] errArgs = new Object[1];
/* 669 */       errArgs[0] = method;
/* 670 */       errMsg = MessageFormat.format(errMsg, errArgs);
/*     */       
/* 672 */       resp.sendError(501, errMsg);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void maybeSetLastModified(HttpServletResponse resp, long lastModified) {
/* 686 */     if (resp.containsHeader("Last-Modified"))
/*     */       return; 
/* 688 */     if (lastModified >= 0L) {
/* 689 */       resp.setDateHeader("Last-Modified", lastModified);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
/*     */     HttpServletRequest request;
/*     */     HttpServletResponse response;
/*     */     try {
/* 723 */       request = (HttpServletRequest)req;
/* 724 */       response = (HttpServletResponse)res;
/* 725 */     } catch (ClassCastException e) {
/* 726 */       throw new ServletException("non-HTTP request or response");
/*     */     } 
/* 728 */     service(request, response);
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\http\HttpServlet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */