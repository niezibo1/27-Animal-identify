package javax.servlet.http;

import java.util.EventListener;

public interface HttpSessionAttributeListener extends EventListener {
  void attributeAdded(HttpSessionBindingEvent paramHttpSessionBindingEvent);
  
  void attributeRemoved(HttpSessionBindingEvent paramHttpSessionBindingEvent);
  
  void attributeReplaced(HttpSessionBindingEvent paramHttpSessionBindingEvent);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\http\HttpSessionAttributeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */