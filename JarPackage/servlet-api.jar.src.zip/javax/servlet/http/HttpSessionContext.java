package javax.servlet.http;

import java.util.Enumeration;

public interface HttpSessionContext {
  HttpSession getSession(String paramString);
  
  Enumeration<String> getIds();
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\http\HttpSessionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */