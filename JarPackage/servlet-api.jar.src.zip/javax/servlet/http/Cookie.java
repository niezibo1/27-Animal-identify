/*     */ package javax.servlet.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cookie
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String LSTRING_FILE = "javax.servlet.http.LocalStrings";
/*  59 */   private static ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.http.LocalStrings");
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */   
/*     */   private String value;
/*     */ 
/*     */   
/*     */   private String comment;
/*     */ 
/*     */   
/*     */   private String domain;
/*     */ 
/*     */   
/*  75 */   private int maxAge = -1;
/*     */   private String path;
/*     */   private boolean secure;
/*  78 */   private int version = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean httpOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String tspecials = ",; ";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String tspecials2NoSlash = "()<>@,;:\\\"[]?={} \t";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String tspecials2WithSlash = "()<>@,;:\\\"[]?={} \t/";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String tspecials2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie(String name, String value) {
/* 109 */     if (name == null || name.length() == 0) {
/* 110 */       throw new IllegalArgumentException(lStrings.getString("err.cookie_name_blank"));
/*     */     }
/*     */     
/* 113 */     if (!isToken(name) || name.equalsIgnoreCase("Comment") || name.equalsIgnoreCase("Discard") || name.equalsIgnoreCase("Domain") || name.equalsIgnoreCase("Expires") || name.equalsIgnoreCase("Max-Age") || name.equalsIgnoreCase("Path") || name.equalsIgnoreCase("Secure") || name.equalsIgnoreCase("Version") || name.startsWith("$")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 125 */       String errMsg = lStrings.getString("err.cookie_name_is_token");
/* 126 */       Object[] errArgs = new Object[1];
/* 127 */       errArgs[0] = name;
/* 128 */       errMsg = MessageFormat.format(errMsg, errArgs);
/* 129 */       throw new IllegalArgumentException(errMsg);
/*     */     } 
/*     */     
/* 132 */     this.name = name;
/* 133 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComment(String purpose) {
/* 147 */     this.comment = purpose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getComment() {
/* 159 */     return this.comment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDomain(String pattern) {
/* 177 */     this.domain = pattern.toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDomain() {
/* 188 */     return this.domain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxAge(int expiry) {
/* 209 */     this.maxAge = expiry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxAge() {
/* 222 */     return this.maxAge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPath(String uri) {
/* 243 */     this.path = uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 255 */     return this.path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecure(boolean flag) {
/* 271 */     this.secure = flag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSecure() {
/* 284 */     return this.secure;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 294 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String newValue) {
/* 312 */     this.value = newValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 323 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVersion() {
/* 337 */     return this.version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVersion(int v) {
/* 354 */     this.version = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 389 */   private static final boolean STRICT_SERVLET_COMPLIANCE = Boolean.valueOf(System.getProperty("org.apache.catalina.STRICT_SERVLET_COMPLIANCE", "false")).booleanValue();
/*     */   private static final boolean FWD_SLASH_IS_SEPARATOR;
/*     */   private static final boolean STRICT_NAMING;
/*     */   
/*     */   static {
/* 394 */     String fwdSlashIsSeparator = System.getProperty("org.apache.tomcat.util.http.ServerCookie.FWD_SLASH_IS_SEPARATOR");
/*     */     
/* 396 */     if (fwdSlashIsSeparator == null) {
/* 397 */       FWD_SLASH_IS_SEPARATOR = STRICT_SERVLET_COMPLIANCE;
/*     */     } else {
/* 399 */       FWD_SLASH_IS_SEPARATOR = Boolean.valueOf(fwdSlashIsSeparator).booleanValue();
/*     */     } 
/*     */ 
/*     */     
/* 403 */     if (FWD_SLASH_IS_SEPARATOR) {
/* 404 */       tspecials2 = "()<>@,;:\\\"[]?={} \t/";
/*     */     } else {
/* 406 */       tspecials2 = "()<>@,;:\\\"[]?={} \t";
/*     */     } 
/*     */     
/* 409 */     String strictNaming = System.getProperty("org.apache.tomcat.util.http.ServerCookie.STRICT_NAMING");
/*     */     
/* 411 */     if (strictNaming == null) {
/* 412 */       STRICT_NAMING = STRICT_SERVLET_COMPLIANCE;
/*     */     } else {
/* 414 */       STRICT_NAMING = Boolean.valueOf(strictNaming).booleanValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isToken(String possibleToken) {
/* 427 */     int len = possibleToken.length();
/*     */     
/* 429 */     for (int i = 0; i < len; i++) {
/* 430 */       char c = possibleToken.charAt(i);
/*     */       
/* 432 */       if (c < ' ' || c >= '' || ",; ".indexOf(c) != -1 || (STRICT_NAMING && tspecials2.indexOf(c) != -1))
/*     */       {
/* 434 */         return false;
/*     */       }
/*     */     } 
/* 437 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 447 */       return super.clone();
/* 448 */     } catch (CloneNotSupportedException e) {
/* 449 */       throw new RuntimeException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHttpOnly(boolean httpOnly) {
/* 462 */     this.httpOnly = httpOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHttpOnly() {
/* 474 */     return this.httpOnly;
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\http\Cookie.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */