/*    */ package javax.servlet.http;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpSessionEvent
/*    */   extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public HttpSessionEvent(HttpSession source) {
/* 30 */     super(source);
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpSession getSession() {
/* 35 */     return (HttpSession)getSource();
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\http\HttpSessionEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */