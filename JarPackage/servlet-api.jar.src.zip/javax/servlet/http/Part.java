package javax.servlet.http;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;

public interface Part {
  InputStream getInputStream() throws IOException;
  
  String getContentType();
  
  String getName();
  
  long getSize();
  
  void write(String paramString) throws IOException;
  
  void delete() throws IOException;
  
  String getHeader(String paramString);
  
  Collection<String> getHeaders(String paramString);
  
  Collection<String> getHeaderNames();
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\http\Part.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */