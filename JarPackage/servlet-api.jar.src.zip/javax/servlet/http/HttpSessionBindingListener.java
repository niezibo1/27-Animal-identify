package javax.servlet.http;

import java.util.EventListener;

public interface HttpSessionBindingListener extends EventListener {
  void valueBound(HttpSessionBindingEvent paramHttpSessionBindingEvent);
  
  void valueUnbound(HttpSessionBindingEvent paramHttpSessionBindingEvent);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\http\HttpSessionBindingListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */