package javax.servlet;

public interface AsyncContext {
  public static final String ASYNC_REQUEST_URI = "javax.servlet.async.request_uri";
  
  public static final String ASYNC_CONTEXT_PATH = "javax.servlet.async.context_path";
  
  public static final String ASYNC_PATH_INFO = "javax.servlet.async.path_info";
  
  public static final String ASYNC_SERVLET_PATH = "javax.servlet.async.servlet_path";
  
  public static final String ASYNC_QUERY_STRING = "javax.servlet.async.query_string";
  
  ServletRequest getRequest();
  
  ServletResponse getResponse();
  
  boolean hasOriginalRequestAndResponse();
  
  void dispatch();
  
  void dispatch(String paramString);
  
  void dispatch(ServletContext paramServletContext, String paramString);
  
  void complete();
  
  void start(Runnable paramRunnable);
  
  void addListener(AsyncListener paramAsyncListener);
  
  void addListener(AsyncListener paramAsyncListener, ServletRequest paramServletRequest, ServletResponse paramServletResponse);
  
  <T extends AsyncListener> T createListener(Class<T> paramClass) throws ServletException;
  
  long getTimeout();
  
  void setTimeout(long paramLong);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\AsyncContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */