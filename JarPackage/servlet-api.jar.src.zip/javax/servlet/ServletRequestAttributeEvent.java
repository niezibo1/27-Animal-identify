/*    */ package javax.servlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletRequestAttributeEvent
/*    */   extends ServletRequestEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final String name;
/*    */   private final Object value;
/*    */   
/*    */   public ServletRequestAttributeEvent(ServletContext sc, ServletRequest request, String name, Object value) {
/* 48 */     super(sc, request);
/* 49 */     this.name = name;
/* 50 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 59 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 71 */     return this.value;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\ServletRequestAttributeEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */