/*    */ package javax.servlet;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ import javax.servlet.annotation.ServletSecurity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpConstraintElement
/*    */ {
/*    */   private static final String LSTRING_FILE = "javax.servlet.LocalStrings";
/* 31 */   private static final ResourceBundle lStrings = ResourceBundle.getBundle("javax.servlet.LocalStrings");
/*    */ 
/*    */   
/*    */   private final ServletSecurity.EmptyRoleSemantic emptyRoleSemantic;
/*    */ 
/*    */   
/*    */   private final ServletSecurity.TransportGuarantee transportGuarantee;
/*    */   
/*    */   private final String[] rolesAllowed;
/*    */ 
/*    */   
/*    */   public HttpConstraintElement() {
/* 43 */     this.emptyRoleSemantic = ServletSecurity.EmptyRoleSemantic.PERMIT;
/* 44 */     this.transportGuarantee = ServletSecurity.TransportGuarantee.NONE;
/* 45 */     this.rolesAllowed = new String[0];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpConstraintElement(ServletSecurity.EmptyRoleSemantic emptyRoleSemantic) {
/* 53 */     this.emptyRoleSemantic = emptyRoleSemantic;
/* 54 */     this.transportGuarantee = ServletSecurity.TransportGuarantee.NONE;
/* 55 */     this.rolesAllowed = new String[0];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpConstraintElement(ServletSecurity.TransportGuarantee transportGuarantee, String... rolesAllowed) {
/* 63 */     this.emptyRoleSemantic = ServletSecurity.EmptyRoleSemantic.PERMIT;
/* 64 */     this.transportGuarantee = transportGuarantee;
/* 65 */     this.rolesAllowed = rolesAllowed;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HttpConstraintElement(ServletSecurity.EmptyRoleSemantic emptyRoleSemantic, ServletSecurity.TransportGuarantee transportGuarantee, String... rolesAllowed) {
/* 77 */     if (rolesAllowed != null && rolesAllowed.length > 0 && ServletSecurity.EmptyRoleSemantic.DENY.equals(emptyRoleSemantic))
/*    */     {
/* 79 */       throw new IllegalArgumentException(lStrings.getString("httpConstraintElement.invalidRolesDeny"));
/*    */     }
/*    */     
/* 82 */     this.emptyRoleSemantic = emptyRoleSemantic;
/* 83 */     this.transportGuarantee = transportGuarantee;
/* 84 */     this.rolesAllowed = rolesAllowed;
/*    */   }
/*    */   
/*    */   public ServletSecurity.EmptyRoleSemantic getEmptyRoleSemantic() {
/* 88 */     return this.emptyRoleSemantic;
/*    */   }
/*    */   
/*    */   public ServletSecurity.TransportGuarantee getTransportGuarantee() {
/* 92 */     return this.transportGuarantee;
/*    */   }
/*    */   
/*    */   public String[] getRolesAllowed() {
/* 96 */     return this.rolesAllowed;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\HttpConstraintElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */