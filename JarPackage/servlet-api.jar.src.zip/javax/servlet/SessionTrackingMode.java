/*    */ package javax.servlet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SessionTrackingMode
/*    */ {
/* 24 */   COOKIE,
/* 25 */   URL,
/* 26 */   SSL;
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\SessionTrackingMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */