/*     */ package javax.servlet;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.annotation.HttpMethodConstraint;
/*     */ import javax.servlet.annotation.ServletSecurity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletSecurityElement
/*     */   extends HttpConstraintElement
/*     */ {
/*  36 */   private final Map<String, HttpMethodConstraintElement> methodConstraints = new HashMap<String, HttpMethodConstraintElement>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(Collection<HttpMethodConstraintElement> httpMethodConstraints) {
/*  57 */     addHttpMethodConstraints(httpMethodConstraints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(HttpConstraintElement httpConstraintElement) {
/*  65 */     this(httpConstraintElement, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(HttpConstraintElement httpConstraintElement, Collection<HttpMethodConstraintElement> httpMethodConstraints) {
/*  77 */     super(httpConstraintElement.getEmptyRoleSemantic(), httpConstraintElement.getTransportGuarantee(), httpConstraintElement.getRolesAllowed());
/*     */ 
/*     */     
/*  80 */     addHttpMethodConstraints(httpMethodConstraints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServletSecurityElement(ServletSecurity annotation) {
/*  89 */     this(new HttpConstraintElement(annotation.value().value(), annotation.value().transportGuarantee(), annotation.value().rolesAllowed()));
/*     */ 
/*     */ 
/*     */     
/*  93 */     List<HttpMethodConstraintElement> l = new ArrayList<HttpMethodConstraintElement>();
/*     */     
/*  95 */     HttpMethodConstraint[] constraints = annotation.httpMethodConstraints();
/*  96 */     if (constraints != null) {
/*  97 */       for (int i = 0; i < constraints.length; i++) {
/*  98 */         HttpMethodConstraintElement e = new HttpMethodConstraintElement(constraints[i].value(), new HttpConstraintElement(constraints[i].emptyRoleSemantic(), constraints[i].transportGuarantee(), constraints[i].rolesAllowed()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 104 */         l.add(e);
/*     */       } 
/*     */     }
/* 107 */     addHttpMethodConstraints(l);
/*     */   }
/*     */   
/*     */   public Collection<HttpMethodConstraintElement> getHttpMethodConstraints() {
/* 111 */     Collection<HttpMethodConstraintElement> result = new HashSet<HttpMethodConstraintElement>();
/*     */     
/* 113 */     result.addAll(this.methodConstraints.values());
/* 114 */     return result;
/*     */   }
/*     */   
/*     */   public Collection<String> getMethodNames() {
/* 118 */     Collection<String> result = new HashSet<String>();
/* 119 */     result.addAll(this.methodConstraints.keySet());
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private void addHttpMethodConstraints(Collection<HttpMethodConstraintElement> httpMethodConstraints) {
/* 125 */     if (httpMethodConstraints == null) {
/*     */       return;
/*     */     }
/* 128 */     for (HttpMethodConstraintElement constraint : httpMethodConstraints) {
/* 129 */       String method = constraint.getMethodName();
/* 130 */       if (this.methodConstraints.containsKey(method)) {
/* 131 */         throw new IllegalArgumentException("Duplicate method name: " + method);
/*     */       }
/*     */       
/* 134 */       this.methodConstraints.put(method, constraint);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\ServletSecurityElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */