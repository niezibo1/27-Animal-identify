/*    */ package javax.servlet.annotation;
/*    */ 
/*    */ import java.lang.annotation.Documented;
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.Inherited;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Inherited
/*    */ @Target({ElementType.TYPE})
/*    */ @Retention(RetentionPolicy.RUNTIME)
/*    */ @Documented
/*    */ public @interface ServletSecurity
/*    */ {
/*    */   HttpConstraint value() default @HttpConstraint;
/*    */   
/*    */   HttpMethodConstraint[] httpMethodConstraints() default {};
/*    */   
/*    */   public enum EmptyRoleSemantic
/*    */   {
/* 51 */     PERMIT,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     DENY;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum TransportGuarantee
/*    */   {
/* 67 */     NONE,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 72 */     CONFIDENTIAL;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\annotation\ServletSecurity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */