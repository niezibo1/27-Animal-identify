package javax.servlet;

import java.io.IOException;

public interface FilterChain {
  void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws IOException, ServletException;
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\FilterChain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */