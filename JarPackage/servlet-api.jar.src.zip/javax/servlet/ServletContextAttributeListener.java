package javax.servlet;

import java.util.EventListener;

public interface ServletContextAttributeListener extends EventListener {
  void attributeAdded(ServletContextAttributeEvent paramServletContextAttributeEvent);
  
  void attributeRemoved(ServletContextAttributeEvent paramServletContextAttributeEvent);
  
  void attributeReplaced(ServletContextAttributeEvent paramServletContextAttributeEvent);
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\ServletContextAttributeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */