/*    */ package javax.servlet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServletInputStream
/*    */   extends InputStream
/*    */ {
/*    */   public int readLine(byte[] b, int off, int len) throws IOException {
/* 70 */     if (len <= 0) {
/* 71 */       return 0;
/*    */     }
/* 73 */     int count = 0;
/*    */     int c;
/* 75 */     while ((c = read()) != -1) {
/* 76 */       b[off++] = (byte)c;
/* 77 */       count++;
/* 78 */       if (c == 10 || count == len) {
/*    */         break;
/*    */       }
/*    */     } 
/* 82 */     return (count > 0) ? count : -1;
/*    */   }
/*    */ }


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\ServletInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */