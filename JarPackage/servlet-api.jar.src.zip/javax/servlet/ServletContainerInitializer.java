package javax.servlet;

import java.util.Set;

public interface ServletContainerInitializer {
  void onStartup(Set<Class<?>> paramSet, ServletContext paramServletContext) throws ServletException;
}


/* Location:              D:\Eclipse\eclipse-workspace\GithubProgram\lib\servlet-api.jar!\javax\servlet\ServletContainerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */