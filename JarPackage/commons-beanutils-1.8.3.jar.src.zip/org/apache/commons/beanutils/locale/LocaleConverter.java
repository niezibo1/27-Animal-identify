package org.apache.commons.beanutils.locale;

import org.apache.commons.beanutils.Converter;

public interface LocaleConverter extends Converter {
  Object convert(Class paramClass, Object paramObject, String paramString);
}


/* Location:              D:\JarPackage\commons-beanutils-1.8.3.jar!\org\apache\commons\beanutils\locale\LocaleConverter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */