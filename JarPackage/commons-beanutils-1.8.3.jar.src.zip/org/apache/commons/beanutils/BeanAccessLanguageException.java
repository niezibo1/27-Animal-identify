/*    */ package org.apache.commons.beanutils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanAccessLanguageException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   public BeanAccessLanguageException() {}
/*    */   
/*    */   public BeanAccessLanguageException(String message) {
/* 46 */     super(message);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\commons-beanutils-1.8.3.jar!\org\apache\commons\beanutils\BeanAccessLanguageException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */