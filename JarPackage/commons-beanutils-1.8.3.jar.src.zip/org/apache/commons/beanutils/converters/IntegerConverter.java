/*    */ package org.apache.commons.beanutils.converters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IntegerConverter
/*    */   extends NumberConverter
/*    */ {
/*    */   public IntegerConverter() {
/* 42 */     super(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IntegerConverter(Object defaultValue) {
/* 54 */     super(false, defaultValue);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Class getDefaultType() {
/* 64 */     return Integer.class;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\commons-beanutils-1.8.3.jar!\org\apache\commons\beanutils\converters\IntegerConverter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */