/*    */ package org.apache.commons.beanutils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NestedNullException
/*    */   extends BeanAccessLanguageException
/*    */ {
/*    */   public NestedNullException() {}
/*    */   
/*    */   public NestedNullException(String message) {
/* 45 */     super(message);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\commons-beanutils-1.8.3.jar!\org\apache\commons\beanutils\NestedNullException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */