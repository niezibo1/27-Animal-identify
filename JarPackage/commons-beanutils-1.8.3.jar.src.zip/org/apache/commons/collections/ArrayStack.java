/*     */ package org.apache.commons.collections;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.EmptyStackException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayStack
/*     */   extends ArrayList
/*     */   implements Buffer
/*     */ {
/*     */   private static final long serialVersionUID = 2130079159931574599L;
/*     */   
/*     */   public ArrayStack() {}
/*     */   
/*     */   public ArrayStack(int initialSize) {
/*  71 */     super(initialSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean empty() {
/*  83 */     return isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object peek() throws EmptyStackException {
/*  93 */     int n = size();
/*  94 */     if (n <= 0) {
/*  95 */       throw new EmptyStackException();
/*     */     }
/*  97 */     return get(n - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object peek(int n) throws EmptyStackException {
/* 111 */     int m = size() - n - 1;
/* 112 */     if (m < 0) {
/* 113 */       throw new EmptyStackException();
/*     */     }
/* 115 */     return get(m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object pop() throws EmptyStackException {
/* 126 */     int n = size();
/* 127 */     if (n <= 0) {
/* 128 */       throw new EmptyStackException();
/*     */     }
/* 130 */     return remove(n - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object push(Object item) {
/* 142 */     add((E)item);
/* 143 */     return item;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int search(Object object) {
/* 158 */     int i = size() - 1;
/* 159 */     int n = 1;
/* 160 */     while (i >= 0) {
/* 161 */       Object current = get(i);
/* 162 */       if ((object == null && current == null) || (object != null && object.equals(current)))
/*     */       {
/* 164 */         return n;
/*     */       }
/* 166 */       i--;
/* 167 */       n++;
/*     */     } 
/* 169 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get() {
/* 179 */     int size = size();
/* 180 */     if (size == 0) {
/* 181 */       throw new BufferUnderflowException();
/*     */     }
/* 183 */     return get(size - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove() {
/* 193 */     int size = size();
/* 194 */     if (size == 0) {
/* 195 */       throw new BufferUnderflowException();
/*     */     }
/* 197 */     return remove(size - 1);
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\commons-beanutils-1.8.3.jar!\org\apache\commons\collections\ArrayStack.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */