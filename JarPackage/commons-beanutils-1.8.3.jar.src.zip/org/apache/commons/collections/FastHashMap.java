/*     */ package org.apache.commons.collections;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastHashMap
/*     */   extends HashMap
/*     */ {
/*  71 */   protected HashMap map = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean fast = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastHashMap() {
/*  86 */     this.map = new HashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastHashMap(int capacity) {
/*  96 */     this.map = new HashMap(capacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastHashMap(int capacity, float factor) {
/* 107 */     this.map = new HashMap(capacity, factor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastHashMap(Map map) {
/* 117 */     this.map = new HashMap(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFast() {
/* 130 */     return this.fast;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFast(boolean fast) {
/* 139 */     this.fast = fast;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 158 */     if (this.fast) {
/* 159 */       return this.map.get(key);
/*     */     }
/* 161 */     synchronized (this.map) {
/* 162 */       return this.map.get(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 173 */     if (this.fast) {
/* 174 */       return this.map.size();
/*     */     }
/* 176 */     synchronized (this.map) {
/* 177 */       return this.map.size();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 188 */     if (this.fast) {
/* 189 */       return this.map.isEmpty();
/*     */     }
/* 191 */     synchronized (this.map) {
/* 192 */       return this.map.isEmpty();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 205 */     if (this.fast) {
/* 206 */       return this.map.containsKey(key);
/*     */     }
/* 208 */     synchronized (this.map) {
/* 209 */       return this.map.containsKey(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 222 */     if (this.fast) {
/* 223 */       return this.map.containsValue(value);
/*     */     }
/* 225 */     synchronized (this.map) {
/* 226 */       return this.map.containsValue(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 247 */     if (this.fast) {
/* 248 */       synchronized (this) {
/* 249 */         HashMap temp = (HashMap)this.map.clone();
/* 250 */         Object result = temp.put(key, value);
/* 251 */         this.map = temp;
/* 252 */         return result;
/*     */       } 
/*     */     }
/* 255 */     synchronized (this.map) {
/* 256 */       return this.map.put(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map in) {
/* 268 */     if (this.fast) {
/* 269 */       synchronized (this) {
/* 270 */         HashMap temp = (HashMap)this.map.clone();
/* 271 */         temp.putAll(in);
/* 272 */         this.map = temp;
/*     */       } 
/*     */     } else {
/* 275 */       synchronized (this.map) {
/* 276 */         this.map.putAll(in);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 289 */     if (this.fast) {
/* 290 */       synchronized (this) {
/* 291 */         HashMap temp = (HashMap)this.map.clone();
/* 292 */         Object result = temp.remove(key);
/* 293 */         this.map = temp;
/* 294 */         return result;
/*     */       } 
/*     */     }
/* 297 */     synchronized (this.map) {
/* 298 */       return this.map.remove(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 307 */     if (this.fast) {
/* 308 */       synchronized (this) {
/* 309 */         this.map = new HashMap();
/*     */       } 
/*     */     } else {
/* 312 */       synchronized (this.map) {
/* 313 */         this.map.clear();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 332 */     if (o == this)
/* 333 */       return true; 
/* 334 */     if (!(o instanceof Map)) {
/* 335 */       return false;
/*     */     }
/* 337 */     Map mo = (Map)o;
/*     */ 
/*     */     
/* 340 */     if (this.fast) {
/* 341 */       if (mo.size() != this.map.size()) {
/* 342 */         return false;
/*     */       }
/* 344 */       Iterator i = this.map.entrySet().iterator();
/* 345 */       while (i.hasNext()) {
/* 346 */         Map.Entry e = i.next();
/* 347 */         Object key = e.getKey();
/* 348 */         Object value = e.getValue();
/* 349 */         if (value == null) {
/* 350 */           if (mo.get(key) != null || !mo.containsKey(key))
/* 351 */             return false; 
/*     */           continue;
/*     */         } 
/* 354 */         if (!value.equals(mo.get(key))) {
/* 355 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 359 */       return true;
/*     */     } 
/*     */     
/* 362 */     synchronized (this.map) {
/* 363 */       if (mo.size() != this.map.size()) {
/* 364 */         return false;
/*     */       }
/* 366 */       Iterator i = this.map.entrySet().iterator();
/* 367 */       while (i.hasNext()) {
/* 368 */         Map.Entry e = i.next();
/* 369 */         Object key = e.getKey();
/* 370 */         Object value = e.getValue();
/* 371 */         if (value == null) {
/* 372 */           if (mo.get(key) != null || !mo.containsKey(key))
/* 373 */             return false; 
/*     */           continue;
/*     */         } 
/* 376 */         if (!value.equals(mo.get(key))) {
/* 377 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 381 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 394 */     if (this.fast) {
/* 395 */       int h = 0;
/* 396 */       Iterator i = this.map.entrySet().iterator();
/* 397 */       while (i.hasNext()) {
/* 398 */         h += i.next().hashCode();
/*     */       }
/* 400 */       return h;
/*     */     } 
/* 402 */     synchronized (this.map) {
/* 403 */       int h = 0;
/* 404 */       Iterator i = this.map.entrySet().iterator();
/* 405 */       while (i.hasNext()) {
/* 406 */         h += i.next().hashCode();
/*     */       }
/* 408 */       return h;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 420 */     FastHashMap results = null;
/* 421 */     if (this.fast) {
/* 422 */       results = new FastHashMap(this.map);
/*     */     } else {
/* 424 */       synchronized (this.map) {
/* 425 */         results = new FastHashMap(this.map);
/*     */       } 
/*     */     } 
/* 428 */     results.setFast(getFast());
/* 429 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set entrySet() {
/* 441 */     return new EntrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set keySet() {
/* 449 */     return new KeySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection values() {
/* 457 */     return new Values();
/*     */   }
/*     */ 
/*     */   
/*     */   private abstract class CollectionView
/*     */     implements Collection
/*     */   {
/*     */     private final FastHashMap this$0;
/*     */ 
/*     */     
/*     */     public CollectionView(FastHashMap this$0) {
/* 468 */       this.this$0 = this$0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {
/* 476 */       if (this.this$0.fast) {
/* 477 */         synchronized (this.this$0) {
/* 478 */           this.this$0.map = new HashMap();
/*     */         } 
/*     */       } else {
/* 481 */         synchronized (this.this$0.map) {
/* 482 */           get(this.this$0.map).clear();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean remove(Object o) {
/* 488 */       if (this.this$0.fast) {
/* 489 */         synchronized (this.this$0) {
/* 490 */           HashMap temp = (HashMap)this.this$0.map.clone();
/* 491 */           boolean r = get(temp).remove(o);
/* 492 */           this.this$0.map = temp;
/* 493 */           return r;
/*     */         } 
/*     */       }
/* 496 */       synchronized (this.this$0.map) {
/* 497 */         return get(this.this$0.map).remove(o);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection o) {
/* 503 */       if (this.this$0.fast) {
/* 504 */         synchronized (this.this$0) {
/* 505 */           HashMap temp = (HashMap)this.this$0.map.clone();
/* 506 */           boolean r = get(temp).removeAll(o);
/* 507 */           this.this$0.map = temp;
/* 508 */           return r;
/*     */         } 
/*     */       }
/* 511 */       synchronized (this.this$0.map) {
/* 512 */         return get(this.this$0.map).removeAll(o);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection o) {
/* 518 */       if (this.this$0.fast) {
/* 519 */         synchronized (this.this$0) {
/* 520 */           HashMap temp = (HashMap)this.this$0.map.clone();
/* 521 */           boolean r = get(temp).retainAll(o);
/* 522 */           this.this$0.map = temp;
/* 523 */           return r;
/*     */         } 
/*     */       }
/* 526 */       synchronized (this.this$0.map) {
/* 527 */         return get(this.this$0.map).retainAll(o);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 533 */       if (this.this$0.fast) {
/* 534 */         return get(this.this$0.map).size();
/*     */       }
/* 536 */       synchronized (this.this$0.map) {
/* 537 */         return get(this.this$0.map).size();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 544 */       if (this.this$0.fast) {
/* 545 */         return get(this.this$0.map).isEmpty();
/*     */       }
/* 547 */       synchronized (this.this$0.map) {
/* 548 */         return get(this.this$0.map).isEmpty();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object o) {
/* 554 */       if (this.this$0.fast) {
/* 555 */         return get(this.this$0.map).contains(o);
/*     */       }
/* 557 */       synchronized (this.this$0.map) {
/* 558 */         return get(this.this$0.map).contains(o);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection o) {
/* 564 */       if (this.this$0.fast) {
/* 565 */         return get(this.this$0.map).containsAll(o);
/*     */       }
/* 567 */       synchronized (this.this$0.map) {
/* 568 */         return get(this.this$0.map).containsAll(o);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] toArray(Object[] o) {
/* 574 */       if (this.this$0.fast) {
/* 575 */         return get(this.this$0.map).toArray(o);
/*     */       }
/* 577 */       synchronized (this.this$0.map) {
/* 578 */         return get(this.this$0.map).toArray(o);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 584 */       if (this.this$0.fast) {
/* 585 */         return get(this.this$0.map).toArray();
/*     */       }
/* 587 */       synchronized (this.this$0.map) {
/* 588 */         return get(this.this$0.map).toArray();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 595 */       if (o == this) {
/* 596 */         return true;
/*     */       }
/* 598 */       if (this.this$0.fast) {
/* 599 */         return get(this.this$0.map).equals(o);
/*     */       }
/* 601 */       synchronized (this.this$0.map) {
/* 602 */         return get(this.this$0.map).equals(o);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 608 */       if (this.this$0.fast) {
/* 609 */         return get(this.this$0.map).hashCode();
/*     */       }
/* 611 */       synchronized (this.this$0.map) {
/* 612 */         return get(this.this$0.map).hashCode();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(Object o) {
/* 618 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean addAll(Collection c) {
/* 622 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public Iterator iterator() {
/* 626 */       return new CollectionViewIterator(this);
/*     */     }
/*     */     protected abstract Collection get(Map param1Map);
/*     */     protected abstract Object iteratorNext(Map.Entry param1Entry);
/*     */     
/*     */     private class CollectionViewIterator implements Iterator { private Map expected;
/*     */       private Map.Entry lastReturned;
/*     */       
/*     */       public CollectionViewIterator(FastHashMap.CollectionView this$0) {
/* 635 */         this.this$1 = this$0; this.lastReturned = null;
/* 636 */         this.expected = this$0.this$0.map;
/* 637 */         this.iterator = this.expected.entrySet().iterator();
/*     */       }
/*     */       private Iterator iterator; private final FastHashMap.CollectionView this$1;
/*     */       public boolean hasNext() {
/* 641 */         if (this.expected != this.this$1.this$0.map) {
/* 642 */           throw new ConcurrentModificationException();
/*     */         }
/* 644 */         return this.iterator.hasNext();
/*     */       }
/*     */       
/*     */       public Object next() {
/* 648 */         if (this.expected != this.this$1.this$0.map) {
/* 649 */           throw new ConcurrentModificationException();
/*     */         }
/* 651 */         this.lastReturned = this.iterator.next();
/* 652 */         return this.this$1.iteratorNext(this.lastReturned);
/*     */       }
/*     */       
/*     */       public void remove() {
/* 656 */         if (this.lastReturned == null) {
/* 657 */           throw new IllegalStateException();
/*     */         }
/* 659 */         if (this.this$1.this$0.fast) {
/* 660 */           synchronized (this.this$1.this$0) {
/* 661 */             if (this.expected != this.this$1.this$0.map) {
/* 662 */               throw new ConcurrentModificationException();
/*     */             }
/* 664 */             this.this$1.this$0.remove(this.lastReturned.getKey());
/* 665 */             this.lastReturned = null;
/* 666 */             this.expected = this.this$1.this$0.map;
/*     */           } 
/*     */         } else {
/* 669 */           this.iterator.remove();
/* 670 */           this.lastReturned = null;
/*     */         } 
/*     */       } }
/*     */   }
/*     */   
/*     */   private class KeySet extends CollectionView implements Set {
/*     */     private final FastHashMap this$0;
/*     */     
/*     */     private KeySet(FastHashMap this$0) {
/* 679 */       FastHashMap.this = FastHashMap.this;
/*     */     }
/*     */     protected Collection get(Map map) {
/* 682 */       return map.keySet();
/*     */     }
/*     */     
/*     */     protected Object iteratorNext(Map.Entry entry) {
/* 686 */       return entry.getKey();
/*     */     }
/*     */   }
/*     */   
/*     */   private class Values extends CollectionView {
/*     */     private final FastHashMap this$0;
/*     */     
/*     */     private Values(FastHashMap this$0) {
/* 694 */       FastHashMap.this = FastHashMap.this;
/*     */     }
/*     */     protected Collection get(Map map) {
/* 697 */       return map.values();
/*     */     }
/*     */     
/*     */     protected Object iteratorNext(Map.Entry entry) {
/* 701 */       return entry.getValue();
/*     */     } }
/*     */   
/*     */   private class EntrySet extends CollectionView implements Set {
/*     */     private final FastHashMap this$0;
/*     */     
/*     */     private EntrySet(FastHashMap this$0) {
/* 708 */       FastHashMap.this = FastHashMap.this;
/*     */     }
/*     */     protected Collection get(Map map) {
/* 711 */       return map.entrySet();
/*     */     }
/*     */     
/*     */     protected Object iteratorNext(Map.Entry entry) {
/* 715 */       return entry;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\commons-beanutils-1.8.3.jar!\org\apache\commons\collections\FastHashMap.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */