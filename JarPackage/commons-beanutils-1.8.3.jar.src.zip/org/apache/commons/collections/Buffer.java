package org.apache.commons.collections;

import java.util.Collection;

public interface Buffer extends Collection {
  Object remove();
  
  Object get();
}


/* Location:              D:\JarPackage\commons-beanutils-1.8.3.jar!\org\apache\commons\collections\Buffer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */