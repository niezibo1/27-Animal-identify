/*     */ package com.show.api.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShowApiUtils
/*     */ {
/*     */   public static String signRequest(Map<String, String> params, String secret) throws IOException {
/*  33 */     TreeSet<String> keys = new TreeSet<String>();
/*  34 */     Iterator<String> it = params.keySet().iterator();
/*  35 */     while (it.hasNext()) {
/*  36 */       String k = it.next();
/*  37 */       Object v = params.get(k);
/*  38 */       if (!(v instanceof com.show.api.FileItem)) keys.add(k);
/*     */     
/*     */     } 
/*  41 */     StringBuilder query = new StringBuilder();
/*  42 */     for (String key : keys) {
/*     */       
/*  44 */       String value = (String)params.get(key) + "";
/*  45 */       if (!key.equals("showapi_sign") && StringUtils.areNotEmpty(new String[] { key, value })) {
/*  46 */         query.append(key).append(value);
/*     */       }
/*     */     } 
/*     */     
/*  50 */     query.append(secret);
/*     */     
/*  52 */     byte[] bytes = encryptMD5(query.toString());
/*     */     
/*  54 */     return byte2hex(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getStringFromException(Throwable e) {
/*  60 */     String result = "";
/*  61 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  62 */     PrintStream ps = new PrintStream(bos);
/*  63 */     e.printStackTrace(ps);
/*     */     try {
/*  65 */       result = bos.toString("UTF-8");
/*  66 */     } catch (IOException ioe) {}
/*     */     
/*  68 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] encryptMD5(String data) throws IOException {
/*  72 */     byte[] bytes = null;
/*     */     try {
/*  74 */       MessageDigest md = MessageDigest.getInstance("MD5");
/*  75 */       bytes = md.digest(data.getBytes("UTF-8"));
/*  76 */     } catch (GeneralSecurityException gse) {
/*  77 */       String msg = getStringFromException(gse);
/*  78 */       throw new IOException(msg);
/*     */     } 
/*  80 */     return bytes;
/*     */   }
/*     */   
/*     */   public static String byte2hex(byte[] bytes) {
/*  84 */     StringBuilder sign = new StringBuilder();
/*  85 */     for (int i = 0; i < bytes.length; i++) {
/*  86 */       String hex = Integer.toHexString(bytes[i] & 0xFF);
/*  87 */       if (hex.length() == 1) {
/*  88 */         sign.append("0");
/*     */       }
/*  90 */       sign.append(hex.toUpperCase());
/*     */     } 
/*  92 */     return sign.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFileSuffix(byte[] bytes) {
/* 102 */     if (bytes == null || bytes.length < 10) {
/* 103 */       return null;
/*     */     }
/*     */     
/* 106 */     if (bytes[0] == 71 && bytes[1] == 73 && bytes[2] == 70)
/* 107 */       return "GIF"; 
/* 108 */     if (bytes[1] == 80 && bytes[2] == 78 && bytes[3] == 71)
/* 109 */       return "PNG"; 
/* 110 */     if (bytes[6] == 74 && bytes[7] == 70 && bytes[8] == 73 && bytes[9] == 70)
/* 111 */       return "JPG"; 
/* 112 */     if (bytes[0] == 66 && bytes[1] == 77) {
/* 113 */       return "BMP";
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMimeType(byte[] bytes) {
/* 126 */     String mimeType, suffix = getFileSuffix(bytes);
/*     */ 
/*     */     
/* 129 */     if ("JPG".equals(suffix)) {
/* 130 */       mimeType = "image/jpeg";
/* 131 */     } else if ("GIF".equals(suffix)) {
/* 132 */       mimeType = "image/gif";
/* 133 */     } else if ("PNG".equals(suffix)) {
/* 134 */       mimeType = "image/png";
/* 135 */     } else if ("BMP".equals(suffix)) {
/* 136 */       mimeType = "image/bmp";
/*     */     } else {
/* 138 */       mimeType = "application/octet-stream";
/*     */     } 
/* 140 */     return mimeType;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\ap\\util\ShowApiUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */