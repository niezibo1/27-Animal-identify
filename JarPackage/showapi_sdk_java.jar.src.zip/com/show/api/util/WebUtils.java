/*     */ package com.show.api.util;
/*     */ 
/*     */ import com.show.api.FileItem;
/*     */ import com.show.api.NormalRequest;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebUtils
/*     */ {
/*     */   private static final String METHOD_POST = "POST";
/*     */   private static final String METHOD_GET = "GET";
/*     */   
/*     */   public static class VerisignTrustManager
/*     */     implements X509TrustManager
/*     */   {
/*     */     public X509Certificate[] getAcceptedIssuers() {
/*  40 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TrustAllTrustManager
/*     */     implements X509TrustManager
/*     */   {
/*     */     public X509Certificate[] getAcceptedIssuers() {
/*  68 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*     */ 
/*     */     
/*     */     public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*     */   }
/*     */   
/*     */   public static ResData _do_execute(NormalRequest req, String method) throws IOException {
/*  79 */     HttpURLConnection conn = null;
/*  80 */     OutputStream out = null;
/*  81 */     byte[] rsp = null;
/*  82 */     byte[] body = new byte[0];
/*  83 */     ResData res = new ResData();
/*  84 */     String ctype = "", query = "", boundary = "";
/*     */     
/*  86 */     String charset = req.getCharset();
/*  87 */     if (method.equals("GET")) {
/*  88 */       ctype = "application/x-www-form-urlencoded;charset=" + charset;
/*  89 */       query = buildQuery(req.getTextMap(), charset);
/*     */     }
/*  91 */     else if (method.equals("POST")) {
/*  92 */       boolean upload = false;
/*  93 */       if (req.getUploadMap() != null && req.getUploadMap().size() > 0) {
/*  94 */         boundary = String.valueOf(System.nanoTime());
/*  95 */         ctype = "multipart/form-data;charset=" + charset + ";boundary=" + boundary;
/*  96 */         upload = true;
/*     */       } else {
/*  98 */         ctype = "application/x-www-form-urlencoded;charset=" + charset;
/*  99 */         ctype = getCtype(req, ctype);
/*     */       } 
/* 101 */       if (req.getBody() != null) {
/* 102 */         body = req.getBody();
/* 103 */       } else if (req.getBodyString() != null) {
/* 104 */         body = req.getBodyString().getBytes(charset);
/*     */       }
/* 106 */       else if (upload) {
/* 107 */         ByteArrayOutputStream bout = new ByteArrayOutputStream();
/* 108 */         byte[] entryBoundaryBytes = ("\r\n--" + boundary + "\r\n").getBytes(charset);
/*     */         
/* 110 */         Set<Map.Entry<String, String>> textEntrySet = req.getTextMap().entrySet();
/* 111 */         for (Map.Entry<String, String> textEntry : textEntrySet) {
/* 112 */           byte[] textBytes = getTextEntry(textEntry.getKey(), textEntry.getValue(), charset);
/* 113 */           bout.write(entryBoundaryBytes);
/* 114 */           bout.write(textBytes);
/*     */         } 
/*     */ 
/*     */         
/* 118 */         Set<Map.Entry<String, File>> fileEntrySet = req.getUploadMap().entrySet();
/* 119 */         for (Map.Entry<String, File> fileEntry : fileEntrySet) {
/* 120 */           File f = fileEntry.getValue();
/* 121 */           FileItem fileItem = new FileItem(f);
/* 122 */           if (fileItem.getContent() == null) {
/*     */             continue;
/*     */           }
/* 125 */           byte[] fileBytes = getFileEntry(fileEntry.getKey(), fileItem.getFileName(), fileItem.getMimeType(), charset);
/* 126 */           bout.write(entryBoundaryBytes);
/* 127 */           bout.write(fileBytes);
/* 128 */           bout.write(fileItem.getContent());
/*     */         } 
/*     */ 
/*     */         
/* 132 */         byte[] endBoundaryBytes = ("\r\n--" + boundary + "--\r\n").getBytes(charset);
/* 133 */         bout.write(endBoundaryBytes);
/* 134 */         body = bout.toByteArray();
/*     */       }
/*     */       else {
/*     */         
/* 138 */         String body_content = buildQuery(req.getTextMap(), charset);
/* 139 */         if (body_content != null)
/*     */         {
/* 141 */           body = body_content.getBytes(charset);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 148 */     URL url = buildGetUrl(req.getUrl(), query);
/*     */     try {
/* 150 */       conn = getConnection(url, method, ctype, req);
/* 151 */       conn.setConnectTimeout(req.getConnectTimeout());
/* 152 */       conn.setReadTimeout(req.getReadTimeout());
/* 153 */       if (!method.equals("GET")) {
/* 154 */         out = conn.getOutputStream();
/* 155 */         out.write(body);
/* 156 */         out.flush();
/*     */       } 
/* 158 */       Map<String, List<String>> res_headMap = conn.getHeaderFields();
/* 159 */       rsp = getResponseAsByte(conn, getLimitReadSize(req));
/* 160 */       req.setRes_headMap(res_headMap);
/* 161 */       req.setRes_status(conn.getResponseCode());
/*     */     } finally {
/* 163 */       if (conn != null) {
/* 164 */         conn.disconnect();
/*     */       }
/*     */     } 
/* 167 */     res.setResData(rsp);
/* 168 */     res.setRes_maybe_encoding(getResponseCharset(conn.getContentType()));
/* 169 */     return res;
/*     */   }
/*     */   
/*     */   public static String doPost(NormalRequest req) throws IOException {
/* 173 */     ResData res = _do_execute(req, "POST");
/* 174 */     return new String(res.getResData(), res.getRes_maybe_encoding());
/*     */   }
/*     */   
/*     */   public static byte[] doPostAsByte(NormalRequest req) throws IOException {
/* 178 */     ResData res = _do_execute(req, "POST");
/* 179 */     return res.getResData();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String doGet(NormalRequest req) throws IOException {
/* 185 */     ResData res = _do_execute(req, "GET");
/* 186 */     return new String(res.getResData(), res.getRes_maybe_encoding());
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] doGetAsByte(NormalRequest req) throws IOException {
/* 191 */     ResData res = _do_execute(req, "GET");
/* 192 */     return res.getResData();
/*     */   }
/*     */ 
/*     */   
/*     */   public static ByteArrayOutputStream unzip(InputStream in, int limit_size) {
/* 197 */     ByteArrayOutputStream fout = new ByteArrayOutputStream();
/*     */     
/*     */     try {
/* 200 */       GZIPInputStream gzin = new GZIPInputStream(in);
/*     */       
/* 202 */       byte[] buf = new byte[1024];
/*     */       
/* 204 */       int allNum = 0; int num;
/* 205 */       while ((num = gzin.read(buf, 0, buf.length)) != -1) {
/* 206 */         fout.write(buf, 0, num);
/* 207 */         allNum += num;
/* 208 */         if (allNum >= limit_size)
/*     */           break; 
/* 210 */       }  gzin.close();
/* 211 */       fout.close();
/* 212 */       in.close();
/* 213 */     } catch (Exception e) {
/* 214 */       System.out.println(e);
/*     */     } 
/* 216 */     return fout;
/*     */   }
/*     */   
/*     */   private static int getLimitReadSize(NormalRequest req) {
/* 220 */     int limit_size = Integer.MAX_VALUE;
/* 221 */     if (req.getLimitReadSize() > 0) limit_size = req.getLimitReadSize(); 
/* 222 */     return limit_size;
/*     */   }
/*     */   private static byte[] getTextEntry(String fieldName, String fieldValue, String charset) throws IOException {
/* 225 */     StringBuilder entry = new StringBuilder();
/* 226 */     entry.append("Content-Disposition:form-data; name=\"");
/* 227 */     entry.append(fieldName);
/* 228 */     entry.append("\"\r\nContent-Type:text/plain\r\n\r\n");
/* 229 */     entry.append(fieldValue);
/*     */     
/* 231 */     return entry.toString().getBytes(charset);
/*     */   }
/*     */   
/*     */   private static byte[] getFileEntry(String fieldName, String fileName, String mimeType, String charset) throws IOException {
/* 235 */     StringBuilder entry = new StringBuilder();
/* 236 */     entry.append("Content-Disposition:form-data; name=\"");
/* 237 */     entry.append(fieldName);
/* 238 */     entry.append("\"; filename=\"");
/* 239 */     entry.append(fileName);
/* 240 */     entry.append("\"\r\nContent-Type:");
/* 241 */     entry.append(mimeType);
/* 242 */     entry.append("\r\n\r\n");
/*     */     
/* 244 */     return entry.toString().getBytes(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getCtype(NormalRequest req, String default_type) {
/* 250 */     String ret = null;
/* 251 */     Map<String, String> params = req.getHeadMap();
/* 252 */     if (params == null || params.isEmpty()) {
/* 253 */       return null;
/*     */     }
/* 255 */     Set<Map.Entry<String, String>> entries = params.entrySet();
/*     */     try {
/* 257 */       for (Map.Entry<String, String> entry : entries) {
/* 258 */         String name = ((String)entry.getKey()).toLowerCase();
/* 259 */         String value = entry.getValue();
/*     */         
/* 261 */         if (name.equals("content-type")) {
/* 262 */           ret = value;
/*     */           break;
/*     */         } 
/*     */       } 
/* 266 */     } catch (Exception e) {
/* 267 */       e.printStackTrace();
/*     */     } 
/* 269 */     if (ret == null && (
/* 270 */       req.getBody() != null || req.getBodyString() != null)) {
/* 271 */       ret = "application/octet-stream;charset=" + req.getCharset();
/*     */     }
/*     */ 
/*     */     
/* 275 */     if (ret != null) return ret; 
/* 276 */     return default_type;
/*     */   }
/*     */ 
/*     */   
/*     */   private static HttpURLConnection getConnection(URL url, String method, String ctype, NormalRequest req) throws IOException {
/*     */     HttpURLConnection conn;
/* 282 */     Proxy proxy = req.getProxy();
/* 283 */     if (proxy != null) {
/* 284 */       conn = (HttpURLConnection)url.openConnection(proxy);
/*     */     } else {
/* 286 */       conn = (HttpURLConnection)url.openConnection();
/*     */     } 
/* 288 */     if (conn instanceof HttpsURLConnection) {
/* 289 */       HttpsURLConnection connHttps = (HttpsURLConnection)conn;
/*     */       try {
/* 291 */         SSLContext ctx = SSLContext.getInstance("TLS");
/* 292 */         ctx.init(null, new TrustManager[] { new TrustAllTrustManager() }, new SecureRandom());
/* 293 */         connHttps.setSSLSocketFactory(ctx.getSocketFactory());
/* 294 */         connHttps.setHostnameVerifier(new HostnameVerifier() {
/*     */               public boolean verify(String hostname, SSLSession session) {
/* 296 */                 return true;
/*     */               }
/*     */             });
/* 299 */       } catch (Exception e) {
/* 300 */         throw new IOException(e);
/*     */       } 
/* 302 */       conn = connHttps;
/*     */     } 
/* 304 */     conn.setRequestMethod(method);
/* 305 */     conn.setDoInput(true);
/* 306 */     conn.setDoOutput(true);
/* 307 */     conn.setRequestProperty("Accept", "application/json, text/javascript, */*; ");
/* 308 */     conn.setRequestProperty("User-Agent", "showapi-sdk-java");
/* 309 */     conn.setRequestProperty("Content-Type", ctype);
/* 310 */     Map<String, String> headerMap = req.getHeadMap();
/* 311 */     if (headerMap != null) {
/* 312 */       for (Map.Entry<String, String> entry : headerMap.entrySet()) {
/* 313 */         conn.setRequestProperty(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/* 316 */     conn.setInstanceFollowRedirects(req.isAllowRedirect());
/* 317 */     return conn;
/*     */   }
/*     */   
/*     */   private static URL buildGetUrl(String strUrl, String query) throws IOException {
/* 321 */     URL url = new URL(strUrl);
/* 322 */     if (StringUtils.isEmpty(query)) {
/* 323 */       return url;
/*     */     }
/*     */     
/* 326 */     if (StringUtils.isEmpty(url.getQuery())) {
/* 327 */       if (strUrl.endsWith("?")) {
/* 328 */         strUrl = strUrl + query;
/*     */       } else {
/* 330 */         strUrl = strUrl + "?" + query;
/*     */       }
/*     */     
/* 333 */     } else if (strUrl.endsWith("&")) {
/* 334 */       strUrl = strUrl + query;
/*     */     } else {
/* 336 */       strUrl = strUrl + "&" + query;
/*     */     } 
/*     */     
/* 339 */     return new URL(strUrl);
/*     */   }
/*     */   
/*     */   public static String buildQuery(Map<String, String> params, String charset) {
/* 343 */     if (params == null || params.isEmpty()) {
/* 344 */       return null;
/*     */     }
/* 346 */     StringBuilder query = new StringBuilder();
/* 347 */     Set<Map.Entry<String, String>> entries = params.entrySet();
/* 348 */     boolean hasParam = false;
/*     */     try {
/* 350 */       for (Map.Entry<String, String> entry : entries) {
/* 351 */         String name = entry.getKey();
/* 352 */         String value = entry.getValue();
/*     */         
/* 354 */         if (name != null && name.length() > 0 && value != null) {
/* 355 */           if (hasParam) {
/* 356 */             query.append("&");
/*     */           } else {
/* 358 */             hasParam = true;
/*     */           } 
/* 360 */           query.append(name).append("=").append(URLEncoder.encode(value, charset));
/*     */         } 
/*     */       } 
/* 363 */     } catch (Exception e) {
/* 364 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 367 */     return query.toString();
/*     */   }
/*     */   protected static byte[] getResponseAsByte(HttpURLConnection conn, int limit_size) throws IOException {
/* 370 */     InputStream es = conn.getErrorStream();
/* 371 */     if (es == null) {
/* 372 */       if (conn.getContentEncoding() != null && conn.getContentEncoding().toLowerCase().equals("gzip")) {
/* 373 */         byte[] bbb = unzip(conn.getInputStream(), limit_size).toByteArray();
/* 374 */         return bbb;
/*     */       } 
/* 376 */       if (conn.getResponseCode() >= 400) {
/* 377 */         return new byte[0];
/*     */       }
/* 379 */       return _readByteFromStream(conn.getInputStream(), limit_size);
/*     */     } 
/*     */     
/* 382 */     return _readByteFromStream(es, limit_size);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String getResponseAsString(HttpURLConnection conn, int limit_size) throws IOException {
/* 387 */     String charset_res = getResponseCharset(conn.getContentType());
/* 388 */     byte[] ret = getResponseAsByte(conn, limit_size);
/* 389 */     return new String(ret, charset_res);
/*     */   }
/*     */   
/*     */   private static byte[] _readByteFromStream(InputStream stream, int limit_size) throws IOException {
/*     */     try {
/* 394 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 395 */       byte[] buf = new byte[1024];
/* 396 */       int read = 0;
/* 397 */       int allNum = 0;
/* 398 */       while ((read = stream.read(buf)) > 0) {
/* 399 */         out.write(buf, 0, read);
/* 400 */         allNum += read;
/* 401 */         if (allNum >= limit_size)
/*     */           break; 
/* 403 */       }  return out.toByteArray();
/*     */     } finally {
/* 405 */       if (stream != null) {
/* 406 */         stream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getResponseCharset(String ctype) {
/* 413 */     String charset = "utf-8";
/* 414 */     if (!StringUtils.isEmpty(ctype)) {
/* 415 */       String[] params = ctype.split(";");
/* 416 */       for (String param : params) {
/* 417 */         param = param.trim();
/* 418 */         if (param.startsWith("charset")) {
/* 419 */           String[] pair = param.split("=", 2);
/* 420 */           if (pair.length == 2 && 
/* 421 */             !StringUtils.isEmpty(pair[1])) {
/* 422 */             charset = pair[1].trim();
/*     */           }
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 429 */     return charset;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 433 */     byte[] b = (new NormalRequest("http://www.boc.cn/sourcedb/whpj/")).getAsByte();
/*     */     
/* 435 */     System.out.println(new String(b, "utf-8"));
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\ap\\util\WebUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */