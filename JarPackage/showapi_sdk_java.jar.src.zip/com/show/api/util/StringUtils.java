/*     */ package com.show.api.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringUtils
/*     */ {
/*     */   public static boolean isEmpty(String value) {
/*     */     int strLen;
/*  27 */     if (value == null || (strLen = value.length()) == 0) {
/*  28 */       return true;
/*     */     }
/*  30 */     for (int i = 0; i < strLen; i++) {
/*  31 */       if (!Character.isWhitespace(value.charAt(i))) {
/*  32 */         return false;
/*     */       }
/*     */     } 
/*  35 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNumeric(Object obj) {
/*  42 */     if (obj == null) {
/*  43 */       return false;
/*     */     }
/*  45 */     char[] chars = obj.toString().toCharArray();
/*  46 */     int length = chars.length;
/*  47 */     if (length < 1) {
/*  48 */       return false;
/*     */     }
/*  50 */     int i = 0;
/*  51 */     if (length > 1 && chars[0] == '-') {
/*  52 */       i = 1;
/*     */     }
/*  54 */     for (; i < length; i++) {
/*  55 */       if (!Character.isDigit(chars[i])) {
/*  56 */         return false;
/*     */       }
/*     */     } 
/*  59 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean areNotEmpty(String... values) {
/*     */     int i;
/*  66 */     boolean result = true;
/*  67 */     if (values == null || values.length == 0) {
/*  68 */       result = false;
/*     */     } else {
/*  70 */       for (String value : values) {
/*  71 */         i = result & (!isEmpty(value) ? 1 : 0);
/*     */       }
/*     */     } 
/*  74 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String unicodeToChinese(String unicode) {
/*  81 */     StringBuilder out = new StringBuilder();
/*  82 */     if (!isEmpty(unicode)) {
/*  83 */       for (int i = 0; i < unicode.length(); i++) {
/*  84 */         out.append(unicode.charAt(i));
/*     */       }
/*     */     }
/*  87 */     return out.toString();
/*     */   }
/*     */   
/*     */   public static String toUnderlineStyle(String name) {
/*  91 */     StringBuilder newName = new StringBuilder();
/*  92 */     for (int i = 0; i < name.length(); i++) {
/*  93 */       char c = name.charAt(i);
/*  94 */       if (Character.isUpperCase(c)) {
/*  95 */         if (i > 0) {
/*  96 */           newName.append("_");
/*     */         }
/*  98 */         newName.append(Character.toLowerCase(c));
/*     */       } else {
/* 100 */         newName.append(c);
/*     */       } 
/*     */     } 
/* 103 */     return newName.toString();
/*     */   }
/*     */   
/*     */   public static String convertString(byte[] data, int offset, int length) {
/* 107 */     if (data == null) {
/* 108 */       return null;
/*     */     }
/*     */     try {
/* 111 */       return new String(data, offset, length, "UTF-8");
/* 112 */     } catch (Exception e) {
/* 113 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] convertBytes(String data) {
/* 119 */     if (data == null) {
/* 120 */       return null;
/*     */     }
/*     */     try {
/* 123 */       return data.getBytes("UTF-8");
/* 124 */     } catch (Exception e) {
/* 125 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\ap\\util\StringUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */