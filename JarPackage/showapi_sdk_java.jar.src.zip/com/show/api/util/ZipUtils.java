/*     */ package com.show.api.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.security.DigestInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZipUtils
/*     */ {
/*  30 */   private static final Set<String> CONTENT_TYPES = new HashSet<String>();
/*  31 */   private static final Pattern REGEX_FILE_NAME = Pattern.compile("attachment;filename=\"([\\w\\-]+)\"");
/*     */   
/*     */   static {
/*  34 */     CONTENT_TYPES.add("application/octet-stream");
/*  35 */     CONTENT_TYPES.add("application/java-archive");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File ungzip(File gzip, File toDir) throws IOException {
/*  50 */     toDir.mkdirs();
/*  51 */     File out = new File(toDir, gzip.getName());
/*  52 */     GZIPInputStream gin = null;
/*  53 */     FileOutputStream fout = null;
/*     */     try {
/*  55 */       FileInputStream fin = new FileInputStream(gzip);
/*  56 */       gin = new GZIPInputStream(fin);
/*  57 */       fout = new FileOutputStream(out);
/*  58 */       copy(gin, fout);
/*  59 */       gin.close();
/*  60 */       fout.close();
/*     */     } finally {
/*  62 */       closeQuietly(gin);
/*  63 */       closeQuietly(fout);
/*     */     } 
/*  65 */     return out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<File> unzip(File zip, File toDir) throws IOException {
/*  76 */     ZipFile zf = null;
/*  77 */     List<File> files = null;
/*     */     try {
/*  79 */       zf = new ZipFile(zip);
/*  80 */       files = new ArrayList<File>();
/*  81 */       Enumeration<?> entries = zf.entries();
/*  82 */       while (entries.hasMoreElements()) {
/*  83 */         ZipEntry entry = (ZipEntry)entries.nextElement();
/*  84 */         if (entry.isDirectory()) {
/*  85 */           (new File(toDir, entry.getName())).mkdirs();
/*     */           
/*     */           continue;
/*     */         } 
/*  89 */         InputStream input = null;
/*  90 */         OutputStream output = null;
/*     */         try {
/*  92 */           File f = new File(toDir, entry.getName());
/*  93 */           input = zf.getInputStream(entry);
/*  94 */           output = new FileOutputStream(f);
/*  95 */           copy(input, output);
/*  96 */           files.add(f);
/*     */         } finally {
/*  98 */           closeQuietly(output);
/*  99 */           closeQuietly(input);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 103 */       if (zf != null) {
/* 104 */         zf.close();
/*     */       }
/*     */     } 
/* 107 */     return files;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File download(String url, File toDir) throws Exception {
/* 118 */     toDir.mkdirs();
/* 119 */     HttpURLConnection conn = null;
/* 120 */     OutputStream output = null;
/* 121 */     File file = null;
/*     */     try {
/* 123 */       conn = getConnection(new URL(url));
/* 124 */       String ctype = conn.getContentType();
/* 125 */       if (CONTENT_TYPES.contains(ctype)) {
/* 126 */         String fileName = getFileName(conn);
/* 127 */         file = new File(toDir, fileName);
/* 128 */         output = new FileOutputStream(file);
/* 129 */         copy(conn.getInputStream(), output);
/*     */       } else {
/* 131 */         String rsp = WebUtils.getResponseAsString(conn, 0);
/* 132 */         throw new Exception(rsp);
/*     */       } 
/* 134 */     } catch (IOException e) {
/* 135 */       throw new Exception(e);
/*     */     } finally {
/* 137 */       closeQuietly(output);
/* 138 */       if (conn != null) {
/* 139 */         conn.disconnect();
/*     */       }
/*     */     } 
/* 142 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File download(String url, File toDir, String fileName) throws Exception {
/* 154 */     toDir.mkdirs();
/* 155 */     HttpURLConnection conn = null;
/* 156 */     OutputStream output = null;
/* 157 */     File file = null;
/*     */     try {
/* 159 */       conn = getConnection(new URL(url));
/* 160 */       String ctype = conn.getContentType();
/* 161 */       if (CONTENT_TYPES.contains(ctype)) {
/* 162 */         file = new File(toDir, fileName);
/* 163 */         output = new FileOutputStream(file);
/* 164 */         copy(conn.getInputStream(), output);
/*     */       } else {
/* 166 */         String rsp = WebUtils.getResponseAsString(conn, 0);
/* 167 */         throw new Exception(rsp);
/*     */       } 
/* 169 */     } catch (IOException e) {
/* 170 */       throw new Exception(e);
/*     */     } finally {
/* 172 */       closeQuietly(output);
/* 173 */       if (conn != null) {
/* 174 */         conn.disconnect();
/*     */       }
/*     */     } 
/* 177 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean checkMd5sum(File file, String checkCode) throws IOException {
/* 188 */     DigestInputStream dInput = null;
/*     */     try {
/* 190 */       FileInputStream fInput = new FileInputStream(file);
/* 191 */       dInput = new DigestInputStream(fInput, getMd5Instance());
/* 192 */       byte[] buf = new byte[8192];
/* 193 */       while (dInput.read(buf) > 0);
/*     */       
/* 195 */       byte[] bytes = dInput.getMessageDigest().digest();
/* 196 */       return bytes2hex(bytes).equals(checkCode);
/*     */     } finally {
/* 198 */       closeQuietly(dInput);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String bytes2hex(byte[] bytes) {
/* 206 */     StringBuilder sb = new StringBuilder();
/* 207 */     for (int i = 0; i < bytes.length; i++) {
/* 208 */       String hex = Integer.toHexString(bytes[i] & 0xFF);
/* 209 */       if (hex.length() == 1) {
/* 210 */         sb.append("0").append(hex);
/*     */       } else {
/* 212 */         sb.append(hex);
/*     */       } 
/*     */     } 
/* 215 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static MessageDigest getMd5Instance() {
/*     */     try {
/* 220 */       return MessageDigest.getInstance("md5");
/* 221 */     } catch (Exception e) {
/* 222 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getFileName(HttpURLConnection conn) {
/* 227 */     String fileName = conn.getHeaderField("Content-Disposition");
/* 228 */     Matcher matcher = REGEX_FILE_NAME.matcher(fileName);
/* 229 */     if (matcher.find()) {
/* 230 */       return matcher.group(1);
/*     */     }
/* 232 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static HttpURLConnection getConnection(URL url) throws IOException {
/* 237 */     HttpURLConnection conn = (HttpURLConnection)url.openConnection();
/* 238 */     conn.setRequestMethod("GET");
/* 239 */     conn.setDoInput(true);
/* 240 */     conn.setDoOutput(true);
/* 241 */     conn.setRequestProperty("Accept", "application/zip;text/html");
/* 242 */     return conn;
/*     */   }
/*     */   
/*     */   private static int copy(InputStream input, OutputStream output) throws IOException {
/* 246 */     long count = copyStream(input, output);
/* 247 */     if (count > 2147483647L) {
/* 248 */       return -1;
/*     */     }
/* 250 */     return (int)count;
/*     */   }
/*     */   
/*     */   private static long copyStream(InputStream input, OutputStream output) throws IOException {
/* 254 */     byte[] buffer = new byte[1024];
/* 255 */     long count = 0L;
/* 256 */     int n = 0;
/* 257 */     while (-1 != (n = input.read(buffer))) {
/* 258 */       output.write(buffer, 0, n);
/* 259 */       count += n;
/*     */     } 
/* 261 */     return count;
/*     */   }
/*     */   
/*     */   private static void closeQuietly(OutputStream output) {
/*     */     try {
/* 266 */       if (output != null) {
/* 267 */         output.close();
/*     */       }
/* 269 */     } catch (IOException ioe) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void closeQuietly(InputStream input) {
/*     */     try {
/* 276 */       if (input != null) {
/* 277 */         input.close();
/*     */       }
/* 279 */     } catch (IOException ioe) {}
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\ap\\util\ZipUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */