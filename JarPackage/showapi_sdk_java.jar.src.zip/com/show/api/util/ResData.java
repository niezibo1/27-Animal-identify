/*    */ package com.show.api.util;
/*    */ 
/*    */ public class ResData {
/*  4 */   private byte[] resData = null;
/*    */   
/*    */   private String res_maybe_encoding;
/*    */   
/*    */   public byte[] getResData() {
/*  9 */     return this.resData;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setResData(byte[] resData) {
/* 14 */     this.resData = resData;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getRes_maybe_encoding() {
/* 19 */     return this.res_maybe_encoding;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRes_maybe_encoding(String res_maybe_encoding) {
/* 24 */     this.res_maybe_encoding = res_maybe_encoding;
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {}
/*    */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\ap\\util\ResData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */