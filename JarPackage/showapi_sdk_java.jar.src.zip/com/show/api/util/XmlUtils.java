/*     */ package com.show.api.util;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import javax.xml.validation.Schema;
/*     */ import javax.xml.validation.SchemaFactory;
/*     */ import javax.xml.validation.Validator;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XmlUtils
/*     */ {
/*     */   private static final String XMLNS_XSI = "xmlns:xsi";
/*     */   private static final String XSI_SCHEMA_LOCATION = "xsi:schemaLocation";
/*     */   private static final String LOGIC_YES = "yes";
/*     */   private static final String DEFAULT_CHARSET = "UTF-8";
/*     */   
/*     */   public static Document newDocument() throws Exception {
/*  66 */     Document doc = null;
/*     */     
/*     */     try {
/*  69 */       doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
/*  70 */     } catch (ParserConfigurationException e) {
/*  71 */       throw e;
/*     */     } 
/*     */     
/*  74 */     return doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document getDocument(File file) throws Exception {
/*  85 */     InputStream in = getInputStream(file);
/*  86 */     return getDocument(new InputSource(in), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Document getDocument(InputSource xml, InputStream xsd) throws Exception {
/*  97 */     Document doc = null;
/*     */     
/*     */     try {
/* 100 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 101 */       if (xsd != null) {
/* 102 */         dbf.setNamespaceAware(true);
/*     */       }
/*     */       
/* 105 */       DocumentBuilder builder = dbf.newDocumentBuilder();
/* 106 */       doc = builder.parse(xml);
/*     */       
/* 108 */       if (xsd != null) {
/* 109 */         validateXml(doc, xsd);
/*     */       }
/* 111 */     } catch (ParserConfigurationException e) {
/* 112 */       throw e;
/* 113 */     } catch (SAXException e) {
/* 114 */       throw new Exception("XML_PARSE_ERROR", e);
/* 115 */     } catch (IOException e) {
/* 116 */       throw new Exception("XML_READ_ERROR", e);
/*     */     } finally {
/* 118 */       closeStream(xml.getByteStream());
/*     */     } 
/*     */     
/* 121 */     return doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element createRootElement(String tagName) throws Exception {
/* 132 */     Document doc = newDocument();
/* 133 */     Element root = doc.createElement(tagName);
/* 134 */     doc.appendChild(root);
/* 135 */     return root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element getRootElementFromStream(InputStream xml) throws Exception {
/* 146 */     return getDocument(new InputSource(xml), null).getDocumentElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element getRootElementFromStream(InputStream xml, InputStream xsd) throws Exception {
/* 157 */     return getDocument(new InputSource(xml), xsd).getDocumentElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element getRootElementFromFile(File xml) throws Exception {
/* 168 */     return getDocument(xml).getDocumentElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element getRootElementFromString(String payload) throws Exception {
/* 179 */     if (payload == null || payload.length() < 1) {
/* 180 */       throw new Exception("XML_PAYLOAD_EMPTY");
/*     */     }
/*     */     
/* 183 */     StringReader sr = new StringReader(escapeXml(payload));
/* 184 */     InputSource source = new InputSource(sr);
/* 185 */     return getDocument(source, null).getDocumentElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Element> getElements(Element parent, String tagName) {
/* 196 */     NodeList nodes = parent.getElementsByTagName(tagName);
/* 197 */     List<Element> elements = new ArrayList<Element>();
/*     */     
/* 199 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 200 */       Node node = nodes.item(i);
/* 201 */       if (node instanceof Element) {
/* 202 */         elements.add((Element)node);
/*     */       }
/*     */     } 
/*     */     
/* 206 */     return elements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element getElement(Element parent, String tagName) {
/* 217 */     List<Element> children = getElements(parent, tagName);
/*     */     
/* 219 */     if (children.isEmpty()) {
/* 220 */       return null;
/*     */     }
/* 222 */     return children.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Element> getChildElements(Element parent, String tagName) {
/* 234 */     NodeList nodes = parent.getElementsByTagName(tagName);
/* 235 */     List<Element> elements = new ArrayList<Element>();
/*     */     
/* 237 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 238 */       Node node = nodes.item(i);
/* 239 */       if (node instanceof Element && node.getParentNode() == parent) {
/* 240 */         elements.add((Element)node);
/*     */       }
/*     */     } 
/*     */     
/* 244 */     return elements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Element> getChildElements(Element parent) {
/* 254 */     NodeList nodes = parent.getChildNodes();
/* 255 */     List<Element> elements = new ArrayList<Element>();
/*     */     
/* 257 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 258 */       Node node = nodes.item(i);
/* 259 */       if (node instanceof Element && node.getParentNode() == parent) {
/* 260 */         elements.add((Element)node);
/*     */       }
/*     */     } 
/*     */     
/* 264 */     return elements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element getChildElement(Element parent, String tagName) {
/* 275 */     List<Element> children = getChildElements(parent, tagName);
/*     */     
/* 277 */     if (children.isEmpty()) {
/* 278 */       return null;
/*     */     }
/* 280 */     return children.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getElementValue(Element parent, String tagName) {
/* 294 */     Element element = getElement(parent, tagName);
/* 295 */     if (element != null) {
/* 296 */       return element.getTextContent();
/*     */     }
/* 298 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getChildElementValue(Element parent, String tagName) {
/* 312 */     Element element = getChildElement(parent, tagName);
/* 313 */     if (element != null) {
/* 314 */       return element.getTextContent();
/*     */     }
/* 316 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getElementValue(Element element) {
/* 327 */     if (element != null) {
/* 328 */       NodeList nodes = element.getChildNodes();
/* 329 */       if (nodes != null && nodes.getLength() > 0) {
/* 330 */         for (int i = 0; i < nodes.getLength(); i++) {
/* 331 */           Node node = nodes.item(i);
/* 332 */           if (node instanceof Text) {
/* 333 */             return ((Text)node).getData();
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 339 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getAttributeValue(Element current, String attrName) {
/* 350 */     if (current.hasAttribute(attrName)) {
/* 351 */       return current.getAttribute(attrName);
/*     */     }
/* 353 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element appendElement(Element parent, String tagName) {
/* 365 */     Element child = parent.getOwnerDocument().createElement(tagName);
/* 366 */     parent.appendChild(child);
/* 367 */     return child;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element appendElement(Element parent, String tagName, String value) {
/* 379 */     Element child = appendElement(parent, tagName);
/* 380 */     child.setTextContent(value);
/* 381 */     return child;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendElement(Element parent, Element child) {
/* 391 */     Node tmp = parent.getOwnerDocument().importNode(child, true);
/* 392 */     parent.appendChild(tmp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element appendCDATAElement(Element parent, String tagName, String value) {
/* 404 */     Element child = appendElement(parent, tagName);
/* 405 */     if (value == null) {
/* 406 */       value = "";
/*     */     }
/*     */     
/* 409 */     Node cdata = child.getOwnerDocument().createCDATASection(value);
/* 410 */     child.appendChild(cdata);
/* 411 */     return child;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String childNodeToString(Node node) throws Exception {
/* 422 */     String payload = null;
/*     */     
/*     */     try {
/* 425 */       Transformer tf = TransformerFactory.newInstance().newTransformer();
/*     */       
/* 427 */       Properties props = tf.getOutputProperties();
/* 428 */       props.setProperty("omit-xml-declaration", "yes");
/* 429 */       props.setProperty("encoding", "UTF-8");
/* 430 */       tf.setOutputProperties(props);
/*     */       
/* 432 */       StringWriter writer = new StringWriter();
/* 433 */       tf.transform(new DOMSource(node), new StreamResult(writer));
/* 434 */       payload = escapeXml(writer.toString());
/* 435 */     } catch (TransformerException e) {
/* 436 */       throw new Exception("XML_TRANSFORM_ERROR", e);
/*     */     } 
/*     */     
/* 439 */     return payload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nodeToString(Node node) throws Exception {
/* 450 */     String payload = null;
/*     */     
/*     */     try {
/* 453 */       Transformer tf = TransformerFactory.newInstance().newTransformer();
/*     */       
/* 455 */       Properties props = tf.getOutputProperties();
/* 456 */       props.setProperty("encoding", "UTF-8");
/* 457 */       props.setProperty("indent", "yes");
/* 458 */       tf.setOutputProperties(props);
/*     */       
/* 460 */       StringWriter writer = new StringWriter();
/* 461 */       tf.transform(new DOMSource(node), new StreamResult(writer));
/* 462 */       payload = escapeXml(writer.toString());
/* 463 */     } catch (TransformerException e) {
/* 464 */       throw new Exception("XML_TRANSFORM_ERROR", e);
/*     */     } 
/*     */     
/* 467 */     return payload;
/*     */   }
/*     */   
/*     */   public static String escapeXml(String payload) {
/* 471 */     StringBuilder out = new StringBuilder();
/* 472 */     for (int i = 0; i < payload.length(); i++) {
/* 473 */       char c = payload.charAt(i);
/* 474 */       if (c == '\t' || c == '\n' || c == '\r' || (c >= ' ' && c <= '퟿') || (c >= '' && c <= '�') || (c >= 65536 && c <= 1114111))
/*     */       {
/* 476 */         out.append(c); } 
/*     */     } 
/* 478 */     return out.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String xmlToString(File file) throws Exception {
/* 489 */     Element root = getRootElementFromFile(file);
/* 490 */     return nodeToString(root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String xmlToString(InputStream in) throws Exception {
/* 501 */     Element root = getRootElementFromStream(in);
/* 502 */     return nodeToString(root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveToXml(Node doc, File file) throws Exception {
/* 513 */     saveToXml(doc, file, "UTF-8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveToXml(Node doc, File file, String charset) throws Exception {
/* 525 */     Writer writer = null;
/*     */     
/*     */     try {
/* 528 */       Transformer tf = TransformerFactory.newInstance().newTransformer();
/*     */       
/* 530 */       Properties props = tf.getOutputProperties();
/* 531 */       props.setProperty("method", "xml");
/* 532 */       props.setProperty("indent", "yes");
/* 533 */       tf.setOutputProperties(props);
/*     */       
/* 535 */       DOMSource dom = new DOMSource(doc);
/* 536 */       writer = new OutputStreamWriter(getOutputStream(file), charset);
/* 537 */       Result result = new StreamResult(writer);
/* 538 */       tf.transform(dom, result);
/* 539 */     } catch (Exception e) {
/* 540 */       throw new Exception("XML_WRITE_FILE_ERROR", e);
/*     */     } finally {
/* 542 */       closeStream(writer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateXml(InputStream xml, InputStream xsd) throws Exception {
/*     */     try {
/* 555 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 556 */       dbf.setNamespaceAware(true);
/* 557 */       Document doc = dbf.newDocumentBuilder().parse(xml);
/* 558 */       validateXml(doc, xsd);
/* 559 */     } catch (SAXException e) {
/* 560 */       throw new Exception("XML_VALIDATE_ERROR", e);
/* 561 */     } catch (Exception e) {
/* 562 */       throw new Exception("XML_READ_ERROR", e);
/*     */     } finally {
/* 564 */       closeStream(xml);
/* 565 */       closeStream(xsd);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateXml(Node root, InputStream xsd) throws Exception {
/*     */     try {
/* 578 */       Source source = new StreamSource(xsd);
/* 579 */       Schema schema = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema").newSchema(source);
/*     */       
/* 581 */       Validator validator = schema.newValidator();
/* 582 */       validator.validate(new DOMSource(root));
/* 583 */     } catch (SAXException e) {
/*     */ 
/*     */ 
/*     */       
/* 587 */       throw new Exception("XML_VALIDATE_ERROR", e);
/* 588 */     } catch (Exception e) {
/* 589 */       throw new Exception("XML_READ_ERROR", e);
/*     */     } finally {
/* 591 */       closeStream(xsd);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String xmlToHtml(String payload, File xsltFile) throws Exception {
/* 604 */     String result = null;
/*     */     
/*     */     try {
/* 607 */       Source template = new StreamSource(xsltFile);
/* 608 */       Transformer transformer = TransformerFactory.newInstance().newTransformer(template);
/*     */       
/* 610 */       Properties props = transformer.getOutputProperties();
/* 611 */       props.setProperty("omit-xml-declaration", "yes");
/* 612 */       transformer.setOutputProperties(props);
/*     */       
/* 614 */       StreamSource source = new StreamSource(new StringReader(payload));
/* 615 */       StreamResult sr = new StreamResult(new StringWriter());
/* 616 */       transformer.transform(source, sr);
/*     */       
/* 618 */       result = sr.getWriter().toString();
/* 619 */     } catch (TransformerException e) {
/* 620 */       throw new Exception("XML_TRANSFORM_ERROR", e);
/*     */     } 
/*     */     
/* 623 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setNamespace(Element element, String namespace, String schemaLocation) {
/* 634 */     element.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", namespace);
/* 635 */     element.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
/* 636 */     element.setAttributeNS("http://www.w3.org/2001/XMLSchema-instance", "xsi:schemaLocation", schemaLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeXml(String payload) throws Exception {
/* 647 */     Element root = createRootElement("xml");
/* 648 */     root.setTextContent(payload);
/* 649 */     return childNodeToString(root.getFirstChild());
/*     */   }
/*     */   
/*     */   private static void closeStream(Closeable stream) {
/* 653 */     if (stream != null) {
/*     */       try {
/* 655 */         stream.close();
/* 656 */       } catch (IOException e) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static InputStream getInputStream(File file) throws Exception {
/* 662 */     InputStream in = null;
/*     */     
/*     */     try {
/* 665 */       in = new FileInputStream(file);
/* 666 */     } catch (FileNotFoundException e) {
/* 667 */       throw new Exception("XML_FILE_NOT_FOUND", e);
/*     */     } 
/*     */     
/* 670 */     return in;
/*     */   }
/*     */   
/*     */   private static OutputStream getOutputStream(File file) throws Exception {
/* 674 */     OutputStream in = null;
/*     */     
/*     */     try {
/* 677 */       in = new FileOutputStream(file);
/* 678 */     } catch (FileNotFoundException e) {
/* 679 */       throw new Exception("XML_FILE_NOT_FOUND", e);
/*     */     } 
/*     */     
/* 682 */     return in;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\ap\\util\XmlUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */