/*    */ package com.show.api.util;
/*    */ 
/*    */ import java.text.DateFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShowApiLogger
/*    */ {
/*    */   private static boolean needEnableLogger = true;
/*    */   
/*    */   public static void setNeedEnableLogger(boolean needEnableLogger) {
/* 26 */     ShowApiLogger.needEnableLogger = needEnableLogger;
/*    */   }
/*    */   
/*    */   public static void logCommError(Exception e, String url, String appId, Map<String, String> params) {
/* 30 */     if (!needEnableLogger)
/* 31 */       return;  if (params == null)
/* 32 */       return;  StringBuilder sb = new StringBuilder();
/* 33 */     appendLog(params, sb);
/* 34 */     logCommError(e, url, appId, sb.toString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void logCommError(Exception e, String urlStr, String appId, String bodyContent) {
/* 42 */     DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
/* 43 */     df.setTimeZone(TimeZone.getTimeZone("GMT+8"));
/* 44 */     String rspCode = "";
/* 45 */     StringBuilder sb = new StringBuilder();
/* 46 */     sb.append(df.format(new Date()));
/* 47 */     sb.append("_");
/* 48 */     sb.append(appId);
/* 49 */     sb.append("_");
/* 50 */     sb.append(urlStr);
/* 51 */     sb.append("_");
/* 52 */     sb.append(rspCode);
/* 53 */     sb.append("_");
/* 54 */     sb.append((e.getMessage() + "").replaceAll("\r\n", " "));
/* 55 */     sb.append(bodyContent);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static void appendLog(Map<String, String> map, StringBuilder sb) {
/* 61 */     boolean first = true;
/* 62 */     Set<Map.Entry<String, String>> set = map.entrySet();
/* 63 */     for (Map.Entry<String, String> entry : set) {
/* 64 */       if (!first) {
/* 65 */         sb.append("&");
/*    */       } else {
/* 67 */         first = false;
/*    */       } 
/* 69 */       sb.append(entry.getKey()).append("=").append(entry.getValue());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\ap\\util\ShowApiLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */