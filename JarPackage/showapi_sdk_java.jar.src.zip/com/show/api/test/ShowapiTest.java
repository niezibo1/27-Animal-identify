/*    */ package com.show.api.test;
/*    */ 
/*    */ import com.show.api.NormalRequest;
/*    */ import com.show.api.ShowApiRequest;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShowapiTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 15 */     File file = new File("d:\\validity.jpg");
/* 16 */     String res = ShowApiRequest.fileToBase64(file);
/* 17 */     System.out.println(res);
/* 18 */     res = "";
/* 19 */     res = NormalRequest.fileToBase64(file);
/* 20 */     System.out.println(res);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\api\test\ShowapiTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */