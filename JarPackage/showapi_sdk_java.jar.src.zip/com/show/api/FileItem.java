/*     */ package com.show.api;
/*     */ 
/*     */ import com.show.api.util.ShowApiUtils;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileItem
/*     */ {
/*     */   private String fileName;
/*     */   private String mimeType;
/*     */   private byte[] content;
/*     */   private File file;
/*     */   
/*     */   public FileItem(File file) {
/*  28 */     this.file = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileItem(String filePath) {
/*  37 */     this(new File(filePath));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileItem(String fileName, byte[] content) {
/*  47 */     this.fileName = fileName;
/*  48 */     this.content = content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileItem(String fileName, byte[] content, String mimeType) {
/*  59 */     this(fileName, content);
/*  60 */     this.mimeType = mimeType;
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  64 */     if (this.fileName == null && this.file != null && this.file.exists()) {
/*  65 */       this.fileName = this.file.getName();
/*     */     }
/*  67 */     return this.fileName;
/*     */   }
/*     */   
/*     */   public String getMimeType() throws IOException {
/*  71 */     if (this.mimeType == null) {
/*  72 */       this.mimeType = ShowApiUtils.getMimeType(getContent());
/*     */     }
/*  74 */     return this.mimeType;
/*     */   }
/*     */   
/*     */   public byte[] getContent() throws IOException {
/*  78 */     if (this.content == null && this.file != null && this.file.exists()) {
/*  79 */       InputStream in = null;
/*  80 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/*     */       try {
/*  82 */         byte[] tempbytes = new byte[1024];
/*  83 */         int byteread = 0;
/*  84 */         in = new FileInputStream(this.file);
/*     */         
/*  86 */         while ((byteread = in.read(tempbytes)) != -1) {
/*  87 */           out.write(tempbytes, 0, byteread);
/*     */         }
/*  89 */         this.content = out.toByteArray();
/*  90 */       } catch (Exception e1) {
/*  91 */         e1.printStackTrace();
/*     */       } finally {
/*  93 */         if (in != null) {
/*     */           try {
/*  95 */             in.close();
/*  96 */             out.close();
/*  97 */           } catch (IOException e1) {
/*  98 */             e1.printStackTrace();
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 105 */     return this.content;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\api\FileItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */