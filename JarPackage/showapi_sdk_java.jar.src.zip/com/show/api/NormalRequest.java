/*     */ package com.show.api;
/*     */ 
/*     */ import com.show.api.util.StringUtils;
/*     */ import com.show.api.util.WebUtils;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.bind.DatatypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NormalRequest
/*     */ {
/*  24 */   protected int connectTimeout = 3000;
/*  25 */   protected int readTimeout = 15000;
/*  26 */   protected String charset = "utf-8";
/*  27 */   protected String charset_out = "utf-8";
/*  28 */   protected int limitReadSize = 0;
/*  29 */   Proxy proxy = null;
/*     */   protected boolean printException = true;
/*     */   protected boolean allowRedirect = true;
/*  32 */   protected byte[] body = null;
/*  33 */   protected String bodyString = null; protected String url;
/*  34 */   protected int res_status = 200;
/*     */   static {
/*  36 */     System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
/*     */   }
/*     */   public boolean isAllowRedirect() {
/*  39 */     return this.allowRedirect;
/*     */   }
/*     */   
/*     */   public NormalRequest setAllowRedirect(boolean allowRedirect) {
/*  43 */     this.allowRedirect = allowRedirect;
/*  44 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isPrintException() {
/*  48 */     return this.printException;
/*     */   }
/*     */   
/*     */   public NormalRequest setPrintException(boolean printException) {
/*  52 */     this.printException = printException;
/*  53 */     return this;
/*     */   }
/*     */   
/*     */   public int getLimitReadSize() {
/*  57 */     return this.limitReadSize;
/*     */   }
/*     */   public NormalRequest setLimitReadSize(int size) {
/*  60 */     this.limitReadSize = size;
/*  61 */     return this;
/*     */   }
/*     */   
/*     */   public NormalRequest setProxy(String proxyIp, int proxyPort) {
/*  65 */     this.proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyIp, proxyPort));
/*  66 */     return this;
/*     */   }
/*     */   
/*     */   public Proxy getProxy() {
/*  70 */     return this.proxy;
/*     */   }
/*     */   
/*     */   public String getCharset_out() {
/*  74 */     return this.charset_out;
/*     */   }
/*     */   
/*     */   public NormalRequest setCharset_out(String charset_out) {
/*  78 */     this.charset_out = charset_out;
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBodyString() {
/*  84 */     return this.bodyString;
/*     */   }
/*     */   
/*     */   public NormalRequest setBodyString(String bodyString) {
/*  88 */     this.bodyString = bodyString;
/*  89 */     return this;
/*     */   }
/*     */   
/*     */   public int getRes_status() {
/*  93 */     return this.res_status;
/*     */   }
/*     */   
/*     */   public NormalRequest setRes_status(int res_status) {
/*  97 */     this.res_status = res_status;
/*  98 */     return this;
/*     */   }
/*     */   
/*     */   public byte[] getBody() {
/* 102 */     return this.body;
/*     */   }
/*     */   
/*     */   public NormalRequest setBody(byte[] body) {
/* 106 */     this.body = body;
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   protected Map<String, String> textMap = new HashMap<String, String>();
/* 114 */   protected Map<String, File> uploadMap = new HashMap<String, File>();
/* 115 */   protected Map<String, String> headMap = new HashMap<String, String>();
/* 116 */   protected Map<String, List<String>> res_headMap = new HashMap<String, List<String>>();
/*     */   
/*     */   public Map<String, List<String>> getRes_headMap() {
/* 119 */     return this.res_headMap;
/*     */   }
/*     */   
/*     */   public void setRes_headMap(Map<String, List<String>> res_headMap) {
/* 123 */     this.res_headMap = res_headMap;
/*     */   }
/*     */   
/*     */   public NormalRequest() {
/* 127 */     addHeadPara("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2427.7 Safari/537.36");
/*     */   }
/*     */   
/*     */   public NormalRequest(String url) {
/* 131 */     this.url = url;
/*     */     
/* 133 */     addHeadPara("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2427.7 Safari/537.36");
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getTextMap() {
/* 138 */     return this.textMap;
/*     */   }
/*     */   public void setTextMap(Map<String, String> textMap) {
/* 141 */     this.textMap = textMap;
/*     */   }
/*     */   public String getUrl() {
/* 144 */     return this.url;
/*     */   }
/*     */   public String getCharset() {
/* 147 */     return this.charset;
/*     */   }
/*     */   public Map<String, File> getUploadMap() {
/* 150 */     return this.uploadMap;
/*     */   }
/*     */   public void setUploadMap(Map<String, File> uploadMap) {
/* 153 */     this.uploadMap = uploadMap;
/*     */   }
/*     */   public Map<String, String> getHeadMap() {
/* 156 */     return this.headMap;
/*     */   }
/*     */   public void setHeadMap(Map<String, String> headMap) {
/* 159 */     this.headMap = headMap;
/*     */   }
/*     */   public int getConnectTimeout() {
/* 162 */     return this.connectTimeout;
/*     */   }
/*     */   public int getReadTimeout() {
/* 165 */     return this.readTimeout;
/*     */   }
/*     */   public NormalRequest setConnectTimeout(int connectTimeout) {
/* 168 */     this.connectTimeout = connectTimeout;
/* 169 */     return this;
/*     */   }
/*     */   public NormalRequest setReadTimeout(int readTimeout) {
/* 172 */     this.readTimeout = readTimeout;
/* 173 */     return this;
/*     */   }
/*     */   
/*     */   public NormalRequest setCharset(String charset) {
/* 177 */     this.charset = charset;
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NormalRequest setUrl(String url) {
/* 186 */     this.url = url;
/* 187 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NormalRequest addTextPara(String key, String value) {
/* 195 */     this.textMap.put(key, value);
/* 196 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NormalRequest addFilePara(String key, File item) {
/* 203 */     this.uploadMap.put(key, item);
/* 204 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NormalRequest addHeadPara(String key, Object value) {
/* 210 */     if (value != null) {
/* 211 */       this.headMap.put(key, value.toString());
/*     */     } else {
/* 213 */       this.headMap.put(key, "");
/*     */     } 
/* 215 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NormalRequest addHeads(String heads) {
/*     */     String[] hs;
/* 224 */     if (StringUtils.isEmpty(heads) || !heads.contains("\n")) {
/* 225 */       return this;
/*     */     }
/*     */     
/* 228 */     if (heads.contains("\r\n"))
/* 229 */     { hs = heads.split("\r\n"); }
/* 230 */     else if (heads.contains("\n"))
/* 231 */     { hs = heads.split("\n"); }
/* 232 */     else { if (heads.contains(":")) {
/* 233 */         String pre = "";
/* 234 */         if (heads.startsWith(":")) {
/* 235 */           pre = ":";
/* 236 */           heads = heads.substring(1);
/*     */         } 
/* 238 */         if (heads.contains(":")) {
/* 239 */           String[] kv = heads.split(":");
/* 240 */           this.headMap.put(pre + kv[0].trim(), kv[1].trim());
/*     */         } 
/* 242 */         return this;
/*     */       } 
/* 244 */       return this; }
/*     */     
/* 246 */     for (String h : hs) {
/* 247 */       if (!h.trim().equals("") && h.contains(":")) {
/*     */ 
/*     */         
/* 250 */         String pre = "";
/* 251 */         if (h.startsWith(":")) {
/* 252 */           pre = ":";
/* 253 */           h = h.substring(1);
/*     */         } 
/* 255 */         if (h.contains(":")) {
/* 256 */           String[] kv = h.split(":");
/* 257 */           this.headMap.put(pre + kv[0].trim(), kv[1].trim());
/*     */         } 
/*     */       } 
/* 260 */     }  return this;
/*     */   }
/*     */   
/*     */   public String post() {
/* 264 */     String res = "";
/*     */     try {
/* 266 */       res = WebUtils.doPost(this);
/* 267 */     } catch (Exception e) {
/* 268 */       if (this.printException) e.printStackTrace(); 
/* 269 */       res = "{\"ret_code\":-1,\"error\":\"" + e.toString() + "\"}";
/*     */     } 
/* 271 */     return res;
/*     */   }
/*     */   
/*     */   public byte[] postAsByte() {
/* 275 */     byte[] res = null;
/*     */     try {
/* 277 */       res = WebUtils.doPostAsByte(this);
/* 278 */     } catch (Exception e) {
/* 279 */       if (this.printException) e.printStackTrace(); 
/*     */       try {
/* 281 */         res = ("{\"ret_code\":-1,\"error\":\"" + e.toString() + "\"}").getBytes("utf-8");
/* 282 */       } catch (UnsupportedEncodingException e1) {
/* 283 */         if (this.printException) e1.printStackTrace(); 
/*     */       } 
/*     */     } 
/* 286 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   public String get() {
/* 291 */     String res = "";
/*     */     try {
/* 293 */       res = WebUtils.doGet(this);
/* 294 */     } catch (Exception e) {
/* 295 */       if (this.printException) e.printStackTrace(); 
/* 296 */       res = "{\"ret_code\":-1,\"error\":\"" + e.toString() + "\"}";
/*     */     } 
/* 298 */     return res;
/*     */   }
/*     */   
/*     */   public byte[] getAsByte() {
/* 302 */     byte[] res = null;
/*     */     try {
/* 304 */       res = WebUtils.doGetAsByte(this);
/* 305 */     } catch (Exception e) {
/* 306 */       if (this.printException) e.printStackTrace(); 
/*     */       try {
/* 308 */         res = ("{\"ret_code\":-1,\"error\":\"" + e.toString() + "\"}").getBytes("utf-8");
/* 309 */       } catch (UnsupportedEncodingException e1) {
/* 310 */         if (this.printException) e1.printStackTrace(); 
/*     */       } 
/*     */     } 
/* 313 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String fileToBase64(File file) {
/* 318 */     byte[] buffer = null;
/*     */     try {
/* 320 */       FileInputStream fis = new FileInputStream(file);
/* 321 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 322 */       byte[] b = new byte[1024];
/*     */       int n;
/* 324 */       while ((n = fis.read(b)) != -1)
/*     */       {
/* 326 */         bos.write(b, 0, n);
/*     */       }
/* 328 */       fis.close();
/* 329 */       bos.close();
/* 330 */       buffer = bos.toByteArray();
/* 331 */     } catch (FileNotFoundException e) {
/* 332 */       e.printStackTrace();
/* 333 */     } catch (IOException e) {
/* 334 */       e.printStackTrace();
/*     */     } 
/* 336 */     String str = DatatypeConverter.printBase64Binary(buffer);
/* 337 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\api\NormalRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */