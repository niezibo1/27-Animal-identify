/*    */ package com.show.api;
/*    */ 
/*    */ import com.show.api.util.ShowApiUtils;
/*    */ import com.show.api.util.WebUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShowApiRequest
/*    */   extends NormalRequest
/*    */ {
/*    */   private String appSecret;
/*    */   
/*    */   public ShowApiRequest(String url, String appid, String appSecret) {
/* 17 */     super(url);
/* 18 */     this.appSecret = appSecret;
/* 19 */     addTextPara("showapi_appid", appid);
/* 20 */     addHeadPara("User-Agent", "showapi-sdk-java");
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAppSecret() {
/* 25 */     return this.appSecret;
/*    */   }
/*    */   
/*    */   public void setAppSecret(String appSecret) {
/* 29 */     this.appSecret = appSecret;
/*    */   }
/*    */ 
/*    */   
/*    */   public String post() {
/* 34 */     String res = null;
/*    */     try {
/* 36 */       byte[] b = postAsByte();
/* 37 */       res = new String(b, "utf-8");
/* 38 */     } catch (Exception e) {
/* 39 */       if (this.printException) e.printStackTrace(); 
/*    */     } 
/* 41 */     return res;
/*    */   }
/*    */   
/*    */   public byte[] postAsByte() {
/* 45 */     byte[] res = null;
/*    */     try {
/* 47 */       String signResult = addSign();
/* 48 */       if (signResult != null) return signResult.getBytes("utf-8"); 
/* 49 */       res = WebUtils.doPostAsByte(this);
/* 50 */     } catch (Exception e) {
/* 51 */       e.printStackTrace();
/*    */       try {
/* 53 */         res = ("{\"showapi_res_code\":-1,\"showapi_res_error\":\"" + e.toString() + "\"}").getBytes("utf-8");
/* 54 */       } catch (UnsupportedEncodingException e1) {
/* 55 */         e1.printStackTrace();
/*    */       } 
/*    */     } 
/* 58 */     return res;
/*    */   }
/*    */   
/*    */   private String addSign() throws IOException {
/* 62 */     if (this.textMap.get("showapi_appid") == null) return errorMsg("showapi_appid不得为空!"); 
/* 63 */     this.textMap.put("showapi_sign", ShowApiUtils.signRequest(this.textMap, this.appSecret));
/* 64 */     return null;
/*    */   }
/*    */   
/*    */   public String get() {
/* 68 */     String res = null;
/*    */     try {
/* 70 */       byte[] b = getAsByte();
/* 71 */       res = new String(b, "utf-8");
/* 72 */     } catch (Exception e) {
/* 73 */       e.printStackTrace();
/* 74 */       res = "{\"showapi_res_code\":-1,\"showapi_res_error\":\"" + e.toString() + "\"}";
/*    */     } 
/* 76 */     return res;
/*    */   }
/*    */   
/*    */   public byte[] getAsByte() {
/* 80 */     byte[] res = null;
/*    */     try {
/* 82 */       String signResult = addSign();
/* 83 */       if (signResult != null) return signResult.getBytes("utf-8"); 
/* 84 */       res = WebUtils.doGetAsByte(this);
/* 85 */     } catch (Exception e) {
/* 86 */       e.printStackTrace();
/*    */       try {
/* 88 */         res = ("{\"showapi_res_code\":-1,\"showapi_res_error\":\"" + e.toString() + "\"}").getBytes("utf-8");
/* 89 */       } catch (UnsupportedEncodingException e1) {
/* 90 */         e1.printStackTrace();
/*    */       } 
/*    */     } 
/* 93 */     return res;
/*    */   }
/*    */   
/*    */   private String errorMsg(String msg) {
/* 97 */     String str = "{\"showapi_res_code\":-1,\"showapi_res_error\":\"" + msg + "\",\"" + "showapi_res_body" + "\":{}}";
/* 98 */     return str;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\showapi_sdk_java.jar!\com\show\api\ShowApiRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */