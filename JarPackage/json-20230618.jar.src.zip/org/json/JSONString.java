package org.json;

public interface JSONString {
  String toJSONString();
}


/* Location:              D:\JarPackage\json-20230618.jar!\org\json\JSONString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */