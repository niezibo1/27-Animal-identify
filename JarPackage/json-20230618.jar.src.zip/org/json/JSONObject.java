/*      */ package org.json;
/*      */ 
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JSONObject
/*      */ {
/*      */   private static final class Null
/*      */   {
/*      */     private Null() {}
/*      */     
/*      */     protected final Object clone() {
/*  100 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(Object object) {
/*  114 */       return (object == null || object == this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  123 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  133 */       return "null";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   static final Pattern NUMBER_PATTERN = Pattern.compile("-?(?:0|[1-9]\\d*)(?:\\.\\d+)?(?:[eE][+-]?\\d+)?");
/*      */ 
/*      */   
/*      */   private final Map<String, Object> map;
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<? extends Map> getMapType() {
/*  149 */     return (Class)this.map.getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   public static final Object NULL = new Null();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject() {
/*  170 */     this.map = new HashMap<String, Object>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject(JSONObject jo, String... names) {
/*  184 */     this(names.length);
/*  185 */     for (int i = 0; i < names.length; i++) {
/*      */       try {
/*  187 */         putOnce(names[i], jo.opt(names[i]));
/*  188 */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject(JSONTokener x) throws JSONException {
/*  203 */     this();
/*      */ 
/*      */ 
/*      */     
/*  207 */     if (x.nextClean() != '{') {
/*  208 */       throw x.syntaxError("A JSONObject text must begin with '{'");
/*      */     }
/*      */     while (true) {
/*  211 */       char prev = x.getPrevious();
/*  212 */       char c = x.nextClean();
/*  213 */       switch (c) {
/*      */         case '\000':
/*  215 */           throw x.syntaxError("A JSONObject text must end with '}'");
/*      */         case '}':
/*      */           return;
/*      */         case '[':
/*      */         case '{':
/*  220 */           if (prev == '{') {
/*  221 */             throw x.syntaxError("A JSON Object can not directly nest another JSON Object or JSON Array.");
/*      */           }
/*      */           break;
/*      */       } 
/*  225 */       x.back();
/*  226 */       String key = x.nextValue().toString();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  231 */       c = x.nextClean();
/*  232 */       if (c != ':') {
/*  233 */         throw x.syntaxError("Expected a ':' after a key");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  238 */       if (key != null) {
/*      */         
/*  240 */         if (opt(key) != null)
/*      */         {
/*  242 */           throw x.syntaxError("Duplicate key \"" + key + "\"");
/*      */         }
/*      */         
/*  245 */         Object value = x.nextValue();
/*  246 */         if (value != null) {
/*  247 */           put(key, value);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  253 */       switch (x.nextClean()) {
/*      */         case ',':
/*      */         case ';':
/*  256 */           if (x.nextClean() == '}') {
/*      */             return;
/*      */           }
/*  259 */           x.back(); continue;
/*      */         case '}':
/*      */           return;
/*      */       }  break;
/*      */     } 
/*  264 */     throw x.syntaxError("Expected a ',' or '}'");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject(Map<?, ?> m) {
/*  281 */     if (m == null) {
/*  282 */       this.map = new HashMap<String, Object>();
/*      */     } else {
/*  284 */       this.map = new HashMap<String, Object>(m.size());
/*  285 */       for (Map.Entry<?, ?> e : m.entrySet()) {
/*  286 */         if (e.getKey() == null) {
/*  287 */           throw new NullPointerException("Null key.");
/*      */         }
/*  289 */         Object value = e.getValue();
/*  290 */         if (value != null) {
/*  291 */           this.map.put(String.valueOf(e.getKey()), wrap(value));
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject(Object bean) {
/*  356 */     this();
/*  357 */     populateMap(bean);
/*      */   }
/*      */   
/*      */   private JSONObject(Object bean, Set<Object> objectsRecord) {
/*  361 */     this();
/*  362 */     populateMap(bean, objectsRecord);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject(Object object, String... names) {
/*  380 */     this(names.length);
/*  381 */     Class<?> c = object.getClass();
/*  382 */     for (int i = 0; i < names.length; i++) {
/*  383 */       String name = names[i];
/*      */       try {
/*  385 */         putOpt(name, c.getField(name).get(object));
/*  386 */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject(String source) throws JSONException {
/*  404 */     this(new JSONTokener(source));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject(String baseName, Locale locale) throws JSONException {
/*  418 */     this();
/*  419 */     ResourceBundle bundle = ResourceBundle.getBundle(baseName, locale, 
/*  420 */         Thread.currentThread().getContextClassLoader());
/*      */ 
/*      */ 
/*      */     
/*  424 */     Enumeration<String> keys = bundle.getKeys();
/*  425 */     while (keys.hasMoreElements()) {
/*  426 */       Object key = keys.nextElement();
/*  427 */       if (key != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  433 */         String[] path = ((String)key).split("\\.");
/*  434 */         int last = path.length - 1;
/*  435 */         JSONObject target = this;
/*  436 */         for (int i = 0; i < last; i++) {
/*  437 */           String segment = path[i];
/*  438 */           JSONObject nextTarget = target.optJSONObject(segment);
/*  439 */           if (nextTarget == null) {
/*  440 */             nextTarget = new JSONObject();
/*  441 */             target.put(segment, nextTarget);
/*      */           } 
/*  443 */           target = nextTarget;
/*      */         } 
/*  445 */         target.put(path[last], bundle.getString((String)key));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JSONObject(int initialCapacity) {
/*  458 */     this.map = new HashMap<String, Object>(initialCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject accumulate(String key, Object value) throws JSONException {
/*  483 */     testValidity(value);
/*  484 */     Object object = opt(key);
/*  485 */     if (object == null) {
/*  486 */       put(key, (value instanceof JSONArray) ? (new JSONArray())
/*  487 */           .put(value) : value);
/*      */     }
/*  489 */     else if (object instanceof JSONArray) {
/*  490 */       ((JSONArray)object).put(value);
/*      */     } else {
/*  492 */       put(key, (new JSONArray()).put(object).put(value));
/*      */     } 
/*  494 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject append(String key, Object value) throws JSONException {
/*  515 */     testValidity(value);
/*  516 */     Object object = opt(key);
/*  517 */     if (object == null) {
/*  518 */       put(key, (new JSONArray()).put(value));
/*  519 */     } else if (object instanceof JSONArray) {
/*  520 */       put(key, ((JSONArray)object).put(value));
/*      */     } else {
/*  522 */       throw wrongValueFormatException(key, "JSONArray", null, null);
/*      */     } 
/*  524 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String doubleToString(double d) {
/*  536 */     if (Double.isInfinite(d) || Double.isNaN(d)) {
/*  537 */       return "null";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  542 */     String string = Double.toString(d);
/*  543 */     if (string.indexOf('.') > 0 && string.indexOf('e') < 0 && string
/*  544 */       .indexOf('E') < 0) {
/*  545 */       while (string.endsWith("0")) {
/*  546 */         string = string.substring(0, string.length() - 1);
/*      */       }
/*  548 */       if (string.endsWith(".")) {
/*  549 */         string = string.substring(0, string.length() - 1);
/*      */       }
/*      */     } 
/*  552 */     return string;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object get(String key) throws JSONException {
/*  565 */     if (key == null) {
/*  566 */       throw new JSONException("Null key.");
/*      */     }
/*  568 */     Object object = opt(key);
/*  569 */     if (object == null) {
/*  570 */       throw new JSONException("JSONObject[" + quote(key) + "] not found.");
/*      */     }
/*  572 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <E extends Enum<E>> E getEnum(Class<E> clazz, String key) throws JSONException {
/*  590 */     E val = optEnum(clazz, key);
/*  591 */     if (val == null)
/*      */     {
/*      */ 
/*      */       
/*  595 */       throw wrongValueFormatException(key, "enum of type " + quote(clazz.getSimpleName()), opt(key), null);
/*      */     }
/*  597 */     return val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String key) throws JSONException {
/*  611 */     Object object = get(key);
/*  612 */     if (object.equals(Boolean.FALSE) || (object instanceof String && ((String)object)
/*      */       
/*  614 */       .equalsIgnoreCase("false")))
/*  615 */       return false; 
/*  616 */     if (object.equals(Boolean.TRUE) || (object instanceof String && ((String)object)
/*      */       
/*  618 */       .equalsIgnoreCase("true"))) {
/*  619 */       return true;
/*      */     }
/*  621 */     throw wrongValueFormatException(key, "Boolean", object, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getBigInteger(String key) throws JSONException {
/*  635 */     Object object = get(key);
/*  636 */     BigInteger ret = objectToBigInteger(object, null);
/*  637 */     if (ret != null) {
/*  638 */       return ret;
/*      */     }
/*  640 */     throw wrongValueFormatException(key, "BigInteger", object, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String key) throws JSONException {
/*  657 */     Object object = get(key);
/*  658 */     BigDecimal ret = objectToBigDecimal(object, null);
/*  659 */     if (ret != null) {
/*  660 */       return ret;
/*      */     }
/*  662 */     throw wrongValueFormatException(key, "BigDecimal", object, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String key) throws JSONException {
/*  676 */     Object object = get(key);
/*  677 */     if (object instanceof Number) {
/*  678 */       return ((Number)object).doubleValue();
/*      */     }
/*      */     try {
/*  681 */       return Double.parseDouble(object.toString());
/*  682 */     } catch (Exception e) {
/*  683 */       throw wrongValueFormatException(key, "double", object, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String key) throws JSONException {
/*  698 */     Object object = get(key);
/*  699 */     if (object instanceof Number) {
/*  700 */       return ((Number)object).floatValue();
/*      */     }
/*      */     try {
/*  703 */       return Float.parseFloat(object.toString());
/*  704 */     } catch (Exception e) {
/*  705 */       throw wrongValueFormatException(key, "float", object, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number getNumber(String key) throws JSONException {
/*  720 */     Object object = get(key);
/*      */     try {
/*  722 */       if (object instanceof Number) {
/*  723 */         return (Number)object;
/*      */       }
/*  725 */       return stringToNumber(object.toString());
/*  726 */     } catch (Exception e) {
/*  727 */       throw wrongValueFormatException(key, "number", object, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String key) throws JSONException {
/*  742 */     Object object = get(key);
/*  743 */     if (object instanceof Number) {
/*  744 */       return ((Number)object).intValue();
/*      */     }
/*      */     try {
/*  747 */       return Integer.parseInt(object.toString());
/*  748 */     } catch (Exception e) {
/*  749 */       throw wrongValueFormatException(key, "int", object, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray getJSONArray(String key) throws JSONException {
/*  763 */     Object object = get(key);
/*  764 */     if (object instanceof JSONArray) {
/*  765 */       return (JSONArray)object;
/*      */     }
/*  767 */     throw wrongValueFormatException(key, "JSONArray", object, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject getJSONObject(String key) throws JSONException {
/*  780 */     Object object = get(key);
/*  781 */     if (object instanceof JSONObject) {
/*  782 */       return (JSONObject)object;
/*      */     }
/*  784 */     throw wrongValueFormatException(key, "JSONObject", object, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String key) throws JSONException {
/*  798 */     Object object = get(key);
/*  799 */     if (object instanceof Number) {
/*  800 */       return ((Number)object).longValue();
/*      */     }
/*      */     try {
/*  803 */       return Long.parseLong(object.toString());
/*  804 */     } catch (Exception e) {
/*  805 */       throw wrongValueFormatException(key, "long", object, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getNames(JSONObject jo) {
/*  817 */     if (jo.isEmpty()) {
/*  818 */       return null;
/*      */     }
/*  820 */     return jo.keySet().<String>toArray(new String[jo.length()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getNames(Object object) {
/*  831 */     if (object == null) {
/*  832 */       return null;
/*      */     }
/*  834 */     Class<?> klass = object.getClass();
/*  835 */     Field[] fields = klass.getFields();
/*  836 */     int length = fields.length;
/*  837 */     if (length == 0) {
/*  838 */       return null;
/*      */     }
/*  840 */     String[] names = new String[length];
/*  841 */     for (int i = 0; i < length; i++) {
/*  842 */       names[i] = fields[i].getName();
/*      */     }
/*  844 */     return names;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String key) throws JSONException {
/*  857 */     Object object = get(key);
/*  858 */     if (object instanceof String) {
/*  859 */       return (String)object;
/*      */     }
/*  861 */     throw wrongValueFormatException(key, "string", object, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean has(String key) {
/*  872 */     return this.map.containsKey(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject increment(String key) throws JSONException {
/*  891 */     Object value = opt(key);
/*  892 */     if (value == null) {
/*  893 */       put(key, 1);
/*  894 */     } else if (value instanceof Integer) {
/*  895 */       put(key, ((Integer)value).intValue() + 1);
/*  896 */     } else if (value instanceof Long) {
/*  897 */       put(key, ((Long)value).longValue() + 1L);
/*  898 */     } else if (value instanceof BigInteger) {
/*  899 */       put(key, ((BigInteger)value).add(BigInteger.ONE));
/*  900 */     } else if (value instanceof Float) {
/*  901 */       put(key, ((Float)value).floatValue() + 1.0F);
/*  902 */     } else if (value instanceof Double) {
/*  903 */       put(key, ((Double)value).doubleValue() + 1.0D);
/*  904 */     } else if (value instanceof BigDecimal) {
/*  905 */       put(key, ((BigDecimal)value).add(BigDecimal.ONE));
/*      */     } else {
/*  907 */       throw new JSONException("Unable to increment [" + quote(key) + "].");
/*      */     } 
/*  909 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNull(String key) {
/*  922 */     return NULL.equals(opt(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<String> keys() {
/*  934 */     return keySet().iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> keySet() {
/*  946 */     return this.map.keySet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Set<Map.Entry<String, Object>> entrySet() {
/*  962 */     return this.map.entrySet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int length() {
/*  971 */     return this.map.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/*  979 */     this.map.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  988 */     return this.map.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray names() {
/*  999 */     if (this.map.isEmpty()) {
/* 1000 */       return null;
/*      */     }
/* 1002 */     return new JSONArray(this.map.keySet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String numberToString(Number number) throws JSONException {
/* 1015 */     if (number == null) {
/* 1016 */       throw new JSONException("Null pointer");
/*      */     }
/* 1018 */     testValidity(number);
/*      */ 
/*      */ 
/*      */     
/* 1022 */     String string = number.toString();
/* 1023 */     if (string.indexOf('.') > 0 && string.indexOf('e') < 0 && string
/* 1024 */       .indexOf('E') < 0) {
/* 1025 */       while (string.endsWith("0")) {
/* 1026 */         string = string.substring(0, string.length() - 1);
/*      */       }
/* 1028 */       if (string.endsWith(".")) {
/* 1029 */         string = string.substring(0, string.length() - 1);
/*      */       }
/*      */     } 
/* 1032 */     return string;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object opt(String key) {
/* 1043 */     return (key == null) ? null : this.map.get(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <E extends Enum<E>> E optEnum(Class<E> clazz, String key) {
/* 1058 */     return optEnum(clazz, key, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <E extends Enum<E>> E optEnum(Class<E> clazz, String key, E defaultValue) {
/*      */     try {
/* 1077 */       Object val = opt(key);
/* 1078 */       if (NULL.equals(val)) {
/* 1079 */         return defaultValue;
/*      */       }
/* 1081 */       if (clazz.isAssignableFrom(val.getClass()))
/*      */       {
/*      */         
/* 1084 */         return (E)val;
/*      */       }
/*      */       
/* 1087 */       return Enum.valueOf(clazz, val.toString());
/* 1088 */     } catch (IllegalArgumentException e) {
/* 1089 */       return defaultValue;
/* 1090 */     } catch (NullPointerException e) {
/* 1091 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean optBoolean(String key) {
/* 1104 */     return optBoolean(key, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean optBoolean(String key, boolean defaultValue) {
/* 1119 */     Object val = opt(key);
/* 1120 */     if (NULL.equals(val)) {
/* 1121 */       return defaultValue;
/*      */     }
/* 1123 */     if (val instanceof Boolean) {
/* 1124 */       return ((Boolean)val).booleanValue();
/*      */     }
/*      */     
/*      */     try {
/* 1128 */       return getBoolean(key);
/* 1129 */     } catch (Exception e) {
/* 1130 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal optBigDecimal(String key, BigDecimal defaultValue) {
/* 1149 */     Object val = opt(key);
/* 1150 */     return objectToBigDecimal(val, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static BigDecimal objectToBigDecimal(Object val, BigDecimal defaultValue) {
/* 1160 */     return objectToBigDecimal(val, defaultValue, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static BigDecimal objectToBigDecimal(Object val, BigDecimal defaultValue, boolean exact) {
/* 1172 */     if (NULL.equals(val)) {
/* 1173 */       return defaultValue;
/*      */     }
/* 1175 */     if (val instanceof BigDecimal) {
/* 1176 */       return (BigDecimal)val;
/*      */     }
/* 1178 */     if (val instanceof BigInteger) {
/* 1179 */       return new BigDecimal((BigInteger)val);
/*      */     }
/* 1181 */     if (val instanceof Double || val instanceof Float) {
/* 1182 */       if (!numberIsFinite((Number)val)) {
/* 1183 */         return defaultValue;
/*      */       }
/* 1185 */       if (exact) {
/* 1186 */         return new BigDecimal(((Number)val).doubleValue());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1191 */       return new BigDecimal(val.toString());
/*      */     } 
/* 1193 */     if (val instanceof Long || val instanceof Integer || val instanceof Short || val instanceof Byte)
/*      */     {
/* 1195 */       return new BigDecimal(((Number)val).longValue());
/*      */     }
/*      */     
/*      */     try {
/* 1199 */       return new BigDecimal(val.toString());
/* 1200 */     } catch (Exception e) {
/* 1201 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger optBigInteger(String key, BigInteger defaultValue) {
/* 1217 */     Object val = opt(key);
/* 1218 */     return objectToBigInteger(val, defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static BigInteger objectToBigInteger(Object val, BigInteger defaultValue) {
/* 1228 */     if (NULL.equals(val)) {
/* 1229 */       return defaultValue;
/*      */     }
/* 1231 */     if (val instanceof BigInteger) {
/* 1232 */       return (BigInteger)val;
/*      */     }
/* 1234 */     if (val instanceof BigDecimal) {
/* 1235 */       return ((BigDecimal)val).toBigInteger();
/*      */     }
/* 1237 */     if (val instanceof Double || val instanceof Float) {
/* 1238 */       if (!numberIsFinite((Number)val)) {
/* 1239 */         return defaultValue;
/*      */       }
/* 1241 */       return (new BigDecimal(((Number)val).doubleValue())).toBigInteger();
/*      */     } 
/* 1243 */     if (val instanceof Long || val instanceof Integer || val instanceof Short || val instanceof Byte)
/*      */     {
/* 1245 */       return BigInteger.valueOf(((Number)val).longValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1254 */       String valStr = val.toString();
/* 1255 */       if (isDecimalNotation(valStr)) {
/* 1256 */         return (new BigDecimal(valStr)).toBigInteger();
/*      */       }
/* 1258 */       return new BigInteger(valStr);
/* 1259 */     } catch (Exception e) {
/* 1260 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double optDouble(String key) {
/* 1274 */     return optDouble(key, Double.NaN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double optDouble(String key, double defaultValue) {
/* 1289 */     Number val = optNumber(key);
/* 1290 */     if (val == null) {
/* 1291 */       return defaultValue;
/*      */     }
/* 1293 */     return val.doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float optFloat(String key) {
/* 1306 */     return optFloat(key, Float.NaN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float optFloat(String key, float defaultValue) {
/* 1321 */     Number val = optNumber(key);
/* 1322 */     if (val == null) {
/* 1323 */       return defaultValue;
/*      */     }
/* 1325 */     float floatValue = val.floatValue();
/*      */ 
/*      */ 
/*      */     
/* 1329 */     return floatValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int optInt(String key) {
/* 1342 */     return optInt(key, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int optInt(String key, int defaultValue) {
/* 1357 */     Number val = optNumber(key, null);
/* 1358 */     if (val == null) {
/* 1359 */       return defaultValue;
/*      */     }
/* 1361 */     return val.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray optJSONArray(String key) {
/* 1373 */     Object o = opt(key);
/* 1374 */     return (o instanceof JSONArray) ? (JSONArray)o : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject optJSONObject(String key) {
/* 1385 */     return optJSONObject(key, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject optJSONObject(String key, JSONObject defaultValue) {
/* 1398 */     Object object = opt(key);
/* 1399 */     return (object instanceof JSONObject) ? (JSONObject)object : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long optLong(String key) {
/* 1412 */     return optLong(key, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long optLong(String key, long defaultValue) {
/* 1427 */     Number val = optNumber(key, null);
/* 1428 */     if (val == null) {
/* 1429 */       return defaultValue;
/*      */     }
/*      */     
/* 1432 */     return val.longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number optNumber(String key) {
/* 1446 */     return optNumber(key, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number optNumber(String key, Number defaultValue) {
/* 1462 */     Object val = opt(key);
/* 1463 */     if (NULL.equals(val)) {
/* 1464 */       return defaultValue;
/*      */     }
/* 1466 */     if (val instanceof Number) {
/* 1467 */       return (Number)val;
/*      */     }
/*      */     
/*      */     try {
/* 1471 */       return stringToNumber(val.toString());
/* 1472 */     } catch (Exception e) {
/* 1473 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String optString(String key) {
/* 1487 */     return optString(key, "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String optString(String key, String defaultValue) {
/* 1501 */     Object object = opt(key);
/* 1502 */     return NULL.equals(object) ? defaultValue : object.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void populateMap(Object bean) {
/* 1515 */     populateMap(bean, Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>()));
/*      */   }
/*      */   
/*      */   private void populateMap(Object bean, Set<Object> objectsRecord) {
/* 1519 */     Class<?> klass = bean.getClass();
/*      */ 
/*      */ 
/*      */     
/* 1523 */     boolean includeSuperClass = (klass.getClassLoader() != null);
/*      */     
/* 1525 */     Method[] methods = includeSuperClass ? klass.getMethods() : klass.getDeclaredMethods();
/* 1526 */     for (Method method : methods) {
/* 1527 */       int modifiers = method.getModifiers();
/* 1528 */       if (Modifier.isPublic(modifiers) && 
/* 1529 */         !Modifier.isStatic(modifiers) && (method
/* 1530 */         .getParameterTypes()).length == 0 && 
/* 1531 */         !method.isBridge() && method
/* 1532 */         .getReturnType() != void.class && 
/* 1533 */         isValidMethodName(method.getName())) {
/* 1534 */         String key = getKeyNameFromMethod(method);
/* 1535 */         if (key != null && !key.isEmpty()) {
/*      */           
/* 1537 */           try { Object result = method.invoke(bean, new Object[0]);
/* 1538 */             if (result != null)
/*      */             {
/*      */ 
/*      */               
/* 1542 */               if (objectsRecord.contains(result)) {
/* 1543 */                 throw recursivelyDefinedObjectException(key);
/*      */               }
/*      */               
/* 1546 */               objectsRecord.add(result);
/*      */               
/* 1548 */               this.map.put(key, wrap(result, objectsRecord));
/*      */               
/* 1550 */               objectsRecord.remove(result);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1555 */               if (result instanceof Closeable) {
/*      */                 try {
/* 1557 */                   ((Closeable)result).close();
/* 1558 */                 } catch (IOException iOException) {}
/*      */               }
/*      */             }
/*      */              }
/* 1562 */           catch (IllegalAccessException illegalAccessException) {  }
/* 1563 */           catch (IllegalArgumentException illegalArgumentException) {  }
/* 1564 */           catch (InvocationTargetException invocationTargetException) {}
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isValidMethodName(String name) {
/* 1572 */     return (!"getClass".equals(name) && !"getDeclaringClass".equals(name));
/*      */   }
/*      */   private static String getKeyNameFromMethod(Method method) {
/*      */     String key;
/* 1576 */     int ignoreDepth = getAnnotationDepth(method, (Class)JSONPropertyIgnore.class);
/* 1577 */     if (ignoreDepth > 0) {
/* 1578 */       int forcedNameDepth = getAnnotationDepth(method, (Class)JSONPropertyName.class);
/* 1579 */       if (forcedNameDepth < 0 || ignoreDepth <= forcedNameDepth)
/*      */       {
/*      */         
/* 1582 */         return null;
/*      */       }
/*      */     } 
/* 1585 */     JSONPropertyName annotation = getAnnotation(method, JSONPropertyName.class);
/* 1586 */     if (annotation != null && annotation.value() != null && !annotation.value().isEmpty()) {
/* 1587 */       return annotation.value();
/*      */     }
/*      */     
/* 1590 */     String name = method.getName();
/* 1591 */     if (name.startsWith("get") && name.length() > 3) {
/* 1592 */       key = name.substring(3);
/* 1593 */     } else if (name.startsWith("is") && name.length() > 2) {
/* 1594 */       key = name.substring(2);
/*      */     } else {
/* 1596 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1601 */     if (key.length() == 0 || Character.isLowerCase(key.charAt(0))) {
/* 1602 */       return null;
/*      */     }
/* 1604 */     if (key.length() == 1) {
/* 1605 */       key = key.toLowerCase(Locale.ROOT);
/* 1606 */     } else if (!Character.isUpperCase(key.charAt(1))) {
/* 1607 */       key = key.substring(0, 1).toLowerCase(Locale.ROOT) + key.substring(1);
/*      */     } 
/* 1609 */     return key;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <A extends Annotation> A getAnnotation(Method m, Class<A> annotationClass) {
/* 1628 */     if (m == null || annotationClass == null) {
/* 1629 */       return null;
/*      */     }
/*      */     
/* 1632 */     if (m.isAnnotationPresent(annotationClass)) {
/* 1633 */       return m.getAnnotation(annotationClass);
/*      */     }
/*      */ 
/*      */     
/* 1637 */     Class<?> c = m.getDeclaringClass();
/* 1638 */     if (c.getSuperclass() == null) {
/* 1639 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1643 */     for (Class<?> i : c.getInterfaces()) {
/*      */       try {
/* 1645 */         Method im = i.getMethod(m.getName(), m.getParameterTypes());
/* 1646 */         return getAnnotation(im, annotationClass);
/* 1647 */       } catch (SecurityException ex) {
/*      */       
/* 1649 */       } catch (NoSuchMethodException ex) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1655 */       return getAnnotation(c
/* 1656 */           .getSuperclass().getMethod(m.getName(), m.getParameterTypes()), annotationClass);
/*      */     }
/* 1658 */     catch (SecurityException ex) {
/* 1659 */       return null;
/* 1660 */     } catch (NoSuchMethodException ex) {
/* 1661 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getAnnotationDepth(Method m, Class<? extends Annotation> annotationClass) {
/* 1678 */     if (m == null || annotationClass == null) {
/* 1679 */       return -1;
/*      */     }
/*      */     
/* 1682 */     if (m.isAnnotationPresent(annotationClass)) {
/* 1683 */       return 1;
/*      */     }
/*      */ 
/*      */     
/* 1687 */     Class<?> c = m.getDeclaringClass();
/* 1688 */     if (c.getSuperclass() == null) {
/* 1689 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 1693 */     for (Class<?> i : c.getInterfaces()) {
/*      */       try {
/* 1695 */         Method im = i.getMethod(m.getName(), m.getParameterTypes());
/* 1696 */         int d = getAnnotationDepth(im, annotationClass);
/* 1697 */         if (d > 0)
/*      */         {
/* 1699 */           return d + 1;
/*      */         }
/* 1701 */       } catch (SecurityException ex) {
/*      */       
/* 1703 */       } catch (NoSuchMethodException ex) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1709 */       int d = getAnnotationDepth(c
/* 1710 */           .getSuperclass().getMethod(m.getName(), m.getParameterTypes()), annotationClass);
/*      */       
/* 1712 */       if (d > 0)
/*      */       {
/* 1714 */         return d + 1;
/*      */       }
/* 1716 */       return -1;
/* 1717 */     } catch (SecurityException ex) {
/* 1718 */       return -1;
/* 1719 */     } catch (NoSuchMethodException ex) {
/* 1720 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject put(String key, boolean value) throws JSONException {
/* 1738 */     return put(key, value ? Boolean.TRUE : Boolean.FALSE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject put(String key, Collection<?> value) throws JSONException {
/* 1756 */     return put(key, new JSONArray(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject put(String key, double value) throws JSONException {
/* 1773 */     return put(key, Double.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject put(String key, float value) throws JSONException {
/* 1790 */     return put(key, Float.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject put(String key, int value) throws JSONException {
/* 1807 */     return put(key, Integer.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject put(String key, long value) throws JSONException {
/* 1824 */     return put(key, Long.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject put(String key, Map<?, ?> value) throws JSONException {
/* 1842 */     return put(key, new JSONObject(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject put(String key, Object value) throws JSONException {
/* 1862 */     if (key == null) {
/* 1863 */       throw new NullPointerException("Null key.");
/*      */     }
/* 1865 */     if (value != null) {
/* 1866 */       testValidity(value);
/* 1867 */       this.map.put(key, value);
/*      */     } else {
/* 1869 */       remove(key);
/*      */     } 
/* 1871 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject putOnce(String key, Object value) throws JSONException {
/* 1888 */     if (key != null && value != null) {
/* 1889 */       if (opt(key) != null) {
/* 1890 */         throw new JSONException("Duplicate key \"" + key + "\"");
/*      */       }
/* 1892 */       return put(key, value);
/*      */     } 
/* 1894 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONObject putOpt(String key, Object value) throws JSONException {
/* 1912 */     if (key != null && value != null) {
/* 1913 */       return put(key, value);
/*      */     }
/* 1915 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object query(String jsonPointer) {
/* 1938 */     return query(new JSONPointer(jsonPointer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object query(JSONPointer jsonPointer) {
/* 1960 */     return jsonPointer.queryFrom(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object optQuery(String jsonPointer) {
/* 1972 */     return optQuery(new JSONPointer(jsonPointer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object optQuery(JSONPointer jsonPointer) {
/*      */     try {
/* 1985 */       return jsonPointer.queryFrom(this);
/* 1986 */     } catch (JSONPointerException e) {
/* 1987 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String quote(String string) {
/* 2004 */     StringWriter sw = new StringWriter();
/* 2005 */     synchronized (sw.getBuffer()) {
/*      */       
/* 2007 */       return quote(string, sw).toString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Writer quote(String string, Writer w) throws IOException {
/* 2016 */     if (string == null || string.isEmpty()) {
/* 2017 */       w.write("\"\"");
/* 2018 */       return w;
/*      */     } 
/*      */ 
/*      */     
/* 2022 */     char c = Character.MIN_VALUE;
/*      */ 
/*      */     
/* 2025 */     int len = string.length();
/*      */     
/* 2027 */     w.write(34);
/* 2028 */     for (int i = 0; i < len; i++) {
/* 2029 */       char b = c;
/* 2030 */       c = string.charAt(i);
/* 2031 */       switch (c) {
/*      */         case '"':
/*      */         case '\\':
/* 2034 */           w.write(92);
/* 2035 */           w.write(c);
/*      */           break;
/*      */         case '/':
/* 2038 */           if (b == '<') {
/* 2039 */             w.write(92);
/*      */           }
/* 2041 */           w.write(c);
/*      */           break;
/*      */         case '\b':
/* 2044 */           w.write("\\b");
/*      */           break;
/*      */         case '\t':
/* 2047 */           w.write("\\t");
/*      */           break;
/*      */         case '\n':
/* 2050 */           w.write("\\n");
/*      */           break;
/*      */         case '\f':
/* 2053 */           w.write("\\f");
/*      */           break;
/*      */         case '\r':
/* 2056 */           w.write("\\r");
/*      */           break;
/*      */         default:
/* 2059 */           if (c < ' ' || (c >= '' && c < ' ') || (c >= ' ' && c < '℀')) {
/*      */             
/* 2061 */             w.write("\\u");
/* 2062 */             String hhhh = Integer.toHexString(c);
/* 2063 */             w.write("0000", 0, 4 - hhhh.length());
/* 2064 */             w.write(hhhh); break;
/*      */           } 
/* 2066 */           w.write(c);
/*      */           break;
/*      */       } 
/*      */     } 
/* 2070 */     w.write(34);
/* 2071 */     return w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object remove(String key) {
/* 2083 */     return this.map.remove(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean similar(Object other) {
/*      */     try {
/* 2096 */       if (!(other instanceof JSONObject)) {
/* 2097 */         return false;
/*      */       }
/* 2099 */       if (!keySet().equals(((JSONObject)other).keySet())) {
/* 2100 */         return false;
/*      */       }
/* 2102 */       for (Map.Entry<String, ?> entry : entrySet()) {
/* 2103 */         String name = entry.getKey();
/* 2104 */         Object valueThis = entry.getValue();
/* 2105 */         Object valueOther = ((JSONObject)other).get(name);
/* 2106 */         if (valueThis == valueOther) {
/*      */           continue;
/*      */         }
/* 2109 */         if (valueThis == null) {
/* 2110 */           return false;
/*      */         }
/* 2112 */         if (valueThis instanceof JSONObject) {
/* 2113 */           if (!((JSONObject)valueThis).similar(valueOther))
/* 2114 */             return false;  continue;
/*      */         } 
/* 2116 */         if (valueThis instanceof JSONArray) {
/* 2117 */           if (!((JSONArray)valueThis).similar(valueOther))
/* 2118 */             return false;  continue;
/*      */         } 
/* 2120 */         if (valueThis instanceof Number && valueOther instanceof Number) {
/* 2121 */           if (!isNumberSimilar((Number)valueThis, (Number)valueOther))
/* 2122 */             return false;  continue;
/*      */         } 
/* 2124 */         if (valueThis instanceof JSONString && valueOther instanceof JSONString) {
/* 2125 */           if (!((JSONString)valueThis).toJSONString().equals(((JSONString)valueOther).toJSONString()))
/* 2126 */             return false;  continue;
/*      */         } 
/* 2128 */         if (!valueThis.equals(valueOther)) {
/* 2129 */           return false;
/*      */         }
/*      */       } 
/* 2132 */       return true;
/* 2133 */     } catch (Throwable exception) {
/* 2134 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isNumberSimilar(Number l, Number r) {
/* 2154 */     if (!numberIsFinite(l) || !numberIsFinite(r))
/*      */     {
/* 2156 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2161 */     if (l.getClass().equals(r.getClass()) && l instanceof Comparable) {
/*      */       
/* 2163 */       int compareTo = ((Comparable<Number>)l).compareTo(r);
/* 2164 */       return (compareTo == 0);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2170 */     BigDecimal lBigDecimal = objectToBigDecimal(l, null, false);
/* 2171 */     BigDecimal rBigDecimal = objectToBigDecimal(r, null, false);
/* 2172 */     if (lBigDecimal == null || rBigDecimal == null) {
/* 2173 */       return false;
/*      */     }
/* 2175 */     return (lBigDecimal.compareTo(rBigDecimal) == 0);
/*      */   }
/*      */   
/*      */   private static boolean numberIsFinite(Number n) {
/* 2179 */     if (n instanceof Double && (((Double)n).isInfinite() || ((Double)n).isNaN()))
/* 2180 */       return false; 
/* 2181 */     if (n instanceof Float && (((Float)n).isInfinite() || ((Float)n).isNaN())) {
/* 2182 */       return false;
/*      */     }
/* 2184 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean isDecimalNotation(String val) {
/* 2194 */     return (val.indexOf('.') > -1 || val.indexOf('e') > -1 || val
/* 2195 */       .indexOf('E') > -1 || "-0".equals(val));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Number stringToNumber(String val) throws NumberFormatException {
/* 2209 */     char initial = val.charAt(0);
/* 2210 */     if ((initial >= '0' && initial <= '9') || initial == '-') {
/*      */       
/* 2212 */       if (isDecimalNotation(val)) {
/*      */         
/*      */         try {
/*      */ 
/*      */           
/* 2217 */           BigDecimal bd = new BigDecimal(val);
/* 2218 */           if (initial == '-' && BigDecimal.ZERO.compareTo(bd) == 0) {
/* 2219 */             return Double.valueOf(-0.0D);
/*      */           }
/* 2221 */           return bd;
/* 2222 */         } catch (NumberFormatException retryAsDouble) {
/*      */           
/*      */           try {
/* 2225 */             Double d = Double.valueOf(val);
/* 2226 */             if (d.isNaN() || d.isInfinite()) {
/* 2227 */               throw new NumberFormatException("val [" + val + "] is not a valid number.");
/*      */             }
/* 2229 */             return d;
/* 2230 */           } catch (NumberFormatException ignore) {
/* 2231 */             throw new NumberFormatException("val [" + val + "] is not a valid number.");
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/* 2236 */       if (initial == '0' && val.length() > 1) {
/* 2237 */         char at1 = val.charAt(1);
/* 2238 */         if (at1 >= '0' && at1 <= '9') {
/* 2239 */           throw new NumberFormatException("val [" + val + "] is not a valid number.");
/*      */         }
/* 2241 */       } else if (initial == '-' && val.length() > 2) {
/* 2242 */         char at1 = val.charAt(1);
/* 2243 */         char at2 = val.charAt(2);
/* 2244 */         if (at1 == '0' && at2 >= '0' && at2 <= '9') {
/* 2245 */           throw new NumberFormatException("val [" + val + "] is not a valid number.");
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2256 */       BigInteger bi = new BigInteger(val);
/* 2257 */       if (bi.bitLength() <= 31) {
/* 2258 */         return Integer.valueOf(bi.intValue());
/*      */       }
/* 2260 */       if (bi.bitLength() <= 63) {
/* 2261 */         return Long.valueOf(bi.longValue());
/*      */       }
/* 2263 */       return bi;
/*      */     } 
/* 2265 */     throw new NumberFormatException("val [" + val + "] is not a valid number.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object stringToValue(String string) {
/* 2281 */     if ("".equals(string)) {
/* 2282 */       return string;
/*      */     }
/*      */ 
/*      */     
/* 2286 */     if ("true".equalsIgnoreCase(string)) {
/* 2287 */       return Boolean.TRUE;
/*      */     }
/* 2289 */     if ("false".equalsIgnoreCase(string)) {
/* 2290 */       return Boolean.FALSE;
/*      */     }
/* 2292 */     if ("null".equalsIgnoreCase(string)) {
/* 2293 */       return NULL;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2301 */     char initial = string.charAt(0);
/* 2302 */     if ((initial >= '0' && initial <= '9') || initial == '-') {
/*      */       try {
/* 2304 */         return stringToNumber(string);
/* 2305 */       } catch (Exception exception) {}
/*      */     }
/*      */     
/* 2308 */     return string;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void testValidity(Object o) throws JSONException {
/* 2320 */     if (o instanceof Number && !numberIsFinite((Number)o)) {
/* 2321 */       throw new JSONException("JSON does not allow non-finite numbers.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JSONArray toJSONArray(JSONArray names) throws JSONException {
/* 2337 */     if (names == null || names.isEmpty()) {
/* 2338 */       return null;
/*      */     }
/* 2340 */     JSONArray ja = new JSONArray();
/* 2341 */     for (int i = 0; i < names.length(); i++) {
/* 2342 */       ja.put(opt(names.getString(i)));
/*      */     }
/* 2344 */     return ja;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*      */     try {
/* 2363 */       return toString(0);
/* 2364 */     } catch (Exception e) {
/* 2365 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(int indentFactor) throws JSONException {
/* 2397 */     StringWriter w = new StringWriter();
/* 2398 */     synchronized (w.getBuffer()) {
/* 2399 */       return write(w, indentFactor, 0).toString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String valueToString(Object value) throws JSONException {
/* 2432 */     return JSONWriter.valueToString(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object wrap(Object object) {
/* 2448 */     return wrap(object, null);
/*      */   }
/*      */   
/*      */   private static Object wrap(Object object, Set<Object> objectsRecord) {
/*      */     try {
/* 2453 */       if (NULL.equals(object)) {
/* 2454 */         return NULL;
/*      */       }
/* 2456 */       if (object instanceof JSONObject || object instanceof JSONArray || NULL
/* 2457 */         .equals(object) || object instanceof JSONString || object instanceof Byte || object instanceof Character || object instanceof Short || object instanceof Integer || object instanceof Long || object instanceof Boolean || object instanceof Float || object instanceof Double || object instanceof String || object instanceof BigInteger || object instanceof BigDecimal || object instanceof Enum)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2464 */         return object;
/*      */       }
/*      */       
/* 2467 */       if (object instanceof Collection) {
/* 2468 */         Collection<?> coll = (Collection)object;
/* 2469 */         return new JSONArray(coll);
/*      */       } 
/* 2471 */       if (object.getClass().isArray()) {
/* 2472 */         return new JSONArray(object);
/*      */       }
/* 2474 */       if (object instanceof Map) {
/* 2475 */         Map<?, ?> map = (Map<?, ?>)object;
/* 2476 */         return new JSONObject(map);
/*      */       } 
/* 2478 */       Package objectPackage = object.getClass().getPackage();
/*      */       
/* 2480 */       String objectPackageName = (objectPackage != null) ? objectPackage.getName() : "";
/* 2481 */       if (objectPackageName.startsWith("java.") || objectPackageName
/* 2482 */         .startsWith("javax.") || object
/* 2483 */         .getClass().getClassLoader() == null) {
/* 2484 */         return object.toString();
/*      */       }
/* 2486 */       if (objectsRecord != null) {
/* 2487 */         return new JSONObject(object, objectsRecord);
/*      */       }
/* 2489 */       return new JSONObject(object);
/*      */     }
/* 2491 */     catch (JSONException exception) {
/* 2492 */       throw exception;
/* 2493 */     } catch (Exception exception) {
/* 2494 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer write(Writer writer) throws JSONException {
/* 2509 */     return write(writer, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final Writer writeValue(Writer writer, Object value, int indentFactor, int indent) throws JSONException, IOException {
/* 2515 */     if (value == null || value.equals(null)) {
/* 2516 */       writer.write("null");
/* 2517 */     } else if (value instanceof JSONString) {
/*      */       Object o;
/*      */       try {
/* 2520 */         o = ((JSONString)value).toJSONString();
/* 2521 */       } catch (Exception e) {
/* 2522 */         throw new JSONException(e);
/*      */       } 
/* 2524 */       writer.write((o != null) ? o.toString() : quote(value.toString()));
/* 2525 */     } else if (value instanceof Number) {
/*      */       
/* 2527 */       String numberAsString = numberToString((Number)value);
/* 2528 */       if (NUMBER_PATTERN.matcher(numberAsString).matches()) {
/* 2529 */         writer.write(numberAsString);
/*      */       }
/*      */       else {
/*      */         
/* 2533 */         quote(numberAsString, writer);
/*      */       } 
/* 2535 */     } else if (value instanceof Boolean) {
/* 2536 */       writer.write(value.toString());
/* 2537 */     } else if (value instanceof Enum) {
/* 2538 */       writer.write(quote(((Enum)value).name()));
/* 2539 */     } else if (value instanceof JSONObject) {
/* 2540 */       ((JSONObject)value).write(writer, indentFactor, indent);
/* 2541 */     } else if (value instanceof JSONArray) {
/* 2542 */       ((JSONArray)value).write(writer, indentFactor, indent);
/* 2543 */     } else if (value instanceof Map) {
/* 2544 */       Map<?, ?> map = (Map<?, ?>)value;
/* 2545 */       (new JSONObject(map)).write(writer, indentFactor, indent);
/* 2546 */     } else if (value instanceof Collection) {
/* 2547 */       Collection<?> coll = (Collection)value;
/* 2548 */       (new JSONArray(coll)).write(writer, indentFactor, indent);
/* 2549 */     } else if (value.getClass().isArray()) {
/* 2550 */       (new JSONArray(value)).write(writer, indentFactor, indent);
/*      */     } else {
/* 2552 */       quote(value.toString(), writer);
/*      */     } 
/* 2554 */     return writer;
/*      */   }
/*      */   
/*      */   static final void indent(Writer writer, int indent) throws IOException {
/* 2558 */     for (int i = 0; i < indent; i++) {
/* 2559 */       writer.write(32);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer write(Writer writer, int indentFactor, int indent) throws JSONException {
/*      */     try {
/* 2594 */       boolean needsComma = false;
/* 2595 */       int length = length();
/* 2596 */       writer.write(123);
/*      */       
/* 2598 */       if (length == 1) {
/* 2599 */         Map.Entry<String, ?> entry = entrySet().iterator().next();
/* 2600 */         String key = entry.getKey();
/* 2601 */         writer.write(quote(key));
/* 2602 */         writer.write(58);
/* 2603 */         if (indentFactor > 0) {
/* 2604 */           writer.write(32);
/*      */         }
/*      */         try {
/* 2607 */           writeValue(writer, entry.getValue(), indentFactor, indent);
/* 2608 */         } catch (Exception e) {
/* 2609 */           throw new JSONException("Unable to write JSONObject value for key: " + key, e);
/*      */         } 
/* 2611 */       } else if (length != 0) {
/* 2612 */         int newIndent = indent + indentFactor;
/* 2613 */         for (Map.Entry<String, ?> entry : entrySet()) {
/* 2614 */           if (needsComma) {
/* 2615 */             writer.write(44);
/*      */           }
/* 2617 */           if (indentFactor > 0) {
/* 2618 */             writer.write(10);
/*      */           }
/* 2620 */           indent(writer, newIndent);
/* 2621 */           String key = entry.getKey();
/* 2622 */           writer.write(quote(key));
/* 2623 */           writer.write(58);
/* 2624 */           if (indentFactor > 0) {
/* 2625 */             writer.write(32);
/*      */           }
/*      */           try {
/* 2628 */             writeValue(writer, entry.getValue(), indentFactor, newIndent);
/* 2629 */           } catch (Exception e) {
/* 2630 */             throw new JSONException("Unable to write JSONObject value for key: " + key, e);
/*      */           } 
/* 2632 */           needsComma = true;
/*      */         } 
/* 2634 */         if (indentFactor > 0) {
/* 2635 */           writer.write(10);
/*      */         }
/* 2637 */         indent(writer, indent);
/*      */       } 
/* 2639 */       writer.write(125);
/* 2640 */       return writer;
/* 2641 */     } catch (IOException exception) {
/* 2642 */       throw new JSONException(exception);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> toMap() {
/* 2656 */     Map<String, Object> results = new HashMap<String, Object>();
/* 2657 */     for (Map.Entry<String, Object> entry : entrySet()) {
/*      */       Object value;
/* 2659 */       if (entry.getValue() == null || NULL.equals(entry.getValue())) {
/* 2660 */         value = null;
/* 2661 */       } else if (entry.getValue() instanceof JSONObject) {
/* 2662 */         value = ((JSONObject)entry.getValue()).toMap();
/* 2663 */       } else if (entry.getValue() instanceof JSONArray) {
/* 2664 */         value = ((JSONArray)entry.getValue()).toList();
/*      */       } else {
/* 2666 */         value = entry.getValue();
/*      */       } 
/* 2668 */       results.put(entry.getKey(), value);
/*      */     } 
/* 2670 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONException wrongValueFormatException(String key, String valueType, Object value, Throwable cause) {
/* 2685 */     if (value == null)
/*      */     {
/* 2687 */       return new JSONException("JSONObject[" + 
/* 2688 */           quote(key) + "] is not a " + valueType + " (null).", cause);
/*      */     }
/*      */ 
/*      */     
/* 2692 */     if (value instanceof Map || value instanceof Iterable || value instanceof JSONObject) {
/* 2693 */       return new JSONException("JSONObject[" + 
/* 2694 */           quote(key) + "] is not a " + valueType + " (" + value.getClass() + ").", cause);
/*      */     }
/*      */     
/* 2697 */     return new JSONException("JSONObject[" + 
/* 2698 */         quote(key) + "] is not a " + valueType + " (" + value.getClass() + " : " + value + ").", cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JSONException recursivelyDefinedObjectException(String key) {
/* 2708 */     return new JSONException("JavaBean object contains recursively defined member variable of key " + 
/* 2709 */         quote(key));
/*      */   }
/*      */ }


/* Location:              D:\JarPackage\json-20230618.jar!\org\json\JSONObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */