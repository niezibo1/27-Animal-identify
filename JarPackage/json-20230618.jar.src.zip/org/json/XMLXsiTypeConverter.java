package org.json;

public interface XMLXsiTypeConverter<T> {
  T convert(String paramString);
}


/* Location:              D:\JarPackage\json-20230618.jar!\org\json\XMLXsiTypeConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */