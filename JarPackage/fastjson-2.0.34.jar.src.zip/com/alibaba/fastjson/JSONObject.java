/*      */ package com.alibaba.fastjson;
/*      */ 
/*      */ import com.alibaba.fastjson.annotation.JSONField;
/*      */ import com.alibaba.fastjson.parser.Feature;
/*      */ import com.alibaba.fastjson.parser.ParserConfig;
/*      */ import com.alibaba.fastjson.util.IOUtils;
/*      */ import com.alibaba.fastjson.util.TypeUtils;
/*      */ import com.alibaba.fastjson2.JSON;
/*      */ import com.alibaba.fastjson2.JSONException;
/*      */ import com.alibaba.fastjson2.JSONFactory;
/*      */ import com.alibaba.fastjson2.JSONReader;
/*      */ import com.alibaba.fastjson2.JSONWriter;
/*      */ import com.alibaba.fastjson2.reader.ObjectReader;
/*      */ import com.alibaba.fastjson2.reader.ObjectReaderProvider;
/*      */ import com.alibaba.fastjson2.util.TypeUtils;
/*      */ import com.alibaba.fastjson2.util.Wrapper;
/*      */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*      */ import com.alibaba.fastjson2.writer.ObjectWriterAdapter;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Date;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Function;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JSONObject
/*      */   extends JSON
/*      */   implements Map<String, Object>, Cloneable, Serializable, InvocationHandler, Wrapper
/*      */ {
/*      */   static ObjectReader<JSONArray> arrayReader;
/*      */   static ObjectReader<JSONObject> objectReader;
/*      */   private static final long serialVersionUID = 1L;
/*      */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*      */   private final Map<String, Object> map;
/*      */   
/*      */   public JSONObject() {
/*   60 */     this(16, false);
/*      */   }
/*      */   
/*      */   public JSONObject(Map<String, Object> map) {
/*   64 */     if (map == null) {
/*   65 */       throw new IllegalArgumentException("map is null.");
/*      */     }
/*   67 */     this.map = map;
/*      */   }
/*      */   
/*      */   public JSONObject(boolean ordered) {
/*   71 */     this(16, ordered);
/*      */   }
/*      */   
/*      */   public JSONObject(int initialCapacity) {
/*   75 */     this(initialCapacity, false);
/*      */   }
/*      */   
/*      */   public JSONObject(int initialCapacity, boolean ordered) {
/*   79 */     if (ordered) {
/*   80 */       this.map = new LinkedHashMap<>(initialCapacity);
/*      */     } else {
/*   82 */       this.map = new HashMap<>(initialCapacity);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static <T> T toJavaObject(JSON json, Class<T> clazz) {
/*   87 */     return (T)TypeUtils.cast(json, clazz, JSONFactory.getDefaultObjectReaderProvider());
/*      */   }
/*      */ 
/*      */   
/*      */   public int size() {
/*   92 */     return this.map.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*   97 */     return this.map.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsKey(Object key) {
/*  102 */     boolean result = this.map.containsKey(key);
/*  103 */     if (!result && (
/*  104 */       key instanceof Number || key instanceof Character || key instanceof Boolean || key instanceof java.util.UUID))
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  109 */       result = this.map.containsKey(key.toString());
/*      */     }
/*      */     
/*  112 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsValue(Object value) {
/*  117 */     return this.map.containsValue(value);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object get(Object key) {
/*  122 */     Object val = this.map.get(key);
/*      */     
/*  124 */     if (val == null && (key instanceof Number || key instanceof Boolean || key instanceof Character))
/*      */     {
/*  126 */       val = this.map.get(key.toString());
/*      */     }
/*      */     
/*  129 */     return val;
/*      */   }
/*      */   
/*      */   public JSONObject getJSONObject(String key) {
/*  133 */     Object value = this.map.get(key);
/*      */     
/*  135 */     if (value instanceof JSONObject) {
/*  136 */       return (JSONObject)value;
/*      */     }
/*      */     
/*  139 */     if (value instanceof String) {
/*  140 */       String str = (String)value;
/*      */       
/*  142 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  143 */         return null;
/*      */       }
/*      */       
/*  146 */       JSONReader reader = JSONReader.of(str);
/*  147 */       if (objectReader == null) {
/*  148 */         objectReader = reader.getObjectReader(JSONObject.class);
/*      */       }
/*  150 */       return (JSONObject)objectReader.readObject(reader, null, null, 0L);
/*      */     } 
/*      */     
/*  153 */     if (value instanceof Map) {
/*  154 */       return new JSONObject((Map<String, Object>)value);
/*      */     }
/*      */     
/*  157 */     if (value == null) {
/*  158 */       return null;
/*      */     }
/*      */     
/*  161 */     Class<?> valueClass = value.getClass();
/*  162 */     ObjectWriter objectWriter = JSONFactory.getDefaultObjectWriterProvider().getObjectWriter(valueClass);
/*  163 */     if (objectWriter instanceof ObjectWriterAdapter) {
/*  164 */       ObjectWriterAdapter writerAdapter = (ObjectWriterAdapter)objectWriter;
/*  165 */       return new JSONObject((Map<String, Object>)writerAdapter.toJSONObject(value));
/*      */     } 
/*      */     
/*  168 */     return null;
/*      */   }
/*      */   
/*      */   public JSONArray getJSONArray(String key) {
/*  172 */     Object value = this.map.get(key);
/*      */     
/*  174 */     if (value == null || value instanceof JSONArray) {
/*  175 */       return (JSONArray)value;
/*      */     }
/*      */     
/*  178 */     if (value instanceof String) {
/*  179 */       String str = (String)value;
/*      */       
/*  181 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  182 */         return null;
/*      */       }
/*      */       
/*  185 */       JSONReader reader = JSONReader.of(str);
/*  186 */       if (arrayReader == null) {
/*  187 */         arrayReader = reader.getObjectReader(JSONArray.class);
/*      */       }
/*  189 */       return (JSONArray)arrayReader.readObject(reader, null, null, 0L);
/*      */     } 
/*      */     
/*  192 */     if (value instanceof List) {
/*  193 */       return new JSONArray((List)value);
/*      */     }
/*      */     
/*  196 */     String jsonString = JSON.toJSONString(value);
/*  197 */     return JSON.parseArray(jsonString);
/*      */   }
/*      */   
/*      */   public <T> T getObject(String key, Class<T> clazz) {
/*  201 */     return getObject(key, clazz, new Feature[0]);
/*      */   }
/*      */   
/*      */   public <T> T getObject(String key, Class<T> clazz, Feature... features) {
/*  205 */     Object obj = this.map.get(key);
/*  206 */     if (obj == null) {
/*  207 */       return null;
/*      */     }
/*      */     
/*  210 */     if (clazz == Object.class && obj instanceof JSONObject) {
/*  211 */       return (T)obj;
/*      */     }
/*      */     
/*  214 */     if (clazz != Object.class && clazz.isInstance(obj)) {
/*  215 */       return (T)obj;
/*      */     }
/*      */     
/*  218 */     ObjectReaderProvider provider = JSONFactory.getDefaultObjectReaderProvider();
/*  219 */     Function<Object, T> typeConvert = provider.getTypeConvert(obj.getClass(), clazz);
/*  220 */     if (typeConvert != null) {
/*  221 */       return typeConvert.apply(obj);
/*      */     }
/*      */     
/*  224 */     if (obj instanceof String) {
/*  225 */       String str = (String)obj;
/*  226 */       if (str.isEmpty() || "null".equals(str)) {
/*  227 */         return null;
/*      */       }
/*      */     } 
/*      */     
/*  231 */     String json = JSON.toJSONString(obj);
/*  232 */     JSONReader jsonReader = JSONReader.of(json, 
/*      */         
/*  234 */         JSON.createReadContext(
/*  235 */           JSONFactory.getDefaultObjectReaderProvider(), JSON.DEFAULT_PARSER_FEATURE, features));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  240 */     boolean fieldBased = jsonReader.getContext().isEnabled(JSONReader.Feature.FieldBased);
/*  241 */     ObjectReader objectReader = provider.getObjectReader(clazz, fieldBased);
/*      */     
/*  243 */     String defaultDateFormat = JSON.DEFFAULT_DATE_FORMAT;
/*  244 */     if (!"yyyy-MM-dd HH:mm:ss".equals(defaultDateFormat)) {
/*  245 */       jsonReader
/*  246 */         .getContext()
/*  247 */         .setDateFormat(defaultDateFormat);
/*      */     }
/*      */     
/*  250 */     return (T)objectReader.readObject(jsonReader, null, null, 0L);
/*      */   }
/*      */   
/*      */   public <T> T getObject(String key, TypeReference typeReference) {
/*  254 */     Object obj = this.map.get(key);
/*  255 */     if (typeReference == null) {
/*  256 */       return (T)obj;
/*      */     }
/*      */     
/*  259 */     Type type = typeReference.getType();
/*      */     
/*  261 */     if (type instanceof Class) {
/*  262 */       Class<Object> clazz = (Class)type;
/*  263 */       if (clazz != Object.class && clazz.isInstance(obj)) {
/*  264 */         return (T)obj;
/*      */       }
/*      */     } 
/*      */     
/*  268 */     ObjectReaderProvider provider = JSONFactory.getDefaultObjectReaderProvider();
/*  269 */     Function<Object, T> typeConvert = provider.getTypeConvert(obj.getClass(), type);
/*  270 */     if (typeConvert != null) {
/*  271 */       return typeConvert.apply(obj);
/*      */     }
/*      */     
/*  274 */     if (obj instanceof String) {
/*  275 */       String str = (String)obj;
/*  276 */       if (str.isEmpty() || "null".equals(str)) {
/*  277 */         return null;
/*      */       }
/*      */     } 
/*      */     
/*  281 */     String json = JSON.toJSONString(obj);
/*  282 */     ObjectReader objectReader = provider.getObjectReader(type);
/*  283 */     JSONReader jsonReader = JSONReader.of(json);
/*      */     
/*  285 */     String defaultDateFormat = JSON.DEFFAULT_DATE_FORMAT;
/*  286 */     if (!"yyyy-MM-dd HH:mm:ss".equals(defaultDateFormat)) {
/*  287 */       jsonReader
/*  288 */         .getContext()
/*  289 */         .setDateFormat(defaultDateFormat);
/*      */     }
/*      */     
/*  292 */     return (T)objectReader.readObject(jsonReader, null, null, 0L);
/*      */   }
/*      */   
/*      */   public Boolean getBoolean(String key) {
/*  296 */     Object value = this.map.get(key);
/*      */     
/*  298 */     if (value == null) {
/*  299 */       return null;
/*      */     }
/*      */     
/*  302 */     if (value instanceof Boolean) {
/*  303 */       return (Boolean)value;
/*      */     }
/*      */     
/*  306 */     if (value instanceof Number) {
/*  307 */       return Boolean.valueOf((((Number)value).intValue() == 1));
/*      */     }
/*      */     
/*  310 */     if (value instanceof String) {
/*  311 */       String str = (String)value;
/*      */       
/*  313 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  314 */         return null;
/*      */       }
/*      */       
/*  317 */       return Boolean.valueOf(("true".equalsIgnoreCase(str) || "1".equals(str)));
/*      */     } 
/*      */     
/*  320 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Boolean");
/*      */   }
/*      */   
/*      */   public Byte getByte(String key) {
/*  324 */     Object value = this.map.get(key);
/*      */     
/*  326 */     if (value == null) {
/*  327 */       return null;
/*      */     }
/*      */     
/*  330 */     if (value instanceof Number) {
/*  331 */       return Byte.valueOf(((Number)value).byteValue());
/*      */     }
/*      */     
/*  334 */     if (value instanceof String) {
/*  335 */       String str = (String)value;
/*      */       
/*  337 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  338 */         return null;
/*      */       }
/*      */       
/*  341 */       return Byte.valueOf(Byte.parseByte(str));
/*      */     } 
/*      */     
/*  344 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Byte");
/*      */   }
/*      */   
/*      */   public byte[] getBytes(String key) {
/*  348 */     Object value = get(key);
/*      */     
/*  350 */     if (value == null) {
/*  351 */       return null;
/*      */     }
/*      */     
/*  354 */     if (value instanceof byte[]) {
/*  355 */       return (byte[])value;
/*      */     }
/*  357 */     if (value instanceof String) {
/*  358 */       return IOUtils.decodeBase64((String)value);
/*      */     }
/*  360 */     throw new JSONException("can not cast to byte[], value : " + value);
/*      */   }
/*      */   
/*      */   public <T> T getObject(String key, Type type) {
/*  364 */     return getObject(key, type, new Feature[0]);
/*      */   }
/*      */   
/*      */   public <T> T getObject(String key, Type type, Feature... features) {
/*  368 */     Object obj = this.map.get(key);
/*  369 */     if (obj == null) {
/*  370 */       return null;
/*      */     }
/*      */     
/*  373 */     if (type instanceof Class) {
/*  374 */       Class<Object> clazz = (Class)type;
/*  375 */       if (clazz != Object.class && clazz.isInstance(obj)) {
/*  376 */         return (T)obj;
/*      */       }
/*      */     } 
/*      */     
/*  380 */     ObjectReaderProvider provider = JSONFactory.getDefaultObjectReaderProvider();
/*  381 */     Function<Object, T> typeConvert = provider.getTypeConvert(obj.getClass(), type);
/*  382 */     if (typeConvert != null) {
/*  383 */       return typeConvert.apply(obj);
/*      */     }
/*      */     
/*  386 */     if (obj instanceof String && ((String)obj).isEmpty()) {
/*  387 */       return null;
/*      */     }
/*      */     
/*  390 */     String json = JSON.toJSONString(obj);
/*  391 */     JSONReader jsonReader = JSONReader.of(json, 
/*      */         
/*  393 */         JSON.createReadContext(
/*  394 */           JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  400 */     boolean fieldBased = jsonReader.getContext().isEnabled(JSONReader.Feature.FieldBased);
/*  401 */     ObjectReader objectReader = provider.getObjectReader(type, fieldBased);
/*      */     
/*  403 */     String defaultDateFormat = JSON.DEFFAULT_DATE_FORMAT;
/*  404 */     if (!"yyyy-MM-dd HH:mm:ss".equals(defaultDateFormat)) {
/*  405 */       jsonReader
/*  406 */         .getContext()
/*  407 */         .setDateFormat(defaultDateFormat);
/*      */     }
/*      */     
/*  410 */     return (T)objectReader.readObject(jsonReader, null, null, 0L);
/*      */   }
/*      */   
/*      */   public boolean getBooleanValue(String key) {
/*  414 */     Object value = get(key);
/*  415 */     Boolean booleanVal = TypeUtils.toBoolean(value);
/*  416 */     if (booleanVal == null) {
/*  417 */       return false;
/*      */     }
/*      */     
/*  420 */     return booleanVal.booleanValue();
/*      */   }
/*      */   
/*      */   public byte getByteValue(String key) {
/*  424 */     Object value = this.map.get(key);
/*      */     
/*  426 */     if (value == null) {
/*  427 */       return 0;
/*      */     }
/*      */     
/*  430 */     if (value instanceof Number) {
/*  431 */       return ((Number)value).byteValue();
/*      */     }
/*      */     
/*  434 */     if (value instanceof String) {
/*  435 */       String str = (String)value;
/*      */       
/*  437 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  438 */         return 0;
/*      */       }
/*      */       
/*  441 */       return Byte.parseByte(str);
/*      */     } 
/*      */     
/*  444 */     throw new JSONException("Can not cast '" + value.getClass() + "' to byte value");
/*      */   }
/*      */   
/*      */   public Short getShort(String key) {
/*  448 */     Object value = this.map.get(key);
/*      */     
/*  450 */     if (value == null) {
/*  451 */       return null;
/*      */     }
/*      */     
/*  454 */     if (value instanceof Short) {
/*  455 */       return (Short)value;
/*      */     }
/*      */     
/*  458 */     if (value instanceof Number) {
/*  459 */       return Short.valueOf(((Number)value).shortValue());
/*      */     }
/*      */     
/*  462 */     if (value instanceof String) {
/*  463 */       String str = (String)value;
/*      */       
/*  465 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  466 */         return null;
/*      */       }
/*      */       
/*  469 */       return Short.valueOf(Short.parseShort(str));
/*      */     } 
/*      */     
/*  472 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Short");
/*      */   }
/*      */   
/*      */   public short getShortValue(String key) {
/*  476 */     Object value = this.map.get(key);
/*      */     
/*  478 */     if (value == null) {
/*  479 */       return 0;
/*      */     }
/*      */     
/*  482 */     if (value instanceof Number) {
/*  483 */       return ((Number)value).shortValue();
/*      */     }
/*      */     
/*  486 */     if (value instanceof String) {
/*  487 */       String str = (String)value;
/*      */       
/*  489 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  490 */         return 0;
/*      */       }
/*      */       
/*  493 */       return Short.parseShort(str);
/*      */     } 
/*      */     
/*  496 */     throw new JSONException("Can not cast '" + value.getClass() + "' to short value");
/*      */   }
/*      */   
/*      */   public Integer getInteger(String key) {
/*  500 */     Object value = this.map.get(key);
/*      */     
/*  502 */     if (value == null) {
/*  503 */       return null;
/*      */     }
/*      */     
/*  506 */     if (value instanceof Integer) {
/*  507 */       return (Integer)value;
/*      */     }
/*      */     
/*  510 */     if (value instanceof Number) {
/*  511 */       return Integer.valueOf(((Number)value).intValue());
/*      */     }
/*      */     
/*  514 */     if (value instanceof String) {
/*  515 */       String str = (String)value;
/*      */       
/*  517 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  518 */         return null;
/*      */       }
/*      */       
/*  521 */       if (str.indexOf('.') != -1) {
/*  522 */         return Integer.valueOf((int)Double.parseDouble(str));
/*      */       }
/*      */       
/*  525 */       return Integer.valueOf(Integer.parseInt(str));
/*      */     } 
/*      */     
/*  528 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Integer");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getIntValue(String key) {
/*  533 */     Object value = this.map.get(key);
/*      */     
/*  535 */     if (value == null) {
/*  536 */       return 0;
/*      */     }
/*      */     
/*  539 */     if (value instanceof Number) {
/*  540 */       return ((Number)value).intValue();
/*      */     }
/*      */     
/*  543 */     if (value instanceof String) {
/*  544 */       String str = (String)value;
/*      */       
/*  546 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  547 */         return 0;
/*      */       }
/*      */       
/*  550 */       if (str.indexOf('.') != -1) {
/*  551 */         return (int)Double.parseDouble(str);
/*      */       }
/*      */       
/*  554 */       return Integer.parseInt(str);
/*      */     } 
/*      */     
/*  557 */     throw new JSONException("Can not cast '" + value.getClass() + "' to int value");
/*      */   }
/*      */ 
/*      */   
/*      */   public Long getLong(String key) {
/*  562 */     Object value = this.map.get(key);
/*      */     
/*  564 */     if (value == null) {
/*  565 */       return null;
/*      */     }
/*      */     
/*  568 */     if (value instanceof Long) {
/*  569 */       return (Long)value;
/*      */     }
/*      */     
/*  572 */     if (value instanceof Number) {
/*  573 */       return Long.valueOf(((Number)value).longValue());
/*      */     }
/*      */     
/*  576 */     if (value instanceof String) {
/*  577 */       String str = (String)value;
/*      */       
/*  579 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  580 */         return null;
/*      */       }
/*      */       
/*  583 */       if (str.indexOf('.') != -1) {
/*  584 */         return Long.valueOf((long)Double.parseDouble(str));
/*      */       }
/*      */       
/*  587 */       return Long.valueOf(Long.parseLong(str));
/*      */     } 
/*      */     
/*  590 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Long");
/*      */   }
/*      */   
/*      */   public long getLongValue(String key) {
/*  594 */     Object value = this.map.get(key);
/*      */     
/*  596 */     if (value == null) {
/*  597 */       return 0L;
/*      */     }
/*      */     
/*  600 */     if (value instanceof Number) {
/*  601 */       return ((Number)value).longValue();
/*      */     }
/*      */     
/*  604 */     if (value instanceof String) {
/*  605 */       String str = (String)value;
/*      */       
/*  607 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  608 */         return 0L;
/*      */       }
/*      */       
/*  611 */       if (str.indexOf('.') != -1) {
/*  612 */         return (long)Double.parseDouble(str);
/*      */       }
/*      */       
/*  615 */       return Long.parseLong(str);
/*      */     } 
/*      */     
/*  618 */     throw new JSONException("Can not cast '" + value.getClass() + "' to long value");
/*      */   }
/*      */   
/*      */   public Float getFloat(String key) {
/*  622 */     Object value = this.map.get(key);
/*      */     
/*  624 */     if (value == null) {
/*  625 */       return null;
/*      */     }
/*      */     
/*  628 */     if (value instanceof Float) {
/*  629 */       return (Float)value;
/*      */     }
/*      */     
/*  632 */     if (value instanceof Number) {
/*  633 */       return Float.valueOf(((Number)value).floatValue());
/*      */     }
/*      */     
/*  636 */     if (value instanceof String) {
/*  637 */       String str = (String)value;
/*      */       
/*  639 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  640 */         return null;
/*      */       }
/*      */       
/*  643 */       return Float.valueOf(Float.parseFloat(str));
/*      */     } 
/*      */     
/*  646 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Float");
/*      */   }
/*      */   
/*      */   public float getFloatValue(String key) {
/*  650 */     Object value = this.map.get(key);
/*      */     
/*  652 */     if (value == null) {
/*  653 */       return 0.0F;
/*      */     }
/*      */     
/*  656 */     if (value instanceof Number) {
/*  657 */       return ((Number)value).floatValue();
/*      */     }
/*      */     
/*  660 */     if (value instanceof String) {
/*  661 */       String str = (String)value;
/*      */       
/*  663 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  664 */         return 0.0F;
/*      */       }
/*      */       
/*  667 */       return Float.parseFloat(str);
/*      */     } 
/*      */     
/*  670 */     throw new JSONException("Can not cast '" + value.getClass() + "' to float value");
/*      */   }
/*      */   
/*      */   public Double getDouble(String key) {
/*  674 */     Object value = this.map.get(key);
/*      */     
/*  676 */     if (value == null) {
/*  677 */       return null;
/*      */     }
/*      */     
/*  680 */     if (value instanceof Double) {
/*  681 */       return (Double)value;
/*      */     }
/*      */     
/*  684 */     if (value instanceof Number) {
/*  685 */       return Double.valueOf(((Number)value).doubleValue());
/*      */     }
/*      */     
/*  688 */     if (value instanceof String) {
/*  689 */       String str = (String)value;
/*      */       
/*  691 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  692 */         return null;
/*      */       }
/*      */       
/*  695 */       return Double.valueOf(Double.parseDouble(str));
/*      */     } 
/*      */     
/*  698 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Double");
/*      */   }
/*      */   
/*      */   public double getDoubleValue(String key) {
/*  702 */     Object value = this.map.get(key);
/*      */     
/*  704 */     if (value == null) {
/*  705 */       return 0.0D;
/*      */     }
/*      */     
/*  708 */     if (value instanceof Number) {
/*  709 */       return ((Number)value).doubleValue();
/*      */     }
/*      */     
/*  712 */     if (value instanceof String) {
/*  713 */       String str = (String)value;
/*      */       
/*  715 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  716 */         return 0.0D;
/*      */       }
/*      */       
/*  719 */       return Double.parseDouble(str);
/*      */     } 
/*      */     
/*  722 */     throw new JSONException("Can not cast '" + value.getClass() + "' to double value");
/*      */   }
/*      */   
/*      */   public BigDecimal getBigDecimal(String key) {
/*  726 */     Object value = this.map.get(key);
/*      */     
/*  728 */     if (value == null) {
/*  729 */       return null;
/*      */     }
/*      */     
/*  732 */     if (value instanceof Number) {
/*  733 */       if (value instanceof BigDecimal) {
/*  734 */         return (BigDecimal)value;
/*      */       }
/*      */       
/*  737 */       if (value instanceof BigInteger) {
/*  738 */         return new BigDecimal((BigInteger)value);
/*      */       }
/*      */       
/*  741 */       if (value instanceof Float) {
/*  742 */         float floatValue = ((Float)value).floatValue();
/*  743 */         return TypeUtils.toBigDecimal(floatValue);
/*      */       } 
/*      */       
/*  746 */       if (value instanceof Double) {
/*  747 */         double doubleValue = ((Double)value).doubleValue();
/*  748 */         return TypeUtils.toBigDecimal(doubleValue);
/*      */       } 
/*      */       
/*  751 */       long longValue = ((Number)value).longValue();
/*  752 */       return BigDecimal.valueOf(longValue);
/*      */     } 
/*      */     
/*  755 */     if (value instanceof String) {
/*  756 */       return TypeUtils.toBigDecimal((String)value);
/*      */     }
/*      */     
/*  759 */     throw new JSONException("Can not cast '" + value.getClass() + "' to BigDecimal");
/*      */   }
/*      */   
/*      */   public BigInteger getBigInteger(String key) {
/*  763 */     Object value = this.map.get(key);
/*      */     
/*  765 */     if (value == null) {
/*  766 */       return null;
/*      */     }
/*      */     
/*  769 */     if (value instanceof BigInteger) {
/*  770 */       return (BigInteger)value;
/*      */     }
/*      */     
/*  773 */     if (value instanceof Number) {
/*  774 */       if (value instanceof BigDecimal) {
/*  775 */         return ((BigDecimal)value).toBigInteger();
/*      */       }
/*      */       
/*  778 */       long longValue = ((Number)value).longValue();
/*  779 */       return BigInteger.valueOf(longValue);
/*      */     } 
/*      */     
/*  782 */     if (value instanceof String) {
/*  783 */       String str = (String)value;
/*      */       
/*  785 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  786 */         return null;
/*      */       }
/*      */       
/*  789 */       return new BigInteger(str);
/*      */     } 
/*      */     
/*  792 */     throw new JSONException("Can not cast '" + value.getClass() + "' to BigInteger");
/*      */   }
/*      */   
/*      */   public String getString(String key) {
/*  796 */     Object value = get(key);
/*      */     
/*  798 */     if (value == null) {
/*  799 */       return null;
/*      */     }
/*      */     
/*  802 */     return value.toString();
/*      */   }
/*      */   
/*      */   public Date getDate(String key) {
/*  806 */     Object value = get(key);
/*  807 */     return TypeUtils.toDate(value);
/*      */   }
/*      */   
/*      */   public Date getSqlDate(String key) {
/*  811 */     Object value = get(key);
/*  812 */     return (Date)TypeUtils.cast(value, Date.class, 
/*      */ 
/*      */         
/*  815 */         JSONFactory.getDefaultObjectReaderProvider());
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String key) {
/*  820 */     Object value = get(key);
/*  821 */     return (Timestamp)TypeUtils.cast(value, Timestamp.class, 
/*      */ 
/*      */         
/*  824 */         JSONFactory.getDefaultObjectReaderProvider());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object put(String key, Object value) {
/*  830 */     return this.map.put(key, value);
/*      */   }
/*      */   
/*      */   public JSONObject fluentPut(String key, Object value) {
/*  834 */     this.map.put(key, value);
/*  835 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void putAll(Map<? extends String, ? extends Object> m) {
/*  840 */     this.map.putAll(m);
/*      */   }
/*      */   
/*      */   public JSONObject fluentPutAll(Map<? extends String, ? extends Object> m) {
/*  844 */     this.map.putAll(m);
/*  845 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear() {
/*  850 */     this.map.clear();
/*      */   }
/*      */   
/*      */   public JSONObject fluentClear() {
/*  854 */     this.map.clear();
/*  855 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object remove(Object key) {
/*  860 */     return this.map.remove(key);
/*      */   }
/*      */   
/*      */   public JSONObject fluentRemove(Object key) {
/*  864 */     this.map.remove(key);
/*  865 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> keySet() {
/*  870 */     return this.map.keySet();
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection<Object> values() {
/*  875 */     return this.map.values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<Map.Entry<String, Object>> entrySet() {
/*  880 */     return this.map.entrySet();
/*      */   }
/*      */ 
/*      */   
/*      */   public Object clone() {
/*  885 */     return new JSONObject((this.map instanceof LinkedHashMap) ? 
/*  886 */         new LinkedHashMap<>(this.map) : 
/*  887 */         new HashMap<>(this.map));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/*  893 */     return this.map.equals(obj);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  898 */     return this.map.hashCode();
/*      */   }
/*      */ 
/*      */   
/*      */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*  903 */     Class<?>[] parameterTypes = method.getParameterTypes();
/*  904 */     if (parameterTypes.length == 1) {
/*  905 */       if ("equals".equals(method.getName())) {
/*  906 */         return Boolean.valueOf(equals(args[0]));
/*      */       }
/*      */       
/*  909 */       Class<?> returnType = method.getReturnType();
/*  910 */       if (returnType != void.class) {
/*  911 */         throw new JSONException("illegal setter");
/*      */       }
/*      */       
/*  914 */       String name = null;
/*  915 */       JSONField annotation = method.<JSONField>getAnnotation(JSONField.class);
/*  916 */       if (annotation != null && 
/*  917 */         annotation.name().length() != 0) {
/*  918 */         name = annotation.name();
/*      */       }
/*      */ 
/*      */       
/*  922 */       if (name == null) {
/*  923 */         name = method.getName();
/*      */         
/*  925 */         if (!name.startsWith("set")) {
/*  926 */           throw new JSONException("illegal setter");
/*      */         }
/*      */         
/*  929 */         name = name.substring(3);
/*  930 */         if (name.length() == 0) {
/*  931 */           throw new JSONException("illegal setter");
/*      */         }
/*  933 */         name = Character.toLowerCase(name.charAt(0)) + name.substring(1);
/*      */       } 
/*      */       
/*  936 */       this.map.put(name, args[0]);
/*  937 */       return null;
/*      */     } 
/*      */     
/*  940 */     if (parameterTypes.length == 0) {
/*  941 */       Class<?> returnType = method.getReturnType();
/*  942 */       if (returnType == void.class) {
/*  943 */         throw new JSONException("illegal getter");
/*      */       }
/*      */       
/*  946 */       String name = null;
/*  947 */       JSONField annotation = method.<JSONField>getAnnotation(JSONField.class);
/*  948 */       if (annotation != null && 
/*  949 */         annotation.name().length() != 0) {
/*  950 */         name = annotation.name();
/*      */       }
/*      */ 
/*      */       
/*  954 */       if (name == null) {
/*  955 */         name = method.getName();
/*  956 */         if (name.startsWith("get"))
/*  957 */         { name = name.substring(3);
/*  958 */           if (name.length() == 0) {
/*  959 */             throw new JSONException("illegal getter");
/*      */           }
/*  961 */           name = Character.toLowerCase(name.charAt(0)) + name.substring(1); }
/*  962 */         else if (name.startsWith("is"))
/*  963 */         { name = name.substring(2);
/*  964 */           if (name.length() == 0) {
/*  965 */             throw new JSONException("illegal getter");
/*      */           }
/*  967 */           name = Character.toLowerCase(name.charAt(0)) + name.substring(1); }
/*  968 */         else { if (name.startsWith("hashCode"))
/*  969 */             return Integer.valueOf(hashCode()); 
/*  970 */           if (name.startsWith("toString")) {
/*  971 */             return toString();
/*      */           }
/*  973 */           throw new JSONException("illegal getter"); }
/*      */       
/*      */       } 
/*      */       
/*  977 */       Object value = this.map.get(name);
/*  978 */       return TypeUtils.cast(value, method.getGenericReturnType(), ParserConfig.getGlobalInstance());
/*      */     } 
/*      */     
/*  981 */     throw new UnsupportedOperationException(method.toGenericString());
/*      */   }
/*      */   
/*      */   public Map<String, Object> getInnerMap() {
/*  985 */     return this.map;
/*      */   }
/*      */   
/*      */   public <T> T toJavaObject(Type type) {
/*  989 */     if (type instanceof Class) {
/*  990 */       return (T)JSONFactory.getDefaultObjectReaderProvider().getObjectReader(type).createInstance(this, 0L);
/*      */     }
/*  992 */     String str = JSON.toJSONString(this);
/*  993 */     return (T)JSON.parseObject(str, type);
/*      */   }
/*      */   
/*      */   public <T> T toJavaObject(Class<T> clazz) {
/*  997 */     if (clazz == Map.class) {
/*  998 */       return (T)this;
/*      */     }
/*      */     
/* 1001 */     if (clazz == Object.class && !containsKey(JSON.DEFAULT_TYPE_KEY)) {
/* 1002 */       return (T)this;
/*      */     }
/*      */     
/* 1005 */     if (clazz.isInstance(this)) {
/* 1006 */       return (T)this;
/*      */     }
/*      */     
/* 1009 */     ObjectReaderProvider provider = JSONFactory.getDefaultObjectReaderProvider();
/* 1010 */     ObjectReader objectReader = provider.getObjectReader(clazz);
/* 1011 */     return (T)objectReader.createInstance(this, 0L);
/*      */   }
/*      */   
/*      */   public <T> T toJavaObject(Class<T> clazz, ParserConfig config, int features) {
/* 1015 */     if (clazz == Map.class) {
/* 1016 */       return (T)this;
/*      */     }
/*      */     
/* 1019 */     if (clazz == Object.class && !containsKey(JSON.DEFAULT_TYPE_KEY)) {
/* 1020 */       return (T)this;
/*      */     }
/*      */     
/* 1023 */     return (T)TypeUtils.castToJavaBean(this, clazz, config);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1028 */     return JSON.toJSONString(this, new JSONWriter.Feature[] { JSONWriter.Feature.ReferenceDetection });
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) {
/* 1033 */     if (iface == Map.class) {
/* 1034 */       return (T)this.map;
/*      */     }
/* 1036 */     return (T)this;
/*      */   }
/*      */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSONObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */