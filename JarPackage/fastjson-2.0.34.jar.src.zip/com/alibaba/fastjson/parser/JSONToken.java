/*    */ package com.alibaba.fastjson.parser;
/*    */ 
/*    */ public class JSONToken {
/*    */   public static final int ERROR = 1;
/*    */   public static final int LITERAL_INT = 2;
/*    */   public static final int LITERAL_FLOAT = 3;
/*    */   public static final int LITERAL_STRING = 4;
/*    */   public static final int LITERAL_ISO8601_DATE = 5;
/*    */   public static final int TRUE = 6;
/*    */   public static final int FALSE = 7;
/*    */   public static final int NULL = 8;
/*    */   public static final int NEW = 9;
/*    */   public static final int LPAREN = 10;
/*    */   public static final int RPAREN = 11;
/*    */   public static final int LBRACE = 12;
/*    */   public static final int RBRACE = 13;
/*    */   public static final int LBRACKET = 14;
/*    */   public static final int RBRACKET = 15;
/*    */   public static final int COMMA = 16;
/*    */   public static final int COLON = 17;
/*    */   public static final int IDENTIFIER = 18;
/*    */   public static final int FIELD_NAME = 19;
/*    */   public static final int EOF = 20;
/*    */   public static final int SET = 21;
/*    */   public static final int TREE_SET = 22;
/*    */   public static final int UNDEFINED = 23;
/*    */   public static final int SEMI = 24;
/*    */   public static final int DOT = 25;
/*    */   public static final int HEX = 26;
/*    */   
/*    */   public static String name(int value) {
/* 32 */     switch (value) {
/*    */       case 1:
/* 34 */         return "error";
/*    */       case 2:
/* 36 */         return "int";
/*    */       case 3:
/* 38 */         return "float";
/*    */       case 4:
/* 40 */         return "string";
/*    */       case 5:
/* 42 */         return "iso8601";
/*    */       case 6:
/* 44 */         return "true";
/*    */       case 7:
/* 46 */         return "false";
/*    */       case 8:
/* 48 */         return "null";
/*    */       case 9:
/* 50 */         return "new";
/*    */       case 10:
/* 52 */         return "(";
/*    */       case 11:
/* 54 */         return ")";
/*    */       case 12:
/* 56 */         return "{";
/*    */       case 13:
/* 58 */         return "}";
/*    */       case 14:
/* 60 */         return "[";
/*    */       case 15:
/* 62 */         return "]";
/*    */       case 16:
/* 64 */         return ",";
/*    */       case 17:
/* 66 */         return ":";
/*    */       case 24:
/* 68 */         return ";";
/*    */       case 25:
/* 70 */         return ".";
/*    */       case 18:
/* 72 */         return "ident";
/*    */       case 19:
/* 74 */         return "fieldName";
/*    */       case 20:
/* 76 */         return "EOF";
/*    */       case 21:
/* 78 */         return "Set";
/*    */       case 22:
/* 80 */         return "TreeSet";
/*    */       case 23:
/* 82 */         return "undefined";
/*    */       case 26:
/* 84 */         return "hex";
/*    */     } 
/* 86 */     return "Unknown";
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\JSONToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */