/*     */ package com.alibaba.fastjson.parser;
/*     */ 
/*     */ import com.alibaba.fastjson.parser.deserializer.ObjectDeserializer;
/*     */ import com.alibaba.fastjson2.JSONException;
/*     */ import com.alibaba.fastjson2.JSONFactory;
/*     */ import com.alibaba.fastjson2.JSONReader;
/*     */ import com.alibaba.fastjson2.reader.ObjectReader;
/*     */ import com.alibaba.fastjson2.reader.ObjectReaderProvider;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ public class ParserConfig
/*     */ {
/*     */   public static final String DENY_PROPERTY = "fastjson.parser.deny";
/*     */   public static final String AUTOTYPE_ACCEPT = "fastjson.parser.autoTypeAccept";
/*  19 */   public static ParserConfig global = new ParserConfig(JSONFactory.getDefaultObjectReaderProvider(), false);
/*     */   
/*     */   public static ParserConfig getGlobalInstance() {
/*  22 */     return global;
/*     */   }
/*     */   
/*     */   final ObjectReaderProvider provider;
/*     */   public final boolean fieldBase;
/*     */   private boolean asmEnable;
/*     */   private boolean autoTypeSupport;
/*     */   
/*     */   ParserConfig(ObjectReaderProvider provider, boolean fieldBase) {
/*  31 */     this.provider = provider;
/*  32 */     this.fieldBase = fieldBase;
/*     */   }
/*     */   
/*     */   public ParserConfig() {
/*  36 */     this(new ObjectReaderProvider(), false);
/*     */   }
/*     */   
/*     */   public ParserConfig(ClassLoader parentClassLoader) {
/*  40 */     this(new ObjectReaderProvider(), false);
/*     */   }
/*     */   
/*     */   public ParserConfig(boolean fieldBase) {
/*  44 */     this(new ObjectReaderProvider(), fieldBase);
/*     */   }
/*     */   
/*     */   public boolean isAsmEnable() {
/*  48 */     return this.asmEnable;
/*     */   }
/*     */   
/*     */   public void setAsmEnable(boolean asmEnable) {
/*  52 */     this.asmEnable = asmEnable;
/*     */   }
/*     */   
/*     */   public ObjectReaderProvider getProvider() {
/*  56 */     return this.provider;
/*     */   }
/*     */   
/*     */   public void putDeserializer(Type type, ObjectDeserializer deserializer) {
/*  60 */     getProvider().register(type, (ObjectReader)deserializer);
/*     */   }
/*     */   
/*     */   public Class<?> checkAutoType(Class type) {
/*  64 */     return JSONFactory.getDefaultObjectReaderProvider().checkAutoType(type.getName(), null, 0L);
/*     */   }
/*     */   
/*     */   public boolean isSafeMode() {
/*  68 */     return ObjectReaderProvider.SAFE_MODE;
/*     */   }
/*     */   
/*     */   public void setSafeMode(boolean safeMode) {
/*  72 */     if (safeMode != ObjectReaderProvider.SAFE_MODE) {
/*  73 */       throw new JSONException("not support operation");
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isAutoTypeSupport() {
/*  78 */     return this.autoTypeSupport;
/*     */   }
/*     */   
/*     */   public void setAutoTypeSupport(boolean autoTypeSupport) {
/*  82 */     this.autoTypeSupport = autoTypeSupport;
/*     */   }
/*     */   
/*     */   public void addAccept(String name) {
/*  86 */     getProvider().addAutoTypeAccept(name);
/*     */   }
/*     */   
/*     */   public void addDeny(String name) {
/*  90 */     getProvider().addAutoTypeDeny(name);
/*     */   }
/*     */   
/*     */   public void addDenyInternal(String name) {
/*  94 */     getProvider().addAutoTypeDeny(name);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDefaultClassLoader(ClassLoader defaultClassLoader) {}
/*     */ 
/*     */   
/*     */   public void addAutoTypeCheckHandler(AutoTypeCheckHandler h) {
/* 103 */     if (getProvider().getAutoTypeBeforeHandler() != null) {
/* 104 */       throw new JSONException("not support operation");
/*     */     }
/*     */     
/* 107 */     getProvider().setAutoTypeBeforeHandler(h);
/*     */   }
/*     */ 
/*     */   
/*     */   public static interface AutoTypeCheckHandler
/*     */     extends JSONReader.AutoTypeBeforeHandler
/*     */   {
/*     */     Class<?> handler(String param1String, Class<?> param1Class, int param1Int);
/*     */ 
/*     */     
/*     */     default Class<?> apply(long typeNameHash, Class<?> expectClass, long features) {
/* 118 */       return null;
/*     */     }
/*     */     
/*     */     default Class<?> apply(String typeName, Class<?> expectClass, long features) {
/* 122 */       return handler(typeName, expectClass, (int)features);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void configFromPropety(Properties properties) {
/* 128 */     String property = properties.getProperty("fastjson.parser.deny");
/* 129 */     String[] items = splitItemsFormProperty(property);
/* 130 */     addItemsToDeny(items);
/*     */ 
/*     */     
/* 133 */     property = properties.getProperty("fastjson.parser.autoTypeAccept");
/* 134 */     items = splitItemsFormProperty(property);
/* 135 */     addItemsToAccept(items);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addItemsToDeny(String[] items) {
/* 140 */     if (items == null) {
/*     */       return;
/*     */     }
/*     */     
/* 144 */     for (int i = 0; i < items.length; i++) {
/* 145 */       String item = items[i];
/* 146 */       addDeny(item);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addItemsToAccept(String[] items) {
/* 151 */     if (items == null) {
/*     */       return;
/*     */     }
/*     */     
/* 155 */     for (int i = 0; i < items.length; i++) {
/* 156 */       String item = items[i];
/* 157 */       addAccept(item);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String[] splitItemsFormProperty(String property) {
/* 162 */     if (property != null && property.length() > 0) {
/* 163 */       return property.split(",");
/*     */     }
/* 165 */     return null;
/*     */   }
/*     */   
/*     */   public ObjectDeserializer get(Type type) {
/* 169 */     ObjectReader objectReader = getProvider().getObjectReader(type);
/* 170 */     if (objectReader instanceof ObjectDeserializer) {
/* 171 */       return (ObjectDeserializer)objectReader;
/*     */     }
/* 173 */     return new ObjectDeserializerWrapper(objectReader);
/*     */   }
/*     */   
/*     */   public ObjectDeserializer getDeserializer(Type type) {
/* 177 */     ObjectReader objectReader = getProvider().getObjectReader(type);
/* 178 */     if (objectReader instanceof ObjectDeserializer) {
/* 179 */       return (ObjectDeserializer)objectReader;
/*     */     }
/* 181 */     return new ObjectDeserializerWrapper(objectReader);
/*     */   }
/*     */   
/*     */   public ObjectDeserializer getDeserializer(Class<?> clazz, Type<?> type) {
/* 185 */     if (type == null) {
/* 186 */       type = clazz;
/*     */     }
/*     */     
/* 189 */     ObjectReader objectReader = getProvider().getObjectReader(type);
/* 190 */     if (objectReader instanceof ObjectDeserializer) {
/* 191 */       return (ObjectDeserializer)objectReader;
/*     */     }
/* 193 */     return new ObjectDeserializerWrapper(objectReader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parserAllFieldToCache(Class<?> clazz, Map<String, Field> fieldCacheMap) {
/* 203 */     Field[] fields = clazz.getDeclaredFields();
/* 204 */     for (Field field : fields) {
/* 205 */       String fieldName = field.getName();
/* 206 */       if (!fieldCacheMap.containsKey(fieldName)) {
/* 207 */         fieldCacheMap.put(fieldName, field);
/*     */       }
/*     */     } 
/* 210 */     if (clazz.getSuperclass() != null && clazz.getSuperclass() != Object.class) {
/* 211 */       parserAllFieldToCache(clazz.getSuperclass(), fieldCacheMap);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Field getFieldFromCache(String fieldName, Map<String, Field> fieldCacheMap) {
/* 216 */     Field field = fieldCacheMap.get(fieldName);
/*     */     
/* 218 */     if (field == null) {
/* 219 */       field = fieldCacheMap.get("_" + fieldName);
/*     */     }
/*     */     
/* 222 */     if (field == null) {
/* 223 */       field = fieldCacheMap.get("m_" + fieldName);
/*     */     }
/*     */     
/* 226 */     if (field == null) {
/* 227 */       char c0 = fieldName.charAt(0);
/* 228 */       if (c0 >= 'a' && c0 <= 'z') {
/* 229 */         char[] chars = fieldName.toCharArray();
/* 230 */         chars[0] = (char)(chars[0] - 32);
/* 231 */         String fieldNameX = new String(chars);
/* 232 */         field = fieldCacheMap.get(fieldNameX);
/*     */       } 
/*     */       
/* 235 */       if (fieldName.length() > 2) {
/* 236 */         char c1 = fieldName.charAt(1);
/* 237 */         if (c0 >= 'a' && c0 <= 'z' && c1 >= 'A' && c1 <= 'Z')
/*     */         {
/* 239 */           for (Map.Entry<String, Field> entry : fieldCacheMap.entrySet()) {
/* 240 */             if (fieldName.equalsIgnoreCase(entry.getKey())) {
/* 241 */               field = entry.getValue();
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 249 */     return field;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\ParserConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */