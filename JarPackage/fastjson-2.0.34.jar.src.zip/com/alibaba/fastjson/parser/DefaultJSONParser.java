/*     */ package com.alibaba.fastjson.parser;
/*     */ 
/*     */ import com.alibaba.fastjson.JSONException;
/*     */ import com.alibaba.fastjson.JSONObject;
/*     */ import com.alibaba.fastjson2.JSONReader;
/*     */ import java.io.Closeable;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DefaultJSONParser
/*     */   implements Closeable
/*     */ {
/*     */   private final JSONReader reader;
/*     */   private final ParserConfig config;
/*     */   private final JSONScanner lexer;
/*     */   private Object input;
/*     */   
/*     */   public DefaultJSONParser(String text) {
/*  21 */     this(JSONReader.of(text), ParserConfig.global);
/*  22 */     this.input = text;
/*     */   }
/*     */   
/*     */   public DefaultJSONParser(Object input, JSONLexer lexer, ParserConfig config) {
/*  26 */     this.lexer = (JSONScanner)lexer;
/*  27 */     this.reader = lexer.getReader();
/*  28 */     this.config = config;
/*  29 */     this.input = input;
/*     */   }
/*     */   
/*     */   public ParserConfig getConfig() {
/*  33 */     return this.config;
/*     */   }
/*     */   
/*     */   public DefaultJSONParser(String text, ParserConfig config) {
/*  37 */     this(JSONReader.of(text), config);
/*     */   }
/*     */   
/*     */   public DefaultJSONParser(JSONReader reader, ParserConfig config) {
/*  41 */     this.reader = reader;
/*  42 */     this.config = config;
/*  43 */     this.lexer = new JSONScanner(this.reader);
/*     */   }
/*     */   
/*     */   public JSONLexer getLexer() {
/*  47 */     return this.lexer;
/*     */   }
/*     */   
/*     */   public JSONReader getRawReader() {
/*  51 */     return this.reader;
/*     */   }
/*     */   
/*     */   public Object parse() {
/*  55 */     return this.reader.readAny();
/*     */   }
/*     */   
/*     */   public <T> List<T> parseArray(Class<T> clazz) {
/*  59 */     return this.reader.readArray(clazz);
/*     */   }
/*     */   
/*     */   public void parseArray(Type type, Collection array) {
/*  63 */     this.reader.readArray(array, type);
/*     */   }
/*     */   
/*     */   public void parseArray(Class<?> clazz, Collection array) {
/*  67 */     this.reader.readArray(array, clazz);
/*     */   }
/*     */   
/*     */   public Object[] parseArray(Type[] types) {
/*  71 */     return this.reader.readArray(types);
/*     */   }
/*     */   
/*     */   public final void parseArray(Collection array) {
/*  75 */     this.reader.readArray(array, Object.class);
/*     */   }
/*     */   
/*     */   public <T> T parseObject(Class<T> clazz) {
/*  79 */     return (T)this.reader.read(clazz);
/*     */   }
/*     */   
/*     */   public <T> T parseObject(Type type) {
/*  83 */     return (T)this.reader.read(type);
/*     */   }
/*     */   
/*     */   public void parseObject(Object object) {
/*  87 */     this.reader.readObject(object, new JSONReader.Feature[0]);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Object parse(Object fieldName) {
/*  92 */     return this.reader.readAny();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void handleResovleTask(Object value) {
/*  97 */     this.reader.handleResolveTasks(value);
/*     */   }
/*     */   
/*     */   public void handleResolveTasks(Object value) {
/* 101 */     this.reader.handleResolveTasks(value); } public final void accept(int token) {
/*     */     char expect;
/*     */     char ch;
/*     */     Number number;
/*     */     boolean isInt;
/* 106 */     switch (token) {
/*     */       case 25:
/* 108 */         expect = '.';
/*     */         break;
/*     */       case 12:
/* 111 */         expect = '{';
/*     */         break;
/*     */       case 13:
/* 114 */         expect = '}';
/*     */         break;
/*     */       case 14:
/* 117 */         expect = '[';
/*     */         break;
/*     */       case 15:
/* 120 */         expect = ']';
/*     */         break;
/*     */       case 10:
/* 123 */         expect = '(';
/*     */         break;
/*     */       case 11:
/* 126 */         expect = ')';
/*     */         break;
/*     */       case 16:
/* 129 */         if (this.reader.hasComma() || this.reader.nextIfComma()) {
/*     */           return;
/*     */         }
/* 132 */         throw new JSONException("syntax error, expect ',', actual " + this.reader
/* 133 */             .current());
/*     */       
/*     */       case 17:
/* 136 */         expect = ':';
/*     */         break;
/*     */       case 6:
/* 139 */         if (!this.reader.nextIfMatchIdent('t', 'r', 'u', 'e')) {
/* 140 */           throw new JSONException("syntax error, expect true, actual " + this.reader
/* 141 */               .current());
/*     */         }
/*     */         return;
/*     */       
/*     */       case 7:
/* 146 */         if (!this.reader.nextIfMatchIdent('f', 'a', 'l', 's', 'e')) {
/* 147 */           throw new JSONException("syntax error, expect false, actual " + this.reader
/* 148 */               .current());
/*     */         }
/*     */         return;
/*     */       
/*     */       case 8:
/* 153 */         if (!this.reader.nextIfNull()) {
/* 154 */           throw new JSONException("syntax error, expect false, actual " + this.reader
/* 155 */               .current());
/*     */         }
/*     */         return;
/*     */       
/*     */       case 4:
/* 160 */         ch = this.reader.current();
/* 161 */         if (ch == '"' || ch == '\'') {
/* 162 */           this.reader.readString();
/*     */           return;
/*     */         } 
/* 165 */         throw new JSONException("syntax error, expect string, actual " + ch);
/*     */ 
/*     */ 
/*     */       
/*     */       case 21:
/* 170 */         if (!this.reader.nextIfSet()) {
/* 171 */           throw new JSONException("syntax error, expect set, actual " + this.reader
/* 172 */               .current());
/*     */         }
/*     */         return;
/*     */       
/*     */       case 2:
/*     */       case 3:
/* 178 */         ch = this.reader.current();
/* 179 */         if (ch != '-' && ch != '+' && (ch < '0' || ch > '9')) {
/* 180 */           throw new JSONException("syntax error, expect int, actual " + this.reader
/* 181 */               .current());
/*     */         }
/*     */         
/* 184 */         number = this.reader.readNumber();
/* 185 */         isInt = (number instanceof Integer || number instanceof Long || number instanceof java.math.BigInteger);
/* 186 */         if (isInt) {
/* 187 */           if (token == 2) {
/*     */             return;
/*     */           }
/*     */         }
/* 191 */         else if (token == 3) {
/*     */           return;
/*     */         } 
/*     */         
/* 195 */         throw new JSONException("syntax error, expect int, actual " + this.reader
/* 196 */             .current());
/*     */       
/*     */       default:
/* 199 */         throw new JSONException("not support accept token " + JSONToken.name(token));
/*     */     } 
/*     */     
/* 202 */     if (!this.reader.nextIfMatch(expect)) {
/* 203 */       throw new JSONException("syntax error, expect " + 
/* 204 */           JSONToken.name(token) + ", actual " + this.reader.current());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public JSONObject parseObject() {
/* 210 */     if (this.reader.nextIfNull()) {
/* 211 */       return null;
/*     */     }
/*     */     
/* 214 */     JSONObject object = new JSONObject(this.lexer.isOrderedField());
/* 215 */     this.reader.read((Map)object, 0L);
/* 216 */     return object;
/*     */   }
/*     */   
/*     */   public void config(Feature feature, boolean state) {
/* 220 */     this.lexer.config(feature, state);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 225 */     this.reader.close();
/*     */   }
/*     */   
/*     */   public String getInput() {
/* 229 */     if (this.input instanceof char[]) {
/* 230 */       return new String((char[])this.input);
/*     */     }
/* 232 */     return this.input.toString();
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Feature feature) {
/* 236 */     return this.lexer.isEnabled(feature);
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\DefaultJSONParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */