/*    */ package com.alibaba.fastjson.parser;
/*    */ 
/*    */ import com.alibaba.fastjson.parser.deserializer.ObjectDeserializer;
/*    */ import com.alibaba.fastjson2.reader.ObjectReader;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ final class ObjectDeserializerWrapper
/*    */   implements ObjectDeserializer
/*    */ {
/*    */   private final ObjectReader raw;
/*    */   
/*    */   ObjectDeserializerWrapper(ObjectReader raw) {
/* 13 */     this.raw = raw;
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
/* 18 */     return (T)this.raw.readObject(parser.getRawReader(), type, fieldName, 0L);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\ObjectDeserializerWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */