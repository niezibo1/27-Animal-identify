/*    */ package com.alibaba.fastjson.parser;
/*    */ 
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public interface ObjectDeserializer {
/*    */   @Deprecated
/*    */   <T> T deserialze(DefaultJSONParser paramDefaultJSONParser, Type paramType, Object paramObject);
/*    */   
/*    */   @Deprecated
/*    */   default int getFastMatchToken() {
/* 11 */     return 0;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\ObjectDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */