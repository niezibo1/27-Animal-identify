/*    */ package com.alibaba.fastjson.parser.deserializer;
/*    */ 
/*    */ import com.alibaba.fastjson.parser.DefaultJSONParser;
/*    */ import com.alibaba.fastjson.parser.ParserConfig;
/*    */ import com.alibaba.fastjson2.JSONReader;
/*    */ import com.alibaba.fastjson2.reader.ObjectReader;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ObjectDeserializer
/*    */   extends ObjectReader
/*    */ {
/*    */   default Object readObject(JSONReader jsonReader, Type fieldType, Object fieldName, long features) {
/* 15 */     DefaultJSONParser parser = new DefaultJSONParser(jsonReader, ParserConfig.global);
/* 16 */     return deserialze(parser, fieldType, fieldName);
/*    */   }
/*    */   
/*    */   <T> T deserialze(DefaultJSONParser paramDefaultJSONParser, Type paramType, Object paramObject);
/*    */   
/*    */   default int getFastMatchToken() {
/* 22 */     return 0;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\deserializer\ObjectDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */