package com.alibaba.fastjson.parser.deserializer;

import com.alibaba.fastjson2.filter.ExtraProcessor;

public interface ExtraProcessor extends ParseProcess, ExtraProcessor {}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\deserializer\ExtraProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */