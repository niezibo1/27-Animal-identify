package com.alibaba.fastjson.parser.deserializer;

import com.alibaba.fastjson2.filter.Filter;

public interface ParseProcess extends Filter {}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\deserializer\ParseProcess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */