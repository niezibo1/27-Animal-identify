/*    */ package com.alibaba.fastjson.parser.deserializer;
/*    */ 
/*    */ import com.alibaba.fastjson.parser.DefaultJSONParser;
/*    */ import com.alibaba.fastjson.parser.ParserConfig;
/*    */ import com.alibaba.fastjson2.reader.ObjectReader;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class JavaBeanDeserializer
/*    */   implements ObjectDeserializer
/*    */ {
/*    */   final ObjectReader objectReader;
/*    */   
/*    */   public JavaBeanDeserializer(ParserConfig config, Class<?> clazz, Type<?> type) {
/* 14 */     if (type == null) {
/* 15 */       type = clazz;
/*    */     }
/*    */     
/* 18 */     if (config == null) {
/* 19 */       config = ParserConfig.global;
/*    */     }
/*    */     
/* 22 */     this.objectReader = config.getProvider().getObjectReader(type);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
/* 27 */     return (T)this.objectReader.readObject(parser.getRawReader(), type, fieldName, 0L);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\deserializer\JavaBeanDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */