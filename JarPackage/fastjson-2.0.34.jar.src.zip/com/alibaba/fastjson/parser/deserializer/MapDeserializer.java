/*    */ package com.alibaba.fastjson.parser.deserializer;
/*    */ 
/*    */ import com.alibaba.fastjson.parser.DefaultJSONParser;
/*    */ import com.alibaba.fastjson2.JSONReader;
/*    */ import com.alibaba.fastjson2.reader.ObjectReader;
/*    */ import com.alibaba.fastjson2.util.ParameterizedTypeImpl;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ public class MapDeserializer
/*    */   implements ObjectDeserializer
/*    */ {
/* 14 */   public static final MapDeserializer instance = new MapDeserializer();
/*    */ 
/*    */   
/*    */   public <T> T deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
/* 18 */     return (T)parser.getRawReader().read(Map.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Map parseMap(DefaultJSONParser parser, Map<String, Object> map, Type valueType, Object fieldName, int features) {
/* 28 */     ParameterizedTypeImpl parameterizedTypeImpl = new ParameterizedTypeImpl(Map.class, new Type[] { String.class, valueType });
/* 29 */     JSONReader reader = parser.getLexer().getReader();
/* 30 */     ObjectReader objectReader = reader.getObjectReader((Type)parameterizedTypeImpl);
/* 31 */     Map<String, Object> object = (Map<String, Object>)objectReader.readObject(reader, (Type)parameterizedTypeImpl, fieldName, 0L);
/* 32 */     map.putAll(object);
/* 33 */     return map;
/*    */   }
/*    */   
/*    */   public static Map parseMap(DefaultJSONParser parser, Map<String, Object> map, Type valueType, Object fieldName) {
/* 37 */     return parseMap(parser, map, valueType, fieldName, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object parseMap(DefaultJSONParser parser, Map<Object, Object> map, Type keyType, Type valueType, Object fieldName) {
/* 47 */     JSONReader jsonReader = parser.getRawReader();
/* 48 */     jsonReader.read(map, keyType, valueType, 0L);
/* 49 */     return map;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\deserializer\MapDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */