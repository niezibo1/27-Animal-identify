/*     */ package com.alibaba.fastjson.parser;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson.JSONException;
/*     */ import com.alibaba.fastjson2.JSONReader;
/*     */ import com.alibaba.fastjson2.util.DateUtils;
/*     */ import java.io.Closeable;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ public class JSONScanner
/*     */   extends JSONLexerBase
/*     */   implements Closeable
/*     */ {
/*     */   private final JSONReader reader;
/*     */   private boolean orderedField;
/*     */   protected int token;
/*     */   private String strVal;
/*     */   protected Calendar calendar;
/*     */   protected String str;
/*     */   
/*     */   public JSONScanner(JSONReader reader) {
/*  24 */     this.reader = reader;
/*     */   }
/*     */   
/*     */   public JSONScanner(String str) {
/*  28 */     this.reader = JSONReader.of(str);
/*  29 */     this.str = str;
/*     */   }
/*     */   
/*     */   public JSONScanner(String str, int features) {
/*  33 */     this.reader = JSONReader.of(str, JSON.createReadContext(features, new Feature[0]));
/*     */   }
/*     */   
/*     */   public Calendar getCalendar() {
/*  37 */     return this.calendar;
/*     */   }
/*     */   
/*     */   public boolean scanISO8601DateIfMatch() {
/*  41 */     return scanISO8601DateIfMatch(true);
/*     */   }
/*     */   
/*     */   public boolean scanISO8601DateIfMatch(boolean strict) {
/*  45 */     if (this.str != null) {
/*     */       try {
/*  47 */         long millis = DateUtils.parseMillis(this.str);
/*  48 */         Calendar calendar = Calendar.getInstance();
/*  49 */         calendar.setTimeInMillis(millis);
/*  50 */         this.calendar = calendar;
/*  51 */         return true;
/*  52 */       } catch (Exception ignored) {
/*  53 */         return false;
/*     */       } 
/*     */     }
/*     */     
/*  57 */     throw new JSONException("UnsupportedOperation");
/*     */   }
/*     */ 
/*     */   
/*     */   public JSONReader getReader() {
/*  62 */     return this.reader;
/*     */   }
/*     */   
/*     */   public boolean isOrderedField() {
/*  66 */     return this.orderedField;
/*     */   }
/*     */ 
/*     */   
/*     */   public String stringVal() {
/*  71 */     return this.strVal;
/*     */   }
/*     */   
/*     */   public BigDecimal decimalValue() {
/*  75 */     return this.reader.getBigDecimal();
/*     */   }
/*     */   
/*     */   public int token() {
/*  79 */     return this.token;
/*     */   }
/*     */   
/*     */   public void config(Feature feature, boolean state) {
/*  83 */     JSONReader.Feature rawFeature = null;
/*     */     
/*  85 */     boolean not = false;
/*  86 */     switch (feature) {
/*     */       case AllowUnQuotedFieldNames:
/*  88 */         rawFeature = JSONReader.Feature.AllowUnQuotedFieldNames;
/*     */         break;
/*     */       case SupportArrayToBean:
/*  91 */         rawFeature = JSONReader.Feature.SupportArrayToBean;
/*     */         break;
/*     */       case DisableFieldSmartMatch:
/*  94 */         rawFeature = JSONReader.Feature.SupportSmartMatch;
/*  95 */         not = true;
/*     */         break;
/*     */       case SupportAutoType:
/*  98 */         rawFeature = JSONReader.Feature.SupportAutoType;
/*     */         break;
/*     */       case NonStringKeyAsString:
/* 101 */         rawFeature = JSONReader.Feature.NonStringKeyAsString;
/*     */         break;
/*     */       case ErrorOnEnumNotMatch:
/* 104 */         rawFeature = JSONReader.Feature.ErrorOnEnumNotMatch;
/*     */         break;
/*     */       case SupportClassForName:
/* 107 */         rawFeature = JSONReader.Feature.SupportClassForName;
/*     */         break;
/*     */       case ErrorOnNotSupportAutoType:
/* 110 */         rawFeature = JSONReader.Feature.ErrorOnNotSupportAutoType;
/*     */         break;
/*     */       case UseNativeJavaObject:
/* 113 */         rawFeature = JSONReader.Feature.UseNativeObject;
/*     */         break;
/*     */       case UseBigDecimal:
/* 116 */         rawFeature = JSONReader.Feature.UseBigDecimalForDoubles;
/* 117 */         not = true;
/*     */         break;
/*     */       case OrderedField:
/* 120 */         this.orderedField = state;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 126 */     if (rawFeature == null) {
/*     */       return;
/*     */     }
/*     */     
/* 130 */     if (not) {
/* 131 */       state = !state;
/*     */     }
/*     */     
/* 134 */     JSONReader.Context context = this.reader.getContext();
/* 135 */     context.config(rawFeature, state);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Feature feature) {
/* 139 */     JSONReader.Feature rawFeature = null;
/*     */     
/* 141 */     switch (feature) {
/*     */       case AllowUnQuotedFieldNames:
/* 143 */         rawFeature = JSONReader.Feature.AllowUnQuotedFieldNames;
/*     */         break;
/*     */       case SupportArrayToBean:
/* 146 */         rawFeature = JSONReader.Feature.SupportArrayToBean;
/*     */         break;
/*     */       case DisableFieldSmartMatch:
/* 149 */         return !this.reader.isEnabled(JSONReader.Feature.SupportSmartMatch);
/*     */       case SupportAutoType:
/* 151 */         rawFeature = JSONReader.Feature.SupportAutoType;
/*     */         break;
/*     */       case NonStringKeyAsString:
/* 154 */         rawFeature = JSONReader.Feature.NonStringKeyAsString;
/*     */         break;
/*     */       case ErrorOnEnumNotMatch:
/* 157 */         rawFeature = JSONReader.Feature.ErrorOnEnumNotMatch;
/*     */         break;
/*     */       case SupportClassForName:
/* 160 */         rawFeature = JSONReader.Feature.SupportClassForName;
/*     */         break;
/*     */       case ErrorOnNotSupportAutoType:
/* 163 */         rawFeature = JSONReader.Feature.ErrorOnNotSupportAutoType;
/*     */         break;
/*     */       case UseNativeJavaObject:
/* 166 */         rawFeature = JSONReader.Feature.UseNativeObject;
/*     */         break;
/*     */       case UseBigDecimal:
/* 169 */         return !this.reader.isEnabled(JSONReader.Feature.UseBigDecimalForDoubles);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 174 */     if (rawFeature == null) {
/* 175 */       return true;
/*     */     }
/*     */     
/* 178 */     return this.reader.isEnabled(rawFeature);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBlankInput() {
/* 183 */     return this.reader.isEnd();
/*     */   }
/*     */ 
/*     */   
/*     */   public int intValue() {
/* 188 */     return this.reader.getInt32Value();
/*     */   }
/*     */ 
/*     */   
/*     */   public long longValue() {
/* 193 */     return this.reader.getInt64Value();
/*     */   } public final void nextToken() {
/*     */     Number number;
/*     */     boolean boolValue;
/* 197 */     this.strVal = null;
/* 198 */     char ch = this.reader.current();
/* 199 */     switch (ch) {
/*     */       case '[':
/* 201 */         this.reader.next();
/* 202 */         this.token = 14;
/*     */         return;
/*     */       case ']':
/* 205 */         this.reader.next();
/* 206 */         this.token = 15;
/*     */         return;
/*     */       case '{':
/* 209 */         this.reader.next();
/* 210 */         this.token = 12;
/*     */         return;
/*     */       case '}':
/* 213 */         this.reader.next();
/* 214 */         this.token = 13;
/*     */         return;
/*     */       case ':':
/* 217 */         this.reader.next();
/* 218 */         this.token = 17;
/*     */         return;
/*     */       case '"':
/*     */       case '\'':
/* 222 */         this.strVal = this.reader.readString();
/* 223 */         this.token = 4;
/*     */         return;
/*     */       case '+':
/*     */       case '-':
/*     */       case '0':
/*     */       case '1':
/*     */       case '2':
/*     */       case '3':
/*     */       case '4':
/*     */       case '5':
/*     */       case '6':
/*     */       case '7':
/*     */       case '8':
/*     */       case '9':
/* 237 */         number = this.reader.readNumber();
/* 238 */         if (number instanceof BigDecimal || number instanceof Float || number instanceof Double) {
/* 239 */           this.token = 3;
/*     */         } else {
/* 241 */           this.token = 2;
/*     */         } 
/*     */         return;
/*     */       case 'f':
/*     */       case 't':
/* 246 */         boolValue = this.reader.readBoolValue();
/* 247 */         this.token = boolValue ? 6 : 7;
/*     */         return;
/*     */       case 'n':
/* 250 */         this.reader.readNull();
/* 251 */         this.token = 8;
/*     */         return;
/*     */       case '\032':
/* 254 */         this.token = 20;
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 260 */     if (this.reader.nextIfNull()) {
/*     */       return;
/*     */     }
/*     */     
/* 264 */     throw new JSONException("not support operation");
/*     */   }
/*     */ 
/*     */   
/*     */   public char getCurrent() {
/* 269 */     return this.reader.current();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void nextToken(int expect) {
/* 274 */     nextToken();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEOF() {
/* 279 */     return this.reader.isEnd();
/*     */   }
/*     */   
/*     */   public void close() {}
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\JSONScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */