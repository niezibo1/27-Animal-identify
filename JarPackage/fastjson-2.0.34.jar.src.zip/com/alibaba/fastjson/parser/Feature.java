/*     */ package com.alibaba.fastjson.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Feature
/*     */ {
/*  25 */   AutoCloseSource,
/*     */ 
/*     */ 
/*     */   
/*  29 */   AllowComment,
/*     */ 
/*     */ 
/*     */   
/*  33 */   AllowUnQuotedFieldNames,
/*     */ 
/*     */ 
/*     */   
/*  37 */   AllowSingleQuotes,
/*     */ 
/*     */ 
/*     */   
/*  41 */   InternFieldNames,
/*     */ 
/*     */ 
/*     */   
/*  45 */   AllowISO8601DateFormat,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   AllowArbitraryCommas,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   UseBigDecimal,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   IgnoreNotMatch,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   SortFeidFastMatch,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   DisableASM,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   DisableCircularReferenceDetect,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   InitStringFieldAsEmpty,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   SupportArrayToBean,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   OrderedField,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   DisableSpecialKeyDetect,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   UseObjectArray,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   SupportNonPublicField,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   IgnoreAutoType,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   DisableFieldSmartMatch,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   SupportAutoType,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   NonStringKeyAsString,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   CustomMapDeserializer,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   ErrorOnEnumNotMatch,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   TrimStringFieldValue,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   SupportClassForName,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   ErrorOnNotSupportAutoType,
/* 155 */   UseNativeJavaObject;
/*     */   
/*     */   public final int mask;
/*     */   
/*     */   Feature() {
/* 160 */     this.mask = 1 << ordinal();
/*     */   }
/*     */   
/*     */   public static boolean isEnabled(int features, Feature feature) {
/* 164 */     return ((features & feature.mask) != 0);
/*     */   }
/*     */   
/*     */   public static int config(int features, Feature feature, boolean state) {
/* 168 */     if (state) {
/* 169 */       features |= feature.mask;
/*     */     } else {
/* 171 */       features &= feature.mask ^ 0xFFFFFFFF;
/*     */     } 
/*     */     
/* 174 */     return features;
/*     */   }
/*     */   
/*     */   public static int of(Feature[] features) {
/* 178 */     if (features == null) {
/* 179 */       return 0;
/*     */     }
/*     */     
/* 182 */     int value = 0;
/*     */     
/* 184 */     for (Feature feature : features) {
/* 185 */       value |= feature.mask;
/*     */     }
/*     */     
/* 188 */     return value;
/*     */   }
/*     */   
/*     */   public final int getMask() {
/* 192 */     return this.mask;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\parser\Feature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */