/*      */ package com.alibaba.fastjson;
/*      */ import com.alibaba.fastjson.parser.Feature;
/*      */ import com.alibaba.fastjson.parser.ParserConfig;
/*      */ import com.alibaba.fastjson.parser.deserializer.ParseProcess;
/*      */ import com.alibaba.fastjson.serializer.NameFilter;
/*      */ import com.alibaba.fastjson.serializer.SerializeConfig;
/*      */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*      */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*      */ import com.alibaba.fastjson.util.IOUtils;
/*      */ import com.alibaba.fastjson2.JSONException;
/*      */ import com.alibaba.fastjson2.JSONFactory;
/*      */ import com.alibaba.fastjson2.JSONReader;
/*      */ import com.alibaba.fastjson2.JSONWriter;
/*      */ import com.alibaba.fastjson2.filter.Filter;
/*      */ import com.alibaba.fastjson2.filter.ValueFilter;
/*      */ import com.alibaba.fastjson2.reader.ObjectReader;
/*      */ import com.alibaba.fastjson2.reader.ObjectReaderProvider;
/*      */ import com.alibaba.fastjson2.util.ParameterizedTypeImpl;
/*      */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*      */ import com.alibaba.fastjson2.writer.ObjectWriterProvider;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Type;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetDecoder;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*      */ import java.util.function.Supplier;
/*      */ 
/*      */ public abstract class JSON implements JSONAware {
/*   41 */   private static TimeZone DEFAULT_TIME_ZONE = TimeZone.getDefault();
/*      */   public static final String VERSION = "2.0.34";
/*   43 */   static final Cache CACHE = new Cache();
/*      */   
/*   45 */   static final AtomicReferenceFieldUpdater<Cache, char[]> CHARS_UPDATER = (AtomicReferenceFieldUpdater)AtomicReferenceFieldUpdater.newUpdater(Cache.class, (Class)char[].class, "chars");
/*   46 */   public static TimeZone defaultTimeZone = DEFAULT_TIME_ZONE;
/*   47 */   public static Locale defaultLocale = Locale.getDefault();
/*   48 */   public static String DEFAULT_TYPE_KEY = "@type";
/*   49 */   public static String DEFFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
/*      */   public static int DEFAULT_PARSER_FEATURE;
/*      */   public static int DEFAULT_GENERATE_FEATURE;
/*      */   
/*      */   static {
/*   54 */     int features = 0;
/*   55 */     features |= Feature.AutoCloseSource.getMask();
/*   56 */     features |= Feature.InternFieldNames.getMask();
/*   57 */     features |= Feature.UseBigDecimal.getMask();
/*   58 */     features |= Feature.AllowUnQuotedFieldNames.getMask();
/*   59 */     features |= Feature.AllowSingleQuotes.getMask();
/*   60 */     features |= Feature.AllowArbitraryCommas.getMask();
/*   61 */     features |= Feature.SortFeidFastMatch.getMask();
/*   62 */     features |= Feature.IgnoreNotMatch.getMask();
/*   63 */     DEFAULT_PARSER_FEATURE = features;
/*      */ 
/*      */ 
/*      */     
/*   67 */     features = 0;
/*   68 */     features |= SerializerFeature.QuoteFieldNames.getMask();
/*   69 */     features |= SerializerFeature.SkipTransientField.getMask();
/*   70 */     features |= SerializerFeature.WriteEnumUsingName.getMask();
/*   71 */     features |= SerializerFeature.SortField.getMask();
/*      */     
/*   73 */     DEFAULT_GENERATE_FEATURE = features;
/*      */   }
/*      */   
/*   76 */   static final Supplier<List> arraySupplier = JSONArray::new;
/*   77 */   static final Supplier<Map> defaultSupplier = JSONObject::new;
/*      */   static final Supplier<Map> orderedSupplier = () -> new JSONObject(true);
/*      */   
/*      */   static {
/*   81 */     boolean android = JDKUtils.ANDROID;
/*   82 */     ObjectReaderProvider readerProvider = JSONFactory.getDefaultObjectReaderProvider();
/*   83 */     if (!android) {
/*   84 */       readerProvider.register((ObjectReaderModule)AwtRederModule.INSTANCE);
/*      */     }
/*   86 */     readerProvider.register(new Fastjson1xReaderModule(readerProvider));
/*      */     
/*   88 */     ObjectWriterProvider writerProvider = SerializeConfig.DEFAULT_PROVIDER;
/*   89 */     if (!android) {
/*   90 */       writerProvider.register((ObjectWriterModule)AwtWriterModule.INSTANCE);
/*      */     }
/*      */     
/*   93 */     writerProvider.register(new Fastjson1xWriterModule(writerProvider));
/*      */   }
/*      */   
/*      */   public static JSONReader.Context createReadContext(int featuresValue, Feature... features) {
/*   97 */     return createReadContext(JSONFactory.getDefaultObjectReaderProvider(), featuresValue, features);
/*      */   }
/*      */   
/*      */   static JSONReader.Context createReadContext(ObjectReaderProvider provider, int featuresValue, Feature... features) {
/*  101 */     for (Feature feature : features) {
/*  102 */       featuresValue |= feature.mask;
/*      */     }
/*      */     
/*  105 */     JSONReader.Context context = new JSONReader.Context(provider);
/*      */     
/*  107 */     if ((featuresValue & Feature.UseBigDecimal.mask) == 0) {
/*  108 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.UseBigDecimalForDoubles });
/*      */     }
/*      */     
/*  111 */     if ((featuresValue & Feature.SupportArrayToBean.mask) != 0) {
/*  112 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.SupportArrayToBean });
/*      */     }
/*      */     
/*  115 */     if ((featuresValue & Feature.ErrorOnEnumNotMatch.mask) != 0) {
/*  116 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.ErrorOnEnumNotMatch });
/*      */     }
/*      */     
/*  119 */     if ((featuresValue & Feature.SupportNonPublicField.mask) != 0) {
/*  120 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.FieldBased });
/*      */     }
/*      */     
/*  123 */     if ((featuresValue & Feature.SupportClassForName.mask) != 0) {
/*  124 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.SupportClassForName });
/*      */     }
/*      */     
/*  127 */     if ((featuresValue & Feature.TrimStringFieldValue.mask) != 0) {
/*  128 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.TrimString });
/*      */     }
/*      */     
/*  131 */     if ((featuresValue & Feature.ErrorOnNotSupportAutoType.mask) != 0) {
/*  132 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.ErrorOnNotSupportAutoType });
/*      */     }
/*      */     
/*  135 */     if ((featuresValue & Feature.AllowUnQuotedFieldNames.mask) != 0) {
/*  136 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.AllowUnQuotedFieldNames });
/*      */     }
/*      */     
/*  139 */     if ((featuresValue & Feature.UseNativeJavaObject.mask) != 0) {
/*  140 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.UseNativeObject });
/*      */     } else {
/*  142 */       context.setArraySupplier(arraySupplier);
/*  143 */       context.setObjectSupplier(
/*  144 */           ((featuresValue & Feature.OrderedField.mask) != 0) ? 
/*  145 */           orderedSupplier : 
/*  146 */           defaultSupplier);
/*      */     } 
/*      */ 
/*      */     
/*  150 */     if ((featuresValue & Feature.NonStringKeyAsString.mask) != 0) {
/*  151 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.NonStringKeyAsString });
/*      */     }
/*      */     
/*  154 */     if ((featuresValue & Feature.DisableFieldSmartMatch.mask) == 0) {
/*  155 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.SupportSmartMatch });
/*      */     }
/*      */     
/*  158 */     if ((featuresValue & Feature.SupportAutoType.mask) != 0) {
/*  159 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.SupportAutoType });
/*      */     }
/*      */     
/*  162 */     String defaultDateFormat = DEFFAULT_DATE_FORMAT;
/*  163 */     if (!"yyyy-MM-dd HH:mm:ss".equals(defaultDateFormat)) {
/*  164 */       context.setDateFormat(defaultDateFormat);
/*      */     }
/*      */     
/*  167 */     context.config(new JSONReader.Feature[] { JSONReader.Feature.Base64StringAsByteArray });
/*      */     
/*  169 */     return context;
/*      */   }
/*      */   
/*      */   public static JSONObject parseObject(String str) {
/*  173 */     if (str == null || str.isEmpty()) {
/*  174 */       return null;
/*      */     }
/*      */     
/*  177 */     JSONReader.Context context = createReadContext(
/*  178 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, new Feature[0]);
/*      */ 
/*      */     
/*  181 */     JSONReader reader = JSONReader.of(str, context);
/*      */     
/*      */     try {
/*  184 */       Map<String, Object> map = new HashMap<>();
/*  185 */       reader.read(map, 0L);
/*  186 */       JSONObject jsonObject = new JSONObject(map);
/*  187 */       reader.handleResolveTasks(jsonObject);
/*  188 */       return jsonObject;
/*  189 */     } catch (JSONException e) {
/*  190 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  191 */       if (cause == null) {
/*  192 */         jSONException1 = e;
/*      */       }
/*  194 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static JSONObject parseObject(String text, Feature... features) {
/*  199 */     if (text == null || text.isEmpty()) {
/*  200 */       return null;
/*      */     }
/*      */     
/*  203 */     JSONReader.Context context = createReadContext(
/*  204 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  208 */     JSONReader reader = JSONReader.of(text, context);
/*      */     
/*  210 */     String defaultDateFormat = DEFFAULT_DATE_FORMAT;
/*  211 */     if (!"yyyy-MM-dd HH:mm:ss".equals(defaultDateFormat)) {
/*  212 */       context.setDateFormat(defaultDateFormat);
/*      */     }
/*      */     
/*  215 */     boolean ordered = false;
/*  216 */     for (Feature feature : features) {
/*  217 */       if (feature == Feature.OrderedField) {
/*  218 */         ordered = true;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     try {
/*  224 */       Map<String, Object> map = ordered ? new LinkedHashMap<>() : new HashMap<>();
/*  225 */       reader.read(map, 0L);
/*  226 */       JSONObject jsonObject = new JSONObject(map);
/*  227 */       reader.handleResolveTasks(jsonObject);
/*  228 */       return jsonObject;
/*  229 */     } catch (JSONException e) {
/*  230 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  231 */       if (cause == null) {
/*  232 */         jSONException1 = e;
/*      */       }
/*  234 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(byte[] bytes, Charset charset, Type objectClass, ParserConfig config, ParseProcess processor, int featureValues, Feature... features) {
/*  247 */     if (bytes == null || bytes.length == 0) {
/*  248 */       return null;
/*      */     }
/*      */     
/*  251 */     if (config == null) {
/*  252 */       config = ParserConfig.global;
/*      */     }
/*      */     
/*  255 */     JSONReader.Context context = createReadContext(config
/*  256 */         .getProvider(), featureValues, features);
/*      */ 
/*      */ 
/*      */     
/*  260 */     if (processor != null) {
/*  261 */       context.config((Filter)processor);
/*      */     }
/*      */     
/*  264 */     JSONReader jsonReader = JSONReader.of(bytes, 0, bytes.length, charset, context);
/*      */     
/*      */     try {
/*  267 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectClass);
/*  268 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  269 */       if (object != null) {
/*  270 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  272 */       return object;
/*  273 */     } catch (JSONException e) {
/*  274 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  275 */       if (cause == null) {
/*  276 */         jSONException1 = e;
/*      */       }
/*  278 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(byte[] bytes, int offset, int len, Charset charset, Type objectType, ParserConfig config, ParseProcess processor, int featureValues, Feature... features) {
/*  293 */     if (bytes == null || bytes.length == 0 || len == 0) {
/*  294 */       return null;
/*      */     }
/*      */     
/*  297 */     if (config == null) {
/*  298 */       config = ParserConfig.global;
/*      */     }
/*      */     
/*  301 */     JSONReader.Context context = createReadContext(config
/*  302 */         .getProvider(), featureValues, features);
/*      */ 
/*      */ 
/*      */     
/*  306 */     if (processor != null) {
/*  307 */       context.config((Filter)processor);
/*      */     }
/*      */     
/*  310 */     JSONReader jsonReader = JSONReader.of(bytes, offset, len, charset, context);
/*      */     
/*      */     try {
/*  313 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectType);
/*  314 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  315 */       if (object != null) {
/*  316 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  318 */       return object;
/*  319 */     } catch (JSONException e) {
/*  320 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  321 */       if (cause == null) {
/*  322 */         jSONException1 = e;
/*      */       }
/*  324 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(char[] str, int length, Type objectType, Feature... features) {
/*  329 */     if (str == null || str.length == 0) {
/*  330 */       return null;
/*      */     }
/*      */     
/*  333 */     JSONReader.Context context = createReadContext(
/*  334 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  338 */     JSONReader jsonReader = JSONReader.of(str, 0, length, context);
/*      */     
/*      */     try {
/*  341 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectType);
/*  342 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  343 */       if (object != null) {
/*  344 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  346 */       return object;
/*  347 */     } catch (JSONException e) {
/*  348 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  349 */       if (cause == null) {
/*  350 */         jSONException1 = e;
/*      */       }
/*  352 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(char[] str, Class<T> objectClass, Feature... features) {
/*  357 */     if (str == null || str.length == 0) {
/*  358 */       return null;
/*      */     }
/*      */     
/*  361 */     JSONReader.Context context = createReadContext(
/*  362 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  366 */     JSONReader jsonReader = JSONReader.of(str, context);
/*      */     
/*      */     try {
/*  369 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectClass);
/*  370 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  371 */       if (object != null) {
/*  372 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  374 */       return object;
/*  375 */     } catch (JSONException e) {
/*  376 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  377 */       if (cause == null) {
/*  378 */         jSONException1 = e;
/*      */       }
/*  380 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(String str, Type objectClass, ParserConfig config, ParseProcess processor, int featureValues, Feature... features) {
/*  392 */     if (str == null || str.isEmpty()) {
/*  393 */       return null;
/*      */     }
/*      */     
/*  396 */     if (config == null) {
/*  397 */       config = ParserConfig.global;
/*      */     }
/*      */     
/*  400 */     JSONReader.Context context = createReadContext(config
/*  401 */         .getProvider(), featureValues, features);
/*      */ 
/*      */ 
/*      */     
/*  405 */     JSONReader jsonReader = JSONReader.of(str, context);
/*  406 */     context.config((Filter)processor);
/*      */     
/*      */     try {
/*  409 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectClass);
/*  410 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  411 */       if (object != null) {
/*  412 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  414 */       return object;
/*  415 */     } catch (JSONException e) {
/*  416 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  417 */       if (cause == null) {
/*  418 */         jSONException1 = e;
/*      */       }
/*  420 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(String input, Type clazz, ParserConfig config, int featureValues, Feature... features) {
/*  426 */     return parseObject(input, clazz, config, (ParseProcess)null, featureValues, features);
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(String str, Type objectType, ParseProcess processor, Feature... features) {
/*  430 */     if (str == null || str.isEmpty()) {
/*  431 */       return null;
/*      */     }
/*      */     
/*  434 */     JSONReader.Context context = createReadContext(
/*  435 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  439 */     JSONReader jsonReader = JSONReader.of(str, context);
/*  440 */     context.config((Filter)processor);
/*      */     
/*      */     try {
/*  443 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectType);
/*  444 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  445 */       if (object != null) {
/*  446 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  448 */       return object;
/*  449 */     } catch (JSONException e) {
/*  450 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  451 */       if (cause == null) {
/*  452 */         jSONException1 = e;
/*      */       }
/*  454 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(String str, Class<T> objectClass, ParseProcess processor, Feature... features) {
/*  460 */     if (str == null || str.isEmpty()) {
/*  461 */       return null;
/*      */     }
/*      */     
/*  464 */     JSONReader.Context context = createReadContext(
/*  465 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  469 */     JSONReader jsonReader = JSONReader.of(str, context);
/*  470 */     context.config((Filter)processor);
/*      */     
/*      */     try {
/*  473 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectClass);
/*  474 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  475 */       if (object != null) {
/*  476 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  478 */       return object;
/*  479 */     } catch (JSONException e) {
/*  480 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  481 */       if (cause == null) {
/*  482 */         jSONException1 = e;
/*      */       }
/*  484 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(String str, TypeReference<T> typeReference, Feature... features) {
/*  490 */     return parseObject(str, typeReference.getType(), features);
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(String input, Type clazz, int featureValues, Feature... features) {
/*  494 */     return parseObject(input, clazz, ParserConfig.global, featureValues, features);
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(String str, Class<T> objectClass) {
/*  498 */     if (str == null || str.isEmpty()) {
/*  499 */       return null;
/*      */     }
/*      */     
/*  502 */     JSONReader.Context context = createReadContext(
/*  503 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, new Feature[0]);
/*      */ 
/*      */     
/*  506 */     JSONReader jsonReader = JSONReader.of(str, context);
/*      */     
/*      */     try {
/*  509 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectClass);
/*  510 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  511 */       if (object != null) {
/*  512 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  514 */       return object;
/*  515 */     } catch (JSONException e) {
/*  516 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  517 */       if (cause == null) {
/*  518 */         jSONException1 = e;
/*      */       }
/*  520 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(String str, Class<T> objectType, Feature... features) {
/*  525 */     if (str == null || str.isEmpty()) {
/*  526 */       return null;
/*      */     }
/*      */     
/*  529 */     JSONReader.Context context = createReadContext(
/*  530 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  534 */     JSONReader jsonReader = JSONReader.of(str, context);
/*      */     
/*      */     try {
/*  537 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectType);
/*  538 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  539 */       if (object != null) {
/*  540 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  542 */       return object;
/*  543 */     } catch (JSONException e) {
/*  544 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  545 */       if (cause == null) {
/*  546 */         jSONException1 = e;
/*      */       }
/*  548 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(String str, Type objectType, Feature... features) {
/*  553 */     if (str == null || str.isEmpty()) {
/*  554 */       return null;
/*      */     }
/*      */     
/*  557 */     JSONReader.Context context = createReadContext(
/*  558 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  562 */     JSONReader jsonReader = JSONReader.of(str, context);
/*      */     
/*      */     try {
/*  565 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectType);
/*  566 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  567 */       if (object != null) {
/*  568 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  570 */       return object;
/*  571 */     } catch (JSONException e) {
/*  572 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  573 */       if (cause == null) {
/*  574 */         jSONException1 = e;
/*      */       }
/*  576 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(String str, Type objectType, ParserConfig config, Feature... features) {
/*  584 */     if (str == null || str.isEmpty()) {
/*  585 */       return null;
/*      */     }
/*      */     
/*  588 */     JSONReader.Context context = createReadContext(config
/*  589 */         .getProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     if (config.fieldBase) {
/*  595 */       context.config(new JSONReader.Feature[] { JSONReader.Feature.FieldBased });
/*      */     }
/*      */     
/*  598 */     JSONReader jsonReader = JSONReader.of(str, context);
/*      */     
/*      */     try {
/*  601 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectType);
/*  602 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  603 */       if (object != null) {
/*  604 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  606 */       return object;
/*  607 */     } catch (JSONException e) {
/*  608 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  609 */       if (cause == null) {
/*  610 */         jSONException1 = e;
/*      */       }
/*  612 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(InputStream is, Type objectType, Feature... features) throws IOException {
/*  620 */     return parseObject(is, StandardCharsets.UTF_8, objectType, features);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(InputStream is, Class<T> objectType, Feature... features) throws IOException {
/*  627 */     return parseObject(is, StandardCharsets.UTF_8, objectType, features);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(InputStream is, Charset charset, Type objectType, ParserConfig config, ParseProcess processor, int featureValues, Feature... features) throws IOException {
/*  639 */     if (is == null) {
/*  640 */       return null;
/*      */     }
/*      */     
/*  643 */     if (config == null) {
/*  644 */       config = ParserConfig.global;
/*      */     }
/*      */     
/*  647 */     JSONReader.Context context = createReadContext(config
/*  648 */         .getProvider(), featureValues, features);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  653 */     if (processor != null) {
/*  654 */       context.config((Filter)processor);
/*      */     }
/*      */     
/*  657 */     JSONReader jsonReader = JSONReader.of(is, charset, context);
/*      */     
/*      */     try {
/*  660 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectType);
/*  661 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  662 */       if (object != null) {
/*  663 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  665 */       return object;
/*  666 */     } catch (JSONException e) {
/*  667 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  668 */       if (cause == null) {
/*  669 */         jSONException1 = e;
/*      */       }
/*  671 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(InputStream is, Charset charset, Type type, ParserConfig config, Feature... features) throws IOException {
/*  682 */     return parseObject(is, charset, type, config, (ParseProcess)null, DEFAULT_PARSER_FEATURE, features);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(InputStream is, Charset charset, Type objectType, Feature... features) throws IOException {
/*  690 */     if (is == null) {
/*  691 */       return null;
/*      */     }
/*      */     
/*  694 */     JSONReader.Context context = createReadContext(
/*  695 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  699 */     JSONReader jsonReader = JSONReader.of(is, charset, context);
/*      */     
/*      */     try {
/*  702 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(objectType);
/*  703 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  704 */       if (object != null) {
/*  705 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  707 */       return object;
/*  708 */     } catch (JSONException e) {
/*  709 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  710 */       if (cause == null) {
/*  711 */         jSONException1 = e;
/*      */       }
/*  713 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> JSONObject parseObject(byte[] jsonBytes, Feature... features) {
/*  721 */     if (jsonBytes == null || jsonBytes.length == 0) {
/*  722 */       return null;
/*      */     }
/*      */     
/*  725 */     JSONReader.Context context = createReadContext(
/*  726 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  730 */     JSONReader reader = JSONReader.of(jsonBytes, context);
/*      */     
/*  732 */     boolean ordered = false;
/*  733 */     for (Feature feature : features) {
/*  734 */       if (feature == Feature.OrderedField) {
/*  735 */         ordered = true;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     try {
/*  741 */       Map<String, Object> map = ordered ? new LinkedHashMap<>() : new HashMap<>();
/*  742 */       reader.read(map, 0L);
/*  743 */       JSONObject jsonObject = new JSONObject(map);
/*  744 */       reader.handleResolveTasks(jsonObject);
/*  745 */       return jsonObject;
/*  746 */     } catch (JSONException e) {
/*  747 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  748 */       if (cause == null) {
/*  749 */         jSONException1 = e;
/*      */       }
/*  751 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(byte[] jsonBytes, Type type, Feature... features) {
/*  756 */     if (jsonBytes == null) {
/*  757 */       return null;
/*      */     }
/*      */     
/*  760 */     JSONReader.Context context = createReadContext(
/*  761 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  765 */     JSONReader jsonReader = JSONReader.of(jsonBytes, context);
/*      */     
/*      */     try {
/*  768 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(type);
/*  769 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  770 */       if (object != null) {
/*  771 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  773 */       return object;
/*  774 */     } catch (JSONException e) {
/*  775 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  776 */       if (cause == null) {
/*  777 */         jSONException1 = e;
/*      */       }
/*  779 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static <T> T parseObject(byte[] jsonBytes, Type type, SerializeFilter filter, Feature... features) {
/*  784 */     if (jsonBytes == null) {
/*  785 */       return null;
/*      */     }
/*      */     
/*  788 */     JSONReader.Context context = createReadContext(
/*  789 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  793 */     JSONReader jsonReader = JSONReader.of(jsonBytes, context);
/*      */     
/*  795 */     if (filter instanceof Filter) {
/*  796 */       context.config((Filter)filter);
/*      */     }
/*      */     
/*      */     try {
/*  800 */       ObjectReader<T> objectReader = jsonReader.getObjectReader(type);
/*  801 */       T object = (T)objectReader.readObject(jsonReader, null, null, 0L);
/*  802 */       if (object != null) {
/*  803 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  805 */       return object;
/*  806 */     } catch (JSONException e) {
/*  807 */       JSONException jSONException1; Throwable cause = e.getCause();
/*  808 */       if (cause == null) {
/*  809 */         jSONException1 = e;
/*      */       }
/*  811 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object parse(String str) {
/*  816 */     if (str == null || str.isEmpty()) {
/*  817 */       return null;
/*      */     }
/*      */     
/*  820 */     JSONReader.Context context = createReadContext(
/*  821 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, new Feature[0]);
/*      */ 
/*      */     
/*  824 */     try { JSONReader jsonReader = JSONReader.of(str, context); 
/*  825 */       try { if (jsonReader.isObject() && !jsonReader.isSupportAutoType(0L))
/*  826 */         { Object object1 = jsonReader.read(JSONObject.class);
/*      */ 
/*      */           
/*  829 */           if (jsonReader != null) jsonReader.close();  return object1; }  Object object = jsonReader.readAny(); if (jsonReader != null) jsonReader.close();  return object; } catch (Throwable throwable) { if (jsonReader != null) try { jsonReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception ex)
/*  830 */     { throw new JSONException(ex.getMessage(), ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static Object parse(String text, int features) {
/*  835 */     return parse(text, ParserConfig.global, features);
/*      */   }
/*      */   
/*      */   public static Object parse(String str, Feature... features) {
/*  839 */     if (str == null || str.isEmpty()) {
/*  840 */       return null;
/*      */     }
/*      */     
/*  843 */     JSONReader.Context context = createReadContext(
/*  844 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  848 */     try { JSONReader jsonReader = JSONReader.of(str, context); 
/*  849 */       try { if (jsonReader.isObject() && !jsonReader.isSupportAutoType(0L))
/*  850 */         { Object object1 = jsonReader.read(JSONObject.class);
/*      */ 
/*      */           
/*  853 */           if (jsonReader != null) jsonReader.close();  return object1; }  Object object = jsonReader.readAny(); if (jsonReader != null) jsonReader.close();  return object; } catch (Throwable throwable) { if (jsonReader != null) try { jsonReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception ex)
/*  854 */     { throw new JSONException(ex.getMessage(), ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static Object parse(String str, ParserConfig config, Feature... features) {
/*  859 */     if (str == null || str.isEmpty()) {
/*  860 */       return null;
/*      */     }
/*      */     
/*  863 */     JSONReader.Context context = createReadContext(config.getProvider(), DEFAULT_PARSER_FEATURE, features); 
/*  864 */     try { JSONReader jsonReader = JSONReader.of(str, context); 
/*  865 */       try { if (jsonReader.isObject() && !jsonReader.isSupportAutoType(0L))
/*  866 */         { Object object1 = jsonReader.read(JSONObject.class);
/*      */ 
/*      */           
/*  869 */           if (jsonReader != null) jsonReader.close();  return object1; }  Object object = jsonReader.read(Object.class); if (jsonReader != null) jsonReader.close();  return object; } catch (Throwable throwable) { if (jsonReader != null) try { jsonReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception ex)
/*  870 */     { throw new JSONException(ex.getMessage(), ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static Object parse(String str, ParserConfig config) {
/*  875 */     if (str == null || str.isEmpty()) {
/*  876 */       return null;
/*      */     }
/*      */     
/*  879 */     JSONReader.Context context = createReadContext(config.getProvider(), DEFAULT_PARSER_FEATURE, new Feature[0]); 
/*  880 */     try { JSONReader jsonReader = JSONReader.of(str, context); 
/*  881 */       try { if (jsonReader.isObject() && !jsonReader.isSupportAutoType(0L))
/*  882 */         { Object object1 = jsonReader.read(JSONObject.class);
/*      */ 
/*      */           
/*  885 */           if (jsonReader != null) jsonReader.close();  return object1; }  Object object = jsonReader.readAny(); if (jsonReader != null) jsonReader.close();  return object; } catch (Throwable throwable) { if (jsonReader != null) try { jsonReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception ex)
/*  886 */     { throw new JSONException(ex.getMessage(), ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static Object parse(String str, ParserConfig config, int features) {
/*  891 */     if (str == null || str.isEmpty()) {
/*  892 */       return null;
/*      */     }
/*      */     
/*  895 */     JSONReader.Context context = createReadContext(config.getProvider(), features, new Feature[0]); 
/*  896 */     try { JSONReader jsonReader = JSONReader.of(str, context); 
/*  897 */       try { if (jsonReader.isObject() && !jsonReader.isSupportAutoType(0L))
/*  898 */         { Object object1 = jsonReader.read(JSONObject.class);
/*      */ 
/*      */           
/*  901 */           if (jsonReader != null) jsonReader.close();  return object1; }  Object object = jsonReader.readAny(); if (jsonReader != null) jsonReader.close();  return object; } catch (Throwable throwable) { if (jsonReader != null) try { jsonReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception ex)
/*  902 */     { throw new JSONException(ex.getMessage(), ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static Object parse(byte[] utf8Bytes, Feature... features) {
/*  907 */     if (utf8Bytes == null || utf8Bytes.length == 0) {
/*  908 */       return null;
/*      */     }
/*      */     
/*  911 */     JSONReader.Context context = createReadContext(
/*  912 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */     
/*  916 */     try { JSONReader jsonReader = JSONReader.of(utf8Bytes, context); 
/*  917 */       try { if (jsonReader.isObject() && !jsonReader.isSupportAutoType(0L))
/*  918 */         { Object object1 = jsonReader.read(JSONObject.class);
/*      */ 
/*      */           
/*  921 */           if (jsonReader != null) jsonReader.close();  return object1; }  Object object = jsonReader.readAny(); if (jsonReader != null) jsonReader.close();  return object; } catch (Throwable throwable) { if (jsonReader != null) try { jsonReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception ex)
/*  922 */     { throw new JSONException(ex.getMessage(), ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static Object parse(byte[] input, int off, int len, CharsetDecoder charsetDecoder, Feature... features) {
/*  927 */     if (input == null || input.length == 0) {
/*  928 */       return null;
/*      */     }
/*      */     
/*  931 */     int featureValues = DEFAULT_PARSER_FEATURE;
/*  932 */     for (Feature feature : features) {
/*  933 */       featureValues = Feature.config(featureValues, feature, true);
/*      */     }
/*      */     
/*  936 */     return parse(input, off, len, charsetDecoder, featureValues);
/*      */   }
/*      */   
/*      */   public static Object parse(byte[] input, int off, int len, CharsetDecoder charsetDecoder, int features) {
/*  940 */     charsetDecoder.reset();
/*      */     
/*  942 */     int scaleLength = (int)(len * charsetDecoder.maxCharsPerByte());
/*  943 */     char[] chars = CHARS_UPDATER.getAndSet(CACHE, null);
/*  944 */     if (chars == null || chars.length < scaleLength) {
/*  945 */       chars = new char[scaleLength];
/*      */     }
/*      */     
/*      */     try {
/*  949 */       ByteBuffer byteBuf = ByteBuffer.wrap(input, off, len);
/*  950 */       CharBuffer charBuf = CharBuffer.wrap(chars);
/*  951 */       IOUtils.decode(charsetDecoder, byteBuf, charBuf);
/*      */       
/*  953 */       int position = charBuf.position();
/*      */       
/*  955 */       JSONReader.Context context = createReadContext(
/*  956 */           JSONFactory.getDefaultObjectReaderProvider(), features, new Feature[0]);
/*      */ 
/*      */       
/*  959 */       JSONReader jsonReader = JSONReader.of(chars, 0, position, context);
/*      */       
/*  961 */       for (Feature feature : Feature.values()) {
/*  962 */         if ((features & feature.mask) != 0) {
/*  963 */           switch (feature) {
/*      */             case SupportArrayToBean:
/*  965 */               context.config(new JSONReader.Feature[] { JSONReader.Feature.SupportArrayToBean });
/*      */               break;
/*      */             case SupportAutoType:
/*  968 */               context.config(new JSONReader.Feature[] { JSONReader.Feature.SupportAutoType });
/*      */               break;
/*      */             case ErrorOnEnumNotMatch:
/*  971 */               context.config(new JSONReader.Feature[] { JSONReader.Feature.ErrorOnEnumNotMatch });
/*      */             case SupportNonPublicField:
/*  973 */               context.config(new JSONReader.Feature[] { JSONReader.Feature.FieldBased });
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/*      */         }
/*      */       } 
/*  980 */       Object object = jsonReader.read(Object.class);
/*  981 */       if (object != null) {
/*  982 */         jsonReader.handleResolveTasks(object);
/*      */       }
/*  984 */       return object;
/*      */     } finally {
/*  986 */       if (chars.length <= 65536) {
/*  987 */         CHARS_UPDATER.set(CACHE, chars);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(byte[] input, int off, int len, CharsetDecoder charsetDecoder, Type clazz, Feature... features) {
/* 1000 */     charsetDecoder.reset();
/*      */     
/* 1002 */     int scaleLength = (int)(len * charsetDecoder.maxCharsPerByte());
/*      */     
/* 1004 */     char[] chars = CHARS_UPDATER.getAndSet(CACHE, null);
/* 1005 */     if (chars == null || chars.length < scaleLength) {
/* 1006 */       chars = new char[scaleLength];
/*      */     }
/*      */     
/*      */     try {
/* 1010 */       ByteBuffer byteBuf = ByteBuffer.wrap(input, off, len);
/* 1011 */       CharBuffer charByte = CharBuffer.wrap(chars);
/* 1012 */       IOUtils.decode(charsetDecoder, byteBuf, charByte);
/*      */       
/* 1014 */       int position = charByte.position();
/*      */       
/* 1016 */       JSONReader.Context context = createReadContext(
/* 1017 */           JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features);
/*      */ 
/*      */ 
/*      */       
/* 1021 */       JSONReader jsonReader = JSONReader.of(chars, 0, position, context);
/*      */       
/* 1023 */       T object = (T)jsonReader.read(clazz);
/* 1024 */       if (object != null) {
/* 1025 */         jsonReader.handleResolveTasks(object);
/*      */       }
/* 1027 */       return object;
/*      */     } finally {
/* 1029 */       if (chars.length <= 65536) {
/* 1030 */         CHARS_UPDATER.set(CACHE, chars);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T parseObject(byte[] input, int off, int len, Charset charset, Type clazz, Feature... features) {
/* 1043 */     JSONReader jsonReader = JSONReader.of(input, off, len, charset, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1048 */         createReadContext(
/* 1049 */           JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1055 */       T object = (T)jsonReader.read(clazz);
/* 1056 */       if (object != null) {
/* 1057 */         jsonReader.handleResolveTasks(object);
/*      */       }
/* 1059 */       T t1 = object;
/* 1060 */       if (jsonReader != null) jsonReader.close();  return t1;
/*      */     } catch (Throwable throwable) {
/*      */       if (jsonReader != null)
/*      */         try {
/*      */           jsonReader.close();
/*      */         } catch (Throwable throwable1) {
/*      */           throwable.addSuppressed(throwable1);
/*      */         }   throw throwable;
/* 1068 */     }  } public static JSONWriter.Context createWriteContext(SerializeConfig config, int featuresValue, SerializerFeature... features) { for (SerializerFeature feature : features) {
/* 1069 */       featuresValue |= feature.mask;
/*      */     }
/*      */     
/* 1072 */     ObjectWriterProvider provider = config.getProvider();
/* 1073 */     provider.setCompatibleWithFieldName(TypeUtils.compatibleWithFieldName);
/*      */     
/* 1075 */     JSONWriter.Context context = new JSONWriter.Context(provider);
/*      */     
/* 1077 */     if (config.fieldBased) {
/* 1078 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.FieldBased });
/*      */     }
/*      */     
/* 1081 */     if (config.propertyNamingStrategy != null && config.propertyNamingStrategy != PropertyNamingStrategy.NeverUseThisValueExceptDefaultValue && config.propertyNamingStrategy != PropertyNamingStrategy.CamelCase1x) {
/*      */ 
/*      */ 
/*      */       
/* 1085 */       NameFilter nameFilter = NameFilter.of(config.propertyNamingStrategy);
/* 1086 */       configFilter(context, (SerializeFilter)nameFilter);
/*      */     } 
/*      */     
/* 1089 */     if ((featuresValue & SerializerFeature.DisableCircularReferenceDetect.mask) == 0) {
/* 1090 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.ReferenceDetection });
/*      */     }
/*      */     
/* 1093 */     if ((featuresValue & SerializerFeature.UseISO8601DateFormat.mask) != 0) {
/* 1094 */       context.setDateFormat("iso8601");
/*      */     } else {
/* 1096 */       context.setDateFormat("millis");
/*      */     } 
/*      */     
/* 1099 */     if ((featuresValue & SerializerFeature.WriteMapNullValue.mask) != 0) {
/* 1100 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteMapNullValue });
/*      */     }
/*      */     
/* 1103 */     if ((featuresValue & SerializerFeature.WriteNullListAsEmpty.mask) != 0) {
/* 1104 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNullListAsEmpty });
/*      */     }
/*      */     
/* 1107 */     if ((featuresValue & SerializerFeature.WriteNullStringAsEmpty.mask) != 0) {
/* 1108 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNullStringAsEmpty });
/*      */     }
/*      */     
/* 1111 */     if ((featuresValue & SerializerFeature.WriteNullNumberAsZero.mask) != 0) {
/* 1112 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNullNumberAsZero });
/*      */     }
/*      */     
/* 1115 */     if ((featuresValue & SerializerFeature.WriteNullBooleanAsFalse.mask) != 0) {
/* 1116 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNullBooleanAsFalse });
/*      */     }
/*      */     
/* 1119 */     if ((featuresValue & SerializerFeature.BrowserCompatible.mask) != 0) {
/* 1120 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.BrowserCompatible });
/*      */     }
/*      */     
/* 1123 */     if ((featuresValue & SerializerFeature.BrowserSecure.mask) != 0) {
/* 1124 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.BrowserSecure });
/*      */     }
/*      */     
/* 1127 */     if ((featuresValue & SerializerFeature.WriteClassName.mask) != 0) {
/* 1128 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteClassName });
/*      */     }
/*      */     
/* 1131 */     if ((featuresValue & SerializerFeature.WriteNonStringValueAsString.mask) != 0) {
/* 1132 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNonStringValueAsString });
/*      */     }
/*      */     
/* 1135 */     if ((featuresValue & SerializerFeature.WriteEnumUsingToString.mask) != 0) {
/* 1136 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteEnumUsingToString });
/*      */     }
/*      */     
/* 1139 */     if ((featuresValue & SerializerFeature.WriteEnumUsingName.mask) != 0) {
/* 1140 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteEnumsUsingName });
/*      */     }
/*      */     
/* 1143 */     if ((featuresValue & SerializerFeature.NotWriteRootClassName.mask) != 0) {
/* 1144 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.NotWriteRootClassName });
/*      */     }
/*      */     
/* 1147 */     if ((featuresValue & SerializerFeature.IgnoreErrorGetter.mask) != 0) {
/* 1148 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.IgnoreErrorGetter });
/*      */     }
/*      */     
/* 1151 */     if ((featuresValue & SerializerFeature.WriteDateUseDateFormat.mask) != 0) {
/* 1152 */       context.setDateFormat(DEFFAULT_DATE_FORMAT);
/*      */     }
/*      */     
/* 1155 */     if ((featuresValue & SerializerFeature.BeanToArray.mask) != 0) {
/* 1156 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.BeanToArray });
/*      */     }
/*      */     
/* 1159 */     if ((featuresValue & SerializerFeature.UseSingleQuotes.mask) != 0) {
/* 1160 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.UseSingleQuotes });
/*      */     }
/*      */     
/* 1163 */     if ((featuresValue & SerializerFeature.MapSortField.mask) != 0) {
/* 1164 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.MapSortField });
/*      */     }
/*      */     
/* 1167 */     if ((featuresValue & SerializerFeature.PrettyFormat.mask) != 0) {
/* 1168 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.PrettyFormat });
/*      */     }
/*      */     
/* 1171 */     if ((featuresValue & SerializerFeature.WriteNonStringKeyAsString.mask) != 0) {
/* 1172 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNonStringKeyAsString });
/*      */     }
/*      */     
/* 1175 */     if ((featuresValue & SerializerFeature.IgnoreNonFieldGetter.mask) != 0) {
/* 1176 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.IgnoreNonFieldGetter });
/*      */     }
/*      */     
/* 1179 */     if ((featuresValue & SerializerFeature.NotWriteDefaultValue.mask) != 0) {
/* 1180 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.NotWriteDefaultValue });
/*      */     }
/*      */     
/* 1183 */     if ((featuresValue & SerializerFeature.WriteBigDecimalAsPlain.mask) != 0) {
/* 1184 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteBigDecimalAsPlain });
/*      */     }
/*      */     
/* 1187 */     if ((featuresValue & SerializerFeature.QuoteFieldNames.mask) == 0 && (featuresValue & SerializerFeature.UseSingleQuotes.mask) == 0)
/*      */     {
/*      */       
/* 1190 */       context.config(new JSONWriter.Feature[] { JSONWriter.Feature.UnquoteFieldName });
/*      */     }
/*      */     
/* 1193 */     if (defaultTimeZone != null && defaultTimeZone != DEFAULT_TIME_ZONE) {
/* 1194 */       context.setZoneId(defaultTimeZone.toZoneId());
/*      */     }
/*      */     
/* 1197 */     context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteByteArrayAsBase64 });
/* 1198 */     context.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteThrowableClassName });
/*      */     
/* 1200 */     return context; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toJSONString(Object object, SerializeConfig config, SerializeFilter[] filters, String dateFormat, int defaultFeatures, SerializerFeature... features) {
/* 1211 */     JSONWriter.Context context = createWriteContext(config, defaultFeatures, features);
/* 1212 */     if (dateFormat != null && !dateFormat.isEmpty()) {
/* 1213 */       context.setDateFormat(dateFormat);
/*      */     }
/*      */     
/* 1216 */     try { JSONWriter writer = JSONWriter.of(context); 
/* 1217 */       try { for (SerializeFilter filter : filters) {
/* 1218 */           configFilter(context, filter);
/*      */         }
/*      */         
/* 1221 */         if (object == null) {
/* 1222 */           writer.writeNull();
/*      */         } else {
/* 1224 */           writer.setRootObject(object);
/* 1225 */           Class<?> valueClass = object.getClass();
/* 1226 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1227 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1230 */         String str = writer.toString();
/* 1231 */         if (writer != null) writer.close();  return str; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1232 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1233 */       throw new JSONException("toJSONString error", cause); }
/* 1234 */     catch (RuntimeException ex)
/* 1235 */     { throw new JSONException("toJSONString error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toJSONString(Object object, SerializeConfig config, SerializeFilter[] filters, SerializerFeature... features) {
/* 1245 */     return toJSONString(object, config, filters, null, DEFAULT_GENERATE_FEATURE, features);
/*      */   }
/*      */   
/*      */   public static String toJSONString(Object object, SerializeFilter[] filters, SerializerFeature... features) {
/* 1249 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features);
/*      */     
/* 1251 */     try { JSONWriter writer = JSONWriter.of(context); 
/* 1252 */       try { for (SerializeFilter filter : filters) {
/* 1253 */           configFilter(context, filter);
/*      */         }
/*      */         
/* 1256 */         if (object == null) {
/* 1257 */           writer.writeNull();
/*      */         } else {
/* 1259 */           writer.setRootObject(object);
/* 1260 */           Class<?> valueClass = object.getClass();
/* 1261 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1262 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1265 */         String str = writer.toString();
/* 1266 */         if (writer != null) writer.close();  return str; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1267 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1268 */       throw new JSONException("toJSONString error", cause); }
/* 1269 */     catch (RuntimeException ex)
/* 1270 */     { throw new JSONException("toJSONString error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static void configFilter(JSONWriter.Context context, SerializeFilter filter) {
/* 1275 */     if (filter instanceof NameFilter) {
/* 1276 */       context.setNameFilter((NameFilter)filter);
/*      */     }
/*      */     
/* 1279 */     if (filter instanceof ValueFilter) {
/* 1280 */       context.setValueFilter((ValueFilter)filter);
/*      */     }
/*      */     
/* 1283 */     if (filter instanceof PropertyPreFilter) {
/* 1284 */       context.setPropertyPreFilter((PropertyPreFilter)filter);
/*      */     }
/*      */     
/* 1287 */     if (filter instanceof PropertyFilter) {
/* 1288 */       context.setPropertyFilter((PropertyFilter)filter);
/*      */     }
/*      */     
/* 1291 */     if (filter instanceof com.alibaba.fastjson.serializer.BeforeFilter) {
/* 1292 */       context.setBeforeFilter((BeforeFilter)filter);
/*      */     }
/*      */     
/* 1295 */     if (filter instanceof com.alibaba.fastjson.serializer.AfterFilter) {
/* 1296 */       context.setAfterFilter((AfterFilter)filter);
/*      */     }
/*      */     
/* 1299 */     if (filter instanceof com.alibaba.fastjson.serializer.LabelFilter) {
/* 1300 */       context.setLabelFilter((LabelFilter)filter);
/*      */     }
/*      */     
/* 1303 */     if (filter instanceof com.alibaba.fastjson.serializer.ContextValueFilter) {
/* 1304 */       context.setContextValueFilter((ContextValueFilter)filter);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeConfig config, SerializeFilter[] filters, int defaultFeatures, SerializerFeature... features) {
/* 1315 */     JSONWriter.Context context = createWriteContext(config, defaultFeatures, features); 
/* 1316 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1317 */       try { for (SerializeFilter filter : filters) {
/* 1318 */           configFilter(context, filter);
/*      */         }
/*      */         
/* 1321 */         if (object == null) {
/* 1322 */           writer.writeNull();
/*      */         } else {
/* 1324 */           writer.setRootObject(object);
/* 1325 */           Class<?> valueClass = object.getClass();
/* 1326 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1327 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1330 */         byte[] arrayOfByte = writer.getBytes();
/* 1331 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1332 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1333 */       throw new JSONException("toJSONBytes error", cause); }
/* 1334 */     catch (RuntimeException ex)
/* 1335 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeConfig config, SerializeFilter filter, SerializerFeature... features) {
/* 1345 */     JSONWriter.Context context = createWriteContext(config, DEFAULT_GENERATE_FEATURE, features); 
/* 1346 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1347 */       try { configFilter(context, filter);
/*      */         
/* 1349 */         if (object == null) {
/* 1350 */           writer.writeNull();
/*      */         } else {
/* 1352 */           writer.setRootObject(object);
/* 1353 */           Class<?> valueClass = object.getClass();
/* 1354 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1355 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1358 */         byte[] arrayOfByte = writer.getBytes();
/* 1359 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1360 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1361 */       throw new JSONException("toJSONBytes error", cause); }
/* 1362 */     catch (RuntimeException ex)
/* 1363 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toJSONBytes(Charset charset, Object object, SerializeConfig config, SerializeFilter[] filters, String dateFormat, int defaultFeatures, SerializerFeature... features) {
/* 1376 */     JSONWriter.Context context = createWriteContext(config, defaultFeatures, features);
/* 1377 */     if (dateFormat != null && !dateFormat.isEmpty()) {
/* 1378 */       context.setDateFormat(dateFormat);
/*      */     }
/*      */     
/* 1381 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1382 */       try { for (SerializeFilter filter : filters) {
/* 1383 */           configFilter(context, filter);
/*      */         }
/*      */         
/* 1386 */         if (object == null) {
/* 1387 */           writer.writeNull();
/*      */         } else {
/* 1389 */           writer.setRootObject(object);
/* 1390 */           Class<?> valueClass = object.getClass();
/* 1391 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1392 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1395 */         byte[] arrayOfByte = writer.getBytes(charset);
/* 1396 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1397 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1398 */       throw new JSONException("toJSONBytes error", cause); }
/* 1399 */     catch (RuntimeException ex)
/* 1400 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeFilter[] filters, SerializerFeature... features) {
/* 1405 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features); 
/* 1406 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1407 */       try { for (SerializeFilter filter : filters) {
/* 1408 */           configFilter(context, filter);
/*      */         }
/*      */         
/* 1411 */         if (object == null) {
/* 1412 */           writer.writeNull();
/*      */         } else {
/* 1414 */           writer.setRootObject(object);
/* 1415 */           Class<?> valueClass = object.getClass();
/* 1416 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1417 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1420 */         byte[] arrayOfByte = writer.getBytes();
/* 1421 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1422 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1423 */       throw new JSONException("toJSONBytes error", cause); }
/* 1424 */     catch (RuntimeException ex)
/* 1425 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeConfig config, SerializerFeature... features) {
/* 1430 */     JSONWriter.Context context = createWriteContext(config, DEFAULT_GENERATE_FEATURE, features); 
/* 1431 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1432 */       try { if (object == null) {
/* 1433 */           writer.writeNull();
/*      */         } else {
/* 1435 */           writer.setRootObject(object);
/* 1436 */           Class<?> valueClass = object.getClass();
/* 1437 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1438 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1441 */         byte[] arrayOfByte = writer.getBytes();
/* 1442 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1443 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1444 */       throw new JSONException("toJSONBytes error", cause); }
/* 1445 */     catch (RuntimeException ex)
/* 1446 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public static String toJSONString(Object object, boolean prettyFormat) {
/* 1452 */     (new SerializerFeature[1])[0] = SerializerFeature.PrettyFormat;
/* 1453 */     SerializerFeature[] features = prettyFormat ? new SerializerFeature[1] : new SerializerFeature[0];
/*      */     
/* 1455 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features);
/*      */     
/* 1457 */     try { JSONWriter writer = JSONWriter.of(context); 
/* 1458 */       try { if (object == null) {
/* 1459 */           writer.writeNull();
/*      */         } else {
/* 1461 */           writer.setRootObject(object);
/* 1462 */           Class<?> valueClass = object.getClass();
/* 1463 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1464 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1467 */         String str = writer.toString();
/* 1468 */         if (writer != null) writer.close();  return str; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1469 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1470 */       throw new JSONException("toJSONString error", cause); }
/* 1471 */     catch (RuntimeException ex)
/* 1472 */     { throw new JSONException("toJSONString error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static String toJSONString(Object object) {
/* 1477 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, new SerializerFeature[0]); 
/* 1478 */     try { JSONWriter writer = JSONWriter.of(context); 
/* 1479 */       try { if (object == null) {
/* 1480 */           writer.writeNull();
/*      */         } else {
/* 1482 */           writer.setRootObject(object);
/* 1483 */           Class<?> valueClass = object.getClass();
/* 1484 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1485 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1488 */         String str = writer.toString();
/* 1489 */         if (writer != null) writer.close();  return str; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1490 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1491 */       throw new JSONException(ex.getMessage(), cause); }
/* 1492 */     catch (RuntimeException ex)
/* 1493 */     { throw new JSONException("toJSONString error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toJSONString(Object object, SerializeFilter filter0, SerializeFilter filter1, SerializeFilter... filters) {
/* 1501 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, new SerializerFeature[0]);
/* 1502 */     configFilter(context, filter0);
/* 1503 */     configFilter(context, filter1);
/* 1504 */     for (SerializeFilter filter : filters) {
/* 1505 */       configFilter(context, filter);
/*      */     }
/*      */     
/* 1508 */     try { JSONWriter writer = JSONWriter.of(context); 
/* 1509 */       try { if (object == null) {
/* 1510 */           writer.writeNull();
/*      */         } else {
/* 1512 */           writer.setRootObject(object);
/* 1513 */           Class<?> valueClass = object.getClass();
/* 1514 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1515 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1518 */         String str = writer.toString();
/* 1519 */         if (writer != null) writer.close();  return str; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1520 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1521 */       throw new JSONException("toJSONString error", cause); }
/* 1522 */     catch (RuntimeException ex)
/* 1523 */     { throw new JSONException("toJSONString error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static String toJSONString(Object object, SerializerFeature... features) {
/* 1528 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features);
/*      */     
/* 1530 */     try { JSONWriter writer = JSONWriter.of(context); 
/* 1531 */       try { if (object == null) {
/* 1532 */           writer.writeNull();
/*      */         } else {
/* 1534 */           writer.setRootObject(object);
/* 1535 */           Class<?> valueClass = object.getClass();
/* 1536 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1537 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1540 */         String str = writer.toString();
/* 1541 */         if (writer != null) writer.close();  return str; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1542 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1543 */       throw new JSONException("toJSONString error", cause); }
/* 1544 */     catch (RuntimeException ex)
/* 1545 */     { throw new JSONException("toJSONString error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static byte[] toJSONBytes(Object object) {
/* 1550 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, new SerializerFeature[0]); 
/* 1551 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1552 */       try { if (object == null) {
/* 1553 */           writer.writeNull();
/*      */         } else {
/* 1555 */           writer.setRootObject(object);
/* 1556 */           Class<?> valueClass = object.getClass();
/* 1557 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1558 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1561 */         byte[] arrayOfByte = writer.getBytes();
/* 1562 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1563 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1564 */       throw new JSONException("toJSONBytes error", cause); }
/* 1565 */     catch (RuntimeException ex)
/* 1566 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeFilter... filters) {
/* 1571 */     return toJSONBytes(object, filters, new SerializerFeature[0]);
/*      */   }
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, int defaultFeatures, SerializerFeature... features) {
/* 1575 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, defaultFeatures, features);
/*      */     
/* 1577 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1578 */       try { if (object == null) {
/* 1579 */           writer.writeNull();
/*      */         } else {
/* 1581 */           writer.setRootObject(object);
/* 1582 */           Class<?> valueClass = object.getClass();
/* 1583 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1584 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1587 */         byte[] arrayOfByte = writer.getBytes();
/* 1588 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1589 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1590 */       throw new JSONException("toJSONBytes error", cause); }
/* 1591 */     catch (RuntimeException ex)
/* 1592 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeFilter filter) {
/* 1597 */     return toJSONBytes(object, SerializeConfig.global, new SerializeFilter[] { filter }, DEFAULT_GENERATE_FEATURE, new SerializerFeature[0]);
/*      */   }
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeFilter filter, SerializerFeature... features) {
/* 1601 */     return toJSONBytes(object, SerializeConfig.global, new SerializeFilter[] { filter }, DEFAULT_GENERATE_FEATURE, features);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeConfig config, SerializeFilter[] filters, String dateFormat, int defaultFeatures, SerializerFeature... features) {
/* 1618 */     JSONWriter.Context context = createWriteContext(config, defaultFeatures, features);
/*      */     
/* 1620 */     if (dateFormat != null && !dateFormat.isEmpty()) {
/* 1621 */       context.setDateFormat(dateFormat);
/*      */     }
/*      */     
/* 1624 */     for (SerializeFilter filter : filters) {
/* 1625 */       configFilter(context, filter);
/*      */     }
/*      */     
/* 1628 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1629 */       try { if (object == null) {
/* 1630 */           writer.writeNull();
/*      */         } else {
/* 1632 */           writer.setRootObject(object);
/* 1633 */           Class<?> valueClass = object.getClass();
/* 1634 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1635 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1638 */         byte[] arrayOfByte = writer.getBytes();
/* 1639 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1640 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1641 */       throw new JSONException("toJSONBytes error", cause); }
/* 1642 */     catch (RuntimeException ex)
/* 1643 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializerFeature... features) {
/* 1648 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features);
/*      */     
/* 1650 */     try { JSONWriter writer = JSONWriter.ofUTF8(context); 
/* 1651 */       try { if (object == null) {
/* 1652 */           writer.writeNull();
/*      */         } else {
/* 1654 */           writer.setRootObject(object);
/* 1655 */           Class<?> valueClass = object.getClass();
/* 1656 */           ObjectWriter objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1657 */           objectWriter.write(writer, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1660 */         byte[] arrayOfByte = writer.getBytes();
/* 1661 */         if (writer != null) writer.close();  return arrayOfByte; } catch (Throwable throwable) { if (writer != null) try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1662 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1663 */       throw new JSONException("toJSONBytes error", cause); }
/* 1664 */     catch (RuntimeException ex)
/* 1665 */     { throw new JSONException("toJSONBytes error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toJSONBytes(Object object, SerializeConfig config, int defaultFeatures, SerializerFeature... features) {
/* 1675 */     return toJSONBytes(object, config, new SerializeFilter[0], defaultFeatures, features);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toJSONString(Object object, SerializeConfig config, SerializerFeature... features) {
/* 1683 */     JSONWriter.Context context = createWriteContext(config, DEFAULT_GENERATE_FEATURE, features);
/* 1684 */     JSONWriter writer = JSONWriter.of(context); 
/* 1685 */     try { writer.setRootObject(object);
/* 1686 */       writer.writeAny(object);
/* 1687 */       String str = writer.toString();
/* 1688 */       if (writer != null) writer.close();  return str; } catch (Throwable throwable) { if (writer != null)
/*      */         try { writer.close(); }
/*      */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*      */           throw throwable; }
/* 1692 */      } public static String toJSONStringZ(Object object, SerializeConfig mapping, SerializerFeature... features) { return toJSONString(object, mapping, new SerializeFilter[0], null, 0, features); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toJSONString(Object object, SerializeConfig config, SerializeFilter filter, SerializerFeature... features) {
/* 1700 */     JSONWriter.Context context = createWriteContext(config, DEFAULT_GENERATE_FEATURE, features);
/* 1701 */     JSONWriter writer = JSONWriter.of(context); 
/* 1702 */     try { NameFilter nameFilter; if (config.propertyNamingStrategy != null && config.propertyNamingStrategy != PropertyNamingStrategy.NeverUseThisValueExceptDefaultValue) {
/*      */         
/* 1704 */         NameFilter nameFilter1 = NameFilter.of(config.propertyNamingStrategy);
/* 1705 */         if (filter instanceof NameFilter) {
/* 1706 */           nameFilter = NameFilter.compose(nameFilter1, (NameFilter)filter);
/*      */         } else {
/* 1708 */           configFilter(context, (SerializeFilter)nameFilter1);
/*      */         } 
/*      */       } 
/*      */       
/* 1712 */       configFilter(context, (SerializeFilter)nameFilter);
/*      */       
/* 1714 */       if (object == null) {
/* 1715 */         writer.writeNull();
/*      */       } else {
/* 1717 */         writer.setRootObject(object);
/* 1718 */         Class<?> valueClass = object.getClass();
/* 1719 */         ObjectWriter<?> objectWriter = context.getObjectWriter(valueClass, valueClass);
/* 1720 */         objectWriter.write(writer, object, null, null, 0L);
/*      */       } 
/* 1722 */       String str = writer.toString();
/* 1723 */       if (writer != null) writer.close();  return str; }
/*      */     catch (Throwable throwable) { if (writer != null)
/*      */         try {
/*      */           writer.close();
/*      */         } catch (Throwable throwable1) {
/*      */           throwable.addSuppressed(throwable1);
/*      */         }   throw throwable; }
/* 1730 */      } public static String toJSONString(Object object, SerializeFilter filter, SerializerFeature... features) { JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features);
/* 1731 */     configFilter(context, filter);
/*      */     
/* 1733 */     JSONWriter jsonWriter = JSONWriter.of(context); 
/* 1734 */     try { if (object == null) {
/* 1735 */         jsonWriter.writeNull();
/*      */       } else {
/* 1737 */         jsonWriter.setRootObject(object);
/* 1738 */         ObjectWriter<?> objectWriter = context.getObjectWriter(object.getClass());
/* 1739 */         objectWriter.write(jsonWriter, object, null, null, 0L);
/*      */       } 
/* 1741 */       String str = jsonWriter.toString();
/* 1742 */       if (jsonWriter != null) jsonWriter.close();  return str; } catch (Throwable throwable) { if (jsonWriter != null)
/*      */         try { jsonWriter.close(); }
/*      */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*      */           throw throwable; }
/* 1746 */      } public static String toJSONString(Object object, int defaultFeatures, SerializerFeature... features) { JSONWriter.Context context = createWriteContext(SerializeConfig.global, defaultFeatures, features);
/* 1747 */     JSONWriter jsonWriter = JSONWriter.of(context); try {
/* 1748 */       if (object == null) {
/* 1749 */         jsonWriter.writeNull();
/*      */       } else {
/* 1751 */         jsonWriter.setRootObject(object);
/* 1752 */         ObjectWriter<?> objectWriter = context.getObjectWriter(object.getClass());
/* 1753 */         objectWriter.write(jsonWriter, object, null, null, 0L);
/*      */       } 
/* 1755 */       String str = jsonWriter.toString();
/* 1756 */       if (jsonWriter != null) jsonWriter.close();  return str;
/*      */     } catch (Throwable throwable) {
/*      */       if (jsonWriter != null)
/*      */         try {
/*      */           jsonWriter.close();
/*      */         } catch (Throwable throwable1) {
/*      */           throwable.addSuppressed(throwable1);
/*      */         }   throw throwable;
/* 1764 */     }  } public static String toJSONStringWithDateFormat(Object object, String dateFormat, SerializerFeature... features) { JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features);
/* 1765 */     JSONWriter jsonWriter = JSONWriter.of(context); 
/* 1766 */     try { context.setDateFormat(dateFormat);
/*      */       
/* 1768 */       if (object == null) {
/* 1769 */         jsonWriter.writeNull();
/*      */       } else {
/* 1771 */         jsonWriter.setRootObject(object);
/* 1772 */         ObjectWriter<?> objectWriter = context.getObjectWriter(object.getClass());
/* 1773 */         objectWriter.write(jsonWriter, object, null, null, 0L);
/*      */       } 
/* 1775 */       String str = jsonWriter.toString();
/* 1776 */       if (jsonWriter != null) jsonWriter.close();  return str; }
/*      */     catch (Throwable throwable) { if (jsonWriter != null)
/*      */         try {
/*      */           jsonWriter.close();
/*      */         } catch (Throwable throwable1) {
/*      */           throwable.addSuppressed(throwable1);
/*      */         }   throw throwable; }
/* 1783 */      } public static final int writeJSONString(OutputStream os, Object object, SerializerFeature... features) throws IOException { return writeJSONString(os, object, new SerializeFilter[0], features); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int writeJSONString(OutputStream os, Object object, SerializeFilter[] filters) throws IOException {
/* 1790 */     return writeJSONString(os, object, filters, new SerializerFeature[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int writeJSONString(OutputStream os, Charset charset, Object object, SerializerFeature... features) throws IOException {
/* 1799 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features);
/*      */     
/* 1801 */     try { JSONWriter jsonWriter = JSONWriter.ofUTF8(context); 
/* 1802 */       try { if (object == null) {
/* 1803 */           jsonWriter.writeNull();
/*      */         } else {
/* 1805 */           jsonWriter.setRootObject(object);
/* 1806 */           ObjectWriter<?> objectWriter = context.getObjectWriter(object.getClass());
/* 1807 */           objectWriter.write(jsonWriter, object, null, null, 0L);
/*      */         } 
/* 1809 */         byte[] bytes = jsonWriter.getBytes(charset);
/* 1810 */         os.write(bytes);
/* 1811 */         int i = bytes.length;
/* 1812 */         if (jsonWriter != null) jsonWriter.close();  return i; } catch (Throwable throwable) { if (jsonWriter != null) try { jsonWriter.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1813 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1814 */       throw new JSONException("writeJSONString error", cause); }
/* 1815 */     catch (RuntimeException ex)
/* 1816 */     { throw new JSONException("writeJSONString error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static void writeJSONString(Writer writer, Object object, SerializerFeature... features) {
/* 1821 */     writeJSONString(writer, object, DEFAULT_GENERATE_FEATURE, features);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void writeJSONString(Writer writer, Object object, int defaultFeatures, SerializerFeature... features) {
/* 1830 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, defaultFeatures, features);
/*      */     
/* 1832 */     try { JSONWriter jsonWriter = JSONWriter.ofUTF8(context); 
/* 1833 */       try { jsonWriter.setRootObject(object);
/*      */         
/* 1835 */         if (object == null) {
/* 1836 */           jsonWriter.writeNull();
/*      */         } else {
/* 1838 */           jsonWriter.setRootObject(object);
/* 1839 */           ObjectWriter<?> objectWriter = context.getObjectWriter(object.getClass());
/* 1840 */           objectWriter.write(jsonWriter, object, null, null, 0L);
/*      */         } 
/*      */         
/* 1843 */         jsonWriter.flushTo(writer);
/* 1844 */         if (jsonWriter != null) jsonWriter.close();  } catch (Throwable throwable) { if (jsonWriter != null) try { jsonWriter.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1845 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1846 */       throw new JSONException("writeJSONString error", cause); }
/* 1847 */     catch (RuntimeException ex)
/* 1848 */     { throw new JSONException("writeJSONString error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int writeJSONString(OutputStream os, Object object, int defaultFeatures, SerializerFeature... features) throws IOException {
/* 1858 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, defaultFeatures, features);
/*      */     
/* 1860 */     try { JSONWriter jsonWriter = JSONWriter.ofUTF8(context); 
/* 1861 */       try { jsonWriter.setRootObject(object);
/*      */         
/* 1863 */         if (object == null) {
/* 1864 */           jsonWriter.writeNull();
/*      */         } else {
/* 1866 */           jsonWriter.setRootObject(object);
/* 1867 */           ObjectWriter<?> objectWriter = context.getObjectWriter(object.getClass());
/* 1868 */           objectWriter.write(jsonWriter, object, null, null, 0L);
/*      */         } 
/* 1870 */         byte[] bytes = jsonWriter.getBytes();
/* 1871 */         os.write(bytes);
/* 1872 */         int i = bytes.length;
/* 1873 */         if (jsonWriter != null) jsonWriter.close();  return i; } catch (Throwable throwable) { if (jsonWriter != null) try { jsonWriter.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1874 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1875 */       throw new JSONException("writeJSONString error", cause); }
/* 1876 */     catch (RuntimeException ex)
/* 1877 */     { throw new JSONException("writeJSONString error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int writeJSONString(OutputStream os, Charset charset, Object object, SerializeConfig config, SerializeFilter[] filters, String dateFormat, int defaultFeatures, SerializerFeature... features) throws IOException {
/* 1891 */     JSONWriter.Context context = createWriteContext(config, defaultFeatures, features);
/* 1892 */     if (dateFormat != null && !dateFormat.isEmpty()) {
/* 1893 */       context.setDateFormat(dateFormat);
/*      */     }
/*      */     
/* 1896 */     try { JSONWriter jsonWriter = JSONWriter.ofUTF8(context); 
/* 1897 */       try { for (SerializeFilter filter : filters) {
/* 1898 */           configFilter(context, filter);
/*      */         }
/*      */         
/* 1901 */         if (object == null) {
/* 1902 */           jsonWriter.writeNull();
/*      */         } else {
/* 1904 */           jsonWriter.setRootObject(object);
/* 1905 */           ObjectWriter<?> objectWriter = context.getObjectWriter(object.getClass());
/* 1906 */           objectWriter.write(jsonWriter, object, null, null, 0L);
/*      */         } 
/* 1908 */         byte[] bytes = jsonWriter.getBytes(charset);
/* 1909 */         os.write(bytes);
/* 1910 */         int i = bytes.length;
/* 1911 */         if (jsonWriter != null) jsonWriter.close();  return i; } catch (Throwable throwable) { if (jsonWriter != null) try { jsonWriter.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1912 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1913 */       throw new JSONException("writeJSONString error", cause); }
/* 1914 */     catch (RuntimeException ex)
/* 1915 */     { throw new JSONException("writeJSONString error", ex); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int writeJSONString(OutputStream os, Object object, SerializeFilter[] filters, SerializerFeature... features) throws IOException {
/* 1925 */     JSONWriter.Context context = createWriteContext(SerializeConfig.global, DEFAULT_GENERATE_FEATURE, features); 
/* 1926 */     try { JSONWriter jsonWriter = JSONWriter.ofUTF8(context); 
/* 1927 */       try { for (SerializeFilter filter : filters) {
/* 1928 */           configFilter(context, filter);
/*      */         }
/*      */         
/* 1931 */         if (object == null) {
/* 1932 */           jsonWriter.writeNull();
/*      */         } else {
/* 1934 */           jsonWriter.setRootObject(object);
/* 1935 */           ObjectWriter<?> objectWriter = context.getObjectWriter(object.getClass());
/* 1936 */           objectWriter.write(jsonWriter, object, null, null, 0L);
/*      */         } 
/* 1938 */         byte[] bytes = jsonWriter.getBytes();
/* 1939 */         os.write(bytes);
/* 1940 */         int i = bytes.length;
/* 1941 */         if (jsonWriter != null) jsonWriter.close();  return i; } catch (Throwable throwable) { if (jsonWriter != null) try { jsonWriter.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException ex)
/* 1942 */     { Throwable cause = (ex.getCause() != null) ? ex.getCause() : (Throwable)ex;
/* 1943 */       throw new JSONException("writeJSONString error", cause); }
/* 1944 */     catch (RuntimeException ex)
/* 1945 */     { throw new JSONException("writeJSONString error", ex); }
/*      */   
/*      */   }
/*      */   
/*      */   public static JSONArray parseArray(String str, Feature... features) {
/* 1950 */     if (str == null || str.isEmpty()) {
/* 1951 */       return null;
/*      */     }
/*      */     
/* 1954 */     JSONReader jsonReader = JSONReader.of(str, 
/*      */         
/* 1956 */         createReadContext(JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features));
/*      */     
/* 1958 */     try { if (jsonReader.nextIfNull())
/* 1959 */       { JSONArray jSONArray = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1965 */         if (jsonReader != null) jsonReader.close();  return jSONArray; }  JSONArray jsonArray = new JSONArray(); jsonReader.read(jsonArray); JSONArray jSONArray1 = jsonArray; if (jsonReader != null) jsonReader.close();  return jSONArray1; } catch (Throwable throwable) { if (jsonReader != null)
/*      */         try { jsonReader.close(); }
/*      */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*      */           throw throwable; }
/* 1969 */      } public static JSONArray parseArray(String str) { if (str == null || str.isEmpty()) {
/* 1970 */       return null;
/*      */     }
/*      */     
/* 1973 */     JSONReader.Context context = createReadContext(
/* 1974 */         JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, new Feature[0]);
/*      */ 
/*      */     
/* 1977 */     JSONReader reader = JSONReader.of(str, context);
/*      */     
/*      */     try {
/* 1980 */       List list = new ArrayList();
/* 1981 */       reader.read(list);
/* 1982 */       JSONArray jsonArray = new JSONArray(list);
/* 1983 */       reader.handleResolveTasks(jsonArray);
/* 1984 */       return jsonArray;
/* 1985 */     } catch (JSONException e) {
/* 1986 */       JSONException jSONException1; Throwable cause = e.getCause();
/* 1987 */       if (cause == null) {
/* 1988 */         jSONException1 = e;
/*      */       }
/* 1990 */       throw new JSONException(e.getMessage(), jSONException1);
/*      */     }  }
/*      */ 
/*      */   
/*      */   public static <T> List<T> parseArray(String text, Class<T> type) {
/* 1995 */     if (text == null || text.isEmpty()) {
/* 1996 */       return null;
/*      */     }
/* 1998 */     ParameterizedTypeImpl paramType = new ParameterizedTypeImpl(new Type[] { type }, null, List.class);
/*      */     
/* 2000 */     try { JSONReader reader = JSONReader.of(text, 
/*      */           
/* 2002 */           createReadContext(JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, new Feature[0]));
/*      */       
/* 2004 */       try { List<T> list = (List)reader.read((Type)paramType);
/* 2005 */         if (reader != null) reader.close();  return list; } catch (Throwable throwable) { if (reader != null) try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException e)
/* 2006 */     { JSONException jSONException1; Throwable cause = e.getCause();
/* 2007 */       if (cause == null) {
/* 2008 */         jSONException1 = e;
/*      */       }
/* 2010 */       throw new JSONException(e.getMessage(), jSONException1); }
/*      */   
/*      */   }
/*      */   
/*      */   public static <T> List<T> parseArray(String text, Class<T> clazz, ParserConfig config) {
/* 2015 */     if (text == null || text.isEmpty()) {
/* 2016 */       return null;
/*      */     }
/*      */     
/* 2019 */     if (config == null) {
/* 2020 */       config = ParserConfig.global;
/*      */     }
/*      */     
/* 2023 */     ParameterizedTypeImpl paramType = new ParameterizedTypeImpl(new Type[] { clazz }, null, List.class);
/*      */     
/* 2025 */     try { JSONReader reader = JSONReader.of(text, 
/*      */           
/* 2027 */           createReadContext(config.getProvider(), DEFAULT_PARSER_FEATURE, new Feature[0]));
/*      */       
/* 2029 */       try { List<T> list = (List)reader.read((Type)paramType);
/* 2030 */         if (reader != null) reader.close();  return list; } catch (Throwable throwable) { if (reader != null) try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException e)
/* 2031 */     { JSONException jSONException1; Throwable cause = e.getCause();
/* 2032 */       if (cause == null) {
/* 2033 */         jSONException1 = e;
/*      */       }
/* 2035 */       throw new JSONException(e.getMessage(), jSONException1); }
/*      */   
/*      */   }
/*      */   
/*      */   public static <T> List<T> parseArray(String text, Class<T> type, Feature... features) {
/* 2040 */     if (text == null || text.isEmpty()) {
/* 2041 */       return null;
/*      */     }
/* 2043 */     ParameterizedTypeImpl paramType = new ParameterizedTypeImpl(new Type[] { type }, null, List.class);
/*      */     
/* 2045 */     try { JSONReader reader = JSONReader.of(text, 
/*      */           
/* 2047 */           createReadContext(JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_PARSER_FEATURE, features));
/*      */       
/* 2049 */       try { List<T> list = (List)reader.read((Type)paramType);
/* 2050 */         if (reader != null) reader.close();  return list; } catch (Throwable throwable) { if (reader != null) try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (JSONException e)
/* 2051 */     { JSONException jSONException1; Throwable cause = e.getCause();
/* 2052 */       if (cause == null) {
/* 2053 */         jSONException1 = e;
/*      */       }
/* 2055 */       throw new JSONException(e.getMessage(), jSONException1); }
/*      */   
/*      */   }
/*      */   
/*      */   public static boolean isValid(String str) {
/* 2060 */     return com.alibaba.fastjson2.JSON.isValid(str);
/*      */   }
/*      */   
/*      */   public static boolean isValidArray(String str) {
/* 2064 */     return com.alibaba.fastjson2.JSON.isValidArray(str);
/*      */   }
/*      */   
/*      */   public static boolean isValidObject(String str) {
/* 2068 */     return com.alibaba.fastjson2.JSON.isValidObject(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T toJavaObject(TypeReference<T> typeReference) {
/* 2076 */     Type type = (typeReference != null) ? typeReference.getType() : Object.class;
/* 2077 */     return toJavaObject(type);
/*      */   }
/*      */   
/*      */   public static <T> T toJavaObject(JSON json, Class<T> clazz) {
/* 2081 */     if (json instanceof JSONObject) {
/* 2082 */       return ((JSONObject)json).toJavaObject(clazz);
/*      */     }
/*      */     
/* 2085 */     String str = toJSONString(json);
/* 2086 */     return parseObject(str, clazz);
/*      */   }
/*      */   
/*      */   public static Object toJSON(Object javaObject) {
/* 2090 */     if (javaObject instanceof JSON) {
/* 2091 */       return javaObject;
/*      */     }
/*      */     
/* 2094 */     String str = toJSONString(javaObject);
/* 2095 */     Object object = parse(str);
/* 2096 */     if (object instanceof List) {
/* 2097 */       return new JSONArray((List)object);
/*      */     }
/* 2099 */     return object;
/*      */   }
/*      */   
/*      */   public static Object toJSON(Object javaObject, SerializeConfig config) {
/* 2103 */     if (javaObject instanceof JSON) {
/* 2104 */       return javaObject;
/*      */     }
/*      */     
/* 2107 */     String str = toJSONString(javaObject, config, new SerializerFeature[0]);
/* 2108 */     Object object = parse(str);
/* 2109 */     if (object instanceof List) {
/* 2110 */       return new JSONArray((List)object);
/*      */     }
/* 2112 */     return object;
/*      */   }
/*      */   
/*      */   public static Object toJSON(Object javaObject, ParserConfig config) {
/* 2116 */     if (javaObject instanceof JSON) {
/* 2117 */       return javaObject;
/*      */     }
/*      */     
/* 2120 */     String str = toJSONString(javaObject);
/* 2121 */     Object object = parse(str, config);
/* 2122 */     if (object instanceof List) {
/* 2123 */       return new JSONArray((List)object);
/*      */     }
/* 2125 */     return object;
/*      */   }
/*      */   
/*      */   public static List<Object> parseArray(String text, Type[] types) {
/* 2129 */     if (text == null || text.isEmpty()) {
/* 2130 */       return null;
/*      */     }
/* 2132 */     List<Object> array = new JSONArray(types.length);
/*      */     
/* 2134 */     JSONReader reader = JSONReader.of(text, 
/*      */         
/* 2136 */         createReadContext(JSONFactory.getDefaultObjectReaderProvider(), DEFAULT_GENERATE_FEATURE, new Feature[0]));
/*      */     
/* 2138 */     try { reader.startArray();
/* 2139 */       for (Type itemType : types) {
/* 2140 */         array.add(reader
/* 2141 */             .read(itemType));
/*      */       }
/*      */       
/* 2144 */       reader.endArray();
/* 2145 */       reader.handleResolveTasks(array);
/* 2146 */       List<Object> list = array;
/* 2147 */       if (reader != null) reader.close();  return list; } catch (Throwable throwable) { if (reader != null)
/*      */         try { reader.close(); }
/*      */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*      */           throw throwable; }
/* 2151 */      } public static void addMixInAnnotations(Type target, Type mixinSource) { if (target != null && mixinSource != null) {
/* 2152 */       ObjectReaderProvider readerProvider = JSONFactory.getDefaultObjectReaderProvider();
/* 2153 */       readerProvider.mixIn((Class)target, (Class)mixinSource);
/*      */       
/* 2155 */       ObjectWriterProvider writerProvider = SerializeConfig.DEFAULT_PROVIDER;
/* 2156 */       writerProvider.mixIn((Class)target, (Class)mixinSource);
/*      */     }  }
/*      */ 
/*      */   
/*      */   public static void removeMixInAnnotations(Type target) {
/* 2161 */     ObjectReaderProvider readerProvider = JSONFactory.getDefaultObjectReaderProvider();
/* 2162 */     readerProvider.mixIn((Class)target, null);
/*      */     
/* 2164 */     ObjectWriterProvider writerProvider = JSONFactory.getDefaultObjectWriterProvider();
/* 2165 */     writerProvider.mixIn((Class)target, null);
/*      */   }
/*      */   
/*      */   public static void clearMixInAnnotations() {
/* 2169 */     ObjectReaderProvider readerProvider = JSONFactory.getDefaultObjectReaderProvider();
/* 2170 */     readerProvider.cleanupMixIn();
/*      */     
/* 2172 */     ObjectWriterProvider writerProvider = JSONFactory.getDefaultObjectWriterProvider();
/* 2173 */     writerProvider.cleanupMixIn();
/*      */   }
/*      */   
/*      */   public static Type getMixInAnnotations(Type target) {
/* 2177 */     ObjectReaderProvider readerProvider = JSONFactory.getDefaultObjectReaderProvider();
/* 2178 */     Class mixIn = readerProvider.getMixIn((Class)target);
/* 2179 */     if (mixIn == null) {
/* 2180 */       mixIn = JSONFactory.getDefaultObjectWriterProvider().getMixIn((Class)target);
/*      */     }
/* 2182 */     return mixIn;
/*      */   }
/*      */   
/*      */   static class Cache {
/*      */     volatile char[] chars;
/*      */   }
/*      */   
/*      */   public String toJSONString() {
/* 2190 */     return com.alibaba.fastjson2.JSON.toJSONString(this, new JSONWriter.Feature[] { JSONWriter.Feature.ReferenceDetection });
/*      */   }
/*      */   
/*      */   public String toString(SerializerFeature... features) {
/* 2194 */     return toJSONString(this, features);
/*      */   }
/*      */   
/*      */   public void writeJSONString(Appendable appendable) {
/* 2198 */     if (appendable instanceof Writer) {
/* 2199 */       writeJSONString((Writer)appendable, this, new SerializerFeature[0]);
/*      */       
/*      */       return;
/*      */     } 
/*      */     try {
/* 2204 */       appendable.append(toJSONString(this));
/* 2205 */     } catch (IOException e) {
/* 2206 */       throw new JSONException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public abstract <T> T toJavaObject(Class<T> paramClass);
/*      */   
/*      */   public abstract <T> T toJavaObject(Type paramType);
/*      */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSON.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */