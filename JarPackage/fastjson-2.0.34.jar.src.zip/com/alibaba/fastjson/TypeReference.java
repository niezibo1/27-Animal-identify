/*     */ package com.alibaba.fastjson;
/*     */ 
/*     */ import com.alibaba.fastjson.util.ParameterizedTypeImpl;
/*     */ import com.alibaba.fastjson.util.TypeUtils;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeReference<T>
/*     */ {
/*  29 */   static ConcurrentMap<Type, Type> classTypeCache = new ConcurrentHashMap<>(16, 0.75F, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Type type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeReference() {
/*  43 */     Type superClass = getClass().getGenericSuperclass();
/*     */     
/*  45 */     Type type = ((ParameterizedType)superClass).getActualTypeArguments()[0];
/*     */     
/*  47 */     Type cachedType = classTypeCache.get(type);
/*  48 */     if (cachedType == null) {
/*  49 */       classTypeCache.putIfAbsent(type, type);
/*  50 */       cachedType = classTypeCache.get(type);
/*     */     } 
/*     */     
/*  53 */     this.type = cachedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeReference(Type... actualTypeArguments) {
/*  60 */     if (actualTypeArguments != null && actualTypeArguments.length == 1 && actualTypeArguments[0] == null)
/*     */     {
/*     */       
/*  63 */       actualTypeArguments = new Type[] { Object.class };
/*     */     }
/*     */     
/*  66 */     Class<?> thisClass = getClass();
/*  67 */     Type superClass = thisClass.getGenericSuperclass();
/*     */     
/*  69 */     ParameterizedType argType = (ParameterizedType)((ParameterizedType)superClass).getActualTypeArguments()[0];
/*  70 */     Type rawType = argType.getRawType();
/*  71 */     Type[] argTypes = argType.getActualTypeArguments();
/*     */     
/*  73 */     int actualIndex = 0;
/*  74 */     for (int i = 0; i < argTypes.length; i++) {
/*  75 */       if (argTypes[i] instanceof java.lang.reflect.TypeVariable && actualIndex < actualTypeArguments.length)
/*     */       {
/*  77 */         argTypes[i] = actualTypeArguments[actualIndex++];
/*     */       }
/*     */       
/*  80 */       if (argTypes[i] instanceof GenericArrayType) {
/*  81 */         argTypes[i] = TypeUtils.checkPrimitiveArray((GenericArrayType)argTypes[i]);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  86 */       if (argTypes[i] instanceof ParameterizedType) {
/*  87 */         argTypes[i] = handlerParameterizedType((ParameterizedType)argTypes[i], actualTypeArguments, actualIndex);
/*     */       }
/*     */     } 
/*     */     
/*  91 */     ParameterizedTypeImpl parameterizedTypeImpl = new ParameterizedTypeImpl(argTypes, thisClass, rawType);
/*  92 */     Type cachedType = classTypeCache.get(parameterizedTypeImpl);
/*  93 */     if (cachedType == null) {
/*  94 */       classTypeCache.putIfAbsent(parameterizedTypeImpl, parameterizedTypeImpl);
/*  95 */       cachedType = classTypeCache.get(parameterizedTypeImpl);
/*     */     } 
/*     */     
/*  98 */     this.type = cachedType;
/*     */   }
/*     */   
/*     */   private Type handlerParameterizedType(ParameterizedType type, Type[] actualTypeArguments, int actualIndex) {
/* 102 */     Class<?> thisClass = getClass();
/* 103 */     Type rawType = type.getRawType();
/* 104 */     Type[] argTypes = type.getActualTypeArguments();
/*     */     
/* 106 */     for (int i = 0; i < argTypes.length; i++) {
/* 107 */       if (argTypes[i] instanceof java.lang.reflect.TypeVariable && actualIndex < actualTypeArguments.length) {
/* 108 */         argTypes[i] = actualTypeArguments[actualIndex++];
/*     */       }
/*     */ 
/*     */       
/* 112 */       if (argTypes[i] instanceof GenericArrayType) {
/* 113 */         argTypes[i] = TypeUtils.checkPrimitiveArray((GenericArrayType)argTypes[i]);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 118 */       if (argTypes[i] instanceof ParameterizedType) {
/* 119 */         return handlerParameterizedType((ParameterizedType)argTypes[i], actualTypeArguments, actualIndex);
/*     */       }
/*     */     } 
/*     */     
/* 123 */     return (Type)new ParameterizedTypeImpl(argTypes, thisClass, rawType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 131 */     return this.type;
/*     */   }
/*     */   
/*     */   public static Type intern(ParameterizedTypeImpl type) {
/* 135 */     Type cachedType = classTypeCache.get(type);
/* 136 */     if (cachedType == null) {
/* 137 */       classTypeCache.putIfAbsent(type, type);
/* 138 */       cachedType = classTypeCache.get(type);
/*     */     } 
/*     */     
/* 141 */     return cachedType;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\TypeReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */