/*     */ package com.alibaba.fastjson;
/*     */ 
/*     */ import com.alibaba.fastjson.parser.Feature;
/*     */ import com.alibaba.fastjson2.JSONException;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class JSONReader
/*     */   implements Closeable {
/*     */   private final Reader input;
/*     */   private final com.alibaba.fastjson2.JSONReader raw;
/*     */   
/*     */   public JSONReader(Reader reader) {
/*  17 */     this(reader, new Feature[0]);
/*     */   }
/*     */   
/*     */   public JSONReader(Reader input, Feature... features) {
/*  21 */     com.alibaba.fastjson2.JSONReader.Context context = JSON.createReadContext(JSON.DEFAULT_PARSER_FEATURE, features);
/*  22 */     this.raw = com.alibaba.fastjson2.JSONReader.of(input, context);
/*  23 */     this.input = input;
/*  24 */     for (int i = 0; i < features.length; i++) {
/*  25 */       if (features[i] == Feature.SupportArrayToBean) {
/*  26 */         context.config(new com.alibaba.fastjson2.JSONReader.Feature[] { com.alibaba.fastjson2.JSONReader.Feature.SupportArrayToBean });
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/*  32 */     this.raw.getContext().setLocale(locale);
/*     */   }
/*     */   
/*     */   public void setTimzeZone(TimeZone timezone) {
/*  36 */     this.raw.getContext().setTimeZone(timezone);
/*     */   }
/*     */   
/*     */   public <T> T readObject(Class<T> type) {
/*  40 */     this.raw.nextIfMatch(':');
/*     */     try {
/*  42 */       return (T)this.raw.read(type);
/*  43 */     } catch (JSONException ex) {
/*  44 */       throw new JSONException(ex.getMessage(), ex.getCause());
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object readObject() {
/*  49 */     this.raw.nextIfMatch(':');
/*  50 */     return this.raw.readAny();
/*     */   }
/*     */   
/*     */   public void readObject(Object object) {
/*  54 */     this.raw.nextIfMatch(':');
/*  55 */     this.raw.readObject(object, new com.alibaba.fastjson2.JSONReader.Feature[0]);
/*     */   }
/*     */   
/*     */   public Integer readInteger() {
/*  59 */     this.raw.nextIfMatch(':');
/*  60 */     return this.raw.readInt32();
/*     */   }
/*     */   
/*     */   public Long readLong() {
/*  64 */     this.raw.nextIfMatch(':');
/*  65 */     return this.raw.readInt64();
/*     */   }
/*     */   
/*     */   public String readString() {
/*  69 */     this.raw.nextIfMatch(':');
/*  70 */     return this.raw.readString();
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/*  74 */     if (this.raw.isEnd()) {
/*  75 */       return false;
/*     */     }
/*     */     
/*  78 */     char ch = this.raw.current();
/*  79 */     return (ch != ']' && ch != '}');
/*     */   }
/*     */   
/*     */   public void startArray() {
/*  83 */     this.raw.nextIfMatch(':');
/*  84 */     if (!this.raw.nextIfArrayStart()) {
/*  85 */       throw new JSONException("not support operation");
/*     */     }
/*     */   }
/*     */   
/*     */   public void endArray() {
/*  90 */     if (!this.raw.nextIfArrayEnd()) {
/*  91 */       throw new JSONException("not support operation");
/*     */     }
/*  93 */     this.raw.nextIfComma();
/*     */   }
/*     */   
/*     */   public void startObject() {
/*  97 */     this.raw.nextIfMatch(':');
/*  98 */     if (!this.raw.nextIfObjectStart()) {
/*  99 */       throw new JSONException("not support operation");
/*     */     }
/*     */   }
/*     */   
/*     */   public void endObject() {
/* 104 */     if (!this.raw.nextIfObjectEnd()) {
/* 105 */       throw new JSONException(this.raw.info("not support operation"));
/*     */     }
/* 107 */     this.raw.nextIfComma();
/*     */   }
/*     */   
/*     */   public Locale getLocal() {
/* 111 */     return this.raw.getContext().getLocale();
/*     */   }
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 115 */     return this.raw.getContext().getTimeZone();
/*     */   }
/*     */   
/*     */   public void config(Feature feature, boolean state) {
/* 119 */     com.alibaba.fastjson2.JSONReader.Feature rawFeature = null;
/* 120 */     switch (feature) {
/*     */       case SupportArrayToBean:
/* 122 */         rawFeature = com.alibaba.fastjson2.JSONReader.Feature.SupportArrayToBean;
/*     */         break;
/*     */       case UseNativeJavaObject:
/* 125 */         rawFeature = com.alibaba.fastjson2.JSONReader.Feature.UseNativeObject;
/*     */         break;
/*     */       case SupportAutoType:
/* 128 */         rawFeature = com.alibaba.fastjson2.JSONReader.Feature.SupportAutoType;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (rawFeature == null) {
/*     */       return;
/*     */     }
/* 137 */     this.raw.getContext().config(rawFeature, state);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 142 */     this.input.close();
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSONReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */