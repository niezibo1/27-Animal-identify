package com.alibaba.fastjson;

public interface JSONAware {
  String toJSONString();
}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSONAware.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */