/*    */ package com.alibaba.fastjson;public class JSONValidator {
/*    */   private JSONReader jsonReader;
/*    */   private Boolean validateResult;
/*    */   private Type type;
/*    */   private char firstChar;
/*    */   
/*    */   public enum Type {
/*  8 */     Object, Array, Value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private JSONValidator(JSONReader jsonReader) {
/* 17 */     this.jsonReader = jsonReader;
/*    */   }
/*    */   
/*    */   public static JSONValidator fromUtf8(byte[] jsonBytes) {
/* 21 */     return new JSONValidator(JSONReader.of(jsonBytes));
/*    */   }
/*    */   
/*    */   public static JSONValidator from(String jsonStr) {
/* 25 */     return new JSONValidator(JSONReader.of(jsonStr));
/*    */   }
/*    */   
/*    */   public boolean validate() {
/* 29 */     if (this.validateResult != null) {
/* 30 */       return this.validateResult.booleanValue();
/*    */     }
/*    */     
/*    */     try {
/* 34 */       this.firstChar = this.jsonReader.current();
/*    */       
/* 36 */       this.jsonReader.skipValue();
/* 37 */     } catch (JSONException error) {
/* 38 */       return (this.validateResult = Boolean.valueOf(false)).booleanValue();
/*    */     } finally {
/* 40 */       this.jsonReader.close();
/*    */     } 
/*    */     
/* 43 */     if (this.firstChar == '{') {
/* 44 */       this.type = Type.Object;
/* 45 */     } else if (this.firstChar == '[') {
/* 46 */       this.type = Type.Array;
/*    */     } else {
/* 48 */       this.type = Type.Value;
/*    */     } 
/*    */     
/* 51 */     return (this.validateResult = Boolean.valueOf(this.jsonReader.isEnd())).booleanValue();
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 55 */     if (this.type == null) {
/* 56 */       validate();
/*    */     }
/*    */     
/* 59 */     return this.type;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSONValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */