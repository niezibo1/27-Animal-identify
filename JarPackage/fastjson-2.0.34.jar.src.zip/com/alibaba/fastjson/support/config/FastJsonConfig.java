/*     */ package com.alibaba.fastjson.support.config;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson.parser.Feature;
/*     */ import com.alibaba.fastjson.parser.ParserConfig;
/*     */ import com.alibaba.fastjson.parser.deserializer.ParseProcess;
/*     */ import com.alibaba.fastjson.serializer.SerializeConfig;
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*     */ import com.alibaba.fastjson.util.IOUtils;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastJsonConfig
/*     */ {
/*  85 */   private Charset charset = IOUtils.UTF8;
/*     */   
/*  87 */   private SerializeConfig serializeConfig = SerializeConfig.getGlobalInstance();
/*  88 */   private ParserConfig parserConfig = ParserConfig.getGlobalInstance();
/*     */   private ParseProcess parseProcess;
/*  90 */   private SerializerFeature[] serializerFeatures = new SerializerFeature[] { SerializerFeature.BrowserSecure };
/*     */ 
/*     */ 
/*     */   
/*  94 */   private SerializeFilter[] serializeFilters = new SerializeFilter[0];
/*  95 */   private Feature[] features = new Feature[0];
/*     */   
/*     */   private Map<Class<?>, SerializeFilter> classSerializeFilters;
/*     */   
/*     */   private String dateFormat;
/*     */   
/*     */   private boolean writeContentLength = true;
/*     */   
/*     */   public SerializeConfig getSerializeConfig() {
/* 104 */     return this.serializeConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSerializeConfig(SerializeConfig serializeConfig) {
/* 111 */     this.serializeConfig = serializeConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParserConfig getParserConfig() {
/* 118 */     return this.parserConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParserConfig(ParserConfig parserConfig) {
/* 125 */     this.parserConfig = parserConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializerFeature[] getSerializerFeatures() {
/* 132 */     return this.serializerFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSerializerFeatures(SerializerFeature... serializerFeatures) {
/* 139 */     this.serializerFeatures = serializerFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializeFilter[] getSerializeFilters() {
/* 146 */     return this.serializeFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSerializeFilters(SerializeFilter... serializeFilters) {
/* 153 */     this.serializeFilters = serializeFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Feature[] getFeatures() {
/* 160 */     return this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFeatures(Feature... features) {
/* 167 */     this.features = features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Class<?>, SerializeFilter> getClassSerializeFilters() {
/* 174 */     return this.classSerializeFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClassSerializeFilters(Map<Class<?>, SerializeFilter> classSerializeFilters) {
/* 182 */     this.classSerializeFilters = classSerializeFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateFormat() {
/* 189 */     this.dateFormat = JSON.DEFFAULT_DATE_FORMAT;
/* 190 */     return this.dateFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDateFormat(String dateFormat) {
/* 197 */     JSON.DEFFAULT_DATE_FORMAT = dateFormat;
/* 198 */     this.dateFormat = dateFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getCharset() {
/* 205 */     return this.charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharset(Charset charset) {
/* 212 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWriteContentLength() {
/* 221 */     return this.writeContentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWriteContentLength(boolean writeContentLength) {
/* 230 */     this.writeContentLength = writeContentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseProcess getParseProcess() {
/* 239 */     return this.parseProcess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParseProcess(ParseProcess parseProcess) {
/* 248 */     this.parseProcess = parseProcess;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\config\FastJsonConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */