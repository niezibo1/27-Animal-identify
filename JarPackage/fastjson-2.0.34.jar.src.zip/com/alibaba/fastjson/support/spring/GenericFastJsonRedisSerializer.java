/*    */ package com.alibaba.fastjson.support.spring;
/*    */ 
/*    */ import com.alibaba.fastjson.JSON;
/*    */ import com.alibaba.fastjson.parser.Feature;
/*    */ import com.alibaba.fastjson.serializer.ContextAutoTypeBeforeHandler;
/*    */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*    */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*    */ import org.springframework.data.redis.serializer.RedisSerializer;
/*    */ import org.springframework.data.redis.serializer.SerializationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericFastJsonRedisSerializer
/*    */   implements RedisSerializer<Object>
/*    */ {
/*    */   ContextAutoTypeBeforeHandler contextFilter;
/*    */   
/*    */   public GenericFastJsonRedisSerializer() {
/* 25 */     this.contextFilter = null;
/*    */   }
/*    */   
/*    */   public GenericFastJsonRedisSerializer(String[] acceptNames) {
/* 29 */     this.contextFilter = new ContextAutoTypeBeforeHandler(acceptNames);
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] serialize(Object object) throws SerializationException {
/* 34 */     if (object == null) {
/* 35 */       return new byte[0];
/*    */     }
/*    */     try {
/* 38 */       return JSON.toJSONBytes(object, new SerializerFeature[] { SerializerFeature.WriteClassName });
/* 39 */     } catch (Exception ex) {
/* 40 */       throw new SerializationException("Could not serialize: " + ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Object deserialize(byte[] bytes) throws SerializationException {
/* 46 */     if (bytes == null || bytes.length == 0) {
/* 47 */       return null;
/*    */     }
/*    */     try {
/* 50 */       return JSON.parseObject(bytes, Object.class, (SerializeFilter)this.contextFilter, new Feature[] { Feature.SupportAutoType });
/* 51 */     } catch (Exception ex) {
/* 52 */       throw new SerializationException("Could not deserialize: " + ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\GenericFastJsonRedisSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */