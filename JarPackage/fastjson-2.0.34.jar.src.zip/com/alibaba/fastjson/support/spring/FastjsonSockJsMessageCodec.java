/*    */ package com.alibaba.fastjson.support.spring;
/*    */ 
/*    */ import com.alibaba.fastjson2.JSON;
/*    */ import com.alibaba.fastjson2.JSONWriter;
/*    */ import com.alibaba.fastjson2.support.config.FastJsonConfig;
/*    */ import java.io.InputStream;
/*    */ import org.springframework.web.socket.sockjs.frame.AbstractSockJsMessageCodec;
/*    */ 
/*    */ public class FastjsonSockJsMessageCodec
/*    */   extends AbstractSockJsMessageCodec
/*    */ {
/* 12 */   private FastJsonConfig fastJsonConfig = new FastJsonConfig();
/*    */   
/*    */   public FastJsonConfig getFastJsonConfig() {
/* 15 */     return this.fastJsonConfig;
/*    */   }
/*    */   
/*    */   public void setFastJsonConfig(FastJsonConfig fastJsonConfig) {
/* 19 */     this.fastJsonConfig = fastJsonConfig;
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] decode(String content) {
/* 24 */     return (String[])JSON.parseObject(content, String[].class);
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] decodeInputStream(InputStream content) {
/* 29 */     return (String[])JSON.parseObject(content, String[].class, new com.alibaba.fastjson2.JSONReader.Feature[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   protected char[] applyJsonQuoting(String content) {
/* 34 */     return content.toCharArray();
/*    */   }
/*    */ 
/*    */   
/*    */   public String encode(String... messages) {
/* 39 */     JSONWriter jsonWriter = JSONWriter.of(this.fastJsonConfig.getWriterFeatures());
/* 40 */     if (jsonWriter.utf8) {
/* 41 */       jsonWriter.writeRaw(new byte[] { 97 });
/*    */     } else {
/* 43 */       jsonWriter.writeRaw(new char[] { 'a' });
/*    */     } 
/* 45 */     jsonWriter.startArray();
/* 46 */     for (int i = 0; i < messages.length; i++) {
/* 47 */       if (i != 0) {
/* 48 */         jsonWriter.writeComma();
/*    */       }
/* 50 */       String message = messages[i];
/* 51 */       jsonWriter.writeString(message);
/*    */     } 
/* 53 */     jsonWriter.endArray();
/* 54 */     return jsonWriter.toString();
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\FastjsonSockJsMessageCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */