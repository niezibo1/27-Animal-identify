/*     */ package com.alibaba.fastjson.support.spring;
/*     */ 
/*     */ import com.alibaba.fastjson.JSONPObject;
/*     */ import com.alibaba.fastjson.support.spring.annotation.ResponseJSONP;
/*     */ import com.alibaba.fastjson.util.IOUtils;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.server.ServerHttpRequest;
/*     */ import org.springframework.http.server.ServerHttpResponse;
/*     */ import org.springframework.http.server.ServletServerHttpRequest;
/*     */ import org.springframework.web.bind.annotation.ControllerAdvice;
/*     */ import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483648)
/*     */ @ControllerAdvice
/*     */ public class JSONPResponseBodyAdvice
/*     */   implements ResponseBodyAdvice<Object>
/*     */ {
/*  42 */   public final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
/*  48 */     return (FastJsonHttpMessageConverter.class.isAssignableFrom(converterType) && (returnType
/*     */       
/*  50 */       .getContainingClass().isAnnotationPresent((Class)ResponseJSONP.class) || returnType.hasMethodAnnotation(ResponseJSONP.class)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
/*  61 */     ResponseJSONP responseJsonp = (ResponseJSONP)returnType.getMethodAnnotation(ResponseJSONP.class);
/*  62 */     if (responseJsonp == null) {
/*  63 */       responseJsonp = (ResponseJSONP)returnType.getContainingClass().getAnnotation(ResponseJSONP.class);
/*     */     }
/*     */     
/*  66 */     HttpServletRequest servletRequest = ((ServletServerHttpRequest)request).getServletRequest();
/*  67 */     String callbackMethodName = servletRequest.getParameter(responseJsonp.callback());
/*     */     
/*  69 */     if (!IOUtils.isValidJsonpQueryParam(callbackMethodName)) {
/*  70 */       if (this.logger.isDebugEnabled()) {
/*  71 */         this.logger.debug("Invalid jsonp parameter value:" + callbackMethodName);
/*     */       }
/*  73 */       callbackMethodName = null;
/*     */     } 
/*     */     
/*  76 */     JSONPObject jsonpObject = new JSONPObject(callbackMethodName);
/*  77 */     jsonpObject.addParameter(body);
/*  78 */     beforeBodyWriteInternal(jsonpObject, selectedContentType, returnType, request, response);
/*  79 */     return jsonpObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeBodyWriteInternal(JSONPObject jsonpObject, MediaType contentType, MethodParameter returnType, ServerHttpRequest request, ServerHttpResponse response) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MediaType getContentType(MediaType contentType, ServerHttpRequest request, ServerHttpResponse response) {
/* 103 */     return FastJsonHttpMessageConverter.APPLICATION_JAVASCRIPT;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\JSONPResponseBodyAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */