/*     */ package com.alibaba.fastjson.support.spring;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson.JSONPObject;
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*     */ import com.alibaba.fastjson.support.config.FastJsonConfig;
/*     */ import com.alibaba.fastjson.util.IOUtils;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastJsonJsonView
/*     */   extends AbstractView
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/json;charset=UTF-8";
/*     */   public static final String DEFAULT_JSONP_CONTENT_TYPE = "application/javascript";
/*  48 */   private static final Pattern CALLBACK_PARAM_PATTERN = Pattern.compile("[0-9A-Za-z_\\.]*");
/*     */   
/*     */   @Deprecated
/*  51 */   protected Charset charset = Charset.forName("UTF-8");
/*     */   @Deprecated
/*  53 */   protected SerializerFeature[] features = new SerializerFeature[0];
/*     */   
/*     */   @Deprecated
/*  56 */   protected SerializeFilter[] filters = new SerializeFilter[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected String dateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<String> renderedAttributes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disableCaching = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean updateContentLength = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean extractValueFromSingleKeyModel;
/*     */ 
/*     */ 
/*     */   
/*  85 */   private FastJsonConfig fastJsonConfig = new FastJsonConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private String[] jsonpParameterNames = new String[] { "jsonp", "callback" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonJsonView() {
/*  96 */     setContentType("application/json;charset=UTF-8");
/*  97 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonConfig getFastJsonConfig() {
/* 105 */     return this.fastJsonConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFastJsonConfig(FastJsonConfig fastJsonConfig) {
/* 113 */     this.fastJsonConfig = fastJsonConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setSerializerFeature(SerializerFeature... features) {
/* 125 */     this.fastJsonConfig.setSerializerFeatures(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Charset getCharset() {
/* 137 */     return this.fastJsonConfig.getCharset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setCharset(Charset charset) {
/* 149 */     this.fastJsonConfig.setCharset(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getDateFormat() {
/* 161 */     return this.fastJsonConfig.getDateFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDateFormat(String dateFormat) {
/* 173 */     this.fastJsonConfig.setDateFormat(dateFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SerializerFeature[] getFeatures() {
/* 185 */     return this.fastJsonConfig.getSerializerFeatures();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setFeatures(SerializerFeature... features) {
/* 197 */     this.fastJsonConfig.setSerializerFeatures(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SerializeFilter[] getFilters() {
/* 209 */     return this.fastJsonConfig.getSerializeFilters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setFilters(SerializeFilter... filters) {
/* 221 */     this.fastJsonConfig.setSerializeFilters(filters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderedAttributes(Set<String> renderedAttributes) {
/* 230 */     this.renderedAttributes = renderedAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExtractValueFromSingleKeyModel() {
/* 239 */     return this.extractValueFromSingleKeyModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtractValueFromSingleKeyModel(boolean extractValueFromSingleKeyModel) {
/* 248 */     this.extractValueFromSingleKeyModel = extractValueFromSingleKeyModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJsonpParameterNames(Set<String> jsonpParameterNames) {
/* 261 */     Assert.notEmpty(jsonpParameterNames, "jsonpParameterName cannot be empty");
/* 262 */     this.jsonpParameterNames = jsonpParameterNames.<String>toArray(new String[jsonpParameterNames.size()]);
/*     */   }
/*     */   
/*     */   private String getJsonpParameterValue(HttpServletRequest request) {
/* 266 */     if (this.jsonpParameterNames != null) {
/* 267 */       for (String name : this.jsonpParameterNames) {
/* 268 */         String value = request.getParameter(name);
/*     */         
/* 270 */         if (IOUtils.isValidJsonpQueryParam(value)) {
/* 271 */           return value;
/*     */         }
/*     */         
/* 274 */         if (this.logger.isDebugEnabled()) {
/* 275 */           this.logger.debug("Ignoring invalid jsonp parameter value: " + value);
/*     */         }
/*     */       } 
/*     */     }
/* 279 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 286 */     Object value = filterModel(model);
/* 287 */     String jsonpParameterValue = getJsonpParameterValue(request);
/* 288 */     if (jsonpParameterValue != null) {
/* 289 */       JSONPObject jsonpObject = new JSONPObject(jsonpParameterValue);
/* 290 */       jsonpObject.addParameter(value);
/* 291 */       value = jsonpObject;
/*     */     } 
/*     */     
/* 294 */     ByteArrayOutputStream outnew = new ByteArrayOutputStream();
/*     */     
/* 296 */     int len = JSON.writeJSONString(outnew, value, this.fastJsonConfig
/*     */ 
/*     */         
/* 299 */         .getSerializeFilters(), this.fastJsonConfig
/* 300 */         .getSerializerFeatures());
/*     */ 
/*     */     
/* 303 */     if (this.updateContentLength)
/*     */     {
/* 305 */       response.setContentLength(len);
/*     */     }
/*     */ 
/*     */     
/* 309 */     ServletOutputStream out = response.getOutputStream();
/* 310 */     outnew.writeTo((OutputStream)out);
/* 311 */     outnew.close();
/* 312 */     out.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response) {
/* 320 */     setResponseContentType(request, response);
/* 321 */     response.setCharacterEncoding(this.fastJsonConfig.getCharset().name());
/* 322 */     if (this.disableCaching) {
/* 323 */       response.addHeader("Pragma", "no-cache");
/* 324 */       response.addHeader("Cache-Control", "no-cache, no-store, max-age=0");
/* 325 */       response.addDateHeader("Expires", 1L);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisableCaching(boolean disableCaching) {
/* 336 */     this.disableCaching = disableCaching;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdateContentLength(boolean updateContentLength) {
/* 347 */     this.updateContentLength = updateContentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object filterModel(Map<String, Object> model) {
/* 362 */     Map<String, Object> result = new HashMap<>(model.size());
/*     */ 
/*     */     
/* 365 */     Set<String> renderedAttributes = !CollectionUtils.isEmpty(this.renderedAttributes) ? this.renderedAttributes : model.keySet();
/*     */     
/* 367 */     for (Map.Entry<String, Object> entry : model.entrySet()) {
/* 368 */       if (!(entry.getValue() instanceof org.springframework.validation.BindingResult) && renderedAttributes
/* 369 */         .contains(entry.getKey())) {
/* 370 */         result.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     } 
/* 373 */     if (this.extractValueFromSingleKeyModel && 
/* 374 */       result.size() == 1) {
/* 375 */       Iterator<Map.Entry<String, Object>> iterator = result.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry<String, Object> entry = iterator.next();
/* 376 */         return entry.getValue(); }
/*     */     
/*     */     } 
/*     */     
/* 380 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setResponseContentType(HttpServletRequest request, HttpServletResponse response) {
/* 385 */     if (getJsonpParameterValue(request) != null) {
/* 386 */       response.setContentType("application/javascript");
/*     */     } else {
/* 388 */       super.setResponseContentType(request, response);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\FastJsonJsonView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */