/*     */ package com.alibaba.fastjson.support.spring.annotation;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson.support.config.FastJsonConfig;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.servlet.view.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastJsonView
/*     */   extends AbstractView
/*     */ {
/*     */   private Set<String> renderedAttributes;
/*     */   private boolean disableCaching = true;
/*     */   private boolean extractValueFromSingleKeyModel;
/*  50 */   private FastJsonConfig fastJsonConfig = new FastJsonConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonView() {
/*  56 */     setContentType("application/json;charset=UTF-8");
/*  57 */     setExposePathVariables(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonConfig getFastJsonConfig() {
/*  64 */     return this.fastJsonConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFastJsonConfig(FastJsonConfig fastJsonConfig) {
/*  71 */     this.fastJsonConfig = fastJsonConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderedAttributes(Set<String> renderedAttributes) {
/*  80 */     this.renderedAttributes = renderedAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExtractValueFromSingleKeyModel() {
/*  89 */     return this.extractValueFromSingleKeyModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtractValueFromSingleKeyModel(boolean extractValueFromSingleKeyModel) {
/*  96 */     this.extractValueFromSingleKeyModel = extractValueFromSingleKeyModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 103 */     Object value = filterModel(model);
/*     */     
/* 105 */     ByteArrayOutputStream outnew = new ByteArrayOutputStream();
/*     */     
/* 107 */     int len = JSON.writeJSONString(outnew, value, this.fastJsonConfig.getSerializeFilters(), this.fastJsonConfig.getSerializerFeatures());
/*     */     
/* 109 */     if (this.fastJsonConfig.isWriteContentLength())
/*     */     {
/* 111 */       response.setContentLength(len);
/*     */     }
/*     */ 
/*     */     
/* 115 */     ServletOutputStream out = response.getOutputStream();
/* 116 */     outnew.writeTo((OutputStream)out);
/* 117 */     outnew.close();
/* 118 */     out.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void prepareResponse(HttpServletRequest request, HttpServletResponse response) {
/* 124 */     setResponseContentType(request, response);
/* 125 */     response.setCharacterEncoding(this.fastJsonConfig.getCharset().name());
/* 126 */     if (this.disableCaching) {
/* 127 */       response.addHeader("Pragma", "no-cache");
/* 128 */       response.addHeader("Cache-Control", "no-cache, no-store, max-age=0");
/* 129 */       response.addDateHeader("Expires", 1L);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisableCaching(boolean disableCaching) {
/* 140 */     this.disableCaching = disableCaching;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdateContentLength(boolean updateContentLength) {
/* 151 */     this.fastJsonConfig.setWriteContentLength(updateContentLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object filterModel(Map<String, Object> model) {
/* 166 */     Map<String, Object> result = new HashMap<>(model.size());
/*     */ 
/*     */     
/* 169 */     Set<String> renderedAttributes = !CollectionUtils.isEmpty(this.renderedAttributes) ? this.renderedAttributes : model.keySet();
/*     */     
/* 171 */     for (Map.Entry<String, Object> entry : model.entrySet()) {
/* 172 */       if (!(entry.getValue() instanceof org.springframework.validation.BindingResult) && renderedAttributes
/* 173 */         .contains(entry.getKey())) {
/* 174 */         result.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     } 
/* 177 */     if (this.extractValueFromSingleKeyModel && 
/* 178 */       result.size() == 1) {
/* 179 */       Iterator<Map.Entry<String, Object>> iterator = result.entrySet().iterator(); if (iterator.hasNext()) { Map.Entry<String, Object> entry = iterator.next();
/* 180 */         return entry.getValue(); }
/*     */     
/*     */     } 
/*     */     
/* 184 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setResponseContentType(HttpServletRequest request, HttpServletResponse response) {
/* 189 */     super.setResponseContentType(request, response);
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\annotation\FastJsonView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */