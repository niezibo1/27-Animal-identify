/*    */ package com.alibaba.fastjson.support.spring;
/*    */ 
/*    */ import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyPreFilters
/*    */ {
/* 15 */   private List<MySimplePropertyPreFilter> filters = new ArrayList<>();
/*    */   
/*    */   public MySimplePropertyPreFilter addFilter() {
/* 18 */     MySimplePropertyPreFilter filter = new MySimplePropertyPreFilter();
/* 19 */     this.filters.add(filter);
/* 20 */     return filter;
/*    */   }
/*    */   
/*    */   public MySimplePropertyPreFilter addFilter(String... properties) {
/* 24 */     MySimplePropertyPreFilter filter = new MySimplePropertyPreFilter(properties);
/* 25 */     this.filters.add(filter);
/* 26 */     return filter;
/*    */   }
/*    */   
/*    */   public MySimplePropertyPreFilter addFilter(Class<?> clazz, String... properties) {
/* 30 */     MySimplePropertyPreFilter filter = new MySimplePropertyPreFilter(clazz, properties);
/* 31 */     this.filters.add(filter);
/* 32 */     return filter;
/*    */   }
/*    */   
/*    */   public List<MySimplePropertyPreFilter> getFilters() {
/* 36 */     return this.filters;
/*    */   }
/*    */   
/*    */   public void setFilters(List<MySimplePropertyPreFilter> filters) {
/* 40 */     this.filters = filters;
/*    */   }
/*    */   
/*    */   public MySimplePropertyPreFilter[] toFilters() {
/* 44 */     return this.filters.<MySimplePropertyPreFilter>toArray(new MySimplePropertyPreFilter[0]);
/*    */   }
/*    */   
/*    */   public class MySimplePropertyPreFilter extends SimplePropertyPreFilter {
/*    */     public MySimplePropertyPreFilter() {
/* 49 */       super(new String[0]);
/*    */     }
/*    */     
/*    */     public MySimplePropertyPreFilter(String... properties) {
/* 53 */       super(properties);
/*    */     }
/*    */     
/*    */     public MySimplePropertyPreFilter(Class<?> clazz, String... properties) {
/* 57 */       super(clazz, properties);
/*    */     }
/*    */     
/*    */     public MySimplePropertyPreFilter addExcludes(String... filters) {
/* 61 */       for (int i = 0; i < filters.length; i++) {
/* 62 */         getExcludes().add(filters[i]);
/*    */       }
/* 64 */       return this;
/*    */     }
/*    */     
/*    */     public MySimplePropertyPreFilter addIncludes(String... filters) {
/* 68 */       for (int i = 0; i < filters.length; i++) {
/* 69 */         getIncludes().add(filters[i]);
/*    */       }
/* 71 */       return this;
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\PropertyPreFilters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */