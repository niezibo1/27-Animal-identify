/*     */ package com.alibaba.fastjson.support.spring;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson.JSONException;
/*     */ import com.alibaba.fastjson.support.config.FastJsonConfig;
/*     */ import com.alibaba.fastjson2.JSON;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastJsonHttpMessageConverter
/*     */   extends AbstractHttpMessageConverter<Object>
/*     */   implements GenericHttpMessageConverter<Object>
/*     */ {
/*  38 */   public static final MediaType APPLICATION_JAVASCRIPT = new MediaType("application", "javascript");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   private FastJsonConfig fastJsonConfig = new FastJsonConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonHttpMessageConverter() {
/*  49 */     super(MediaType.ALL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonConfig getFastJsonConfig() {
/*  56 */     return this.fastJsonConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFastJsonConfig(FastJsonConfig fastJsonConfig) {
/*  63 */     this.fastJsonConfig = fastJsonConfig;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean supports(Class<?> clazz) {
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType) {
/*  73 */     return canRead(contextClass, mediaType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite(Type type, Class<?> clazz, MediaType mediaType) {
/*  78 */     return canWrite(clazz, mediaType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/*  87 */     return readType(getType(type, contextClass), inputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(Object o, Type type, MediaType contentType, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/*  98 */     write(o, contentType, outputMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage) throws IOException, HttpMessageNotReadableException {
/* 106 */     return readType(getType(clazz, null), inputMessage);
/*     */   }
/*     */   private Object readType(Type type, HttpInputMessage inputMessage) {
/*     */     
/* 110 */     try { ByteArrayOutputStream baos = new ByteArrayOutputStream(); 
/* 111 */       try { InputStream in = inputMessage.getBody();
/*     */         
/* 113 */         byte[] buf = new byte[65536];
/*     */         while (true) {
/* 115 */           int len = in.read(buf);
/* 116 */           if (len == -1) {
/*     */             break;
/*     */           }
/*     */           
/* 120 */           if (len > 0) {
/* 121 */             baos.write(buf, 0, len);
/*     */           }
/*     */         } 
/* 124 */         byte[] bytes = baos.toByteArray();
/*     */         
/* 126 */         Object object = JSON.parseObject(bytes, type, this.fastJsonConfig.getFeatures());
/* 127 */         baos.close(); return object; } catch (Throwable throwable) { try { baos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (JSONException ex)
/* 128 */     { throw new HttpMessageNotReadableException("JSON parse error: " + ex.getMessage(), ex); }
/* 129 */     catch (IOException ex)
/* 130 */     { throw new HttpMessageNotReadableException("I/O error while reading input message", ex); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeInternal(Object object, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException {
/*     */     
/* 139 */     try { ByteArrayOutputStream baos = new ByteArrayOutputStream(); 
/* 140 */       try { int contentLength; HttpHeaders headers = outputMessage.getHeaders();
/*     */ 
/*     */         
/* 143 */         if (object instanceof String && JSON.isValidObject((String)object)) {
/* 144 */           byte[] strBytes = ((String)object).getBytes(this.fastJsonConfig.getCharset());
/* 145 */           contentLength = strBytes.length;
/* 146 */           outputMessage.getBody().write(strBytes, 0, strBytes.length);
/* 147 */         } else if (object instanceof byte[] && JSON.isValid((byte[])object)) {
/* 148 */           byte[] strBytes = (byte[])object;
/* 149 */           contentLength = strBytes.length;
/* 150 */           outputMessage.getBody().write(strBytes, 0, strBytes.length);
/*     */         } else {
/* 152 */           if (object instanceof com.alibaba.fastjson2.JSONPObject) {
/* 153 */             headers.setContentType(APPLICATION_JAVASCRIPT);
/*     */           }
/*     */           
/* 156 */           contentLength = JSON.writeJSONString(baos, object, this.fastJsonConfig
/*     */               
/* 158 */               .getSerializeFilters(), this.fastJsonConfig
/* 159 */               .getSerializerFeatures());
/*     */         } 
/*     */ 
/*     */         
/* 163 */         if (headers.getContentLength() < 0L && this.fastJsonConfig.isWriteContentLength()) {
/* 164 */           headers.setContentLength(contentLength);
/*     */         }
/*     */         
/* 167 */         baos.writeTo(outputMessage.getBody());
/* 168 */         baos.close(); } catch (Throwable throwable) { try { baos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (JSONException ex)
/* 169 */     { throw new HttpMessageNotWritableException("Could not write JSON: " + ex.getMessage(), ex); }
/* 170 */     catch (IOException ex)
/* 171 */     { throw new HttpMessageNotWritableException("I/O error while writing output message", ex); }
/*     */   
/*     */   }
/*     */   
/*     */   protected Type getType(Type type, Class<?> contextClass) {
/* 176 */     if (Spring4TypeResolvableHelper.isSupport()) {
/* 177 */       return Spring4TypeResolvableHelper.getType(type, contextClass);
/*     */     }
/* 179 */     return type;
/*     */   }
/*     */   
/*     */   private static class Spring4TypeResolvableHelper {
/*     */     private static boolean hasClazzResolvableType;
/*     */     
/*     */     static {
/*     */       try {
/* 187 */         Class.forName("org.springframework.core.ResolvableType");
/* 188 */         hasClazzResolvableType = true;
/* 189 */       } catch (ClassNotFoundException e) {
/* 190 */         hasClazzResolvableType = false;
/*     */       } 
/*     */     }
/*     */     
/*     */     private static boolean isSupport() {
/* 195 */       return hasClazzResolvableType;
/*     */     }
/*     */     
/*     */     private static Type getType(Type type, Class<?> contextClass) {
/* 199 */       if (contextClass != null) {
/* 200 */         ResolvableType resolvedType = ResolvableType.forType(type);
/* 201 */         if (type instanceof TypeVariable) {
/* 202 */           ResolvableType resolvedTypeVariable = resolveVariable((TypeVariable)type, 
/*     */               
/* 204 */               ResolvableType.forClass(contextClass));
/*     */           
/* 206 */           if (resolvedTypeVariable != ResolvableType.NONE) {
/* 207 */             return resolvedTypeVariable.resolve();
/*     */           }
/* 209 */         } else if (type instanceof ParameterizedType && resolvedType.hasUnresolvableGenerics()) {
/* 210 */           ParameterizedType parameterizedType = (ParameterizedType)type;
/* 211 */           Class<?>[] generics = new Class[(parameterizedType.getActualTypeArguments()).length];
/* 212 */           Type[] typeArguments = parameterizedType.getActualTypeArguments();
/*     */           
/* 214 */           for (int i = 0; i < typeArguments.length; i++) {
/* 215 */             Type typeArgument = typeArguments[i];
/* 216 */             if (typeArgument instanceof TypeVariable) {
/* 217 */               ResolvableType resolvedTypeArgument = resolveVariable((TypeVariable)typeArgument, 
/*     */                   
/* 219 */                   ResolvableType.forClass(contextClass));
/*     */               
/* 221 */               if (resolvedTypeArgument != ResolvableType.NONE) {
/* 222 */                 generics[i] = resolvedTypeArgument.resolve();
/*     */               } else {
/* 224 */                 generics[i] = ResolvableType.forType(typeArgument).resolve();
/*     */               } 
/*     */             } else {
/* 227 */               generics[i] = ResolvableType.forType(typeArgument).resolve();
/*     */             } 
/*     */           } 
/*     */           
/* 231 */           return ResolvableType.forClassWithGenerics(resolvedType.getRawClass(), generics).getType();
/*     */         } 
/*     */       } 
/*     */       
/* 235 */       return type;
/*     */     }
/*     */ 
/*     */     
/*     */     private static ResolvableType resolveVariable(TypeVariable<?> typeVariable, ResolvableType contextType) {
/* 240 */       if (contextType.hasGenerics()) {
/* 241 */         ResolvableType resolvedType = ResolvableType.forType(typeVariable, contextType);
/* 242 */         if (resolvedType.resolve() != null) {
/* 243 */           return resolvedType;
/*     */         }
/*     */       } 
/*     */       
/* 247 */       ResolvableType superType = contextType.getSuperType();
/* 248 */       if (superType != ResolvableType.NONE) {
/* 249 */         ResolvableType resolvedType = resolveVariable(typeVariable, superType);
/* 250 */         if (resolvedType.resolve() != null) {
/* 251 */           return resolvedType;
/*     */         }
/*     */       } 
/* 254 */       for (ResolvableType ifc : contextType.getInterfaces()) {
/* 255 */         ResolvableType resolvedType = resolveVariable(typeVariable, ifc);
/* 256 */         if (resolvedType.resolve() != null) {
/* 257 */           return resolvedType;
/*     */         }
/*     */       } 
/* 260 */       return ResolvableType.NONE;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\FastJsonHttpMessageConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */