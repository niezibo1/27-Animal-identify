/*    */ package com.alibaba.fastjson.support.spring;
/*    */ 
/*    */ import com.alibaba.fastjson.JSON;
/*    */ import com.alibaba.fastjson.support.config.FastJsonConfig;
/*    */ import org.springframework.data.redis.serializer.RedisSerializer;
/*    */ import org.springframework.data.redis.serializer.SerializationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastJsonRedisSerializer<T>
/*    */   implements RedisSerializer<T>
/*    */ {
/*    */   private final Class<T> type;
/* 21 */   private FastJsonConfig fastJsonConfig = new FastJsonConfig();
/*    */   
/*    */   public FastJsonRedisSerializer(Class<T> type) {
/* 24 */     this.type = type;
/*    */   }
/*    */   
/*    */   public FastJsonConfig getFastJsonConfig() {
/* 28 */     return this.fastJsonConfig;
/*    */   }
/*    */   
/*    */   public void setFastJsonConfig(FastJsonConfig fastJsonConfig) {
/* 32 */     this.fastJsonConfig = fastJsonConfig;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] serialize(T type) throws SerializationException {
/* 37 */     if (type == null) {
/* 38 */       return new byte[0];
/*    */     }
/*    */     try {
/* 41 */       return JSON.toJSONBytes(type, this.fastJsonConfig.getSerializeFilters(), this.fastJsonConfig.getSerializerFeatures());
/* 42 */     } catch (Exception ex) {
/* 43 */       throw new SerializationException("Could not serialize: " + ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public T deserialize(byte[] bytes) throws SerializationException {
/* 49 */     if (bytes == null || bytes.length == 0) {
/* 50 */       return null;
/*    */     }
/*    */     try {
/* 53 */       return (T)JSON.parseObject(bytes, this.type, this.fastJsonConfig.getFeatures());
/* 54 */     } catch (Exception ex) {
/* 55 */       throw new SerializationException("Could not deserialize: " + ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\FastJsonRedisSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */