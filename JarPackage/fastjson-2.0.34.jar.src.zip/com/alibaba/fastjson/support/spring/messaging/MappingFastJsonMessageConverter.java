/*    */ package com.alibaba.fastjson.support.spring.messaging;
/*    */ 
/*    */ import com.alibaba.fastjson.JSON;
/*    */ import com.alibaba.fastjson.support.config.FastJsonConfig;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import org.springframework.messaging.Message;
/*    */ import org.springframework.messaging.MessageHeaders;
/*    */ import org.springframework.messaging.converter.AbstractMessageConverter;
/*    */ import org.springframework.util.MimeType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingFastJsonMessageConverter
/*    */   extends AbstractMessageConverter
/*    */ {
/* 27 */   private FastJsonConfig fastJsonConfig = new FastJsonConfig();
/*    */   
/*    */   public MappingFastJsonMessageConverter() {
/* 30 */     super(new MimeType("application", "json", StandardCharsets.UTF_8));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FastJsonConfig getFastJsonConfig() {
/* 37 */     return this.fastJsonConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFastJsonConfig(FastJsonConfig fastJsonConfig) {
/* 44 */     this.fastJsonConfig = fastJsonConfig;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean supports(Class<?> clazz) {
/* 49 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean canConvertFrom(Message<?> message, Class<?> targetClass) {
/* 54 */     return supports(targetClass);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean canConvertTo(Object payload, MessageHeaders headers) {
/* 59 */     return supports(payload.getClass());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object convertFromInternal(Message<?> message, Class<?> targetClass, Object conversionHint) {
/* 65 */     Object payload = message.getPayload();
/* 66 */     Object obj = null;
/* 67 */     if (payload instanceof byte[]) {
/* 68 */       obj = JSON.parseObject((byte[])payload, targetClass, this.fastJsonConfig.getFeatures());
/* 69 */     } else if (payload instanceof String) {
/* 70 */       obj = JSON.parseObject((String)payload, targetClass, this.fastJsonConfig.getFeatures());
/*    */     } 
/*    */     
/* 73 */     return obj;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object convertToInternal(Object payload, MessageHeaders headers, Object conversionHint) {
/*    */     Object obj;
/* 80 */     if (byte[].class == getSerializedPayloadClass()) {
/* 81 */       if (payload instanceof String && JSON.isValid((String)payload)) {
/* 82 */         obj = ((String)payload).getBytes(this.fastJsonConfig.getCharset());
/*    */       } else {
/* 84 */         obj = JSON.toJSONBytes(payload, this.fastJsonConfig.getSerializeFilters(), this.fastJsonConfig.getSerializerFeatures());
/*    */       }
/*    */     
/* 87 */     } else if (payload instanceof String && JSON.isValid((String)payload)) {
/* 88 */       obj = payload;
/*    */     } else {
/* 90 */       obj = JSON.toJSONString(payload, this.fastJsonConfig.getSerializeFilters(), this.fastJsonConfig.getSerializerFeatures());
/*    */     } 
/*    */ 
/*    */     
/* 94 */     return obj;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\spring\messaging\MappingFastJsonMessageConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */