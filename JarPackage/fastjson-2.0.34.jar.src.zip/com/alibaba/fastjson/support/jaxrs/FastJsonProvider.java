/*     */ package com.alibaba.fastjson.support.jaxrs;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson.JSONException;
/*     */ import com.alibaba.fastjson.serializer.SerializeConfig;
/*     */ import com.alibaba.fastjson.serializer.SerializeFilter;
/*     */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*     */ import com.alibaba.fastjson.support.config.FastJsonConfig;
/*     */ import com.alibaba.fastjson2.JSONWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.ws.rs.Consumes;
/*     */ import javax.ws.rs.Produces;
/*     */ import javax.ws.rs.WebApplicationException;
/*     */ import javax.ws.rs.core.Context;
/*     */ import javax.ws.rs.core.MediaType;
/*     */ import javax.ws.rs.core.MultivaluedMap;
/*     */ import javax.ws.rs.core.Response;
/*     */ import javax.ws.rs.core.StreamingOutput;
/*     */ import javax.ws.rs.ext.ContextResolver;
/*     */ import javax.ws.rs.ext.MessageBodyReader;
/*     */ import javax.ws.rs.ext.MessageBodyWriter;
/*     */ import javax.ws.rs.ext.Provider;
/*     */ import javax.ws.rs.ext.Providers;
/*     */ 
/*     */ 
/*     */ 
/*     */ @Provider
/*     */ @Consumes({"*/*"})
/*     */ @Produces({"*/*"})
/*     */ public class FastJsonProvider
/*     */   implements MessageBodyReader<Object>, MessageBodyWriter<Object>
/*     */ {
/*  43 */   public static final Class<?>[] DEFAULT_UNREADABLES = new Class[] { InputStream.class, Reader.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final Class<?>[] DEFAULT_UNWRITABLES = new Class[] { InputStream.class, OutputStream.class, Writer.class, StreamingOutput.class, Response.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  58 */   protected Charset charset = Charset.forName("UTF-8");
/*     */   @Deprecated
/*  60 */   protected SerializerFeature[] features = new SerializerFeature[0];
/*     */   
/*     */   @Deprecated
/*  63 */   protected SerializeFilter[] filters = new SerializeFilter[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected String dateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Context
/*     */   protected Providers providers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private FastJsonConfig fastJsonConfig = new FastJsonConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?>[] clazzes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean pretty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonConfig getFastJsonConfig() {
/*  97 */     return this.fastJsonConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFastJsonConfig(FastJsonConfig fastJsonConfig) {
/* 105 */     this.fastJsonConfig = fastJsonConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonProvider() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonProvider(Class<?>[] clazzes) {
/* 118 */     this.clazzes = clazzes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FastJsonProvider setPretty(boolean p) {
/* 125 */     this.pretty = p;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public FastJsonProvider(String charset) {
/* 138 */     this.fastJsonConfig.setCharset(Charset.forName(charset));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Charset getCharset() {
/* 150 */     return this.fastJsonConfig.getCharset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setCharset(Charset charset) {
/* 162 */     this.fastJsonConfig.setCharset(charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getDateFormat() {
/* 174 */     return this.fastJsonConfig.getDateFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDateFormat(String dateFormat) {
/* 186 */     this.fastJsonConfig.setDateFormat(dateFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SerializerFeature[] getFeatures() {
/* 198 */     return this.fastJsonConfig.getSerializerFeatures();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setFeatures(SerializerFeature... features) {
/* 210 */     this.fastJsonConfig.setSerializerFeatures(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SerializeFilter[] getFilters() {
/* 222 */     return this.fastJsonConfig.getSerializeFilters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setFilters(SerializeFilter... filters) {
/* 234 */     this.fastJsonConfig.setSerializeFilters(filters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAssignableFrom(Class<?> type, Class<?>[] classes) {
/* 245 */     if (type == null) {
/* 246 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 250 */     for (Class<?> cls : classes) {
/* 251 */       if (cls.isAssignableFrom(type)) {
/* 252 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 256 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValidType(Class<?> type, Annotation[] classAnnotations) {
/* 267 */     if (type == null) {
/* 268 */       return false;
/*     */     }
/*     */     
/* 271 */     if (this.clazzes != null) {
/* 272 */       for (Class<?> cls : this.clazzes) {
/*     */         
/* 274 */         if (cls == type) {
/* 275 */           return true;
/*     */         }
/*     */       } 
/*     */       
/* 279 */       return false;
/*     */     } 
/*     */     
/* 282 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasMatchingMediaType(MediaType mediaType) {
/* 292 */     if (mediaType != null) {
/* 293 */       String subtype = mediaType.getSubtype();
/*     */       
/* 295 */       return ("json".equalsIgnoreCase(subtype) || subtype
/* 296 */         .endsWith("+json") || "javascript"
/* 297 */         .equals(subtype) || "x-javascript"
/* 298 */         .equals(subtype) || "x-json"
/* 299 */         .equals(subtype) || "x-www-form-urlencoded"
/* 300 */         .equalsIgnoreCase(subtype) || subtype
/* 301 */         .endsWith("x-www-form-urlencoded"));
/*     */     } 
/* 303 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 316 */     if (!hasMatchingMediaType(mediaType)) {
/* 317 */       return false;
/*     */     }
/*     */     
/* 320 */     if (!isAssignableFrom(type, DEFAULT_UNWRITABLES)) {
/* 321 */       return false;
/*     */     }
/*     */     
/* 324 */     return isValidType(type, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSize(Object t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 338 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(Object obj, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream) throws IOException, WebApplicationException {
/* 354 */     FastJsonConfig fastJsonConfig = locateConfigProvider(type, mediaType);
/* 355 */     SerializerFeature[] serializerFeatures = fastJsonConfig.getSerializerFeatures();
/*     */     
/* 357 */     if (this.pretty) {
/* 358 */       if (serializerFeatures == null) {
/* 359 */         serializerFeatures = new SerializerFeature[] { SerializerFeature.PrettyFormat };
/*     */       } else {
/* 361 */         List<SerializerFeature> featureList = new ArrayList<>(Arrays.asList(serializerFeatures));
/* 362 */         featureList.add(SerializerFeature.PrettyFormat);
/* 363 */         serializerFeatures = featureList.<SerializerFeature>toArray(serializerFeatures);
/*     */       } 
/* 365 */       fastJsonConfig.setSerializerFeatures(serializerFeatures);
/*     */     } 
/*     */     
/*     */     try {
/* 369 */       writeJSONStringWithFastJsonConfig(entityStream, fastJsonConfig
/*     */           
/* 371 */           .getCharset(), obj, fastJsonConfig
/*     */           
/* 373 */           .getSerializeConfig(), fastJsonConfig
/* 374 */           .getSerializeFilters(), fastJsonConfig
/* 375 */           .getDateFormat(), JSON.DEFAULT_GENERATE_FEATURE, fastJsonConfig
/*     */           
/* 377 */           .getSerializerFeatures());
/*     */ 
/*     */       
/* 380 */       entityStream.flush();
/* 381 */     } catch (JSONException ex) {
/* 382 */       throw new WebApplicationException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int writeJSONStringWithFastJsonConfig(OutputStream os, Charset charset, Object object, SerializeConfig config, SerializeFilter[] filters, String dateFormat, int defaultFeatures, SerializerFeature... features) throws IOException {
/* 395 */     for (SerializerFeature feature : features) {
/* 396 */       defaultFeatures |= feature.mask;
/*     */     }
/*     */     
/* 399 */     JSONWriter.Context context = JSON.createWriteContext(config, defaultFeatures, features);
/* 400 */     JSONWriter writer = JSONWriter.ofUTF8(context);
/* 401 */     context.setDateFormat(dateFormat);
/*     */     
/*     */     try {
/* 404 */       if (filters != null) {
/* 405 */         for (SerializeFilter filter : filters) {
/* 406 */           JSON.configFilter(context, filter);
/*     */         }
/*     */       }
/*     */       
/* 410 */       writer.writeAny(object);
/*     */       
/* 412 */       int len = writer.flushTo(os, charset);
/* 413 */       return len;
/*     */     } finally {
/* 415 */       writer.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
/* 429 */     if (!hasMatchingMediaType(mediaType)) {
/* 430 */       return false;
/*     */     }
/*     */     
/* 433 */     if (!isAssignableFrom(type, DEFAULT_UNREADABLES)) {
/* 434 */       return false;
/*     */     }
/*     */     
/* 437 */     return isValidType(type, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object readFrom(Class<Object> type, Type genericType, Annotation[] annotations, MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream) throws IOException, WebApplicationException {
/*     */     try {
/* 453 */       FastJsonConfig fastJsonConfig = locateConfigProvider(type, mediaType);
/*     */       
/* 455 */       return JSON.parseObject(entityStream, fastJsonConfig
/* 456 */           .getCharset(), genericType, fastJsonConfig
/*     */           
/* 458 */           .getParserConfig(), fastJsonConfig
/* 459 */           .getParseProcess(), JSON.DEFAULT_PARSER_FEATURE, fastJsonConfig
/*     */           
/* 461 */           .getFeatures());
/* 462 */     } catch (JSONException ex) {
/* 463 */       throw new WebApplicationException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FastJsonConfig locateConfigProvider(Class<?> type, MediaType mediaType) {
/* 471 */     if (this.providers != null) {
/* 472 */       ContextResolver<FastJsonConfig> resolver = this.providers.getContextResolver(FastJsonConfig.class, mediaType);
/*     */       
/* 474 */       if (resolver == null) {
/* 475 */         resolver = this.providers.getContextResolver(FastJsonConfig.class, null);
/*     */       }
/*     */       
/* 478 */       if (resolver != null) {
/* 479 */         return (FastJsonConfig)resolver.getContext(type);
/*     */       }
/*     */     } 
/*     */     
/* 483 */     return this.fastJsonConfig;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\jaxrs\FastJsonProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */