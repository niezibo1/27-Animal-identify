/*    */ package com.alibaba.fastjson.support.jaxrs;
/*    */ 
/*    */ import javax.ws.rs.core.Configuration;
/*    */ import javax.ws.rs.core.Feature;
/*    */ import javax.ws.rs.core.FeatureContext;
/*    */ import javax.ws.rs.ext.MessageBodyReader;
/*    */ import javax.ws.rs.ext.MessageBodyWriter;
/*    */ import org.glassfish.jersey.CommonProperties;
/*    */ import org.glassfish.jersey.internal.util.PropertiesHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FastJsonFeature
/*    */   implements Feature
/*    */ {
/* 23 */   private static final String JSON_FEATURE = FastJsonFeature.class.getSimpleName();
/*    */ 
/*    */   
/*    */   public boolean configure(FeatureContext context) {
/*    */     try {
/* 28 */       Configuration config = context.getConfiguration();
/*    */       
/* 30 */       String jsonFeature = (String)CommonProperties.getValue(config
/* 31 */           .getProperties(), config
/* 32 */           .getRuntimeType(), "jersey.config.jsonFeature", JSON_FEATURE, String.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 39 */       if (!JSON_FEATURE.equalsIgnoreCase(jsonFeature)) {
/* 40 */         return false;
/*    */       }
/*    */ 
/*    */       
/* 44 */       context.property(
/* 45 */           PropertiesHelper.getPropertyNameForRuntime("jersey.config.jsonFeature", config
/*    */             
/* 47 */             .getRuntimeType()), JSON_FEATURE);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 53 */       if (!config.isRegistered(FastJsonProvider.class)) {
/* 54 */         context.register(FastJsonProvider.class, new Class[] { MessageBodyReader.class, MessageBodyWriter.class });
/*    */       }
/* 56 */     } catch (NoSuchMethodError noSuchMethodError) {}
/*    */ 
/*    */ 
/*    */     
/* 60 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\jaxrs\FastJsonFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */