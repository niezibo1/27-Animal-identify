/*    */ package com.alibaba.fastjson.support.jaxrs;
/*    */ 
/*    */ import javax.annotation.Priority;
/*    */ import javax.ws.rs.core.Configuration;
/*    */ import javax.ws.rs.core.FeatureContext;
/*    */ import org.glassfish.jersey.internal.spi.AutoDiscoverable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Priority(1999)
/*    */ public class FastJsonAutoDiscoverable
/*    */   implements AutoDiscoverable
/*    */ {
/*    */   public static final String FASTJSON_AUTO_DISCOVERABLE = "fastjson.auto.discoverable";
/*    */   public static volatile boolean autoDiscover = true;
/*    */   
/*    */   static {
/*    */     try {
/* 25 */       autoDiscover = Boolean.parseBoolean(
/* 26 */           System.getProperty("fastjson.auto.discoverable", String.valueOf(autoDiscover)));
/* 27 */     } catch (Throwable throwable) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void configure(FeatureContext context) {
/* 34 */     Configuration config = context.getConfiguration();
/*    */ 
/*    */     
/* 37 */     if (!config.isRegistered(FastJsonFeature.class) && autoDiscover)
/* 38 */       context.register(FastJsonFeature.class); 
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\jaxrs\FastJsonAutoDiscoverable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */