/*     */ package com.alibaba.fastjson.support.retrofit;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson.support.config.FastJsonConfig;
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import okhttp3.MediaType;
/*     */ import okhttp3.RequestBody;
/*     */ import okhttp3.ResponseBody;
/*     */ import retrofit2.Converter;
/*     */ import retrofit2.Retrofit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Retrofit2ConverterFactory
/*     */   extends Converter.Factory
/*     */ {
/*  27 */   private static final MediaType MEDIA_TYPE = MediaType.parse("application/json; charset=UTF-8");
/*     */   
/*     */   private FastJsonConfig fastJsonConfig;
/*     */   
/*     */   public Retrofit2ConverterFactory() {
/*  32 */     this.fastJsonConfig = new FastJsonConfig();
/*     */   }
/*     */   
/*     */   public Retrofit2ConverterFactory(FastJsonConfig fastJsonConfig) {
/*  36 */     this.fastJsonConfig = fastJsonConfig;
/*     */   }
/*     */   
/*     */   public static Retrofit2ConverterFactory create() {
/*  40 */     return create(new FastJsonConfig());
/*     */   }
/*     */   
/*     */   public static Retrofit2ConverterFactory create(FastJsonConfig fastJsonConfig) {
/*  44 */     if (fastJsonConfig == null) {
/*  45 */       throw new NullPointerException("fastJsonConfig == null");
/*     */     }
/*  47 */     return new Retrofit2ConverterFactory(fastJsonConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<ResponseBody, Object> responseBodyConverter(Type type, Annotation[] annotations, Retrofit retrofit) {
/*  55 */     return new ResponseBodyConverter(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<Object, RequestBody> requestBodyConverter(Type type, Annotation[] parameterAnnotations, Annotation[] methodAnnotations, Retrofit retrofit) {
/*  64 */     return new RequestBodyConverter();
/*     */   }
/*     */   
/*     */   public FastJsonConfig getFastJsonConfig() {
/*  68 */     return this.fastJsonConfig;
/*     */   }
/*     */   
/*     */   public Retrofit2ConverterFactory setFastJsonConfig(FastJsonConfig fastJsonConfig) {
/*  72 */     this.fastJsonConfig = fastJsonConfig;
/*  73 */     return this;
/*     */   }
/*     */   
/*     */   final class ResponseBodyConverter<T>
/*     */     implements Converter<ResponseBody, T> {
/*     */     private final Type type;
/*     */     
/*     */     ResponseBodyConverter(Type type) {
/*  81 */       this.type = type;
/*     */     }
/*     */ 
/*     */     
/*     */     public T convert(ResponseBody value) throws IOException {
/*     */       try {
/*  87 */         return (T)JSON.parseObject(value.bytes(), this.type, Retrofit2ConverterFactory.this.fastJsonConfig.getFeatures());
/*     */       }
/*  89 */       catch (Exception e) {
/*  90 */         throw new IOException("JSON parse error: " + e.getMessage(), e);
/*     */       } finally {
/*  92 */         value.close();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final class RequestBodyConverter<T>
/*     */     implements Converter<T, RequestBody>
/*     */   {
/*     */     public RequestBody convert(T value) throws IOException {
/*     */       try {
/* 105 */         byte[] content = JSON.toJSONBytes(value, Retrofit2ConverterFactory.this
/* 106 */             .fastJsonConfig.getSerializeFilters(), Retrofit2ConverterFactory.this.fastJsonConfig.getSerializerFeatures());
/* 107 */         return RequestBody.create(Retrofit2ConverterFactory.MEDIA_TYPE, content);
/* 108 */       } catch (Exception e) {
/* 109 */         throw new IOException("Could not write JSON: " + e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\retrofit\Retrofit2ConverterFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */