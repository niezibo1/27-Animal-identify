/*     */ package com.alibaba.fastjson.support.hsf;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson.JSONArray;
/*     */ import com.alibaba.fastjson.JSONException;
/*     */ import com.alibaba.fastjson.JSONObject;
/*     */ import com.alibaba.fastjson2.JSONReader;
/*     */ import com.alibaba.fastjson2.util.Fnv;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class HSFJSONUtils
/*     */ {
/*  16 */   static final long HASH_ARGS_TYPES = Fnv.hashCode64("argsTypes");
/*  17 */   static final long HASH_ARGS_OBJS = Fnv.hashCode64("argsObjs");
/*     */   public static Object[] parseInvocationArguments(String json, MethodLocator methodLocator) {
/*     */     Object[] values;
/*  20 */     JSONReader jsonReader = JSONReader.of(json);
/*     */     
/*  22 */     Method method = null;
/*     */ 
/*     */ 
/*     */     
/*  26 */     if (jsonReader.nextIfObjectStart()) {
/*  27 */       long hash0 = jsonReader.readFieldNameHashCode();
/*  28 */       if (hash0 == HASH_ARGS_TYPES) {
/*  29 */         String[] typeNames; if (jsonReader.nextIfArrayStart()) {
/*  30 */           String name0 = null, name1 = null;
/*  31 */           List<String> nameList = null;
/*  32 */           int i = 0;
/*  33 */           for (;; i++) {
/*  34 */             if (jsonReader.nextIfArrayEnd()) {
/*  35 */               jsonReader.nextIfComma(); break;
/*     */             } 
/*  37 */             if (jsonReader.isEnd()) {
/*  38 */               throw new JSONException("illegal format");
/*     */             }
/*  40 */             String name = jsonReader.readString();
/*  41 */             if (i == 0) {
/*  42 */               name0 = name;
/*  43 */             } else if (i == 1) {
/*  44 */               name1 = name;
/*  45 */             } else if (i == 2) {
/*  46 */               nameList = new ArrayList<>();
/*  47 */               nameList.add(name0);
/*  48 */               nameList.add(name1);
/*  49 */               nameList.add(name);
/*     */             } else {
/*  51 */               nameList.add(name);
/*     */             } 
/*     */           } 
/*     */           
/*  55 */           if (i == 0) {
/*  56 */             typeNames = new String[0];
/*  57 */           } else if (i == 1) {
/*  58 */             typeNames = new String[] { name0 };
/*  59 */           } else if (i == 2) {
/*  60 */             typeNames = new String[] { name0, name1 };
/*     */           } else {
/*  62 */             typeNames = new String[nameList.size()];
/*  63 */             nameList.toArray(typeNames);
/*     */           } 
/*     */         } else {
/*  66 */           throw new JSONException("illegal format");
/*     */         } 
/*  68 */         method = methodLocator.findMethod(typeNames);
/*     */       } 
/*     */       
/*  71 */       if (method != null) {
/*  72 */         Type[] argTypes = method.getGenericParameterTypes();
/*  73 */         long hash1 = jsonReader.readFieldNameHashCode();
/*  74 */         if (hash1 == HASH_ARGS_OBJS) {
/*  75 */           values = jsonReader.readArray(argTypes);
/*     */         } else {
/*  77 */           throw new JSONException("illegal format");
/*     */         } 
/*     */       } else {
/*  80 */         JSONObject jsonObject = JSON.parseObject(json);
/*  81 */         String[] typeNames = (String[])jsonObject.getObject("argsTypes", String[].class);
/*  82 */         method = methodLocator.findMethod(typeNames);
/*     */         
/*  84 */         JSONArray argsObjs = jsonObject.getJSONArray("argsObjs");
/*  85 */         if (argsObjs == null) {
/*  86 */           values = null;
/*     */         } else {
/*  88 */           Type[] argTypes = method.getGenericParameterTypes();
/*  89 */           values = new Object[argTypes.length];
/*  90 */           for (int i = 0; i < argTypes.length; i++) {
/*  91 */             Type type = argTypes[i];
/*  92 */             values[i] = argsObjs.getObject(i, type);
/*     */           } 
/*     */         } 
/*     */       } 
/*  96 */     } else if (jsonReader.nextIfArrayStart()) {
/*  97 */       String[] typeNames; if (jsonReader.nextIfArrayStart()) {
/*  98 */         String name0 = null, name1 = null;
/*  99 */         List<String> nameList = null;
/* 100 */         int i = 0;
/* 101 */         for (;; i++) {
/* 102 */           if (jsonReader.nextIfArrayEnd()) {
/* 103 */             jsonReader.nextIfComma(); break;
/*     */           } 
/* 105 */           if (jsonReader.isEnd()) {
/* 106 */             throw new JSONException("illegal format");
/*     */           }
/* 108 */           String name = jsonReader.readString();
/* 109 */           if (i == 0) {
/* 110 */             name0 = name;
/* 111 */           } else if (i == 1) {
/* 112 */             name1 = name;
/* 113 */           } else if (i == 2) {
/* 114 */             nameList = new ArrayList<>();
/* 115 */             nameList.add(name0);
/* 116 */             nameList.add(name1);
/* 117 */             nameList.add(name);
/*     */           } else {
/* 119 */             nameList.add(name);
/*     */           } 
/*     */         } 
/*     */         
/* 123 */         if (i == 0) {
/* 124 */           typeNames = new String[0];
/* 125 */         } else if (i == 1) {
/* 126 */           typeNames = new String[] { name0 };
/* 127 */         } else if (i == 2) {
/* 128 */           typeNames = new String[] { name0, name1 };
/*     */         } else {
/* 130 */           typeNames = new String[nameList.size()];
/* 131 */           nameList.toArray(typeNames);
/*     */         } 
/*     */       } else {
/* 134 */         throw new JSONException("illegal format");
/*     */       } 
/*     */       
/* 137 */       method = methodLocator.findMethod(typeNames);
/*     */       
/* 139 */       Type[] argTypes = method.getGenericParameterTypes();
/* 140 */       values = jsonReader.readArray(argTypes);
/*     */     } else {
/* 142 */       values = null;
/*     */     } 
/*     */     
/* 145 */     return values;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\hsf\HSFJSONUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */