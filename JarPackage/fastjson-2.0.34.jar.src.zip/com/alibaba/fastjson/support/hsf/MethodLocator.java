package com.alibaba.fastjson.support.hsf;

import java.lang.reflect.Method;

public interface MethodLocator {
  Method findMethod(String[] paramArrayOfString);
}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\hsf\MethodLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */