/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(seeAlso = {GeometryCollection.class, LineString.class, MultiLineString.class, Point.class, MultiPoint.class, Polygon.class, MultiPolygon.class, Feature.class, FeatureCollection.class}, typeKey = "type")
/*    */ public abstract class Geometry
/*    */ {
/*    */   private final String type;
/*    */   private double[] bbox;
/*    */   
/*    */   protected Geometry(String type) {
/* 27 */     this.type = type;
/*    */   }
/*    */   
/*    */   public String getType() {
/* 31 */     return this.type;
/*    */   }
/*    */   
/*    */   public double[] getBbox() {
/* 35 */     return this.bbox;
/*    */   }
/*    */   
/*    */   public void setBbox(double[] bbox) {
/* 39 */     this.bbox = bbox;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\Geometry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */