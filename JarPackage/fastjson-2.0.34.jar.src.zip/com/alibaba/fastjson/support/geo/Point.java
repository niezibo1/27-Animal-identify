/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONField;
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "Point", orders = {"type", "bbox", "coordinates"})
/*    */ public class Point
/*    */   extends Geometry
/*    */ {
/*    */   private double longitude;
/*    */   private double latitude;
/*    */   
/*    */   public Point() {
/* 16 */     super("Point");
/*    */   }
/*    */   
/*    */   public double[] getCoordinates() {
/* 20 */     return new double[] { this.longitude, this.latitude };
/*    */   }
/*    */   
/*    */   public void setCoordinates(double[] coordinates) {
/* 24 */     if (coordinates == null || coordinates.length == 0) {
/* 25 */       this.longitude = 0.0D;
/* 26 */       this.latitude = 0.0D;
/*    */       
/*    */       return;
/*    */     } 
/* 30 */     if (coordinates.length == 1) {
/* 31 */       this.longitude = coordinates[0];
/*    */       
/*    */       return;
/*    */     } 
/* 35 */     this.longitude = coordinates[0];
/* 36 */     this.latitude = coordinates[1];
/*    */   }
/*    */   
/*    */   @JSONField(serialize = false)
/*    */   public double getLongitude() {
/* 41 */     return this.longitude;
/*    */   }
/*    */   
/*    */   @JSONField(serialize = false)
/*    */   public double getLatitude() {
/* 46 */     return this.latitude;
/*    */   }
/*    */   
/*    */   @JSONField(deserialize = false)
/*    */   public void setLongitude(double longitude) {
/* 51 */     this.longitude = longitude;
/*    */   }
/*    */   
/*    */   @JSONField(deserialize = false)
/*    */   public void setLatitude(double latitude) {
/* 56 */     this.latitude = latitude;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\Point.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */