/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "FeatureCollection", orders = {"type", "bbox", "coordinates"})
/*    */ public class FeatureCollection
/*    */   extends Geometry
/*    */ {
/* 14 */   private List<Feature> features = new ArrayList<>();
/*    */   
/*    */   public FeatureCollection() {
/* 17 */     super("FeatureCollection");
/*    */   }
/*    */   
/*    */   public List<Feature> getFeatures() {
/* 21 */     return this.features;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\FeatureCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */