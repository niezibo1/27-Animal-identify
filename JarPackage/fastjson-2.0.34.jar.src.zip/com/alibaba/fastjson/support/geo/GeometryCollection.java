/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "GeometryCollection", orders = {"type", "bbox", "geometries"})
/*    */ public class GeometryCollection
/*    */   extends Geometry
/*    */ {
/* 14 */   private List<Geometry> geometries = new ArrayList<>();
/*    */   
/*    */   public GeometryCollection() {
/* 17 */     super("GeometryCollection");
/*    */   }
/*    */   
/*    */   public List<Geometry> getGeometries() {
/* 21 */     return this.geometries;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\GeometryCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */