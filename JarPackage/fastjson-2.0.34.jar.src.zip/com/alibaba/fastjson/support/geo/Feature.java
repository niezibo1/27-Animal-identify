/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "Feature", orders = {"type", "id", "bbox", "coordinates", "properties"})
/*    */ public class Feature
/*    */   extends Geometry
/*    */ {
/*    */   private String id;
/*    */   private Geometry geometry;
/* 16 */   private Map<String, String> properties = new LinkedHashMap<>();
/*    */   
/*    */   public Feature() {
/* 19 */     super("Feature");
/*    */   }
/*    */   
/*    */   public Geometry getGeometry() {
/* 23 */     return this.geometry;
/*    */   }
/*    */   
/*    */   public void setGeometry(Geometry geometry) {
/* 27 */     this.geometry = geometry;
/*    */   }
/*    */   
/*    */   public Map<String, String> getProperties() {
/* 31 */     return this.properties;
/*    */   }
/*    */   
/*    */   public void setProperties(Map<String, String> properties) {
/* 35 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 39 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(String id) {
/* 43 */     this.id = id;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\Feature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */