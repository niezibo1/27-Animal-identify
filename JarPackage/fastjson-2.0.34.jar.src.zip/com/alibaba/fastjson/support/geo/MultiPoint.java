/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "MultiPoint", orders = {"type", "bbox", "coordinates"})
/*    */ public class MultiPoint
/*    */   extends Geometry
/*    */ {
/*    */   private double[][] coordinates;
/*    */   
/*    */   public MultiPoint() {
/* 14 */     super("MultiPoint");
/*    */   }
/*    */   
/*    */   public double[][] getCoordinates() {
/* 18 */     return this.coordinates;
/*    */   }
/*    */   
/*    */   public void setCoordinates(double[][] coordinates) {
/* 22 */     this.coordinates = coordinates;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\MultiPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */