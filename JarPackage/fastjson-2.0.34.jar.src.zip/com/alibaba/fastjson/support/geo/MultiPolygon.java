/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "MultiPolygon", orders = {"type", "bbox", "coordinates"})
/*    */ public class MultiPolygon
/*    */   extends Geometry
/*    */ {
/*    */   private double[][][][] coordinates;
/*    */   
/*    */   public MultiPolygon() {
/* 14 */     super("MultiPolygon");
/*    */   }
/*    */   
/*    */   public double[][][][] getCoordinates() {
/* 18 */     return this.coordinates;
/*    */   }
/*    */   
/*    */   public void setCoordinates(double[][][][] coordinates) {
/* 22 */     this.coordinates = coordinates;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\MultiPolygon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */