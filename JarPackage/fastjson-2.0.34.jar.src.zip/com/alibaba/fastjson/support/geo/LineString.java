/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "LineString", orders = {"type", "bbox", "coordinates"})
/*    */ public class LineString
/*    */   extends Geometry
/*    */ {
/*    */   private double[][] coordinates;
/*    */   
/*    */   public LineString() {
/* 14 */     super("LineString");
/*    */   }
/*    */   
/*    */   public double[][] getCoordinates() {
/* 18 */     return this.coordinates;
/*    */   }
/*    */   
/*    */   public void setCoordinates(double[][] coordinates) {
/* 22 */     this.coordinates = coordinates;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\LineString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */