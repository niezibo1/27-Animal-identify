/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "Polygon", orders = {"type", "bbox", "coordinates"})
/*    */ public class Polygon
/*    */   extends Geometry
/*    */ {
/*    */   private double[][][] coordinates;
/*    */   
/*    */   public Polygon() {
/* 14 */     super("Polygon");
/*    */   }
/*    */   
/*    */   public double[][][] getCoordinates() {
/* 18 */     return this.coordinates;
/*    */   }
/*    */   
/*    */   public void setCoordinates(double[][][] coordinates) {
/* 22 */     this.coordinates = coordinates;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\Polygon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */