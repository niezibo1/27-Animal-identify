/*    */ package com.alibaba.fastjson.support.geo;
/*    */ 
/*    */ import com.alibaba.fastjson.annotation.JSONType;
/*    */ 
/*    */ 
/*    */ 
/*    */ @JSONType(typeName = "MultiLineString", orders = {"type", "bbox", "coordinates"})
/*    */ public class MultiLineString
/*    */   extends Geometry
/*    */ {
/*    */   private double[][][] coordinates;
/*    */   
/*    */   public MultiLineString() {
/* 14 */     super("MultiLineString");
/*    */   }
/*    */   
/*    */   public double[][][] getCoordinates() {
/* 18 */     return this.coordinates;
/*    */   }
/*    */   
/*    */   public void setCoordinates(double[][][] coordinates) {
/* 22 */     this.coordinates = coordinates;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\support\geo\MultiLineString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */