/*    */ package com.alibaba.fastjson;
/*    */ 
/*    */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class JSONWriter
/*    */ {
/*    */   private final Writer out;
/*    */   final com.alibaba.fastjson2.JSONWriter raw;
/*    */   
/*    */   public JSONWriter(Writer out) {
/* 13 */     this.out = out;
/* 14 */     this.raw = com.alibaba.fastjson2.JSONWriter.ofUTF8();
/*    */   }
/*    */   
/*    */   public void config(SerializerFeature feature, boolean state) {
/* 18 */     com.alibaba.fastjson2.JSONWriter.Context ctx = this.raw.getContext();
/* 19 */     switch (feature) {
/*    */       case UseISO8601DateFormat:
/* 21 */         if (state) {
/* 22 */           ctx.setDateFormat("iso8601");
/*    */         }
/*    */         break;
/*    */       case WriteMapNullValue:
/* 26 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.WriteNulls, state);
/*    */         break;
/*    */       case WriteNullListAsEmpty:
/* 29 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.WriteNullListAsEmpty, state);
/*    */         break;
/*    */       case WriteNullStringAsEmpty:
/* 32 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.WriteNullStringAsEmpty, state);
/*    */         break;
/*    */       case WriteNullNumberAsZero:
/* 35 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.WriteNullNumberAsZero, state);
/*    */         break;
/*    */       case WriteNullBooleanAsFalse:
/* 38 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.WriteNullBooleanAsFalse, state);
/*    */         break;
/*    */       case BrowserCompatible:
/* 41 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.BrowserCompatible, state);
/*    */         break;
/*    */       case WriteClassName:
/* 44 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.WriteClassName, state);
/*    */         break;
/*    */       case WriteNonStringValueAsString:
/* 47 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.WriteNonStringValueAsString, state);
/*    */         break;
/*    */       case WriteEnumUsingToString:
/* 50 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.WriteEnumUsingToString, state);
/*    */         break;
/*    */       case NotWriteRootClassName:
/* 53 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.NotWriteRootClassName, state);
/*    */         break;
/*    */       case IgnoreErrorGetter:
/* 56 */         ctx.config(com.alibaba.fastjson2.JSONWriter.Feature.IgnoreErrorGetter, state);
/*    */         break;
/*    */       case WriteDateUseDateFormat:
/* 59 */         if (state) {
/* 60 */           ctx.setDateFormat(JSON.DEFFAULT_DATE_FORMAT);
/*    */         }
/*    */         break;
/*    */       case BeanToArray:
/* 64 */         if (state) {
/* 65 */           ctx.config(new com.alibaba.fastjson2.JSONWriter.Feature[] { com.alibaba.fastjson2.JSONWriter.Feature.BeanToArray });
/*    */         }
/*    */         break;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeObject(Object object) {
/* 74 */     this.raw.writeAny(object);
/*    */   }
/*    */   
/*    */   public void flush() throws IOException {
/* 78 */     this.raw.flushTo(this.out);
/* 79 */     this.out.flush();
/*    */   }
/*    */   
/*    */   public void close() {
/* 83 */     this.raw.close();
/*    */     try {
/* 85 */       this.out.close();
/* 86 */     } catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSONWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */