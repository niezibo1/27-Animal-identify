package com.alibaba.fastjson.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.CONSTRUCTOR, ElementType.METHOD})
public @interface JSONCreator {
  String[] parameterNames() default {};
}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\annotation\JSONCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */