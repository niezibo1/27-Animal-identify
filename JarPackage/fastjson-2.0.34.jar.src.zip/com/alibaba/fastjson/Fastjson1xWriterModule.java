/*    */ package com.alibaba.fastjson;
/*    */ 
/*    */ import com.alibaba.fastjson2.JSONWriter;
/*    */ import com.alibaba.fastjson2.modules.ObjectWriterModule;
/*    */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*    */ import com.alibaba.fastjson2.writer.ObjectWriterProvider;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class Fastjson1xWriterModule
/*    */   implements ObjectWriterModule
/*    */ {
/*    */   final ObjectWriterProvider provider;
/*    */   
/*    */   public Fastjson1xWriterModule(ObjectWriterProvider provider) {
/* 15 */     this.provider = provider;
/*    */   }
/*    */ 
/*    */   
/*    */   public ObjectWriter getObjectWriter(Type objectType, Class<?> objectClass) {
/* 20 */     if (objectClass != null && JSONAware.class
/* 21 */       .isAssignableFrom(objectClass) && JSONArray.class != objectClass && JSONObject.class != objectClass)
/*    */     {
/*    */ 
/*    */       
/* 25 */       return JSONAwareWriter.INSTANCE;
/*    */     }
/*    */     
/* 28 */     return null;
/*    */   }
/*    */   
/*    */   static class JSONAwareWriter
/*    */     implements ObjectWriter {
/* 33 */     static final JSONAwareWriter INSTANCE = new JSONAwareWriter();
/*    */ 
/*    */     
/*    */     public void write(JSONWriter jsonWriter, Object object, Object fieldName, Type fieldType, long features) {
/* 37 */       if (object == null) {
/* 38 */         jsonWriter.writeNull();
/*    */         
/*    */         return;
/*    */       } 
/* 42 */       JSONAware jsonAware = (JSONAware)object;
/* 43 */       String str = jsonAware.toJSONString();
/* 44 */       jsonWriter.writeRaw(str);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\Fastjson1xWriterModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */