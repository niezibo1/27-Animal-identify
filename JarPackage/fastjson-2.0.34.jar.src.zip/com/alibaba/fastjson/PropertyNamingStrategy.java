/*     */ package com.alibaba.fastjson;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PropertyNamingStrategy
/*     */ {
/*   8 */   CamelCase,
/*     */ 
/*     */ 
/*     */   
/*  12 */   CamelCase1x,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  19 */   PascalCase,
/*  20 */   SnakeCase,
/*  21 */   UpperCase,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  29 */   UpperCamelCaseWithSpaces,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   UpperCamelCaseWithUnderScores,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   UpperCamelCaseWithDashes,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   UpperCamelCaseWithDots,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   KebabCase,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   UpperCaseWithUnderScores,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   LowerCaseWithUnderScores,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   LowerCaseWithDashes,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   LowerCaseWithDots,
/* 106 */   NoChange,
/* 107 */   NeverUseThisValueExceptDefaultValue; public String translate(String propertyName) { StringBuilder buf;
/*     */     char ch;
/*     */     int i;
/* 110 */     switch (this) {
/*     */       case SnakeCase:
/* 112 */         buf = new StringBuilder();
/* 113 */         for (i = 0; i < propertyName.length(); i++) {
/* 114 */           char c = propertyName.charAt(i);
/* 115 */           if (c >= 'A' && c <= 'Z') {
/* 116 */             char ch_ucase = (char)(c + 32);
/* 117 */             if (i > 0) {
/* 118 */               buf.append('_');
/*     */             }
/* 120 */             buf.append(ch_ucase);
/*     */           } else {
/* 122 */             buf.append(c);
/*     */           } 
/*     */         } 
/* 125 */         return buf.toString();
/*     */       
/*     */       case KebabCase:
/* 128 */         buf = new StringBuilder();
/* 129 */         for (i = 0; i < propertyName.length(); i++) {
/* 130 */           char c = propertyName.charAt(i);
/* 131 */           if (c >= 'A' && c <= 'Z') {
/* 132 */             char ch_ucase = (char)(c + 32);
/* 133 */             if (i > 0) {
/* 134 */               buf.append('-');
/*     */             }
/* 136 */             buf.append(ch_ucase);
/*     */           } else {
/* 138 */             buf.append(c);
/*     */           } 
/*     */         } 
/* 141 */         return buf.toString();
/*     */       
/*     */       case PascalCase:
/* 144 */         ch = propertyName.charAt(0);
/* 145 */         if (ch >= 'a' && ch <= 'z') {
/* 146 */           char[] chars = propertyName.toCharArray();
/* 147 */           chars[0] = (char)(chars[0] - 32);
/* 148 */           return new String(chars);
/*     */         } 
/*     */         
/* 151 */         return propertyName;
/*     */       
/*     */       case CamelCase:
/* 154 */         ch = propertyName.charAt(0);
/* 155 */         if (ch >= 'A' && ch <= 'Z') {
/* 156 */           char[] chars = propertyName.toCharArray();
/* 157 */           chars[0] = (char)(chars[0] + 32);
/* 158 */           return new String(chars);
/*     */         } 
/*     */         
/* 161 */         return propertyName;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 166 */     return propertyName; }
/*     */ 
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\PropertyNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */