/*     */ package com.alibaba.fastjson;
/*     */ import com.alibaba.fastjson.parser.ParserConfig;
/*     */ import com.alibaba.fastjson.util.TypeUtils;
/*     */ import com.alibaba.fastjson2.JSON;
/*     */ import com.alibaba.fastjson2.JSONException;
/*     */ import com.alibaba.fastjson2.JSONFactory;
/*     */ import com.alibaba.fastjson2.JSONReader;
/*     */ import com.alibaba.fastjson2.reader.ObjectReader;
/*     */ import com.alibaba.fastjson2.reader.ObjectReaderProvider;
/*     */ import com.alibaba.fastjson2.util.TypeUtils;
/*     */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*     */ import com.alibaba.fastjson2.writer.ObjectWriterAdapter;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ public class JSONArray extends JSON implements List<Object>, Serializable, Cloneable {
/*  28 */   private List list = (List)new com.alibaba.fastjson2.JSONArray();
/*     */   
/*     */   static ObjectReader<JSONArray> arrayReader;
/*     */   
/*     */   static ObjectReader<JSONObject> objectReader;
/*     */   protected transient Object relatedArray;
/*     */   protected transient Type componentType;
/*     */   
/*     */   public JSONArray(List list) {
/*  37 */     this.list = list;
/*     */   }
/*     */   
/*     */   public JSONArray(int initialCapacity) {
/*  41 */     this.list = new ArrayList(initialCapacity);
/*     */   }
/*     */   
/*     */   public Byte getByte(int index) {
/*  45 */     Object value = get(index);
/*     */     
/*  47 */     if (value == null) {
/*  48 */       return null;
/*     */     }
/*     */     
/*  51 */     if (value instanceof Number) {
/*  52 */       return Byte.valueOf(((Number)value).byteValue());
/*     */     }
/*     */     
/*  55 */     if (value instanceof String) {
/*  56 */       String str = (String)value;
/*     */       
/*  58 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  59 */         return null;
/*     */       }
/*     */       
/*  62 */       return Byte.valueOf(Byte.parseByte(str));
/*     */     } 
/*     */     
/*  65 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Byte");
/*     */   }
/*     */   
/*     */   public Short getShort(int index) {
/*  69 */     Object value = get(index);
/*     */     
/*  71 */     if (value == null) {
/*  72 */       return null;
/*     */     }
/*     */     
/*  75 */     if (value instanceof Short) {
/*  76 */       return (Short)value;
/*     */     }
/*     */     
/*  79 */     if (value instanceof Number) {
/*  80 */       return Short.valueOf(((Number)value).shortValue());
/*     */     }
/*     */     
/*  83 */     if (value instanceof String) {
/*  84 */       String str = (String)value;
/*     */       
/*  86 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/*  87 */         return null;
/*     */       }
/*     */       
/*  90 */       return Short.valueOf(Short.parseShort(str));
/*     */     } 
/*     */     
/*  93 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Short");
/*     */   }
/*     */   
/*     */   public Float getFloat(int index) {
/*  97 */     Object value = get(index);
/*     */     
/*  99 */     if (value == null) {
/* 100 */       return null;
/*     */     }
/*     */     
/* 103 */     if (value instanceof Float) {
/* 104 */       return (Float)value;
/*     */     }
/*     */     
/* 107 */     if (value instanceof Number) {
/* 108 */       return Float.valueOf(((Number)value).floatValue());
/*     */     }
/*     */     
/* 111 */     if (value instanceof String) {
/* 112 */       String str = (String)value;
/*     */       
/* 114 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 115 */         return null;
/*     */       }
/*     */       
/* 118 */       return Float.valueOf(Float.parseFloat(str));
/*     */     } 
/*     */     
/* 121 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Float");
/*     */   }
/*     */   
/*     */   public Double getDouble(int index) {
/* 125 */     Object value = get(index);
/*     */     
/* 127 */     if (value == null) {
/* 128 */       return null;
/*     */     }
/*     */     
/* 131 */     if (value instanceof Double) {
/* 132 */       return (Double)value;
/*     */     }
/*     */     
/* 135 */     if (value instanceof Number) {
/* 136 */       return Double.valueOf(((Number)value).doubleValue());
/*     */     }
/*     */     
/* 139 */     if (value instanceof String) {
/* 140 */       String str = (String)value;
/*     */       
/* 142 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 143 */         return null;
/*     */       }
/*     */       
/* 146 */       return Double.valueOf(Double.parseDouble(str));
/*     */     } 
/*     */     
/* 149 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Double");
/*     */   }
/*     */   
/*     */   public int getIntValue(int index) {
/* 153 */     Object value = get(index);
/*     */     
/* 155 */     if (value == null) {
/* 156 */       return 0;
/*     */     }
/*     */     
/* 159 */     if (value instanceof Number) {
/* 160 */       return ((Number)value).intValue();
/*     */     }
/*     */     
/* 163 */     if (value instanceof String) {
/* 164 */       String str = (String)value;
/*     */       
/* 166 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 167 */         return 0;
/*     */       }
/*     */       
/* 170 */       return Integer.parseInt(str);
/*     */     } 
/*     */     
/* 173 */     throw new JSONException("Can not cast '" + value.getClass() + "' to int value");
/*     */   }
/*     */   
/*     */   public BigDecimal getBigDecimal(int index) {
/* 177 */     Object value = get(index);
/*     */     
/* 179 */     if (value == null) {
/* 180 */       return null;
/*     */     }
/*     */     
/* 183 */     if (value instanceof Number) {
/* 184 */       if (value instanceof BigDecimal) {
/* 185 */         return (BigDecimal)value;
/*     */       }
/*     */       
/* 188 */       if (value instanceof BigInteger) {
/* 189 */         return new BigDecimal((BigInteger)value);
/*     */       }
/*     */       
/* 192 */       if (value instanceof Float) {
/* 193 */         float floatValue = ((Float)value).floatValue();
/* 194 */         return TypeUtils.toBigDecimal(floatValue);
/*     */       } 
/*     */       
/* 197 */       if (value instanceof Double) {
/* 198 */         double doubleValue = ((Double)value).doubleValue();
/* 199 */         return TypeUtils.toBigDecimal(doubleValue);
/*     */       } 
/*     */       
/* 202 */       long longValue = ((Number)value).longValue();
/* 203 */       return BigDecimal.valueOf(longValue);
/*     */     } 
/*     */     
/* 206 */     if (value instanceof String) {
/* 207 */       String str = (String)value;
/* 208 */       return TypeUtils.toBigDecimal(str);
/*     */     } 
/*     */     
/* 211 */     throw new JSONException("Can not cast '" + value.getClass() + "' to BigDecimal");
/*     */   }
/*     */   
/*     */   public long getLongValue(int index) {
/* 215 */     Object value = get(index);
/*     */     
/* 217 */     if (value == null) {
/* 218 */       return 0L;
/*     */     }
/*     */     
/* 221 */     if (value instanceof Number) {
/* 222 */       return ((Number)value).longValue();
/*     */     }
/*     */     
/* 225 */     if (value instanceof String) {
/* 226 */       String str = (String)value;
/*     */       
/* 228 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 229 */         return 0L;
/*     */       }
/*     */       
/* 232 */       return Long.parseLong(str);
/*     */     } 
/*     */     
/* 235 */     throw new JSONException("Can not cast '" + value.getClass() + "' to long value");
/*     */   }
/*     */   
/*     */   public Integer getInteger(int index) {
/* 239 */     Object value = get(index);
/* 240 */     if (value == null) {
/* 241 */       return null;
/*     */     }
/*     */     
/* 244 */     if (value instanceof Integer) {
/* 245 */       return (Integer)value;
/*     */     }
/*     */     
/* 248 */     if (value instanceof Number) {
/* 249 */       return Integer.valueOf(((Number)value).intValue());
/*     */     }
/*     */     
/* 252 */     if (value instanceof String) {
/* 253 */       String str = (String)value;
/*     */       
/* 255 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 256 */         return null;
/*     */       }
/*     */       
/* 259 */       return Integer.valueOf(Integer.parseInt(str));
/*     */     } 
/*     */     
/* 262 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Integer");
/*     */   }
/*     */   
/*     */   public Long getLong(int index) {
/* 266 */     Object value = this.list.get(index);
/* 267 */     if (value == null) {
/* 268 */       return null;
/*     */     }
/*     */     
/* 271 */     if (value instanceof Long) {
/* 272 */       return (Long)value;
/*     */     }
/*     */     
/* 275 */     if (value instanceof Number) {
/* 276 */       return Long.valueOf(((Number)value).longValue());
/*     */     }
/*     */     
/* 279 */     if (value instanceof String) {
/* 280 */       String str = (String)value;
/*     */       
/* 282 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 283 */         return null;
/*     */       }
/*     */       
/* 286 */       return Long.valueOf(Long.parseLong(str));
/*     */     } 
/*     */     
/* 289 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Long");
/*     */   }
/*     */   
/*     */   public boolean getBooleanValue(int index) {
/* 293 */     Object value = get(index);
/*     */     
/* 295 */     if (value == null) {
/* 296 */       return false;
/*     */     }
/*     */     
/* 299 */     if (value instanceof Boolean) {
/* 300 */       return ((Boolean)value).booleanValue();
/*     */     }
/*     */     
/* 303 */     if (value instanceof Number) {
/* 304 */       return (((Number)value).intValue() == 1);
/*     */     }
/*     */     
/* 307 */     if (value instanceof String) {
/* 308 */       String str = (String)value;
/* 309 */       return ("true".equalsIgnoreCase(str) || "1".equals(str));
/*     */     } 
/*     */     
/* 312 */     throw new JSONException("Can not cast '" + value.getClass() + "' to boolean value");
/*     */   }
/*     */   
/*     */   public Boolean getBoolean(int index) {
/* 316 */     Object value = get(index);
/*     */     
/* 318 */     if (value == null) {
/* 319 */       return null;
/*     */     }
/*     */     
/* 322 */     if (value instanceof Boolean) {
/* 323 */       return (Boolean)value;
/*     */     }
/*     */     
/* 326 */     if (value instanceof Number) {
/* 327 */       return Boolean.valueOf((((Number)value).intValue() == 1));
/*     */     }
/*     */     
/* 330 */     if (value instanceof String) {
/* 331 */       String str = (String)value;
/*     */       
/* 333 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 334 */         return null;
/*     */       }
/*     */       
/* 337 */       return Boolean.valueOf(("true".equalsIgnoreCase(str) || "1".equals(str)));
/*     */     } 
/*     */     
/* 340 */     throw new JSONException("Can not cast '" + value.getClass() + "' to Boolean");
/*     */   }
/*     */   
/*     */   public JSONObject getJSONObject(int index) {
/* 344 */     Object value = get(index);
/*     */     
/* 346 */     if (value instanceof JSONObject) {
/* 347 */       return (JSONObject)value;
/*     */     }
/*     */     
/* 350 */     if (value instanceof String) {
/* 351 */       String str = (String)value;
/*     */       
/* 353 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 354 */         return null;
/*     */       }
/*     */       
/* 357 */       JSONReader reader = JSONReader.of(str);
/* 358 */       if (objectReader == null) {
/* 359 */         objectReader = reader.getObjectReader(JSONObject.class);
/*     */       }
/* 361 */       return (JSONObject)objectReader.readObject(reader, null, null, 0L);
/*     */     } 
/*     */     
/* 364 */     if (value instanceof Map) {
/* 365 */       return new JSONObject((Map<String, Object>)value);
/*     */     }
/*     */     
/* 368 */     if (value == null) {
/* 369 */       return null;
/*     */     }
/*     */     
/* 372 */     Class<?> valueClass = value.getClass();
/* 373 */     ObjectWriter objectWriter = JSONFactory.getDefaultObjectWriterProvider().getObjectWriter(valueClass);
/* 374 */     if (objectWriter instanceof ObjectWriterAdapter) {
/* 375 */       ObjectWriterAdapter writerAdapter = (ObjectWriterAdapter)objectWriter;
/* 376 */       return new JSONObject((Map<String, Object>)writerAdapter
/* 377 */           .toJSONObject(value));
/*     */     } 
/*     */ 
/*     */     
/* 381 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 386 */     return this.list.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 391 */     return this.list.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 396 */     return this.list.contains(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator iterator() {
/* 401 */     return this.list.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 406 */     return this.list.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray(Object[] a) {
/* 411 */     return this.list.toArray(a);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(Object item) {
/* 416 */     return this.list.add(item);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 421 */     return this.list.remove(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection c) {
/* 426 */     return this.list.addAll(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int index, Collection c) {
/* 431 */     return this.list.addAll(index, c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 436 */     this.list.clear();
/*     */   }
/*     */   
/*     */   public JSONArray fluentClear() {
/* 440 */     this.list.clear();
/* 441 */     return this;
/*     */   }
/*     */   
/*     */   public JSONArray fluentRemove(int index) {
/* 445 */     this.list.remove(index);
/* 446 */     return this;
/*     */   }
/*     */   
/*     */   public JSONArray fluentRemove(Object o) {
/* 450 */     this.list.remove(o);
/* 451 */     return this;
/*     */   }
/*     */   
/*     */   public JSONArray fluentSet(int index, Object element) {
/* 455 */     set(index, element);
/* 456 */     return this;
/*     */   }
/*     */   
/*     */   public JSONArray fluentRemoveAll(Collection<?> c) {
/* 460 */     this.list.removeAll(c);
/* 461 */     return this;
/*     */   }
/*     */   
/*     */   public JSONArray fluentAddAll(Collection<?> c) {
/* 465 */     this.list.addAll(c);
/* 466 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getShortValue(int index) {
/* 479 */     Object value = this.list.get(index);
/*     */     
/* 481 */     if (value == null) {
/* 482 */       return 0;
/*     */     }
/*     */     
/* 485 */     if (value instanceof Number) {
/* 486 */       return ((Number)value).shortValue();
/*     */     }
/*     */     
/* 489 */     if (value instanceof String) {
/* 490 */       String str = (String)value;
/*     */       
/* 492 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 493 */         return 0;
/*     */       }
/*     */       
/* 496 */       return Short.parseShort(str);
/*     */     } 
/*     */     
/* 499 */     throw new JSONException("Can not cast '" + value.getClass() + "' to short value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloatValue(int index) {
/* 512 */     Object value = this.list.get(index);
/*     */     
/* 514 */     if (value == null) {
/* 515 */       return 0.0F;
/*     */     }
/*     */     
/* 518 */     if (value instanceof Number) {
/* 519 */       return ((Number)value).floatValue();
/*     */     }
/*     */     
/* 522 */     if (value instanceof String) {
/* 523 */       String str = (String)value;
/*     */       
/* 525 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 526 */         return 0.0F;
/*     */       }
/*     */       
/* 529 */       return Float.parseFloat(str);
/*     */     } 
/*     */     
/* 532 */     throw new JSONException("Can not cast '" + value.getClass() + "' to float value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDoubleValue(int index) {
/* 545 */     Object value = this.list.get(index);
/*     */     
/* 547 */     if (value == null) {
/* 548 */       return 0.0D;
/*     */     }
/*     */     
/* 551 */     if (value instanceof Number) {
/* 552 */       return ((Number)value).doubleValue();
/*     */     }
/*     */     
/* 555 */     if (value instanceof String) {
/* 556 */       String str = (String)value;
/*     */       
/* 558 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 559 */         return 0.0D;
/*     */       }
/*     */       
/* 562 */       return Double.parseDouble(str);
/*     */     } 
/*     */     
/* 565 */     throw new JSONException("Can not cast '" + value.getClass() + "' to double value");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 570 */     return this.list.retainAll(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 575 */     return this.list.removeAll(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 580 */     return this.list.containsAll(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(int index) {
/* 585 */     return this.list.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByteValue(int index) {
/* 598 */     Object value = this.list.get(index);
/*     */     
/* 600 */     if (value == null) {
/* 601 */       return 0;
/*     */     }
/*     */     
/* 604 */     if (value instanceof Number) {
/* 605 */       return ((Number)value).byteValue();
/*     */     }
/*     */     
/* 608 */     if (value instanceof String) {
/* 609 */       String str = (String)value;
/*     */       
/* 611 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 612 */         return 0;
/*     */       }
/*     */       
/* 615 */       return Byte.parseByte(str);
/*     */     } 
/*     */     
/* 618 */     throw new JSONException("Can not cast '" + value.getClass() + "' to byte value");
/*     */   }
/*     */   
/*     */   public BigInteger getBigInteger(int index) {
/* 622 */     Object value = this.list.get(index);
/*     */     
/* 624 */     if (value == null) {
/* 625 */       return null;
/*     */     }
/*     */     
/* 628 */     if (value instanceof Number) {
/* 629 */       if (value instanceof BigInteger) {
/* 630 */         return (BigInteger)value;
/*     */       }
/*     */       
/* 633 */       if (value instanceof BigDecimal) {
/* 634 */         return ((BigDecimal)value).toBigInteger();
/*     */       }
/*     */       
/* 637 */       long longValue = ((Number)value).longValue();
/* 638 */       return BigInteger.valueOf(longValue);
/*     */     } 
/*     */     
/* 641 */     if (value instanceof String) {
/* 642 */       String str = (String)value;
/*     */       
/* 644 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 645 */         return null;
/*     */       }
/*     */       
/* 648 */       return new BigInteger(str);
/*     */     } 
/*     */     
/* 651 */     throw new JSONException("Can not cast '" + value.getClass() + "' to BigInteger");
/*     */   }
/*     */   
/*     */   public Date getSqlDate(int index) {
/* 655 */     Object object = get(index);
/* 656 */     return (Date)TypeUtils.cast(object, Date.class);
/*     */   }
/*     */   
/*     */   public Timestamp getTimestamp(int index) {
/* 660 */     Object object = get(index);
/* 661 */     return (Timestamp)TypeUtils.cast(object, Timestamp.class);
/*     */   }
/*     */   
/*     */   public Date getDate(int index) {
/* 665 */     Object value = get(index);
/*     */     
/* 667 */     if (value == null) {
/* 668 */       return null;
/*     */     }
/*     */     
/* 671 */     if (value instanceof Date) {
/* 672 */       return (Date)value;
/*     */     }
/*     */     
/* 675 */     if (value instanceof Number) {
/* 676 */       long millis = ((Number)value).longValue();
/* 677 */       if (millis == 0L) {
/* 678 */         return null;
/*     */       }
/* 680 */       return new Date(millis);
/*     */     } 
/*     */     
/* 683 */     return TypeUtils.toDate(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object set(int index, Object element) {
/* 688 */     if (index == -1) {
/* 689 */       this.list.add(element);
/* 690 */       return null;
/*     */     } 
/*     */     
/* 693 */     if (this.list.size() <= index) {
/* 694 */       for (int i = this.list.size(); i < index; i++) {
/* 695 */         this.list.add(null);
/*     */       }
/* 697 */       this.list.add(element);
/* 698 */       return null;
/*     */     } 
/*     */     
/* 701 */     return this.list.set(index, element);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int index, Object element) {
/* 706 */     this.list.add(index, element);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(int index) {
/* 711 */     return this.list.remove(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object o) {
/* 716 */     return this.list.indexOf(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 721 */     return this.list.lastIndexOf(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator listIterator() {
/* 726 */     return this.list.listIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator listIterator(int index) {
/* 731 */     return this.list.listIterator(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public List subList(int fromIndex, int toIndex) {
/* 736 */     return this.list.subList(fromIndex, toIndex);
/*     */   }
/*     */   
/*     */   public String getString(int index) {
/* 740 */     Object value = this.list.get(index);
/* 741 */     if (value == null) {
/* 742 */       return null;
/*     */     }
/*     */     
/* 745 */     if (value instanceof String) {
/* 746 */       return (String)value;
/*     */     }
/*     */     
/* 749 */     return JSON.toJSONString(value);
/*     */   }
/*     */   
/*     */   public JSONArray getJSONArray(int index) {
/* 753 */     Object value = get(index);
/*     */     
/* 755 */     if (value instanceof JSONArray) {
/* 756 */       return (JSONArray)value;
/*     */     }
/*     */     
/* 759 */     if (value instanceof String) {
/* 760 */       String str = (String)value;
/*     */       
/* 762 */       if (str.isEmpty() || "null".equalsIgnoreCase(str)) {
/* 763 */         return null;
/*     */       }
/*     */       
/* 766 */       JSONReader reader = JSONReader.of(str);
/* 767 */       if (arrayReader == null) {
/* 768 */         arrayReader = reader.getObjectReader(JSONArray.class);
/*     */       }
/* 770 */       return (JSONArray)arrayReader.readObject(reader, null, null, 0L);
/*     */     } 
/*     */     
/* 773 */     if (value instanceof List) {
/* 774 */       return new JSONArray((List)value);
/*     */     }
/*     */     
/* 777 */     return null;
/*     */   }
/*     */   
/*     */   public <T> T getObject(int index, Type type) {
/* 781 */     Object obj = this.list.get(index);
/* 782 */     if (type instanceof Class) {
/* 783 */       return (T)TypeUtils.cast(obj, (Class)type);
/*     */     }
/* 785 */     String json = JSON.toJSONString(obj);
/* 786 */     return JSON.parseObject(json, type, new com.alibaba.fastjson.parser.Feature[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getObject(int index, Class<T> clazz) {
/* 791 */     Object obj = this.list.get(index);
/* 792 */     if (obj == null) {
/* 793 */       return null;
/*     */     }
/*     */     
/* 796 */     if (clazz.isInstance(obj)) {
/* 797 */       return (T)obj;
/*     */     }
/*     */     
/* 800 */     ObjectReaderProvider provider = JSONFactory.getDefaultObjectReaderProvider();
/* 801 */     Function<Object, T> typeConvert = provider.getTypeConvert(obj.getClass(), clazz);
/* 802 */     if (typeConvert != null) {
/* 803 */       return typeConvert.apply(obj);
/*     */     }
/*     */     
/* 806 */     String json = JSON.toJSONString(obj);
/* 807 */     ObjectReader objectReader = provider.getObjectReader(clazz);
/* 808 */     JSONReader jsonReader = JSONReader.of(json);
/*     */     
/* 810 */     String defaultDateFormat = JSON.DEFFAULT_DATE_FORMAT;
/* 811 */     if (!"yyyy-MM-dd HH:mm:ss".equals(defaultDateFormat)) {
/* 812 */       jsonReader
/* 813 */         .getContext()
/* 814 */         .setDateFormat(defaultDateFormat);
/*     */     }
/*     */     
/* 817 */     return (T)objectReader.readObject(jsonReader, null, null, 0L);
/*     */   }
/*     */   
/*     */   public <T> List<T> toJavaList(Class<T> clazz) {
/* 821 */     List<T> list = new ArrayList<>(size());
/*     */     
/* 823 */     ObjectReaderProvider provider = JSONFactory.getDefaultObjectReaderProvider();
/* 824 */     ObjectReader objectReader = provider.getObjectReader(clazz);
/*     */     
/* 826 */     for (Object item : this) {
/*     */       T classItem;
/* 828 */       if (item instanceof Map) {
/* 829 */         classItem = (T)objectReader.createInstance((Map)item, 0L);
/*     */       } else {
/* 831 */         if (item == null || item.getClass() == clazz) {
/* 832 */           list.add((T)item);
/*     */           
/*     */           continue;
/*     */         } 
/* 836 */         Function typeConvert = provider.getTypeConvert(item.getClass(), clazz);
/* 837 */         if (typeConvert != null) {
/* 838 */           Object converted = typeConvert.apply(item);
/* 839 */           list.add((T)converted);
/*     */           
/*     */           continue;
/*     */         } 
/* 843 */         throw new JSONException((
/* 844 */             (item == null) ? "null" : item.getClass()) + " cannot be converted to " + clazz);
/*     */       } 
/*     */       
/* 847 */       list.add(classItem);
/*     */     } 
/*     */     
/* 850 */     return list;
/*     */   }
/*     */   
/*     */   public JSONArray fluentAdd(Object e) {
/* 854 */     this.list.add(e);
/* 855 */     return this;
/*     */   }
/*     */   
/*     */   public <T> T toJavaObject(Class<T> clazz) {
/* 859 */     ObjectReaderProvider provider = JSONFactory.getDefaultObjectReaderProvider();
/* 860 */     ObjectReader<T> objectReader = provider.getObjectReader(clazz);
/* 861 */     return (T)objectReader.createInstance(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 866 */     return toJSONString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public JSONArray clone() {
/* 871 */     return new JSONArray(new ArrayList(this.list));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 876 */     return this.list.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 881 */     if (this == obj) {
/* 882 */       return true;
/*     */     }
/*     */     
/* 885 */     if (obj instanceof JSONArray) {
/* 886 */       return this.list.equals(((JSONArray)obj).list);
/*     */     }
/*     */     
/* 889 */     return this.list.equals(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T toJavaObject(Type type) {
/* 894 */     return (T)TypeUtils.cast(this, type, ParserConfig.getGlobalInstance());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Type getComponentType() {
/* 899 */     return this.componentType;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setComponentType(Type componentType) {
/* 904 */     this.componentType = componentType;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Object getRelatedArray() {
/* 909 */     return this.relatedArray;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setRelatedArray(Object relatedArray) {
/* 914 */     this.relatedArray = relatedArray;
/*     */   }
/*     */   
/*     */   public JSONArray() {}
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSONArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */