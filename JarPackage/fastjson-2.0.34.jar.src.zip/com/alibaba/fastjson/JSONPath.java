/*    */ package com.alibaba.fastjson;
/*    */ 
/*    */ import com.alibaba.fastjson.parser.ParserConfig;
/*    */ import com.alibaba.fastjson.util.TypeUtils;
/*    */ import com.alibaba.fastjson2.JSONReader;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class JSONPath
/*    */ {
/*    */   private final com.alibaba.fastjson2.JSONPath path;
/*    */   
/*    */   private JSONPath(com.alibaba.fastjson2.JSONPath path) {
/* 14 */     this.path = path;
/*    */   }
/*    */   
/*    */   public static JSONPath compile(String path) {
/* 18 */     if (path == null) {
/* 19 */       throw new JSONException("jsonpath can not be null");
/*    */     }
/*    */     
/* 22 */     return new JSONPath(com.alibaba.fastjson2.JSONPath.of(path));
/*    */   }
/*    */   
/*    */   public Object eval(Object object) {
/* 26 */     return this.path.eval(object);
/*    */   }
/*    */   
/*    */   public boolean set(Object object, Object value) {
/* 30 */     this.path.set(object, value);
/* 31 */     return true;
/*    */   }
/*    */   
/*    */   public String getPath() {
/* 35 */     return this.path.toString();
/*    */   }
/*    */   
/*    */   public static <T> T read(String json, String path, Type clazz, ParserConfig parserConfig) {
/* 39 */     com.alibaba.fastjson2.JSONPath jsonPath = com.alibaba.fastjson2.JSONPath.of(path);
/* 40 */     Object r = jsonPath.extract(JSONReader.of(json));
/* 41 */     return (T)TypeUtils.cast(r, clazz, parserConfig);
/*    */   }
/*    */   
/*    */   public static <T> T read(String json, String path, Type clazz) {
/* 45 */     com.alibaba.fastjson2.JSONPath jsonPath = com.alibaba.fastjson2.JSONPath.of(path);
/* 46 */     Object r = jsonPath.extract(JSONReader.of(json));
/* 47 */     return (T)TypeUtils.cast(r, clazz, ParserConfig.global);
/*    */   }
/*    */   
/*    */   public static Object eval(Object rootObject, String path) {
/* 51 */     com.alibaba.fastjson2.JSONPath jsonPath = com.alibaba.fastjson2.JSONPath.of(path);
/* 52 */     return jsonPath.eval(rootObject);
/*    */   }
/*    */   
/*    */   public static boolean set(Object rootObject, String path, Object value) {
/* 56 */     com.alibaba.fastjson2.JSONPath jsonPath = com.alibaba.fastjson2.JSONPath.of(path);
/* 57 */     jsonPath.set(rootObject, value);
/* 58 */     return true;
/*    */   }
/*    */   
/*    */   public static Map<String, Object> paths(Object javaObject) {
/* 62 */     return com.alibaba.fastjson2.JSONPath.paths(javaObject);
/*    */   }
/*    */   
/*    */   public static void arrayAdd(Object rootObject, String path, Object... values) {
/* 66 */     com.alibaba.fastjson2.JSONPath jsonPath = com.alibaba.fastjson2.JSONPath.of(path);
/* 67 */     jsonPath.arrayAdd(rootObject, values);
/*    */   }
/*    */   
/*    */   public static Object extract(String json, String path) {
/* 71 */     com.alibaba.fastjson2.JSONPath jsonPath = com.alibaba.fastjson2.JSONPath.of(path);
/* 72 */     JSONReader jsonReader = JSONReader.of(json);
/* 73 */     return jsonPath.extract(jsonReader);
/*    */   }
/*    */   
/*    */   public static boolean remove(Object root, String path) {
/* 77 */     return 
/* 78 */       com.alibaba.fastjson2.JSONPath.of(path)
/* 79 */       .remove(root);
/*    */   }
/*    */   
/*    */   public static boolean contains(Object rootObject, String path) {
/* 83 */     com.alibaba.fastjson2.JSONPath jsonPath = com.alibaba.fastjson2.JSONPath.of(path);
/* 84 */     return jsonPath.contains(rootObject);
/*    */   }
/*    */   
/*    */   public static Object read(String json, String path) {
/* 88 */     return com.alibaba.fastjson2.JSONPath.extract(json, path);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSONPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */