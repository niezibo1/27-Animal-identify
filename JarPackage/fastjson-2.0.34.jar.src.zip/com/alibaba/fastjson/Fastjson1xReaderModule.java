/*    */ package com.alibaba.fastjson;
/*    */ 
/*    */ import com.alibaba.fastjson2.JSONReader;
/*    */ import com.alibaba.fastjson2.modules.ObjectReaderModule;
/*    */ import com.alibaba.fastjson2.reader.ObjectReader;
/*    */ import com.alibaba.fastjson2.reader.ObjectReaderProvider;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ 
/*    */ public class Fastjson1xReaderModule
/*    */   implements ObjectReaderModule
/*    */ {
/*    */   final ObjectReaderProvider provider;
/*    */   
/*    */   public Fastjson1xReaderModule(ObjectReaderProvider provider) {
/* 17 */     this.provider = provider;
/*    */   }
/*    */ 
/*    */   
/*    */   public ObjectReader getObjectReader(ObjectReaderProvider provider, Type type) {
/* 22 */     if (type == JSON.class) {
/* 23 */       return new JSONImpl();
/*    */     }
/* 25 */     return null;
/*    */   }
/*    */   
/*    */   static class JSONImpl
/*    */     implements ObjectReader
/*    */   {
/*    */     public Object readObject(JSONReader jsonReader, Type fieldType, Object fieldName, long features) {
/* 32 */       if (jsonReader.isObject()) {
/* 33 */         return jsonReader.read(JSONObject.class);
/*    */       }
/* 35 */       if (jsonReader.isArray()) {
/* 36 */         return jsonReader.read(JSONArray.class);
/*    */       }
/*    */       
/* 39 */       throw new JSONException("read json error");
/*    */     }
/*    */ 
/*    */     
/*    */     public Object createInstance(Collection collection) {
/* 44 */       return Collections.emptyList();
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\Fastjson1xReaderModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */