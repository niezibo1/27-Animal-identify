/*    */ package com.alibaba.fastjson;
/*    */ 
/*    */ import com.alibaba.fastjson2.JSONPObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class JSONPObject extends JSONPObject {
/*  8 */   private final List<Object> parameters = new ArrayList();
/*    */ 
/*    */   
/*    */   public JSONPObject() {}
/*    */   
/*    */   public JSONPObject(String function) {
/* 14 */     super(function);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\JSONPObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */