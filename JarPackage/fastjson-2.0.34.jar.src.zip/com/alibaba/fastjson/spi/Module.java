package com.alibaba.fastjson.spi;

import com.alibaba.fastjson.parser.ParserConfig;
import com.alibaba.fastjson.parser.deserializer.ObjectDeserializer;
import com.alibaba.fastjson.serializer.ObjectSerializer;
import com.alibaba.fastjson.serializer.SerializeConfig;

public interface Module {
  ObjectDeserializer createDeserializer(ParserConfig paramParserConfig, Class paramClass);
  
  ObjectSerializer createSerializer(SerializeConfig paramSerializeConfig, Class paramClass);
}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\spi\Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */