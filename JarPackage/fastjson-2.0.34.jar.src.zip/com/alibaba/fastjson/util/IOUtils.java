/*     */ package com.alibaba.fastjson.util;
/*     */ 
/*     */ import com.alibaba.fastjson.JSONException;
/*     */ import java.io.Closeable;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.CharacterCodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CoderResult;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOUtils
/*     */ {
/*  30 */   public static final Charset UTF8 = StandardCharsets.UTF_8;
/*  31 */   public static final char[] DIGITS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*  32 */   public static final boolean[] firstIdentifierFlags = new boolean[256];
/*  33 */   public static final boolean[] identifierFlags = new boolean[256];
/*  34 */   public static final byte[] specicalFlags_doubleQuotes = new byte[161];
/*  35 */   public static final byte[] specicalFlags_singleQuotes = new byte[161];
/*  36 */   public static final boolean[] specicalFlags_doubleQuotesFlags = new boolean[161];
/*  37 */   public static final boolean[] specicalFlags_singleQuotesFlags = new boolean[161];
/*  38 */   public static final char[] replaceChars = new char[93];
/*  39 */   public static final char[] CA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
/*  40 */   static final int[] IA = new int[256];
/*     */   
/*     */   static {
/*  43 */     Arrays.fill(IA, -1);
/*  44 */     for (int j = 0, iS = CA.length; j < iS; j++) {
/*  45 */       IA[CA[j]] = j;
/*     */     }
/*  47 */     IA[61] = 0;
/*     */     char c;
/*  49 */     for (c = Character.MIN_VALUE; c < firstIdentifierFlags.length; c = (char)(c + 1)) {
/*  50 */       if (c >= 'A' && c <= 'Z') {
/*  51 */         firstIdentifierFlags[c] = true;
/*  52 */       } else if (c >= 'a' && c <= 'z') {
/*  53 */         firstIdentifierFlags[c] = true;
/*  54 */       } else if (c == '_' || c == '$') {
/*  55 */         firstIdentifierFlags[c] = true;
/*     */       } 
/*     */     } 
/*     */     
/*  59 */     for (c = Character.MIN_VALUE; c < identifierFlags.length; c = (char)(c + 1)) {
/*  60 */       if (c >= 'A' && c <= 'Z') {
/*  61 */         identifierFlags[c] = true;
/*  62 */       } else if (c >= 'a' && c <= 'z') {
/*  63 */         identifierFlags[c] = true;
/*  64 */       } else if (c == '_') {
/*  65 */         identifierFlags[c] = true;
/*  66 */       } else if (c >= '0' && c <= '9') {
/*  67 */         identifierFlags[c] = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  73 */     specicalFlags_doubleQuotes[0] = 4;
/*  74 */     specicalFlags_doubleQuotes[1] = 4;
/*  75 */     specicalFlags_doubleQuotes[2] = 4;
/*  76 */     specicalFlags_doubleQuotes[3] = 4;
/*  77 */     specicalFlags_doubleQuotes[4] = 4;
/*  78 */     specicalFlags_doubleQuotes[5] = 4;
/*  79 */     specicalFlags_doubleQuotes[6] = 4;
/*  80 */     specicalFlags_doubleQuotes[7] = 4;
/*  81 */     specicalFlags_doubleQuotes[8] = 1;
/*  82 */     specicalFlags_doubleQuotes[9] = 1;
/*  83 */     specicalFlags_doubleQuotes[10] = 1;
/*  84 */     specicalFlags_doubleQuotes[11] = 4;
/*  85 */     specicalFlags_doubleQuotes[12] = 1;
/*  86 */     specicalFlags_doubleQuotes[13] = 1;
/*  87 */     specicalFlags_doubleQuotes[34] = 1;
/*  88 */     specicalFlags_doubleQuotes[92] = 1;
/*     */     
/*  90 */     specicalFlags_singleQuotes[0] = 4;
/*  91 */     specicalFlags_singleQuotes[1] = 4;
/*  92 */     specicalFlags_singleQuotes[2] = 4;
/*  93 */     specicalFlags_singleQuotes[3] = 4;
/*  94 */     specicalFlags_singleQuotes[4] = 4;
/*  95 */     specicalFlags_singleQuotes[5] = 4;
/*  96 */     specicalFlags_singleQuotes[6] = 4;
/*  97 */     specicalFlags_singleQuotes[7] = 4;
/*  98 */     specicalFlags_singleQuotes[8] = 1;
/*  99 */     specicalFlags_singleQuotes[9] = 1;
/* 100 */     specicalFlags_singleQuotes[10] = 1;
/* 101 */     specicalFlags_singleQuotes[11] = 4;
/* 102 */     specicalFlags_singleQuotes[12] = 1;
/* 103 */     specicalFlags_singleQuotes[13] = 1;
/* 104 */     specicalFlags_singleQuotes[92] = 1;
/* 105 */     specicalFlags_singleQuotes[39] = 1;
/*     */     int i;
/* 107 */     for (i = 14; i <= 31; i++) {
/* 108 */       specicalFlags_doubleQuotes[i] = 4;
/* 109 */       specicalFlags_singleQuotes[i] = 4;
/*     */     } 
/*     */     
/* 112 */     for (i = 127; i < 160; i++) {
/* 113 */       specicalFlags_doubleQuotes[i] = 4;
/* 114 */       specicalFlags_singleQuotes[i] = 4;
/*     */     } 
/*     */     
/* 117 */     for (i = 0; i < 161; i++) {
/* 118 */       specicalFlags_doubleQuotesFlags[i] = (specicalFlags_doubleQuotes[i] != 0);
/* 119 */       specicalFlags_singleQuotesFlags[i] = (specicalFlags_singleQuotes[i] != 0);
/*     */     } 
/*     */     
/* 122 */     replaceChars[0] = '0';
/* 123 */     replaceChars[1] = '1';
/* 124 */     replaceChars[2] = '2';
/* 125 */     replaceChars[3] = '3';
/* 126 */     replaceChars[4] = '4';
/* 127 */     replaceChars[5] = '5';
/* 128 */     replaceChars[6] = '6';
/* 129 */     replaceChars[7] = '7';
/* 130 */     replaceChars[8] = 'b';
/* 131 */     replaceChars[9] = 't';
/* 132 */     replaceChars[10] = 'n';
/* 133 */     replaceChars[11] = 'v';
/* 134 */     replaceChars[12] = 'f';
/* 135 */     replaceChars[13] = 'r';
/* 136 */     replaceChars[34] = '"';
/* 137 */     replaceChars[39] = '\'';
/* 138 */     replaceChars[47] = '/';
/* 139 */     replaceChars[92] = '\\';
/*     */   }
/*     */   
/*     */   public static void decode(CharsetDecoder charsetDecoder, ByteBuffer byteBuf, CharBuffer charByte) {
/*     */     try {
/* 144 */       CoderResult cr = charsetDecoder.decode(byteBuf, charByte, true);
/*     */       
/* 146 */       if (!cr.isUnderflow()) {
/* 147 */         cr.throwException();
/*     */       }
/*     */       
/* 150 */       cr = charsetDecoder.flush(charByte);
/*     */       
/* 152 */       if (!cr.isUnderflow()) {
/* 153 */         cr.throwException();
/*     */       }
/* 155 */     } catch (CharacterCodingException x) {
/*     */ 
/*     */       
/* 158 */       throw new JSONException("utf8 decode error, " + x.getMessage(), x);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] decodeBase64(String s) {
/* 164 */     int sLen = s.length();
/* 165 */     if (sLen == 0) {
/* 166 */       return new byte[0];
/*     */     }
/*     */     
/* 169 */     int sIx = 0, eIx = sLen - 1;
/*     */ 
/*     */     
/* 172 */     while (sIx < eIx && IA[s.charAt(sIx) & 0xFF] < 0) {
/* 173 */       sIx++;
/*     */     }
/*     */ 
/*     */     
/* 177 */     while (eIx > 0 && IA[s.charAt(eIx) & 0xFF] < 0) {
/* 178 */       eIx--;
/*     */     }
/*     */ 
/*     */     
/* 182 */     int pad = (s.charAt(eIx) == '=') ? ((s.charAt(eIx - 1) == '=') ? 2 : 1) : 0;
/* 183 */     int cCnt = eIx - sIx + 1;
/* 184 */     int sepCnt = (sLen > 76) ? (((s.charAt(76) == '\r') ? (cCnt / 78) : 0) << 1) : 0;
/*     */     
/* 186 */     int len = ((cCnt - sepCnt) * 6 >> 3) - pad;
/* 187 */     byte[] dArr = new byte[len];
/*     */ 
/*     */     
/* 190 */     int d = 0; int cc, eLen;
/* 191 */     for (cc = 0, eLen = len / 3 * 3; d < eLen; ) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 196 */       int i = IA[s.charAt(sIx)] << 18 | IA[s.charAt(sIx + 1)] << 12 | IA[s.charAt(sIx + 2)] << 6 | IA[s.charAt(sIx + 3)];
/* 197 */       sIx += 4;
/*     */ 
/*     */       
/* 200 */       dArr[d] = (byte)(i >> 16);
/* 201 */       dArr[d + 1] = (byte)(i >> 8);
/* 202 */       dArr[d + 2] = (byte)i;
/* 203 */       d += 3;
/*     */ 
/*     */       
/* 206 */       if (sepCnt > 0 && ++cc == 19) {
/* 207 */         sIx += 2;
/* 208 */         cc = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 212 */     if (d < len) {
/*     */       
/* 214 */       int i = 0;
/* 215 */       for (int j = 0; sIx <= eIx - pad; j++) {
/* 216 */         i |= IA[s.charAt(sIx++)] << 18 - j * 6;
/*     */       }
/*     */       
/* 219 */       for (int r = 16; d < len; r -= 8) {
/* 220 */         dArr[d++] = (byte)(i >> r);
/*     */       }
/*     */     } 
/*     */     
/* 224 */     return dArr;
/*     */   }
/*     */   
/*     */   public static void close(Closeable x) {
/* 228 */     if (x != null) {
/*     */       try {
/* 230 */         x.close();
/* 231 */       } catch (Exception exception) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getChars(byte b, int index, char[] buf) {
/* 238 */     com.alibaba.fastjson2.util.IOUtils.getChars(b, index, buf);
/*     */   }
/*     */   
/*     */   public static void getChars(int i, int index, char[] buf) {
/* 242 */     com.alibaba.fastjson2.util.IOUtils.getChars(i, index, buf);
/*     */   }
/*     */   
/*     */   public static void getChars(long i, int index, char[] buf) {
/* 246 */     com.alibaba.fastjson2.util.IOUtils.getChars(i, index, buf);
/*     */   }
/*     */   
/*     */   public static int stringSize(int x) {
/* 250 */     return com.alibaba.fastjson2.util.IOUtils.stringSize(x);
/*     */   }
/*     */   
/*     */   public static int stringSize(long x) {
/* 254 */     return com.alibaba.fastjson2.util.IOUtils.stringSize(x);
/*     */   }
/*     */   
/*     */   public static int decodeUTF8(byte[] sa, int sp, int len, char[] da) {
/* 258 */     return com.alibaba.fastjson2.util.IOUtils.decodeUTF8(sa, sp, len, da);
/*     */   }
/*     */   
/*     */   public static boolean isIdent(char ch) {
/* 262 */     return (ch < identifierFlags.length && identifierFlags[ch]);
/*     */   }
/*     */   
/*     */   public static boolean isValidJsonpQueryParam(String value) {
/* 266 */     if (value == null || value.length() == 0) {
/* 267 */       return false;
/*     */     }
/*     */     
/* 270 */     for (int i = 0, len = value.length(); i < len; i++) {
/* 271 */       char ch = value.charAt(i);
/* 272 */       if (ch != '.' && !isIdent(ch)) {
/* 273 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 277 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjso\\util\IOUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */