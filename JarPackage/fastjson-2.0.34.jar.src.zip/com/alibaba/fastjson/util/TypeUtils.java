/*      */ package com.alibaba.fastjson.util;
/*      */ 
/*      */ import com.alibaba.fastjson.JSON;
/*      */ import com.alibaba.fastjson.JSONException;
/*      */ import com.alibaba.fastjson.JSONObject;
/*      */ import com.alibaba.fastjson.PropertyNamingStrategy;
/*      */ import com.alibaba.fastjson.annotation.JSONField;
/*      */ import com.alibaba.fastjson.annotation.JSONType;
/*      */ import com.alibaba.fastjson.parser.Feature;
/*      */ import com.alibaba.fastjson.parser.ParserConfig;
/*      */ import com.alibaba.fastjson.serializer.SerializerFeature;
/*      */ import com.alibaba.fastjson2.JSONFactory;
/*      */ import com.alibaba.fastjson2.reader.ObjectReader;
/*      */ import com.alibaba.fastjson2.util.DateUtils;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.GenericArrayType;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Date;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TypeUtils
/*      */ {
/*      */   static final long FNV1A_64_MAGIC_HASHCODE = -3750763034362895579L;
/*      */   static final long FNV1A_64_MAGIC_PRIME = 1099511628211L;
/*      */   private static boolean setAccessibleEnable = true;
/*      */   public static boolean compatibleWithJavaBean;
/*      */   public static boolean compatibleWithFieldName;
/*      */   private static volatile Class kotlin_metadata;
/*      */   private static volatile boolean kotlin_metadata_error;
/*   62 */   private static ConcurrentMap<String, Class<?>> mappings = new ConcurrentHashMap<>(256, 0.75F, 1); private static volatile boolean kotlin_class_klass_error; private static volatile Constructor kotlin_kclass_constructor; private static volatile Method kotlin_kclass_getConstructors; private static volatile Method kotlin_kfunction_getParameters; private static volatile Method kotlin_kparameter_getName; private static volatile boolean kotlin_error;
/*      */   private static volatile Map<Class, String[]> kotlinIgnores;
/*      */   private static volatile boolean kotlinIgnores_error;
/*      */   private static Class<?> pathClass;
/*      */   private static boolean PATH_CLASS_ERROR;
/*      */   private static boolean transientClassInited;
/*      */   private static Class<? extends Annotation> transientClass;
/*      */   
/*      */   public static <T> T cast(Object obj, Class<T> clazz, ParserConfig config) {
/*   71 */     return (T)com.alibaba.fastjson2.util.TypeUtils.cast(obj, clazz, config.getProvider());
/*      */   }
/*      */ 
/*      */   
/*      */   public static <T> T cast(Object obj, Type type, ParserConfig mapping) {
/*   76 */     if (obj == null) {
/*   77 */       return null;
/*      */     }
/*      */     
/*   80 */     if (obj instanceof String) {
/*   81 */       String strVal = (String)obj;
/*   82 */       if (strVal.length() == 0 || "null"
/*   83 */         .equals(strVal) || "NULL"
/*   84 */         .equals(strVal)) {
/*   85 */         return null;
/*      */       }
/*      */     } 
/*      */     
/*   89 */     if (type instanceof Class) {
/*   90 */       return cast(obj, (Class<T>)type, mapping);
/*      */     }
/*      */     
/*   93 */     if (type instanceof ParameterizedType) {
/*   94 */       return cast(obj, (ParameterizedType)type, mapping);
/*      */     }
/*      */     
/*   97 */     if (type instanceof java.lang.reflect.TypeVariable) {
/*   98 */       return (T)obj;
/*      */     }
/*  100 */     throw new JSONException("can not cast to : " + type);
/*      */   }
/*      */ 
/*      */   
/*      */   public static <T> T cast(Object obj, ParameterizedType type, ParserConfig mapping) {
/*  105 */     Type rawTye = type.getRawType();
/*      */     
/*  107 */     if (rawTye == List.class || rawTye == ArrayList.class) {
/*  108 */       Type itemType = type.getActualTypeArguments()[0];
/*  109 */       if (obj instanceof List) {
/*  110 */         List listObj = (List)obj;
/*  111 */         List<Object> arrayList = new ArrayList(listObj.size());
/*      */         
/*  113 */         for (int i = 0; i < listObj.size(); i++) {
/*  114 */           Object itemValue, item = listObj.get(i);
/*      */ 
/*      */           
/*  117 */           if (itemType instanceof Class) {
/*  118 */             if (item != null && item.getClass() == JSONObject.class) {
/*  119 */               itemValue = ((JSONObject)item).toJavaObject((Class)itemType, mapping, 0);
/*      */             } else {
/*  121 */               itemValue = cast(item, (Class)itemType, mapping);
/*      */             } 
/*      */           } else {
/*  124 */             itemValue = cast(item, itemType, mapping);
/*      */           } 
/*      */           
/*  127 */           arrayList.add(itemValue);
/*      */         } 
/*  129 */         return (T)arrayList;
/*      */       } 
/*      */     } 
/*      */     
/*  133 */     if (rawTye == Set.class || rawTye == HashSet.class || rawTye == TreeSet.class || rawTye == Collection.class || rawTye == List.class || rawTye == ArrayList.class) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  138 */       Type itemType = type.getActualTypeArguments()[0];
/*  139 */       if (obj instanceof Iterable) {
/*      */         Collection<Object> collection;
/*  141 */         if (rawTye == Set.class || rawTye == HashSet.class) {
/*  142 */           collection = new HashSet();
/*  143 */         } else if (rawTye == TreeSet.class) {
/*  144 */           collection = new TreeSet();
/*      */         } else {
/*  146 */           collection = new ArrayList();
/*      */         } 
/*  148 */         for (Iterator it = ((Iterable)obj).iterator(); it.hasNext(); ) {
/*  149 */           Object itemValue, item = it.next();
/*      */ 
/*      */           
/*  152 */           if (itemType instanceof Class) {
/*  153 */             if (item != null && item.getClass() == JSONObject.class) {
/*  154 */               itemValue = ((JSONObject)item).toJavaObject((Class)itemType, mapping, 0);
/*      */             } else {
/*  156 */               itemValue = cast(item, (Class)itemType, mapping);
/*      */             } 
/*      */           } else {
/*  159 */             itemValue = cast(item, itemType, mapping);
/*      */           } 
/*      */           
/*  162 */           collection.add(itemValue);
/*      */         } 
/*  164 */         return (T)collection;
/*      */       } 
/*      */     } 
/*      */     
/*  168 */     if (rawTye == Map.class || rawTye == HashMap.class) {
/*  169 */       Type keyType = type.getActualTypeArguments()[0];
/*  170 */       Type valueType = type.getActualTypeArguments()[1];
/*  171 */       if (obj instanceof Map) {
/*  172 */         Map<Object, Object> map = new HashMap<>();
/*  173 */         for (Map.Entry entry : ((Map)obj).entrySet()) {
/*  174 */           Object key = cast(entry.getKey(), keyType, mapping);
/*  175 */           Object value = cast(entry.getValue(), valueType, mapping);
/*  176 */           map.put(key, value);
/*      */         } 
/*  178 */         return (T)map;
/*      */       } 
/*      */     } 
/*  181 */     if (obj instanceof String) {
/*  182 */       String strVal = (String)obj;
/*  183 */       if (strVal.length() == 0) {
/*  184 */         return null;
/*      */       }
/*      */     } 
/*  187 */     if ((type.getActualTypeArguments()).length == 1) {
/*  188 */       Type argType = type.getActualTypeArguments()[0];
/*  189 */       if (argType instanceof java.lang.reflect.WildcardType) {
/*  190 */         return cast(obj, rawTye, mapping);
/*      */       }
/*      */     } 
/*      */     
/*  194 */     if (rawTye == Map.Entry.class && obj instanceof Map && ((Map)obj).size() == 1) {
/*  195 */       Map.Entry entry = ((Map)obj).entrySet().iterator().next();
/*  196 */       return (T)entry;
/*      */     } 
/*      */     
/*  199 */     if (rawTye instanceof Class) {
/*  200 */       if (mapping == null) {
/*  201 */         mapping = ParserConfig.global;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  210 */       throw new JSONException("TODO : " + type);
/*      */     } 
/*      */     
/*  213 */     throw new JSONException("can not cast to : " + type);
/*      */   }
/*      */ 
/*      */   
/*      */   public static <T> T castToJavaBean(Map<String, Object> map, Class<T> clazz, ParserConfig config) {
/*      */     try {
/*  219 */       if (clazz == StackTraceElement.class) {
/*  220 */         int lineNumber; String declaringClass = (String)map.get("className");
/*  221 */         String methodName = (String)map.get("methodName");
/*  222 */         String fileName = (String)map.get("fileName");
/*      */ 
/*      */         
/*  225 */         Number value = (Number)map.get("lineNumber");
/*  226 */         if (value == null) {
/*  227 */           lineNumber = 0;
/*  228 */         } else if (value instanceof BigDecimal) {
/*  229 */           lineNumber = ((BigDecimal)value).intValueExact();
/*      */         } else {
/*  231 */           lineNumber = value.intValue();
/*      */         } 
/*      */         
/*  234 */         return (T)new StackTraceElement(declaringClass, methodName, fileName, lineNumber);
/*      */       } 
/*      */ 
/*      */       
/*  238 */       Object iClassObject = map.get(JSON.DEFAULT_TYPE_KEY);
/*  239 */       if (iClassObject instanceof String) {
/*  240 */         String className = (String)iClassObject;
/*      */         
/*  242 */         if (config == null) {
/*  243 */           config = ParserConfig.global;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  252 */         throw new JSONException("TODO");
/*      */       } 
/*      */ 
/*      */       
/*  256 */       if (clazz.isInterface()) {
/*      */         
/*  258 */         if (map instanceof JSONObject) {
/*  259 */           JSONObject object = (JSONObject)map;
/*      */         } else {
/*  261 */           JSONObject object = new JSONObject(map);
/*      */         } 
/*  263 */         if (config == null) {
/*  264 */           config = ParserConfig.getGlobalInstance();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  273 */         throw new JSONException("TODO");
/*      */       } 
/*      */       
/*  276 */       if (clazz == Locale.class) {
/*  277 */         Object arg0 = map.get("language");
/*  278 */         Object arg1 = map.get("country");
/*  279 */         if (arg0 instanceof String) {
/*  280 */           String language = (String)arg0;
/*  281 */           if (arg1 instanceof String) {
/*  282 */             String country = (String)arg1;
/*  283 */             return (T)new Locale(language, country);
/*  284 */           }  if (arg1 == null) {
/*  285 */             return (T)new Locale(language);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  290 */       if (clazz == String.class && map instanceof JSONObject) {
/*  291 */         return (T)map.toString();
/*      */       }
/*      */       
/*  294 */       if (clazz == LinkedHashMap.class && map instanceof JSONObject) {
/*  295 */         JSONObject jsonObject = (JSONObject)map;
/*  296 */         Map<?, ?> innerMap = jsonObject.getInnerMap();
/*  297 */         if (innerMap instanceof LinkedHashMap) {
/*  298 */           return (T)innerMap;
/*      */         }
/*  300 */         LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
/*  301 */         linkedHashMap.putAll(innerMap);
/*      */       } 
/*      */ 
/*      */       
/*  305 */       ObjectReader objectReader = JSONFactory.getDefaultObjectReaderProvider().getObjectReader(clazz);
/*  306 */       return (T)objectReader.createInstance(map, 0L);
/*  307 */     } catch (Exception e) {
/*  308 */       throw new JSONException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Type checkPrimitiveArray(GenericArrayType<?> genericArrayType) {
/*  313 */     Type<?> clz = genericArrayType;
/*  314 */     Type genericComponentType = genericArrayType.getGenericComponentType();
/*      */     
/*  316 */     String prefix = "[";
/*  317 */     while (genericComponentType instanceof GenericArrayType) {
/*      */       
/*  319 */       genericComponentType = ((GenericArrayType)genericComponentType).getGenericComponentType();
/*  320 */       prefix = prefix + prefix;
/*      */     } 
/*      */     
/*  323 */     if (genericComponentType instanceof Class) {
/*  324 */       Class<?> ck = (Class)genericComponentType;
/*  325 */       if (ck.isPrimitive()) {
/*      */         try {
/*  327 */           if (ck == boolean.class) {
/*  328 */             clz = Class.forName(prefix + "Z");
/*  329 */           } else if (ck == char.class) {
/*  330 */             clz = Class.forName(prefix + "C");
/*  331 */           } else if (ck == byte.class) {
/*  332 */             clz = Class.forName(prefix + "B");
/*  333 */           } else if (ck == short.class) {
/*  334 */             clz = Class.forName(prefix + "S");
/*  335 */           } else if (ck == int.class) {
/*  336 */             clz = Class.forName(prefix + "I");
/*  337 */           } else if (ck == long.class) {
/*  338 */             clz = Class.forName(prefix + "J");
/*  339 */           } else if (ck == float.class) {
/*  340 */             clz = Class.forName(prefix + "F");
/*  341 */           } else if (ck == double.class) {
/*  342 */             clz = Class.forName(prefix + "D");
/*      */           } 
/*  344 */         } catch (ClassNotFoundException classNotFoundException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  349 */     return clz;
/*      */   }
/*      */   
/*      */   public static boolean isProxy(Class<?> clazz) {
/*  353 */     return com.alibaba.fastjson2.util.TypeUtils.isProxy(clazz);
/*      */   }
/*      */   
/*      */   public static boolean isGenericParamType(Type type) {
/*  357 */     if (type instanceof ParameterizedType) {
/*  358 */       return true;
/*      */     }
/*  360 */     if (type instanceof Class) {
/*  361 */       Type superType = ((Class)type).getGenericSuperclass();
/*  362 */       return (superType != Object.class && isGenericParamType(superType));
/*      */     } 
/*  364 */     return false;
/*      */   }
/*      */   
/*      */   public static Type getGenericParamType(Type type) {
/*  368 */     if (type instanceof ParameterizedType) {
/*  369 */       return type;
/*      */     }
/*  371 */     if (type instanceof Class) {
/*  372 */       return getGenericParamType(((Class)type).getGenericSuperclass());
/*      */     }
/*  374 */     return type;
/*      */   }
/*      */   
/*      */   public static boolean isTransient(Method method) {
/*  378 */     if (method == null) {
/*  379 */       return false;
/*      */     }
/*  381 */     if (!transientClassInited) {
/*      */       try {
/*  383 */         transientClass = (Class)Class.forName("java.beans.Transient");
/*  384 */       } catch (Exception exception) {
/*      */       
/*      */       } finally {
/*  387 */         transientClassInited = true;
/*      */       } 
/*      */     }
/*  390 */     if (transientClass != null) {
/*  391 */       Annotation annotation = getAnnotation(method, (Class)transientClass);
/*  392 */       return (annotation != null);
/*      */     } 
/*  394 */     return false;
/*      */   }
/*      */   
/*      */   public static String castToString(Object value) {
/*  398 */     if (value == null) {
/*  399 */       return null;
/*      */     }
/*  401 */     return value.toString();
/*      */   }
/*      */   
/*      */   public static long fnv1a_64_lower(String key) {
/*  405 */     long hashCode = -3750763034362895579L;
/*  406 */     for (int i = 0; i < key.length(); i++) {
/*  407 */       char ch = key.charAt(i);
/*  408 */       if (ch >= 'A' && ch <= 'Z') {
/*  409 */         ch = (char)(ch + 32);
/*      */       }
/*  411 */       hashCode ^= ch;
/*  412 */       hashCode *= 1099511628211L;
/*      */     } 
/*  414 */     return hashCode;
/*      */   }
/*      */   
/*      */   public static long fnv1a_64(String key) {
/*  418 */     long hashCode = -3750763034362895579L;
/*  419 */     for (int i = 0; i < key.length(); i++) {
/*  420 */       char ch = key.charAt(i);
/*  421 */       hashCode ^= ch;
/*  422 */       hashCode *= 1099511628211L;
/*      */     } 
/*  424 */     return hashCode;
/*      */   }
/*      */   
/*      */   public static long fnv1a_64_extract(String key) {
/*  428 */     long hashCode = -3750763034362895579L;
/*  429 */     for (int i = 0; i < key.length(); i++) {
/*  430 */       char ch = key.charAt(i);
/*  431 */       if (ch != '_' && ch != '-' && ch != ' ') {
/*      */ 
/*      */         
/*  434 */         if (ch >= 'A' && ch <= 'Z') {
/*  435 */           ch = (char)(ch + 32);
/*      */         }
/*  437 */         hashCode ^= ch;
/*  438 */         hashCode *= 1099511628211L;
/*      */       } 
/*  440 */     }  return hashCode;
/*      */   }
/*      */   
/*      */   public static Long castToLong(Object value) {
/*  444 */     return com.alibaba.fastjson2.util.TypeUtils.toLong(value);
/*      */   }
/*      */   
/*      */   public static Integer castToInt(Object value) {
/*  448 */     return com.alibaba.fastjson2.util.TypeUtils.toInteger(value);
/*      */   }
/*      */   
/*      */   public static Boolean castToBoolean(Object value) {
/*  452 */     return com.alibaba.fastjson2.util.TypeUtils.toBoolean(value);
/*      */   }
/*      */   
/*      */   public static long longExtractValue(Number number) {
/*  456 */     if (number == null) {
/*  457 */       return 0L;
/*      */     }
/*      */     
/*  460 */     if (number instanceof BigDecimal) {
/*  461 */       return ((BigDecimal)number).longValueExact();
/*      */     }
/*      */     
/*  464 */     return number.longValue();
/*      */   }
/*      */   
/*      */   public static <A extends Annotation> A getAnnotation(Class<?> targetClass, Class<A> annotationClass) {
/*  468 */     A targetAnnotation = targetClass.getAnnotation(annotationClass);
/*      */     
/*  470 */     Class<?> mixInClass = null;
/*  471 */     Type type = JSON.getMixInAnnotations(targetClass);
/*  472 */     if (type instanceof Class) {
/*  473 */       mixInClass = (Class)type;
/*      */     }
/*      */     
/*  476 */     if (mixInClass != null) {
/*  477 */       A mixInAnnotation = mixInClass.getAnnotation(annotationClass);
/*  478 */       Annotation[] annotations = mixInClass.getAnnotations();
/*  479 */       if (mixInAnnotation == null && annotations.length > 0) {
/*  480 */         for (Annotation annotation : annotations) {
/*  481 */           mixInAnnotation = annotation.annotationType().getAnnotation(annotationClass);
/*  482 */           if (mixInAnnotation != null) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */       }
/*  487 */       if (mixInAnnotation != null) {
/*  488 */         return mixInAnnotation;
/*      */       }
/*      */     } 
/*      */     
/*  492 */     Annotation[] targetClassAnnotations = targetClass.getAnnotations();
/*  493 */     if (targetAnnotation == null && targetClassAnnotations.length > 0) {
/*  494 */       for (Annotation annotation : targetClassAnnotations) {
/*  495 */         targetAnnotation = annotation.annotationType().getAnnotation(annotationClass);
/*  496 */         if (targetAnnotation != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*  501 */     return targetAnnotation;
/*      */   }
/*      */   
/*      */   public static <A extends Annotation> A getAnnotation(Field field, Class<A> annotationClass) {
/*  505 */     A targetAnnotation = field.getAnnotation(annotationClass);
/*      */     
/*  507 */     Class<?> clazz = field.getDeclaringClass();
/*      */     
/*  509 */     Class<?> mixInClass = null;
/*  510 */     Type type = JSON.getMixInAnnotations(clazz);
/*  511 */     if (type instanceof Class) {
/*  512 */       mixInClass = (Class)type;
/*      */     }
/*      */     
/*  515 */     if (mixInClass != null) {
/*  516 */       Field mixInField = null;
/*  517 */       String fieldName = field.getName();
/*      */       
/*  519 */       for (Class<?> currClass = mixInClass; currClass != null && currClass != Object.class; currClass = currClass.getSuperclass()) {
/*      */         try {
/*  521 */           mixInField = currClass.getDeclaredField(fieldName);
/*      */           break;
/*  523 */         } catch (NoSuchFieldException noSuchFieldException) {}
/*      */       } 
/*      */ 
/*      */       
/*  527 */       if (mixInField == null) {
/*  528 */         return targetAnnotation;
/*      */       }
/*  530 */       A mixInAnnotation = mixInField.getAnnotation(annotationClass);
/*  531 */       if (mixInAnnotation != null) {
/*  532 */         return mixInAnnotation;
/*      */       }
/*      */     } 
/*  535 */     return targetAnnotation;
/*      */   }
/*      */   
/*      */   public static <A extends Annotation> A getAnnotation(Method method, Class<A> annotationClass) {
/*  539 */     A targetAnnotation = method.getAnnotation(annotationClass);
/*      */     
/*  541 */     Class<?> clazz = method.getDeclaringClass();
/*      */     
/*  543 */     Class<?> mixInClass = null;
/*  544 */     Type type = JSON.getMixInAnnotations(clazz);
/*  545 */     if (type instanceof Class) {
/*  546 */       mixInClass = (Class)type;
/*      */     }
/*      */     
/*  549 */     if (mixInClass != null) {
/*  550 */       Method mixInMethod = null;
/*  551 */       String methodName = method.getName();
/*  552 */       Class<?>[] parameterTypes = method.getParameterTypes();
/*      */       
/*  554 */       for (Class<?> currClass = mixInClass; currClass != null && currClass != Object.class; currClass = currClass.getSuperclass()) {
/*      */         try {
/*  556 */           mixInMethod = currClass.getDeclaredMethod(methodName, parameterTypes);
/*      */           break;
/*  558 */         } catch (NoSuchMethodException noSuchMethodException) {}
/*      */       } 
/*      */ 
/*      */       
/*  562 */       if (mixInMethod == null) {
/*  563 */         return targetAnnotation;
/*      */       }
/*  565 */       A mixInAnnotation = mixInMethod.getAnnotation(annotationClass);
/*  566 */       if (mixInAnnotation != null) {
/*  567 */         return mixInAnnotation;
/*      */       }
/*      */     } 
/*  570 */     return targetAnnotation;
/*      */   }
/*      */   
/*      */   public static Double castToDouble(Object value) {
/*  574 */     return com.alibaba.fastjson2.util.TypeUtils.toDouble(value);
/*      */   }
/*      */   
/*      */   public static <T> T castToJavaBean(Object obj, Class<T> clazz) {
/*  578 */     return (T)com.alibaba.fastjson2.util.TypeUtils.cast(obj, clazz);
/*      */   }
/*      */   
/*      */   public static Class<?> getClass(Type type) {
/*  582 */     return com.alibaba.fastjson2.util.TypeUtils.getClass(type);
/*      */   }
/*      */   
/*      */   public static BigDecimal castToBigDecimal(Object value) {
/*  586 */     return com.alibaba.fastjson2.util.TypeUtils.toBigDecimal(value);
/*      */   }
/*      */   
/*      */   public static BigInteger castToBigInteger(Object value) {
/*  590 */     return com.alibaba.fastjson2.util.TypeUtils.toBigInteger(value);
/*      */   }
/*      */   
/*      */   public static Timestamp castToTimestamp(Object value) {
/*  594 */     return (Timestamp)com.alibaba.fastjson2.util.TypeUtils.cast(value, Timestamp.class);
/*      */   }
/*      */   
/*      */   public static Date castToSqlDate(Object value) {
/*  598 */     return (Date)com.alibaba.fastjson2.util.TypeUtils.cast(value, Date.class);
/*      */   }
/*      */   
/*      */   public static byte byteValue(BigDecimal decimal) {
/*  602 */     if (decimal == null) {
/*  603 */       return 0;
/*      */     }
/*      */     
/*  606 */     int scale = decimal.scale();
/*  607 */     if (scale >= -100 && scale <= 100) {
/*  608 */       return decimal.byteValue();
/*      */     }
/*      */     
/*  611 */     return decimal.byteValueExact();
/*      */   }
/*      */   
/*      */   public static short shortValue(BigDecimal decimal) {
/*  615 */     if (decimal == null) {
/*  616 */       return 0;
/*      */     }
/*      */     
/*  619 */     int scale = decimal.scale();
/*  620 */     if (scale >= -100 && scale <= 100) {
/*  621 */       return decimal.shortValue();
/*      */     }
/*      */     
/*  624 */     return decimal.shortValueExact();
/*      */   }
/*      */   
/*      */   public static int intValue(BigDecimal decimal) {
/*  628 */     if (decimal == null) {
/*  629 */       return 0;
/*      */     }
/*      */     
/*  632 */     int scale = decimal.scale();
/*  633 */     if (scale >= -100 && scale <= 100) {
/*  634 */       return decimal.intValue();
/*      */     }
/*      */     
/*  637 */     return decimal.intValueExact();
/*      */   }
/*      */   
/*      */   public static long longValue(BigDecimal decimal) {
/*  641 */     if (decimal == null) {
/*  642 */       return 0L;
/*      */     }
/*      */     
/*  645 */     int scale = decimal.scale();
/*  646 */     if (scale >= -100 && scale <= 100) {
/*  647 */       return decimal.longValue();
/*      */     }
/*      */     
/*  650 */     return decimal.longValueExact();
/*      */   }
/*      */   
/*      */   public static Character castToChar(Object value) {
/*  654 */     if (value == null) {
/*  655 */       return null;
/*      */     }
/*  657 */     if (value instanceof Character) {
/*  658 */       return (Character)value;
/*      */     }
/*  660 */     if (value instanceof String) {
/*  661 */       String strVal = (String)value;
/*  662 */       if (strVal.length() == 0) {
/*  663 */         return null;
/*      */       }
/*  665 */       if (strVal.length() != 1) {
/*  666 */         throw new JSONException("can not cast to char, value : " + value);
/*      */       }
/*  668 */       return Character.valueOf(strVal.charAt(0));
/*      */     } 
/*  670 */     throw new JSONException("can not cast to char, value : " + value);
/*      */   }
/*      */   
/*      */   public static Short castToShort(Object value) {
/*  674 */     return com.alibaba.fastjson2.util.TypeUtils.toShort(value);
/*      */   }
/*      */   
/*      */   public static Byte castToByte(Object value) {
/*  678 */     return com.alibaba.fastjson2.util.TypeUtils.toByte(value);
/*      */   }
/*      */   
/*      */   public static Float castToFloat(Object value) {
/*  682 */     return com.alibaba.fastjson2.util.TypeUtils.toFloat(value);
/*      */   }
/*      */   
/*      */   public static Date castToDate(Object value) {
/*  686 */     return com.alibaba.fastjson2.util.TypeUtils.toDate(value);
/*      */   }
/*      */   
/*      */   public static Date castToDate(Object value, String format) {
/*  690 */     if (value == null) {
/*  691 */       return null;
/*      */     }
/*      */     
/*  694 */     if (value instanceof String) {
/*  695 */       String str = (String)value;
/*  696 */       return DateUtils.parseDate(str, format, null);
/*      */     } 
/*      */     
/*  699 */     return com.alibaba.fastjson2.util.TypeUtils.toDate(value);
/*      */   }
/*      */   
/*      */   public static byte[] castToBytes(Object value) {
/*  703 */     if (value instanceof byte[]) {
/*  704 */       return (byte[])value;
/*      */     }
/*  706 */     if (value instanceof String) {
/*  707 */       return IOUtils.decodeBase64((String)value);
/*      */     }
/*  709 */     throw new JSONException("can not cast to byte[], value : " + value);
/*      */   }
/*      */   
/*      */   public static List<FieldInfo> computeGetters(Class<?> clazz, Map<String, String> aliasMap) {
/*  713 */     return computeGetters(clazz, aliasMap, true);
/*      */   }
/*      */   
/*      */   public static List<FieldInfo> computeGetters(Class<?> clazz, Map<String, String> aliasMap, boolean sorted) {
/*  717 */     JSONType jsonType = getAnnotation(clazz, JSONType.class);
/*  718 */     Map<String, Field> fieldCacheMap = new HashMap<>();
/*  719 */     ParserConfig.parserAllFieldToCache(clazz, fieldCacheMap);
/*  720 */     return computeGetters(clazz, jsonType, aliasMap, fieldCacheMap, sorted, PropertyNamingStrategy.CamelCase);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<FieldInfo> computeGetters(Class<?> clazz, JSONType jsonType, Map<String, String> aliasMap, Map<String, Field> fieldCacheMap, boolean sorted, PropertyNamingStrategy propertyNamingStrategy) {
/*  730 */     Map<String, FieldInfo> fieldInfoMap = new LinkedHashMap<>();
/*  731 */     boolean kotlin = isKotlin(clazz);
/*      */     
/*  733 */     Constructor[] constructors = null;
/*  734 */     Annotation[][] paramAnnotationArrays = null;
/*  735 */     String[] paramNames = null;
/*  736 */     short[] paramNameMapping = null;
/*  737 */     Method[] methods = clazz.getMethods();
/*      */     try {
/*  739 */       Arrays.sort(methods, new MethodInheritanceComparator());
/*  740 */     } catch (Throwable throwable) {}
/*      */ 
/*      */ 
/*      */     
/*  744 */     for (Method method : methods) {
/*  745 */       String propertyName, methodName = method.getName();
/*  746 */       int ordinal = 0, serialzeFeatures = 0, parserFeatures = 0;
/*  747 */       String label = null;
/*  748 */       if (Modifier.isStatic(method.getModifiers())) {
/*      */         continue;
/*      */       }
/*      */       
/*  752 */       Class<?> returnType = method.getReturnType();
/*  753 */       if (returnType.equals(void.class)) {
/*      */         continue;
/*      */       }
/*      */       
/*  757 */       if ((method.getParameterTypes()).length != 0) {
/*      */         continue;
/*      */       }
/*      */       
/*  761 */       if (returnType == ClassLoader.class || returnType == InputStream.class || returnType == Reader.class) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  767 */       if (methodName.equals("getMetaClass") && returnType
/*  768 */         .getName().equals("groovy.lang.MetaClass")) {
/*      */         continue;
/*      */       }
/*  771 */       if (methodName.equals("getSuppressed") && method
/*  772 */         .getDeclaringClass() == Throwable.class) {
/*      */         continue;
/*      */       }
/*      */       
/*  776 */       if (kotlin && isKotlinIgnore(clazz, methodName)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  782 */       Boolean fieldAnnotationAndNameExists = Boolean.valueOf(false);
/*  783 */       JSONField annotation = getAnnotation(method, JSONField.class);
/*  784 */       if (annotation == null) {
/*  785 */         annotation = getSuperMethodAnnotation(clazz, method);
/*      */       }
/*  787 */       if (annotation == null && kotlin) {
/*  788 */         if (constructors == null) {
/*  789 */           constructors = (Constructor[])clazz.getDeclaredConstructors();
/*  790 */           Constructor creatorConstructor = getKotlinConstructor(constructors);
/*  791 */           if (creatorConstructor != null) {
/*  792 */             paramAnnotationArrays = getParameterAnnotations(creatorConstructor);
/*  793 */             paramNames = getKoltinConstructorParameters(clazz);
/*  794 */             if (paramNames != null) {
/*  795 */               String[] paramNames_sorted = new String[paramNames.length];
/*  796 */               System.arraycopy(paramNames, 0, paramNames_sorted, 0, paramNames.length);
/*      */               
/*  798 */               Arrays.sort((Object[])paramNames_sorted);
/*  799 */               paramNameMapping = new short[paramNames.length]; short p;
/*  800 */               for (p = 0; p < paramNames.length; p = (short)(p + 1)) {
/*  801 */                 int index = Arrays.binarySearch((Object[])paramNames_sorted, paramNames[p]);
/*  802 */                 paramNameMapping[index] = p;
/*      */               } 
/*  804 */               paramNames = paramNames_sorted;
/*      */             } 
/*      */           } 
/*      */         } 
/*  808 */         if (paramNames != null && paramNameMapping != null && methodName.startsWith("get")) {
/*  809 */           String str = decapitalize(methodName.substring(3));
/*  810 */           int p = Arrays.binarySearch((Object[])paramNames, str);
/*  811 */           if (p < 0) {
/*  812 */             for (int i = 0; i < paramNames.length; i++) {
/*  813 */               if (str.equalsIgnoreCase(paramNames[i])) {
/*  814 */                 p = i;
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           }
/*  819 */           if (p >= 0) {
/*  820 */             short index = paramNameMapping[p];
/*  821 */             Annotation[] paramAnnotations = paramAnnotationArrays[index];
/*  822 */             if (paramAnnotations != null) {
/*  823 */               for (Annotation paramAnnotation : paramAnnotations) {
/*  824 */                 if (paramAnnotation instanceof JSONField) {
/*  825 */                   annotation = (JSONField)paramAnnotation;
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             }
/*  830 */             if (annotation == null) {
/*  831 */               Field field1 = ParserConfig.getFieldFromCache(str, fieldCacheMap);
/*  832 */               if (field1 != null) {
/*  833 */                 annotation = getAnnotation(field1, JSONField.class);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  839 */       if (annotation != null) {
/*  840 */         if (!annotation.serialize()) {
/*      */           continue;
/*      */         }
/*  843 */         ordinal = annotation.ordinal();
/*  844 */         serialzeFeatures = SerializerFeature.of(annotation.serialzeFeatures());
/*  845 */         parserFeatures = Feature.of(annotation.parseFeatures());
/*  846 */         if (annotation.name().length() != 0) {
/*  847 */           String str = annotation.name();
/*  848 */           if (aliasMap != null) {
/*  849 */             str = aliasMap.get(str);
/*  850 */             if (str == null) {
/*      */               continue;
/*      */             }
/*      */           } 
/*  854 */           FieldInfo fieldInfo = new FieldInfo(str, method, null, clazz, null, ordinal, serialzeFeatures, parserFeatures, annotation, null, label);
/*      */           
/*  856 */           fieldInfoMap.put(str, fieldInfo);
/*      */           continue;
/*      */         } 
/*  859 */         if (annotation.label().length() != 0) {
/*  860 */           label = annotation.label();
/*      */         }
/*      */       } 
/*  863 */       if (methodName.startsWith("get")) {
/*  864 */         if (methodName.length() < 4) {
/*      */           continue;
/*      */         }
/*  867 */         if (methodName.equals("getClass")) {
/*      */           continue;
/*      */         }
/*  870 */         if (methodName.equals("getDeclaringClass") && clazz.isEnum()) {
/*      */           continue;
/*      */         }
/*  873 */         char c3 = methodName.charAt(3);
/*      */         
/*  875 */         Field field1 = null;
/*  876 */         if (Character.isUpperCase(c3) || c3 > 'Ȁ') {
/*      */ 
/*      */           
/*  879 */           if (compatibleWithJavaBean) {
/*  880 */             propertyName = decapitalize(methodName.substring(3));
/*      */           } else {
/*  882 */             propertyName = getPropertyNameByMethodName(methodName);
/*      */           } 
/*  884 */           propertyName = getPropertyNameByCompatibleFieldName(fieldCacheMap, methodName, propertyName, 3);
/*  885 */         } else if (c3 == '_') {
/*  886 */           propertyName = methodName.substring(3);
/*  887 */           field1 = fieldCacheMap.get(propertyName);
/*  888 */           if (field1 == null) {
/*  889 */             String temp = propertyName;
/*  890 */             propertyName = methodName.substring(4);
/*  891 */             field1 = ParserConfig.getFieldFromCache(propertyName, fieldCacheMap);
/*  892 */             if (field1 == null) {
/*  893 */               propertyName = temp;
/*      */             }
/*      */           } 
/*  896 */         } else if (c3 == 'f') {
/*  897 */           propertyName = methodName.substring(3);
/*  898 */         } else if (methodName.length() >= 5 && Character.isUpperCase(methodName.charAt(4))) {
/*  899 */           propertyName = decapitalize(methodName.substring(3));
/*      */         } else {
/*  901 */           propertyName = methodName.substring(3);
/*  902 */           field1 = ParserConfig.getFieldFromCache(propertyName, fieldCacheMap);
/*  903 */           if (field1 == null) {
/*      */             continue;
/*      */           }
/*      */         } 
/*  907 */         boolean bool = isJSONTypeIgnore(clazz, propertyName);
/*  908 */         if (bool) {
/*      */           continue;
/*      */         }
/*      */         
/*  912 */         if (field1 == null)
/*      */         {
/*  914 */           field1 = ParserConfig.getFieldFromCache(propertyName, fieldCacheMap);
/*      */         }
/*      */         
/*  917 */         if (field1 == null && propertyName.length() > 1) {
/*  918 */           char ch = propertyName.charAt(1);
/*  919 */           if (ch >= 'A' && ch <= 'Z') {
/*  920 */             String javaBeanCompatiblePropertyName = decapitalize(methodName.substring(3));
/*  921 */             field1 = ParserConfig.getFieldFromCache(javaBeanCompatiblePropertyName, fieldCacheMap);
/*      */           } 
/*      */         } 
/*  924 */         JSONField jSONField = null;
/*  925 */         if (field1 != null) {
/*  926 */           jSONField = getAnnotation(field1, JSONField.class);
/*  927 */           if (jSONField != null) {
/*  928 */             if (!jSONField.serialize()) {
/*      */               continue;
/*      */             }
/*  931 */             ordinal = jSONField.ordinal();
/*  932 */             serialzeFeatures = SerializerFeature.of(jSONField.serialzeFeatures());
/*  933 */             parserFeatures = Feature.of(jSONField.parseFeatures());
/*  934 */             if (jSONField.name().length() != 0) {
/*  935 */               fieldAnnotationAndNameExists = Boolean.valueOf(true);
/*  936 */               propertyName = jSONField.name();
/*  937 */               if (aliasMap != null) {
/*  938 */                 propertyName = aliasMap.get(propertyName);
/*  939 */                 if (propertyName == null) {
/*      */                   continue;
/*      */                 }
/*      */               } 
/*      */             } 
/*  944 */             if (jSONField.label().length() != 0) {
/*  945 */               label = jSONField.label();
/*      */             }
/*      */           } 
/*      */         } 
/*  949 */         if (aliasMap != null) {
/*  950 */           propertyName = aliasMap.get(propertyName);
/*  951 */           if (propertyName == null) {
/*      */             continue;
/*      */           }
/*      */         } 
/*  955 */         if (propertyNamingStrategy != null && !fieldAnnotationAndNameExists.booleanValue()) {
/*  956 */           propertyName = propertyNamingStrategy.translate(propertyName);
/*      */         }
/*  958 */         FieldInfo fieldInfo = new FieldInfo(propertyName, method, field1, clazz, null, ordinal, serialzeFeatures, parserFeatures, annotation, jSONField, label);
/*      */         
/*  960 */         fieldInfoMap.put(propertyName, fieldInfo);
/*      */       } 
/*  962 */       if (!methodName.startsWith("is") || 
/*  963 */         methodName.length() < 3) {
/*      */         continue;
/*      */       }
/*  966 */       if (returnType != boolean.class && returnType != Boolean.class) {
/*      */         continue;
/*      */       }
/*      */       
/*  970 */       char c2 = methodName.charAt(2);
/*      */       
/*  972 */       Field field = null;
/*  973 */       if (Character.isUpperCase(c2)) {
/*  974 */         if (compatibleWithJavaBean) {
/*  975 */           propertyName = decapitalize(methodName.substring(2));
/*      */         } else {
/*  977 */           propertyName = Character.toLowerCase(methodName.charAt(2)) + methodName.substring(3);
/*      */         } 
/*  979 */         propertyName = getPropertyNameByCompatibleFieldName(fieldCacheMap, methodName, propertyName, 2);
/*  980 */       } else if (c2 == '_') {
/*  981 */         propertyName = methodName.substring(3);
/*  982 */         field = fieldCacheMap.get(propertyName);
/*  983 */         if (field == null) {
/*  984 */           String temp = propertyName;
/*  985 */           propertyName = methodName.substring(2);
/*  986 */           field = ParserConfig.getFieldFromCache(propertyName, fieldCacheMap);
/*  987 */           if (field == null) {
/*  988 */             propertyName = temp;
/*      */           }
/*      */         } 
/*  991 */       } else if (c2 == 'f') {
/*  992 */         propertyName = methodName.substring(2);
/*      */       } else {
/*  994 */         propertyName = methodName.substring(2);
/*  995 */         field = ParserConfig.getFieldFromCache(propertyName, fieldCacheMap);
/*  996 */         if (field == null) {
/*      */           continue;
/*      */         }
/*      */       } 
/* 1000 */       boolean ignore = isJSONTypeIgnore(clazz, propertyName);
/* 1001 */       if (ignore) {
/*      */         continue;
/*      */       }
/*      */       
/* 1005 */       if (field == null) {
/* 1006 */         field = ParserConfig.getFieldFromCache(propertyName, fieldCacheMap);
/*      */       }
/*      */       
/* 1009 */       if (field == null) {
/* 1010 */         field = ParserConfig.getFieldFromCache(methodName, fieldCacheMap);
/*      */       }
/* 1012 */       JSONField fieldAnnotation = null;
/* 1013 */       if (field != null) {
/* 1014 */         fieldAnnotation = getAnnotation(field, JSONField.class);
/* 1015 */         if (fieldAnnotation != null) {
/* 1016 */           if (!fieldAnnotation.serialize()) {
/*      */             continue;
/*      */           }
/* 1019 */           ordinal = fieldAnnotation.ordinal();
/* 1020 */           serialzeFeatures = SerializerFeature.of(fieldAnnotation.serialzeFeatures());
/* 1021 */           parserFeatures = Feature.of(fieldAnnotation.parseFeatures());
/* 1022 */           if (fieldAnnotation.name().length() != 0) {
/* 1023 */             propertyName = fieldAnnotation.name();
/* 1024 */             if (aliasMap != null) {
/* 1025 */               propertyName = aliasMap.get(propertyName);
/* 1026 */               if (propertyName == null) {
/*      */                 continue;
/*      */               }
/*      */             } 
/*      */           } 
/* 1031 */           if (fieldAnnotation.label().length() != 0) {
/* 1032 */             label = fieldAnnotation.label();
/*      */           }
/*      */         } 
/*      */       } 
/* 1036 */       if (aliasMap != null) {
/* 1037 */         propertyName = aliasMap.get(propertyName);
/* 1038 */         if (propertyName == null) {
/*      */           continue;
/*      */         }
/*      */       } 
/* 1042 */       if (propertyNamingStrategy != null) {
/* 1043 */         propertyName = propertyNamingStrategy.translate(propertyName);
/*      */       }
/*      */       
/* 1046 */       if (!fieldInfoMap.containsKey(propertyName)) {
/*      */ 
/*      */         
/* 1049 */         FieldInfo fieldInfo = new FieldInfo(propertyName, method, field, clazz, null, ordinal, serialzeFeatures, parserFeatures, annotation, fieldAnnotation, label);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1062 */         fieldInfoMap.put(propertyName, fieldInfo);
/*      */       }  continue;
/*      */     } 
/* 1065 */     Field[] fields = clazz.getFields();
/* 1066 */     computeFields(clazz, aliasMap, propertyNamingStrategy, fieldInfoMap, fields);
/* 1067 */     return getFieldInfos(clazz, sorted, fieldInfoMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void computeFields(Class<?> clazz, Map<String, String> aliasMap, PropertyNamingStrategy propertyNamingStrategy, Map<String, FieldInfo> fieldInfoMap, Field[] fields) {
/* 1077 */     for (Field field : fields) {
/* 1078 */       if (Modifier.isStatic(field.getModifiers())) {
/*      */         continue;
/*      */       }
/* 1081 */       JSONField fieldAnnotation = getAnnotation(field, JSONField.class);
/* 1082 */       int ordinal = 0, serialzeFeatures = 0, parserFeatures = 0;
/* 1083 */       String propertyName = field.getName();
/* 1084 */       String label = null;
/* 1085 */       if (fieldAnnotation != null) {
/* 1086 */         if (!fieldAnnotation.serialize()) {
/*      */           continue;
/*      */         }
/* 1089 */         ordinal = fieldAnnotation.ordinal();
/* 1090 */         serialzeFeatures = SerializerFeature.of(fieldAnnotation.serialzeFeatures());
/* 1091 */         parserFeatures = Feature.of(fieldAnnotation.parseFeatures());
/* 1092 */         if (fieldAnnotation.name().length() != 0) {
/* 1093 */           propertyName = fieldAnnotation.name();
/*      */         }
/* 1095 */         if (fieldAnnotation.label().length() != 0) {
/* 1096 */           label = fieldAnnotation.label();
/*      */         }
/*      */       } 
/* 1099 */       if (aliasMap != null) {
/* 1100 */         propertyName = aliasMap.get(propertyName);
/* 1101 */         if (propertyName == null) {
/*      */           continue;
/*      */         }
/*      */       } 
/* 1105 */       if (propertyNamingStrategy != null) {
/* 1106 */         propertyName = propertyNamingStrategy.translate(propertyName);
/*      */       }
/* 1108 */       if (!fieldInfoMap.containsKey(propertyName)) {
/* 1109 */         FieldInfo fieldInfo = new FieldInfo(propertyName, null, field, clazz, null, ordinal, serialzeFeatures, parserFeatures, null, fieldAnnotation, label);
/*      */         
/* 1111 */         fieldInfoMap.put(propertyName, fieldInfo);
/*      */       } 
/*      */       continue;
/*      */     } 
/*      */   }
/*      */   private static List<FieldInfo> getFieldInfos(Class<?> clazz, boolean sorted, Map<String, FieldInfo> fieldInfoMap) {
/* 1117 */     List<FieldInfo> fieldInfoList = new ArrayList<>();
/* 1118 */     String[] orders = null;
/* 1119 */     JSONType annotation = getAnnotation(clazz, JSONType.class);
/* 1120 */     if (annotation != null) {
/* 1121 */       orders = annotation.orders();
/*      */     }
/* 1123 */     if (orders != null && orders.length > 0) {
/* 1124 */       LinkedHashMap<String, FieldInfo> map = new LinkedHashMap<>(fieldInfoMap.size());
/* 1125 */       for (FieldInfo field : fieldInfoMap.values()) {
/* 1126 */         map.put(field.name, field);
/*      */       }
/* 1128 */       for (String item : orders) {
/* 1129 */         FieldInfo field = map.get(item);
/* 1130 */         if (field != null) {
/* 1131 */           fieldInfoList.add(field);
/* 1132 */           map.remove(item);
/*      */         } 
/*      */       } 
/* 1135 */       fieldInfoList.addAll(map.values());
/*      */     } else {
/* 1137 */       fieldInfoList.addAll(fieldInfoMap.values());
/* 1138 */       if (sorted) {
/* 1139 */         Collections.sort(fieldInfoList);
/*      */       }
/*      */     } 
/* 1142 */     return fieldInfoList;
/*      */   }
/*      */   
/*      */   static void setAccessible(AccessibleObject obj) {
/* 1146 */     if (!setAccessibleEnable) {
/*      */       return;
/*      */     }
/* 1149 */     if (obj.isAccessible()) {
/*      */       return;
/*      */     }
/*      */     try {
/* 1153 */       obj.setAccessible(true);
/* 1154 */     } catch (Throwable error) {
/* 1155 */       setAccessibleEnable = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean isKotlin(Class clazz) {
/* 1160 */     if (kotlin_metadata == null && !kotlin_metadata_error) {
/*      */       try {
/* 1162 */         kotlin_metadata = Class.forName("kotlin.Metadata");
/* 1163 */       } catch (Throwable e) {
/* 1164 */         kotlin_metadata_error = true;
/*      */       } 
/*      */     }
/* 1167 */     return (kotlin_metadata != null && clazz.isAnnotationPresent(kotlin_metadata));
/*      */   }
/*      */   
/*      */   public static Constructor getKotlinConstructor(Constructor[] constructors) {
/* 1171 */     return getKotlinConstructor(constructors, null);
/*      */   }
/*      */   
/*      */   public static Constructor getKotlinConstructor(Constructor[] constructors, String[] paramNames) {
/* 1175 */     Constructor<?> creatorConstructor = null;
/* 1176 */     for (Constructor<?> constructor : constructors) {
/* 1177 */       Class<?>[] parameterTypes = constructor.getParameterTypes();
/* 1178 */       if (paramNames == null || parameterTypes.length == paramNames.length)
/*      */       {
/*      */ 
/*      */         
/* 1182 */         if (parameterTypes.length <= 0 || !parameterTypes[parameterTypes.length - 1].getName().equals("kotlin.jvm.internal.DefaultConstructorMarker"))
/*      */         {
/*      */           
/* 1185 */           if (creatorConstructor == null || (creatorConstructor.getParameterTypes()).length < parameterTypes.length)
/*      */           {
/*      */             
/* 1188 */             creatorConstructor = constructor; }  }  } 
/*      */     } 
/* 1190 */     return creatorConstructor;
/*      */   }
/*      */   
/*      */   public static String[] getKoltinConstructorParameters(Class clazz) {
/* 1194 */     if (kotlin_kclass_constructor == null && !kotlin_class_klass_error) {
/*      */       try {
/* 1196 */         Class<?> class_kotlin_kclass = Class.forName("kotlin.reflect.jvm.internal.KClassImpl");
/* 1197 */         kotlin_kclass_constructor = class_kotlin_kclass.getConstructor(new Class[] { Class.class });
/* 1198 */       } catch (Throwable e) {
/* 1199 */         kotlin_class_klass_error = true;
/*      */       } 
/*      */     }
/* 1202 */     if (kotlin_kclass_constructor == null) {
/* 1203 */       return null;
/*      */     }
/*      */     
/* 1206 */     if (kotlin_kclass_getConstructors == null && !kotlin_class_klass_error) {
/*      */       try {
/* 1208 */         Class<?> class_kotlin_kclass = Class.forName("kotlin.reflect.jvm.internal.KClassImpl");
/* 1209 */         kotlin_kclass_getConstructors = class_kotlin_kclass.getMethod("getConstructors", new Class[0]);
/* 1210 */       } catch (Throwable e) {
/* 1211 */         kotlin_class_klass_error = true;
/*      */       } 
/*      */     }
/*      */     
/* 1215 */     if (kotlin_kfunction_getParameters == null && !kotlin_class_klass_error) {
/*      */       try {
/* 1217 */         Class<?> class_kotlin_kfunction = Class.forName("kotlin.reflect.KFunction");
/* 1218 */         kotlin_kfunction_getParameters = class_kotlin_kfunction.getMethod("getParameters", new Class[0]);
/* 1219 */       } catch (Throwable e) {
/* 1220 */         kotlin_class_klass_error = true;
/*      */       } 
/*      */     }
/*      */     
/* 1224 */     if (kotlin_kparameter_getName == null && !kotlin_class_klass_error) {
/*      */       try {
/* 1226 */         Class<?> class_kotlinn_kparameter = Class.forName("kotlin.reflect.KParameter");
/* 1227 */         kotlin_kparameter_getName = class_kotlinn_kparameter.getMethod("getName", new Class[0]);
/* 1228 */       } catch (Throwable e) {
/* 1229 */         kotlin_class_klass_error = true;
/*      */       } 
/*      */     }
/*      */     
/* 1233 */     if (kotlin_error) {
/* 1234 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 1238 */       Object constructor = null;
/* 1239 */       Object kclassImpl = kotlin_kclass_constructor.newInstance(new Object[] { clazz });
/* 1240 */       Iterable it = (Iterable)kotlin_kclass_getConstructors.invoke(kclassImpl, new Object[0]);
/* 1241 */       for (Iterator iterator = it.iterator(); iterator.hasNext(); iterator.hasNext()) {
/* 1242 */         Object item = iterator.next();
/* 1243 */         List list = (List)kotlin_kfunction_getParameters.invoke(item, new Object[0]);
/* 1244 */         if (constructor == null || list.size() != 0)
/*      */         {
/*      */           
/* 1247 */           constructor = item;
/*      */         }
/*      */       } 
/* 1250 */       if (constructor == null) {
/* 1251 */         return null;
/*      */       }
/*      */       
/* 1254 */       List parameters = (List)kotlin_kfunction_getParameters.invoke(constructor, new Object[0]);
/* 1255 */       String[] names = new String[parameters.size()];
/* 1256 */       for (int i = 0; i < parameters.size(); i++) {
/* 1257 */         Object param = parameters.get(i);
/* 1258 */         names[i] = (String)kotlin_kparameter_getName.invoke(param, new Object[0]);
/*      */       } 
/* 1260 */       return names;
/* 1261 */     } catch (Throwable e) {
/* 1262 */       e.printStackTrace();
/* 1263 */       kotlin_error = true;
/*      */       
/* 1265 */       return null;
/*      */     } 
/*      */   }
/*      */   static boolean isKotlinIgnore(Class clazz, String methodName) {
/* 1269 */     if (kotlinIgnores == null && !kotlinIgnores_error) {
/*      */       try {
/* 1271 */         Map<Class<?>, String[]> map = (Map)new HashMap<>();
/* 1272 */         Class<?> charRangeClass = Class.forName("kotlin.ranges.CharRange");
/* 1273 */         map.put(charRangeClass, new String[] { "getEndInclusive", "isEmpty" });
/* 1274 */         Class<?> intRangeClass = Class.forName("kotlin.ranges.IntRange");
/* 1275 */         map.put(intRangeClass, new String[] { "getEndInclusive", "isEmpty" });
/* 1276 */         Class<?> longRangeClass = Class.forName("kotlin.ranges.LongRange");
/* 1277 */         map.put(longRangeClass, new String[] { "getEndInclusive", "isEmpty" });
/* 1278 */         Class<?> floatRangeClass = Class.forName("kotlin.ranges.ClosedFloatRange");
/* 1279 */         map.put(floatRangeClass, new String[] { "getEndInclusive", "isEmpty" });
/* 1280 */         Class<?> doubleRangeClass = Class.forName("kotlin.ranges.ClosedDoubleRange");
/* 1281 */         map.put(doubleRangeClass, new String[] { "getEndInclusive", "isEmpty" });
/* 1282 */         kotlinIgnores = map;
/* 1283 */       } catch (Throwable error) {
/* 1284 */         kotlinIgnores_error = true;
/*      */       } 
/*      */     }
/* 1287 */     if (kotlinIgnores == null) {
/* 1288 */       return false;
/*      */     }
/* 1290 */     String[] ignores = kotlinIgnores.get(clazz);
/* 1291 */     return (ignores != null && Arrays.binarySearch((Object[])ignores, methodName) >= 0);
/*      */   }
/*      */   
/*      */   private static boolean isJSONTypeIgnore(Class<?> clazz, String propertyName) {
/* 1295 */     JSONType jsonType = getAnnotation(clazz, JSONType.class);
/* 1296 */     if (jsonType != null) {
/*      */ 
/*      */ 
/*      */       
/* 1300 */       String[] fields = jsonType.includes();
/* 1301 */       if (fields.length > 0) {
/* 1302 */         for (String field : fields) {
/* 1303 */           if (propertyName.equals(field)) {
/* 1304 */             return false;
/*      */           }
/*      */         } 
/* 1307 */         return true;
/*      */       } 
/* 1309 */       fields = jsonType.ignores();
/* 1310 */       for (String field : fields) {
/* 1311 */         if (propertyName.equals(field)) {
/* 1312 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1317 */     if (clazz.getSuperclass() != Object.class && clazz.getSuperclass() != null) {
/* 1318 */       return isJSONTypeIgnore(clazz.getSuperclass(), propertyName);
/*      */     }
/* 1320 */     return false;
/*      */   }
/*      */   
/*      */   public static JSONField getSuperMethodAnnotation(Class<?> clazz, Method method) {
/* 1324 */     Class<?>[] interfaces = clazz.getInterfaces();
/* 1325 */     if (interfaces.length > 0) {
/* 1326 */       Class<?>[] types = method.getParameterTypes();
/* 1327 */       for (Class<?> interfaceClass : interfaces) {
/* 1328 */         for (Method interfaceMethod : interfaceClass.getMethods()) {
/* 1329 */           Class<?>[] interfaceTypes = interfaceMethod.getParameterTypes();
/* 1330 */           if (interfaceTypes.length == types.length)
/*      */           {
/*      */             
/* 1333 */             if (interfaceMethod.getName().equals(method.getName())) {
/*      */ 
/*      */               
/* 1336 */               boolean match = true;
/* 1337 */               for (int i = 0; i < types.length; i++) {
/* 1338 */                 if (!interfaceTypes[i].equals(types[i])) {
/* 1339 */                   match = false;
/*      */                   break;
/*      */                 } 
/*      */               } 
/* 1343 */               if (match) {
/*      */ 
/*      */                 
/* 1346 */                 JSONField annotation = getAnnotation(interfaceMethod, JSONField.class);
/* 1347 */                 if (annotation != null)
/* 1348 */                   return annotation; 
/*      */               } 
/*      */             }  } 
/*      */         } 
/*      */       } 
/* 1353 */     }  Class<?> superClass = clazz.getSuperclass();
/* 1354 */     if (superClass == null) {
/* 1355 */       return null;
/*      */     }
/* 1357 */     if (Modifier.isAbstract(superClass.getModifiers())) {
/* 1358 */       Class<?>[] types = method.getParameterTypes();
/* 1359 */       for (Method interfaceMethod : superClass.getMethods()) {
/* 1360 */         Class<?>[] interfaceTypes = interfaceMethod.getParameterTypes();
/* 1361 */         if (interfaceTypes.length == types.length)
/*      */         {
/*      */           
/* 1364 */           if (interfaceMethod.getName().equals(method.getName())) {
/*      */ 
/*      */             
/* 1367 */             boolean match = true;
/* 1368 */             for (int i = 0; i < types.length; i++) {
/* 1369 */               if (!interfaceTypes[i].equals(types[i])) {
/* 1370 */                 match = false;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1374 */             if (match) {
/*      */ 
/*      */               
/* 1377 */               JSONField annotation = getAnnotation(interfaceMethod, JSONField.class);
/* 1378 */               if (annotation != null)
/* 1379 */                 return annotation; 
/*      */             } 
/*      */           }  } 
/*      */       } 
/* 1383 */     }  return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static String getPropertyNameByCompatibleFieldName(Map<String, Field> fieldCacheMap, String methodName, String propertyName, int fromIdx) {
/* 1388 */     if (compatibleWithFieldName && 
/* 1389 */       !fieldCacheMap.containsKey(propertyName)) {
/* 1390 */       String tempPropertyName = methodName.substring(fromIdx);
/* 1391 */       return fieldCacheMap.containsKey(tempPropertyName) ? tempPropertyName : propertyName;
/*      */     } 
/*      */     
/* 1394 */     return propertyName;
/*      */   }
/*      */   
/*      */   public static String decapitalize(String name) {
/* 1398 */     if (name == null || name.length() == 0) {
/* 1399 */       return name;
/*      */     }
/* 1401 */     if (name.length() > 1 && Character.isUpperCase(name.charAt(1)) && Character.isUpperCase(name.charAt(0))) {
/* 1402 */       return name;
/*      */     }
/* 1404 */     char[] chars = name.toCharArray();
/* 1405 */     chars[0] = Character.toLowerCase(chars[0]);
/* 1406 */     return new String(chars);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPropertyNameByMethodName(String methodName) {
/* 1416 */     return Character.toLowerCase(methodName.charAt(3)) + methodName.substring(4);
/*      */   }
/*      */   
/*      */   public static Annotation[][] getParameterAnnotations(Constructor<?> constructor) {
/* 1420 */     Annotation[][] targetAnnotations = constructor.getParameterAnnotations();
/*      */     
/* 1422 */     Class<?> clazz = constructor.getDeclaringClass();
/*      */     
/* 1424 */     Class<?> mixInClass = null;
/* 1425 */     Type type = JSON.getMixInAnnotations(clazz);
/* 1426 */     if (type instanceof Class) {
/* 1427 */       mixInClass = (Class)type;
/*      */     }
/*      */     
/* 1430 */     if (mixInClass != null) {
/* 1431 */       Constructor<?> mixInConstructor = null;
/* 1432 */       Class<?>[] parameterTypes = constructor.getParameterTypes();
/*      */       
/* 1434 */       List<Class<?>> enclosingClasses = new ArrayList<>(2);
/* 1435 */       for (Class<?> enclosingClass = mixInClass.getEnclosingClass(); enclosingClass != null; enclosingClass = enclosingClass.getEnclosingClass()) {
/* 1436 */         enclosingClasses.add(enclosingClass);
/*      */       }
/* 1438 */       int level = enclosingClasses.size();
/*      */       
/* 1440 */       for (Class<?> currClass = mixInClass; currClass != null && currClass != Object.class; currClass = currClass.getSuperclass()) {
/*      */         try {
/* 1442 */           if (level != 0) {
/* 1443 */             Class<?>[] outerClassAndParameterTypes = new Class[level + parameterTypes.length];
/* 1444 */             System.arraycopy(parameterTypes, 0, outerClassAndParameterTypes, level, parameterTypes.length);
/* 1445 */             for (int i = level; i > 0; i--) {
/* 1446 */               outerClassAndParameterTypes[i - 1] = enclosingClasses.get(i - 1);
/*      */             }
/* 1448 */             mixInConstructor = mixInClass.getDeclaredConstructor(outerClassAndParameterTypes); break;
/*      */           } 
/* 1450 */           mixInConstructor = mixInClass.getDeclaredConstructor(parameterTypes);
/*      */           
/*      */           break;
/* 1453 */         } catch (NoSuchMethodException e) {
/* 1454 */           level--;
/*      */         } 
/*      */       } 
/* 1457 */       if (mixInConstructor == null) {
/* 1458 */         return targetAnnotations;
/*      */       }
/* 1460 */       Annotation[][] mixInAnnotations = mixInConstructor.getParameterAnnotations();
/* 1461 */       if (mixInAnnotations != null) {
/* 1462 */         return mixInAnnotations;
/*      */       }
/*      */     } 
/* 1465 */     return targetAnnotations;
/*      */   }
/*      */   
/*      */   public static class MethodInheritanceComparator
/*      */     implements Comparator<Method> {
/*      */     public int compare(Method m1, Method m2) {
/* 1471 */       int cmp = m1.getName().compareTo(m2.getName());
/* 1472 */       if (cmp != 0) {
/* 1473 */         return cmp;
/*      */       }
/*      */       
/* 1476 */       Class<?> class1 = m1.getReturnType();
/* 1477 */       Class<?> class2 = m2.getReturnType();
/*      */       
/* 1479 */       if (class1.equals(class2)) {
/* 1480 */         return 0;
/*      */       }
/*      */       
/* 1483 */       if (class1.isAssignableFrom(class2)) {
/* 1484 */         return -1;
/*      */       }
/*      */       
/* 1487 */       if (class2.isAssignableFrom(class1)) {
/* 1488 */         return 1;
/*      */       }
/* 1490 */       return 0;
/*      */     }
/*      */   }
/*      */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjso\\util\TypeUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */