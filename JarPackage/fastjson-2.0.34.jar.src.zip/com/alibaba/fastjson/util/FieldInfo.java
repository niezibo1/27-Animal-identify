/*     */ package com.alibaba.fastjson.util;
/*     */ 
/*     */ import com.alibaba.fastjson.TypeReference;
/*     */ import com.alibaba.fastjson.annotation.JSONField;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.GenericDeclaration;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldInfo
/*     */   implements Comparable<FieldInfo>
/*     */ {
/*     */   public final String name;
/*     */   public final Method method;
/*     */   public final Field field;
/*     */   private int ordinal;
/*     */   public final Class<?> fieldClass;
/*     */   public final Type fieldType;
/*     */   public final Class<?> declaringClass;
/*     */   public final boolean getOnly;
/*     */   public final int serialzeFeatures;
/*     */   public final int parserFeatures;
/*     */   public final String label;
/*     */   private final JSONField fieldAnnotation;
/*     */   private final JSONField methodAnnotation;
/*     */   public final boolean fieldAccess;
/*     */   public final boolean fieldTransient;
/*     */   public final char[] nameChars;
/*     */   public final boolean isEnum;
/*     */   public final boolean jsonDirect;
/*     */   public final boolean unwrapped;
/*     */   public final String format;
/*     */   public final String[] alternateNames;
/*     */   public final long nameHashCode;
/*     */   
/*     */   public FieldInfo(String name, Method method, Field field, Class<?> clazz, Type type, int ordinal, int serialzeFeatures, int parserFeatures, JSONField fieldAnnotation, JSONField methodAnnotation, String label) {
/*  55 */     this(name, method, field, clazz, type, ordinal, serialzeFeatures, parserFeatures, fieldAnnotation, methodAnnotation, label, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldInfo(String name, Method method, Field field, Class<?> clazz, Type type, int ordinal, int serialzeFeatures, int parserFeatures, JSONField fieldAnnotation, JSONField methodAnnotation, String label, Map<TypeVariable, Type> genericInfo) {
/*     */     Type fieldType;
/*     */     Class<?> fieldClass;
/*  72 */     if (field != null) {
/*  73 */       String fieldName = field.getName();
/*  74 */       if (fieldName.equals(name)) {
/*  75 */         name = fieldName;
/*     */       }
/*     */     } 
/*     */     
/*  79 */     if (ordinal < 0) {
/*  80 */       ordinal = 0;
/*     */     }
/*     */     
/*  83 */     this.name = name;
/*  84 */     this.method = method;
/*  85 */     this.field = field;
/*  86 */     this.ordinal = ordinal;
/*  87 */     this.serialzeFeatures = serialzeFeatures;
/*  88 */     this.parserFeatures = parserFeatures;
/*  89 */     this.fieldAnnotation = fieldAnnotation;
/*  90 */     this.methodAnnotation = methodAnnotation;
/*     */     
/*  92 */     if (field != null) {
/*  93 */       int modifiers = field.getModifiers();
/*  94 */       this.fieldAccess = ((modifiers & 0x1) != 0 || method == null);
/*  95 */       this
/*  96 */         .fieldTransient = (Modifier.isTransient(modifiers) || TypeUtils.isTransient(method));
/*     */     } else {
/*  98 */       this.fieldAccess = false;
/*  99 */       this.fieldTransient = TypeUtils.isTransient(method);
/*     */     } 
/*     */     
/* 102 */     if (label != null && label.length() > 0) {
/* 103 */       this.label = label;
/*     */     } else {
/* 105 */       this.label = "";
/*     */     } 
/*     */     
/* 108 */     String format = null;
/* 109 */     JSONField annotation = getAnnotation();
/*     */     
/* 111 */     this.nameHashCode = nameHashCode64(name, annotation);
/*     */     
/* 113 */     boolean jsonDirect = false;
/* 114 */     if (annotation != null) {
/* 115 */       format = annotation.format();
/*     */       
/* 117 */       if (format.trim().length() == 0) {
/* 118 */         format = null;
/*     */       }
/* 120 */       jsonDirect = annotation.jsonDirect();
/* 121 */       this.unwrapped = annotation.unwrapped();
/* 122 */       this.alternateNames = annotation.alternateNames();
/*     */     } else {
/* 124 */       jsonDirect = false;
/* 125 */       this.unwrapped = false;
/* 126 */       this.alternateNames = new String[0];
/*     */     } 
/* 128 */     this.format = format;
/*     */     
/* 130 */     this.nameChars = genFieldNameChars();
/*     */     
/* 132 */     if (method != null) {
/* 133 */       TypeUtils.setAccessible(method);
/*     */     }
/*     */     
/* 136 */     if (field != null) {
/* 137 */       TypeUtils.setAccessible(field);
/*     */     }
/*     */     
/* 140 */     boolean getOnly = false;
/*     */ 
/*     */     
/* 143 */     if (method != null) {
/*     */       Class<?>[] types;
/* 145 */       if ((types = method.getParameterTypes()).length == 1) {
/* 146 */         fieldClass = types[0];
/* 147 */         fieldType = method.getGenericParameterTypes()[0];
/* 148 */       } else if (types.length == 2 && types[0] == String.class && types[1] == Object.class) {
/* 149 */         fieldType = fieldClass = types[0];
/*     */       } else {
/* 151 */         fieldClass = method.getReturnType();
/* 152 */         fieldType = method.getGenericReturnType();
/* 153 */         getOnly = true;
/*     */       } 
/* 155 */       this.declaringClass = method.getDeclaringClass();
/*     */     } else {
/* 157 */       fieldClass = field.getType();
/* 158 */       fieldType = field.getGenericType();
/* 159 */       this.declaringClass = field.getDeclaringClass();
/* 160 */       getOnly = Modifier.isFinal(field.getModifiers());
/*     */     } 
/* 162 */     this.getOnly = getOnly;
/* 163 */     this.jsonDirect = (jsonDirect && fieldClass == String.class);
/*     */     
/* 165 */     if (clazz != null && fieldClass == Object.class && fieldType instanceof TypeVariable) {
/* 166 */       TypeVariable<?> tv = (TypeVariable)fieldType;
/* 167 */       Type type1 = getInheritGenericType(clazz, type, tv);
/* 168 */       if (type1 != null) {
/* 169 */         this.fieldClass = TypeUtils.getClass(type1);
/* 170 */         this.fieldType = type1;
/*     */         
/* 172 */         this.isEnum = fieldClass.isEnum();
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 177 */     Type genericFieldType = fieldType;
/*     */     
/* 179 */     if (!(fieldType instanceof Class)) {
/* 180 */       genericFieldType = getFieldType(clazz, (type != null) ? type : clazz, fieldType, genericInfo);
/*     */       
/* 182 */       if (genericFieldType != fieldType) {
/* 183 */         if (genericFieldType instanceof ParameterizedType) {
/* 184 */           fieldClass = TypeUtils.getClass(genericFieldType);
/* 185 */         } else if (genericFieldType instanceof Class) {
/* 186 */           fieldClass = TypeUtils.getClass(genericFieldType);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 191 */     this.fieldType = genericFieldType;
/* 192 */     this.fieldClass = fieldClass;
/*     */     
/* 194 */     this.isEnum = fieldClass.isEnum();
/*     */   }
/*     */   
/*     */   private long nameHashCode64(String name, JSONField annotation) {
/* 198 */     if (annotation != null && annotation.name().length() != 0) {
/* 199 */       return TypeUtils.fnv1a_64_lower(name);
/*     */     }
/* 201 */     return TypeUtils.fnv1a_64_extract(name);
/*     */   }
/*     */   
/*     */   protected char[] genFieldNameChars() {
/* 205 */     int nameLen = this.name.length();
/* 206 */     char[] name_chars = new char[nameLen + 3];
/* 207 */     this.name.getChars(0, this.name.length(), name_chars, 1);
/* 208 */     name_chars[0] = '"';
/* 209 */     name_chars[nameLen + 1] = '"';
/* 210 */     name_chars[nameLen + 2] = ':';
/* 211 */     return name_chars;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getFieldType(Class<?> clazz, Type type, Type fieldType, Map<TypeVariable, Type> genericInfo) {
/* 220 */     if (clazz == null || type == null) {
/* 221 */       return fieldType;
/*     */     }
/*     */     
/* 224 */     if (fieldType instanceof GenericArrayType) {
/* 225 */       GenericArrayType genericArrayType = (GenericArrayType)fieldType;
/* 226 */       Type componentType = genericArrayType.getGenericComponentType();
/* 227 */       Type componentTypeX = getFieldType(clazz, type, componentType, genericInfo);
/* 228 */       if (componentType != componentTypeX) {
/* 229 */         Type<?> fieldTypeX = Array.newInstance(TypeUtils.getClass(componentTypeX), 0).getClass();
/* 230 */         return fieldTypeX;
/*     */       } 
/*     */       
/* 233 */       return fieldType;
/*     */     } 
/*     */     
/* 236 */     if (!TypeUtils.isGenericParamType(type)) {
/* 237 */       return fieldType;
/*     */     }
/*     */     
/* 240 */     if (fieldType instanceof TypeVariable) {
/* 241 */       ParameterizedType paramType = (ParameterizedType)TypeUtils.getGenericParamType(type);
/* 242 */       Class<?> parameterizedClass = TypeUtils.getClass(paramType);
/* 243 */       TypeVariable<?> typeVar = (TypeVariable)fieldType;
/*     */       
/* 245 */       TypeVariable[] arrayOfTypeVariable = (TypeVariable[])parameterizedClass.getTypeParameters();
/* 246 */       for (int i = 0; i < arrayOfTypeVariable.length; i++) {
/* 247 */         if (arrayOfTypeVariable[i].getName().equals(typeVar.getName())) {
/* 248 */           fieldType = paramType.getActualTypeArguments()[i];
/* 249 */           return fieldType;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 254 */     if (fieldType instanceof ParameterizedType) {
/* 255 */       ParameterizedType parameterizedFieldType = (ParameterizedType)fieldType;
/*     */       
/* 257 */       Type[] arguments = parameterizedFieldType.getActualTypeArguments();
/*     */ 
/*     */ 
/*     */       
/* 261 */       boolean changed = getArgument(arguments, genericInfo);
/*     */       
/* 263 */       if (!changed) {
/* 264 */         TypeVariable[] arrayOfTypeVariable; ParameterizedType paramType; if (type instanceof ParameterizedType) {
/* 265 */           paramType = (ParameterizedType)type;
/* 266 */           arrayOfTypeVariable = (TypeVariable[])clazz.getTypeParameters();
/* 267 */         } else if (clazz.getGenericSuperclass() instanceof ParameterizedType) {
/* 268 */           paramType = (ParameterizedType)clazz.getGenericSuperclass();
/* 269 */           arrayOfTypeVariable = clazz.getSuperclass().getTypeParameters();
/*     */         } else {
/* 271 */           paramType = parameterizedFieldType;
/* 272 */           arrayOfTypeVariable = (TypeVariable[])type.getClass().getTypeParameters();
/*     */         } 
/*     */         
/* 275 */         changed = getArgument(arguments, arrayOfTypeVariable, paramType.getActualTypeArguments());
/*     */       } 
/*     */       
/* 278 */       if (changed) {
/* 279 */         fieldType = TypeReference.intern(new ParameterizedTypeImpl(arguments, parameterizedFieldType
/* 280 */               .getOwnerType(), parameterizedFieldType
/* 281 */               .getRawType()));
/*     */         
/* 283 */         return fieldType;
/*     */       } 
/*     */     } 
/*     */     
/* 287 */     return fieldType;
/*     */   }
/*     */   
/*     */   private static boolean getArgument(Type[] typeArgs, Map<TypeVariable, Type> genericInfo) {
/* 291 */     if (genericInfo == null || genericInfo.size() == 0) {
/* 292 */       return false;
/*     */     }
/* 294 */     boolean changed = false;
/* 295 */     for (int i = 0; i < typeArgs.length; i++) {
/* 296 */       Type typeArg = typeArgs[i];
/* 297 */       if (typeArg instanceof ParameterizedType) {
/* 298 */         ParameterizedType p_typeArg = (ParameterizedType)typeArg;
/* 299 */         Type[] p_typeArg_args = p_typeArg.getActualTypeArguments();
/* 300 */         boolean p_changed = getArgument(p_typeArg_args, genericInfo);
/* 301 */         if (p_changed) {
/* 302 */           typeArgs[i] = TypeReference.intern(new ParameterizedTypeImpl(p_typeArg_args, p_typeArg
/* 303 */                 .getOwnerType(), p_typeArg.getRawType()));
/*     */           
/* 305 */           changed = true;
/*     */         } 
/* 307 */       } else if (typeArg instanceof TypeVariable && 
/* 308 */         genericInfo.containsKey(typeArg)) {
/* 309 */         typeArgs[i] = genericInfo.get(typeArg);
/* 310 */         changed = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 315 */     return changed;
/*     */   }
/*     */   
/*     */   private static boolean getArgument(Type[] typeArgs, TypeVariable[] typeVariables, Type[] arguments) {
/* 319 */     if (arguments == null || typeVariables.length == 0) {
/* 320 */       return false;
/*     */     }
/*     */     
/* 323 */     boolean changed = false;
/* 324 */     for (int i = 0; i < typeArgs.length; i++) {
/* 325 */       Type typeArg = typeArgs[i];
/* 326 */       if (typeArg instanceof ParameterizedType) {
/* 327 */         ParameterizedType p_typeArg = (ParameterizedType)typeArg;
/* 328 */         Type[] p_typeArg_args = p_typeArg.getActualTypeArguments();
/* 329 */         boolean p_changed = getArgument(p_typeArg_args, typeVariables, arguments);
/* 330 */         if (p_changed) {
/* 331 */           typeArgs[i] = TypeReference.intern(new ParameterizedTypeImpl(p_typeArg_args, p_typeArg
/* 332 */                 .getOwnerType(), p_typeArg.getRawType()));
/*     */           
/* 334 */           changed = true;
/*     */         } 
/* 336 */       } else if (typeArg instanceof TypeVariable) {
/* 337 */         for (int j = 0; j < typeVariables.length; j++) {
/* 338 */           if (typeArg.equals(typeVariables[j])) {
/* 339 */             typeArgs[i] = arguments[j];
/* 340 */             changed = true;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 346 */     return changed;
/*     */   }
/*     */   
/*     */   private static Type getInheritGenericType(Class<?> clazz, Type type, TypeVariable<?> tv) {
/* 350 */     GenericDeclaration gd = (GenericDeclaration)tv.getGenericDeclaration();
/*     */     
/* 352 */     Class<?> class_gd = null;
/* 353 */     if (gd instanceof Class) {
/* 354 */       class_gd = (Class)tv.getGenericDeclaration();
/*     */     }
/*     */     
/* 357 */     Type[] arguments = null;
/* 358 */     if (class_gd == clazz) {
/* 359 */       if (type instanceof ParameterizedType) {
/* 360 */         ParameterizedType ptype = (ParameterizedType)type;
/* 361 */         arguments = ptype.getActualTypeArguments();
/*     */       } 
/*     */     } else {
/* 364 */       for (Class<?> c = clazz; c != null && c != Object.class && c != class_gd; c = c.getSuperclass()) {
/* 365 */         Type superType = c.getGenericSuperclass();
/*     */         
/* 367 */         if (superType instanceof ParameterizedType) {
/* 368 */           ParameterizedType p_superType = (ParameterizedType)superType;
/* 369 */           Type[] p_superType_args = p_superType.getActualTypeArguments();
/* 370 */           getArgument(p_superType_args, (TypeVariable[])c.getTypeParameters(), arguments);
/* 371 */           arguments = p_superType_args;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 376 */     if (arguments == null || class_gd == null) {
/* 377 */       return null;
/*     */     }
/*     */     
/* 380 */     Type actualType = null;
/* 381 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])class_gd.getTypeParameters();
/* 382 */     for (int j = 0; j < arrayOfTypeVariable.length; j++) {
/* 383 */       if (tv.equals(arrayOfTypeVariable[j])) {
/* 384 */         actualType = arguments[j];
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 389 */     return actualType;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 393 */     return this.name;
/*     */   }
/*     */   
/*     */   public Member getMember() {
/* 397 */     if (this.method != null) {
/* 398 */       return this.method;
/*     */     }
/* 400 */     return this.field;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<?> getDeclaredClass() {
/* 405 */     if (this.method != null) {
/* 406 */       return this.method.getDeclaringClass();
/*     */     }
/*     */     
/* 409 */     if (this.field != null) {
/* 410 */       return this.field.getDeclaringClass();
/*     */     }
/*     */     
/* 413 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(FieldInfo o) {
/* 418 */     if (o.method != null && this.method != null && o.method
/* 419 */       .isBridge() && !this.method.isBridge() && o.method
/* 420 */       .getName().equals(this.method.getName())) {
/* 421 */       return 1;
/*     */     }
/*     */     
/* 424 */     if (this.ordinal < o.ordinal) {
/* 425 */       return -1;
/*     */     }
/*     */     
/* 428 */     if (this.ordinal > o.ordinal) {
/* 429 */       return 1;
/*     */     }
/*     */     
/* 432 */     int result = this.name.compareTo(o.name);
/*     */     
/* 434 */     if (result != 0) {
/* 435 */       return result;
/*     */     }
/*     */     
/* 438 */     Class<?> thisDeclaringClass = getDeclaredClass();
/* 439 */     Class<?> otherDeclaringClass = o.getDeclaredClass();
/*     */     
/* 441 */     if (thisDeclaringClass != null && otherDeclaringClass != null && thisDeclaringClass != otherDeclaringClass) {
/* 442 */       if (thisDeclaringClass.isAssignableFrom(otherDeclaringClass)) {
/* 443 */         return -1;
/*     */       }
/*     */       
/* 446 */       if (otherDeclaringClass.isAssignableFrom(thisDeclaringClass)) {
/* 447 */         return 1;
/*     */       }
/*     */     } 
/* 450 */     boolean isSampeType = (this.field != null && this.field.getType() == this.fieldClass);
/* 451 */     boolean oSameType = (o.field != null && o.field.getType() == o.fieldClass);
/*     */     
/* 453 */     if (isSampeType && !oSameType) {
/* 454 */       return 1;
/*     */     }
/*     */     
/* 457 */     if (oSameType && !isSampeType) {
/* 458 */       return -1;
/*     */     }
/*     */     
/* 461 */     if (o.fieldClass.isPrimitive() && !this.fieldClass.isPrimitive()) {
/* 462 */       return 1;
/*     */     }
/*     */     
/* 465 */     if (this.fieldClass.isPrimitive() && !o.fieldClass.isPrimitive()) {
/* 466 */       return -1;
/*     */     }
/*     */     
/* 469 */     if (o.fieldClass.getName().startsWith("java.") && !this.fieldClass.getName().startsWith("java.")) {
/* 470 */       return 1;
/*     */     }
/*     */     
/* 473 */     if (this.fieldClass.getName().startsWith("java.") && !o.fieldClass.getName().startsWith("java.")) {
/* 474 */       return -1;
/*     */     }
/*     */     
/* 477 */     return this.fieldClass.getName().compareTo(o.fieldClass.getName());
/*     */   }
/*     */   
/*     */   public JSONField getAnnotation() {
/* 481 */     if (this.fieldAnnotation != null) {
/* 482 */       return this.fieldAnnotation;
/*     */     }
/*     */     
/* 485 */     return this.methodAnnotation;
/*     */   }
/*     */   
/*     */   public String getFormat() {
/* 489 */     return this.format;
/*     */   }
/*     */   
/*     */   public Object get(Object javaObject) throws IllegalAccessException, InvocationTargetException {
/* 493 */     return (this.method != null) ? 
/* 494 */       this.method.invoke(javaObject, new Object[0]) : 
/* 495 */       this.field.get(javaObject);
/*     */   }
/*     */   
/*     */   public void set(Object javaObject, Object value) throws IllegalAccessException, InvocationTargetException {
/* 499 */     if (this.method != null) {
/* 500 */       this.method.invoke(javaObject, new Object[] { value });
/*     */       
/*     */       return;
/*     */     } 
/* 504 */     this.field.set(javaObject, value);
/*     */   }
/*     */   
/*     */   public void setAccessible() throws SecurityException {
/* 508 */     if (this.method != null) {
/* 509 */       TypeUtils.setAccessible(this.method);
/*     */       
/*     */       return;
/*     */     } 
/* 513 */     TypeUtils.setAccessible(this.field);
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjso\\util\FieldInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */