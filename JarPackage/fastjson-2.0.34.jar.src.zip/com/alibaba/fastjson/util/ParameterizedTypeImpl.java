/*   */ package com.alibaba.fastjson.util;
/*   */ 
/*   */ import com.alibaba.fastjson2.util.ParameterizedTypeImpl;
/*   */ import java.lang.reflect.Type;
/*   */ 
/*   */ public class ParameterizedTypeImpl extends ParameterizedTypeImpl {
/*   */   public ParameterizedTypeImpl(Type[] actualTypeArguments, Type ownerType, Type rawType) {
/* 8 */     super(actualTypeArguments, ownerType, rawType);
/*   */   }
/*   */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjso\\util\ParameterizedTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */