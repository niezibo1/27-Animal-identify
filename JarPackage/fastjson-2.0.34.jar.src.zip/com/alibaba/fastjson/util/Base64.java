/*     */ package com.alibaba.fastjson.util;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */ {
/*  11 */   public static final char[] CA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
/*  12 */   public static final int[] IA = new int[256];
/*     */   
/*     */   static {
/*  15 */     Arrays.fill(IA, -1);
/*  16 */     for (int i = 0, j = CA.length; i < j; i++) {
/*  17 */       IA[CA[i]] = i;
/*     */     }
/*  19 */     IA[61] = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeFast(char[] chars, int offset, int charsLen) {
/*  35 */     if (charsLen == 0) {
/*  36 */       return new byte[0];
/*     */     }
/*     */     
/*  39 */     int sIx = offset, eIx = offset + charsLen - 1;
/*     */ 
/*     */     
/*  42 */     while (sIx < eIx && IA[chars[sIx]] < 0) {
/*  43 */       sIx++;
/*     */     }
/*     */ 
/*     */     
/*  47 */     while (eIx > 0 && IA[chars[eIx]] < 0) {
/*  48 */       eIx--;
/*     */     }
/*     */ 
/*     */     
/*  52 */     int pad = (chars[eIx] == '=') ? ((chars[eIx - 1] == '=') ? 2 : 1) : 0;
/*  53 */     int cCnt = eIx - sIx + 1;
/*  54 */     int sepCnt = (charsLen > 76) ? (((chars[76] == '\r') ? (cCnt / 78) : 0) << 1) : 0;
/*     */     
/*  56 */     int len = ((cCnt - sepCnt) * 6 >> 3) - pad;
/*  57 */     byte[] bytes = new byte[len];
/*     */ 
/*     */     
/*  60 */     int d = 0; int cc, eLen;
/*  61 */     for (cc = 0, eLen = len / 3 * 3; d < eLen; ) {
/*     */       
/*  63 */       int i = IA[chars[sIx]] << 18 | IA[chars[sIx + 1]] << 12 | IA[chars[sIx + 2]] << 6 | IA[chars[sIx + 3]];
/*     */ 
/*     */ 
/*     */       
/*  67 */       sIx += 4;
/*     */ 
/*     */       
/*  70 */       bytes[d] = (byte)(i >> 16);
/*  71 */       bytes[d + 1] = (byte)(i >> 8);
/*  72 */       bytes[d + 2] = (byte)i;
/*  73 */       d += 3;
/*     */ 
/*     */       
/*  76 */       if (sepCnt > 0 && ++cc == 19) {
/*  77 */         sIx += 2;
/*  78 */         cc = 0;
/*     */       } 
/*     */     } 
/*     */     
/*  82 */     if (d < len) {
/*     */       
/*  84 */       int i = 0;
/*  85 */       for (int j = 0; sIx <= eIx - pad; j++) {
/*  86 */         i |= IA[chars[sIx++]] << 18 - j * 6;
/*     */       }
/*     */       
/*  89 */       for (int r = 16; d < len; r -= 8) {
/*  90 */         bytes[d++] = (byte)(i >> r);
/*     */       }
/*     */     } 
/*     */     
/*  94 */     return bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] decodeFast(String chars, int offset, int charsLen) {
/*  99 */     if (charsLen == 0) {
/* 100 */       return new byte[0];
/*     */     }
/*     */     
/* 103 */     int sIx = offset, eIx = offset + charsLen - 1;
/*     */ 
/*     */     
/* 106 */     while (sIx < eIx && IA[chars.charAt(sIx)] < 0) {
/* 107 */       sIx++;
/*     */     }
/*     */ 
/*     */     
/* 111 */     while (eIx > 0 && IA[chars.charAt(eIx)] < 0) {
/* 112 */       eIx--;
/*     */     }
/*     */ 
/*     */     
/* 116 */     int pad = (chars.charAt(eIx) == '=') ? ((chars.charAt(eIx - 1) == '=') ? 2 : 1) : 0;
/* 117 */     int cCnt = eIx - sIx + 1;
/* 118 */     int sepCnt = (charsLen > 76) ? (((chars.charAt(76) == '\r') ? (cCnt / 78) : 0) << 1) : 0;
/*     */     
/* 120 */     int len = ((cCnt - sepCnt) * 6 >> 3) - pad;
/* 121 */     byte[] bytes = new byte[len];
/*     */ 
/*     */     
/* 124 */     int d = 0; int cc, eLen;
/* 125 */     for (cc = 0, eLen = len / 3 * 3; d < eLen; ) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 130 */       int i = IA[chars.charAt(sIx)] << 18 | IA[chars.charAt(sIx + 1)] << 12 | IA[chars.charAt(sIx + 2)] << 6 | IA[chars.charAt(sIx + 3)];
/* 131 */       sIx += 4;
/*     */ 
/*     */       
/* 134 */       bytes[d] = (byte)(i >> 16);
/* 135 */       bytes[d + 1] = (byte)(i >> 8);
/* 136 */       bytes[d + 2] = (byte)i;
/* 137 */       d += 3;
/*     */ 
/*     */       
/* 140 */       if (sepCnt > 0 && ++cc == 19) {
/* 141 */         sIx += 2;
/* 142 */         cc = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 146 */     if (d < len) {
/*     */       
/* 148 */       int i = 0;
/* 149 */       for (int j = 0; sIx <= eIx - pad; j++) {
/* 150 */         i |= IA[chars.charAt(sIx++)] << 18 - j * 6;
/*     */       }
/*     */       
/* 153 */       for (int r = 16; d < len; r -= 8) {
/* 154 */         bytes[d++] = (byte)(i >> r);
/*     */       }
/*     */     } 
/*     */     
/* 158 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeFast(String s) {
/* 174 */     int sLen = s.length();
/* 175 */     if (sLen == 0) {
/* 176 */       return new byte[0];
/*     */     }
/*     */     
/* 179 */     int sIx = 0, eIx = sLen - 1;
/*     */ 
/*     */     
/* 182 */     while (sIx < eIx && IA[s.charAt(sIx) & 0xFF] < 0) {
/* 183 */       sIx++;
/*     */     }
/*     */ 
/*     */     
/* 187 */     while (eIx > 0 && IA[s.charAt(eIx) & 0xFF] < 0) {
/* 188 */       eIx--;
/*     */     }
/*     */ 
/*     */     
/* 192 */     int pad = (s.charAt(eIx) == '=') ? ((s.charAt(eIx - 1) == '=') ? 2 : 1) : 0;
/* 193 */     int cCnt = eIx - sIx + 1;
/* 194 */     int sepCnt = (sLen > 76) ? (((s.charAt(76) == '\r') ? (cCnt / 78) : 0) << 1) : 0;
/*     */     
/* 196 */     int len = ((cCnt - sepCnt) * 6 >> 3) - pad;
/* 197 */     byte[] dArr = new byte[len];
/*     */ 
/*     */     
/* 200 */     int d = 0; int cc, eLen;
/* 201 */     for (cc = 0, eLen = len / 3 * 3; d < eLen; ) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 206 */       int i = IA[s.charAt(sIx)] << 18 | IA[s.charAt(sIx + 1)] << 12 | IA[s.charAt(sIx + 2)] << 6 | IA[s.charAt(sIx + 3)];
/* 207 */       sIx += 4;
/*     */ 
/*     */       
/* 210 */       dArr[d] = (byte)(i >> 16);
/* 211 */       dArr[d + 1] = (byte)(i >> 8);
/* 212 */       dArr[d + 2] = (byte)i;
/* 213 */       d += 3;
/*     */ 
/*     */       
/* 216 */       if (sepCnt > 0 && ++cc == 19) {
/* 217 */         sIx += 2;
/* 218 */         cc = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     if (d < len) {
/*     */       
/* 224 */       int i = 0;
/* 225 */       for (int j = 0; sIx <= eIx - pad; j++) {
/* 226 */         i |= IA[s.charAt(sIx++)] << 18 - j * 6;
/*     */       }
/*     */       
/* 229 */       for (int r = 16; d < len; r -= 8) {
/* 230 */         dArr[d++] = (byte)(i >> r);
/*     */       }
/*     */     } 
/*     */     
/* 234 */     return dArr;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjso\\util\Base64.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */