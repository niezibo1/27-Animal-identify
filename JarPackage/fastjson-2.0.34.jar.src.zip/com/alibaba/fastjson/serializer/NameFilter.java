/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson.PropertyNamingStrategy;
/*    */ import com.alibaba.fastjson2.filter.NameFilter;
/*    */ import com.alibaba.fastjson2.util.BeanUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface NameFilter
/*    */   extends SerializeFilter, NameFilter
/*    */ {
/*    */   static NameFilter of(PropertyNamingStrategy namingStrategy) {
/* 24 */     return (object, name, value) -> BeanUtils.fieldName(name, namingStrategy.name());
/*    */   }
/*    */   
/*    */   static NameFilter compose(NameFilter before, NameFilter after) {
/* 28 */     return (object, name, value) -> after.process(object, before.process(object, name, value), value);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\NameFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */