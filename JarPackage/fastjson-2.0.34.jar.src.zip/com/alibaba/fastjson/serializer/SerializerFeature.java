/*     */ package com.alibaba.fastjson.serializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum SerializerFeature
/*     */ {
/*  22 */   QuoteFieldNames,
/*     */ 
/*     */ 
/*     */   
/*  26 */   UseSingleQuotes,
/*     */ 
/*     */ 
/*     */   
/*  30 */   WriteMapNullValue,
/*     */ 
/*     */ 
/*     */   
/*  34 */   WriteEnumUsingToString,
/*     */ 
/*     */ 
/*     */   
/*  38 */   WriteEnumUsingName,
/*     */ 
/*     */ 
/*     */   
/*  42 */   UseISO8601DateFormat,
/*     */ 
/*     */ 
/*     */   
/*  46 */   WriteNullListAsEmpty,
/*     */ 
/*     */ 
/*     */   
/*  50 */   WriteNullStringAsEmpty,
/*     */ 
/*     */ 
/*     */   
/*  54 */   WriteNullNumberAsZero,
/*     */ 
/*     */ 
/*     */   
/*  58 */   WriteNullBooleanAsFalse,
/*     */ 
/*     */ 
/*     */   
/*  62 */   SkipTransientField,
/*     */ 
/*     */ 
/*     */   
/*  66 */   SortField,
/*     */ 
/*     */ 
/*     */   
/*  70 */   WriteTabAsSpecial,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   PrettyFormat,
/*     */ 
/*     */ 
/*     */   
/*  79 */   WriteClassName,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   DisableCircularReferenceDetect,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   WriteSlashAsSpecial,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   BrowserCompatible,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   WriteDateUseDateFormat,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   NotWriteRootClassName,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   DisableCheckSpecialChar,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   BeanToArray,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   WriteNonStringKeyAsString,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   NotWriteDefaultValue,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   BrowserSecure,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   IgnoreNonFieldGetter,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   WriteNonStringValueAsString,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   IgnoreErrorGetter,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   WriteBigDecimalAsPlain,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   MapSortField; public static final SerializerFeature[] EMPTY;
/*     */   static {
/* 157 */     EMPTY = new SerializerFeature[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     WRITE_MAP_NULL_FEATURES = WriteMapNullValue.getMask() | WriteNullBooleanAsFalse.getMask() | WriteNullListAsEmpty.getMask() | WriteNullNumberAsZero.getMask() | WriteNullStringAsEmpty.getMask();
/*     */   }
/*     */   public static final int WRITE_MAP_NULL_FEATURES; public final int mask;
/*     */   SerializerFeature() {
/* 167 */     this.mask = 1 << ordinal();
/*     */   }
/*     */   
/*     */   public static boolean isEnabled(int features, SerializerFeature feature) {
/* 171 */     return ((features & feature.mask) != 0);
/*     */   }
/*     */   
/*     */   public static boolean isEnabled(int features, int features1, SerializerFeature feature) {
/* 175 */     return (((features | features1) & feature.mask) != 0);
/*     */   }
/*     */   
/*     */   public static int config(int features, SerializerFeature feature, boolean state) {
/* 179 */     if (state) {
/* 180 */       features |= feature.mask;
/*     */     } else {
/* 182 */       features &= feature.mask ^ 0xFFFFFFFF;
/*     */     } 
/*     */     
/* 185 */     return features;
/*     */   }
/*     */   
/*     */   public static int of(SerializerFeature[] features) {
/* 189 */     if (features == null) {
/* 190 */       return 0;
/*     */     }
/*     */     
/* 193 */     int value = 0;
/*     */     
/* 195 */     for (SerializerFeature feature : features) {
/* 196 */       value |= feature.mask;
/*     */     }
/*     */     
/* 199 */     return value;
/*     */   }
/*     */   
/*     */   public final int getMask() {
/* 203 */     return this.mask;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\SerializerFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */