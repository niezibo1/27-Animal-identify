/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson2.JSONWriter;
/*    */ import com.alibaba.fastjson2.writer.FieldWriter;
/*    */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class JavaBeanSerializer
/*    */   implements ObjectSerializer
/*    */ {
/*    */   private final ObjectWriter raw;
/*    */   
/*    */   public JavaBeanSerializer(ObjectWriter raw) {
/* 15 */     this.raw = raw;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
/* 26 */     JSONWriter jsonWriter = serializer.out.raw;
/* 27 */     this.raw.write(jsonWriter, object, fieldName, fieldType, 0L);
/*    */   }
/*    */   
/*    */   public Object getFieldValue(Object object, String key) {
/* 31 */     FieldWriter fieldWriter = this.raw.getFieldWriter(key);
/* 32 */     if (fieldWriter == null) {
/* 33 */       return null;
/*    */     }
/* 35 */     return fieldWriter.getFieldValue(object);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\JavaBeanSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */