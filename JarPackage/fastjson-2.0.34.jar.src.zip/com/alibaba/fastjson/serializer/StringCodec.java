/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson.parser.DefaultJSONParser;
/*    */ import com.alibaba.fastjson2.JSONReader;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class StringCodec
/*    */   implements ObjectSerializer
/*    */ {
/* 11 */   public static final StringCodec instance = new StringCodec();
/*    */   public static <T> T deserialze(DefaultJSONParser parser) {
/* 13 */     return (T)parser.getRawReader().readString();
/*    */   }
/*    */   
/*    */   public <T> T deserialze(DefaultJSONParser parser, Type clazz, Object fieldName) {
/* 17 */     JSONReader reader = parser.getRawReader();
/* 18 */     String str = reader.readString();
/*    */     
/* 20 */     if (clazz == StringBuffer.class) {
/* 21 */       return (T)new StringBuffer(str);
/*    */     }
/*    */     
/* 24 */     if (clazz == StringBuilder.class) {
/* 25 */       return (T)new StringBuilder(str);
/*    */     }
/*    */     
/* 28 */     return (T)str;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
/* 33 */     SerializeWriter out = serializer.out;
/* 34 */     out.writeString((String)object);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\StringCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */