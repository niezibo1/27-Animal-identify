/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson2.JSONWriter;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public final class ToStringSerializer
/*    */   implements ObjectSerializer
/*    */ {
/* 10 */   public static final ToStringSerializer instance = new ToStringSerializer();
/*    */ 
/*    */   
/*    */   public void write(JSONWriter jsonWriter, Object object, Object fieldName, Type fieldType, long features) {
/* 14 */     if (object == null) {
/* 15 */       jsonWriter.writeNull();
/*    */       
/*    */       return;
/*    */     } 
/* 19 */     String strVal = object.toString();
/* 20 */     jsonWriter.writeString(strVal);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
/* 30 */     JSONWriter jsonWriter = serializer.out.raw;
/* 31 */     if (object == null) {
/* 32 */       jsonWriter.writeNull();
/*    */       
/*    */       return;
/*    */     } 
/* 36 */     String strVal = object.toString();
/* 37 */     jsonWriter.writeString(strVal);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\ToStringSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */