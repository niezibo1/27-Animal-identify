/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson.JSONException;
/*    */ import com.alibaba.fastjson2.JSONWriter;
/*    */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ 
/*    */ public interface ObjectSerializer
/*    */   extends ObjectWriter
/*    */ {
/*    */   default void write(JSONWriter jsonWriter, Object object, Object fieldName, Type fieldType, long features) {
/* 14 */     JSONSerializer jsonSerializer = new JSONSerializer(jsonWriter);
/*    */     try {
/* 16 */       write(jsonSerializer, object, fieldName, fieldType, 0);
/* 17 */     } catch (IOException e) {
/* 18 */       throw new JSONException("write error", e);
/*    */     } 
/*    */   }
/*    */   
/*    */   void write(JSONSerializer paramJSONSerializer, Object paramObject1, Object paramObject2, Type paramType, int paramInt) throws IOException;
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\ObjectSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */