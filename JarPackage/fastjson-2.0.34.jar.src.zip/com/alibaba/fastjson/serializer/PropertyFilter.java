package com.alibaba.fastjson.serializer;

import com.alibaba.fastjson2.filter.PropertyFilter;

public interface PropertyFilter extends PropertyFilter, SerializeFilter {}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\PropertyFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */