package com.alibaba.fastjson.serializer;

import com.alibaba.fastjson2.filter.PascalNameFilter;

public class PascalNameFilter extends PascalNameFilter implements NameFilter {}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\PascalNameFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */