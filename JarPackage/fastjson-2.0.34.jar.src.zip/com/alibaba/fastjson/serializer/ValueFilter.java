/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson2.filter.ValueFilter;
/*    */ 
/*    */ public interface ValueFilter extends SerializeFilter, ValueFilter {
/*    */   Object process(Object paramObject1, String paramString, Object paramObject2);
/*    */   
/*    */   default Object apply(Object object, String name, Object value) {
/*  9 */     return process(object, name, value);
/*    */   }
/*    */   
/*    */   static ValueFilter compose(ValueFilter before, ValueFilter after) {
/* 13 */     return (object, name, value) -> after.process(object, name, before.process(object, name, value));
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\ValueFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */