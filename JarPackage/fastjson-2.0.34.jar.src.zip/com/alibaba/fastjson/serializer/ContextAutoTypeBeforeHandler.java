/*   */ package com.alibaba.fastjson.serializer;
/*   */ 
/*   */ import com.alibaba.fastjson2.filter.ContextAutoTypeBeforeHandler;
/*   */ 
/*   */ public class ContextAutoTypeBeforeHandler extends ContextAutoTypeBeforeHandler implements SerializeFilter {
/*   */   public ContextAutoTypeBeforeHandler(String[] acceptNames) {
/* 7 */     super(acceptNames);
/*   */   }
/*   */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\ContextAutoTypeBeforeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */