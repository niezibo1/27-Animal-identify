/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson2.JSONWriter;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ListSerializer
/*    */   implements ObjectSerializer
/*    */ {
/* 11 */   public static final ListSerializer instance = new ListSerializer();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
/* 18 */     JSONWriter out = serializer.out.raw;
/*    */     
/* 20 */     if (object == null) {
/* 21 */       out.writeArrayNull();
/*    */       
/*    */       return;
/*    */     } 
/* 25 */     List<?> list = (List)object;
/* 26 */     out.write(list);
/*    */   }
/*    */   
/*    */   public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType) throws IOException {
/* 30 */     JSONWriter out = serializer.out.raw;
/*    */     
/* 32 */     if (object == null) {
/* 33 */       out.writeArrayNull();
/*    */       
/*    */       return;
/*    */     } 
/* 37 */     List<?> list = (List)object;
/* 38 */     out.write(list);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\ListSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */