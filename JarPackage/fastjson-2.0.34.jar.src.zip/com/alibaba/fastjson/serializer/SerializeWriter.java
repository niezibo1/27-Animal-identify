/*     */ package com.alibaba.fastjson.serializer;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson2.JSONWriter;
/*     */ import com.alibaba.fastjson2.filter.LabelFilter;
/*     */ import com.alibaba.fastjson2.filter.PropertyPreFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public class SerializeWriter
/*     */   implements Cloneable
/*     */ {
/*     */   SerializeConfig config;
/*     */   final JSONWriter raw;
/*     */   final ListWrapper<PropertyFilter> propertyFilters;
/*     */   final ListWrapper<ValueFilter> valueFilters;
/*     */   final ListWrapper<NameFilter> nameFilters;
/*     */   final ListWrapper<BeforeFilter> beforeFilters;
/*     */   final ListWrapper<AfterFilter> afterFilters;
/*     */   
/*     */   public SerializeWriter() {
/*  26 */     this(JSONWriter.of());
/*     */   }
/*     */   
/*     */   public SerializeWriter(SerializerFeature... features) {
/*  30 */     this(
/*  31 */         JSONWriter.of(
/*  32 */           JSON.createWriteContext(SerializeConfig.global, JSON.DEFAULT_PARSER_FEATURE, features)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializeWriter(SerializeConfig config, SerializerFeature... features) {
/*  42 */     this(
/*  43 */         JSONWriter.of(
/*  44 */           JSON.createWriteContext(config, JSON.DEFAULT_PARSER_FEATURE, features)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     this.config = config;
/*     */   }
/*     */   
/*     */   public SerializeWriter(JSONWriter raw) {
/*  55 */     this.raw = raw;
/*  56 */     this.propertyFilters = new ListWrapper<>();
/*  57 */     this.valueFilters = new ListWrapper<>();
/*  58 */     this.nameFilters = new ListWrapper<>();
/*  59 */     this.beforeFilters = new ListWrapper<>();
/*  60 */     this.afterFilters = new ListWrapper<>();
/*     */   }
/*     */   
/*     */   public void writeNull() {
/*  64 */     this.raw.writeNull();
/*     */   }
/*     */   
/*     */   public void writeNull(SerializerFeature feature) {
/*  68 */     this.raw.writeNull();
/*     */   }
/*     */   
/*     */   public void writeString(String text) {
/*  72 */     this.raw.writeString(text);
/*     */   }
/*     */   
/*     */   public void write(String text) {
/*  76 */     this.raw.writeRaw(text);
/*     */   }
/*     */   
/*     */   public List<PropertyFilter> getPropertyFilters() {
/*  80 */     return this.propertyFilters;
/*     */   }
/*     */   
/*     */   public List<ValueFilter> getValueFilters() {
/*  84 */     return this.valueFilters;
/*     */   }
/*     */   
/*     */   public List<NameFilter> getNameFilters() {
/*  88 */     return this.nameFilters;
/*     */   }
/*     */   
/*     */   public List<BeforeFilter> getBeforeFilters() {
/*  92 */     return this.beforeFilters;
/*     */   }
/*     */   
/*     */   public List<AfterFilter> getAfterFilters() {
/*  96 */     return this.afterFilters;
/*     */   }
/*     */   
/*     */   class ListWrapper<T>
/*     */     extends ArrayList<T>
/*     */   {
/*     */     public boolean add(T filter) {
/* 103 */       JSONWriter.Context context = SerializeWriter.this.raw.getContext();
/*     */       
/* 105 */       if (filter instanceof PropertyFilter) {
/* 106 */         context.setPropertyFilter((PropertyFilter)filter);
/*     */       }
/*     */       
/* 109 */       if (filter instanceof ValueFilter) {
/* 110 */         context.setValueFilter((ValueFilter)filter);
/*     */       }
/*     */       
/* 113 */       if (filter instanceof NameFilter) {
/* 114 */         context.setNameFilter((NameFilter)filter);
/*     */       }
/*     */       
/* 117 */       if (filter instanceof PropertyPreFilter) {
/* 118 */         context.setPropertyPreFilter((PropertyPreFilter)filter);
/*     */       }
/*     */       
/* 121 */       if (filter instanceof BeforeFilter) {
/* 122 */         context.setBeforeFilter((BeforeFilter)filter);
/*     */       }
/*     */       
/* 125 */       if (filter instanceof AfterFilter) {
/* 126 */         context.setAfterFilter((AfterFilter)filter);
/*     */       }
/*     */       
/* 129 */       if (filter instanceof LabelFilter) {
/* 130 */         context.setLabelFilter((LabelFilter)filter);
/*     */       }
/*     */       
/* 133 */       return super.add(filter);
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(int c) {
/* 138 */     this.raw.writeRaw((char)c);
/*     */   }
/*     */   
/*     */   public void write(char c) {
/* 142 */     this.raw.writeRaw(c);
/*     */   }
/*     */   
/*     */   public void writeInt(int i) {
/* 146 */     this.raw.writeInt32(i);
/*     */   }
/*     */   
/*     */   public void writeLong(long i) {
/* 150 */     this.raw.writeInt64(i);
/*     */   }
/*     */   
/*     */   public void writeFieldName(String key) {
/* 154 */     this.raw.writeName(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     return this.raw.toString();
/*     */   }
/*     */   
/*     */   public byte[] toBytes(Charset charset) {
/* 163 */     return this.raw.getBytes(charset);
/*     */   }
/*     */   
/*     */   public byte[] toBytes(String charsetName) {
/* 167 */     return this.raw.getBytes(Charset.forName(charsetName));
/*     */   }
/*     */   
/*     */   public void close() {
/* 171 */     this.raw.close();
/*     */   }
/*     */   
/*     */   public void writeTo(Writer out) throws IOException {
/* 175 */     this.raw.flushTo(out);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(SerializerFeature feature) {
/* 179 */     JSONWriter.Feature rawFeature = null;
/* 180 */     switch (feature) {
/*     */       case BeanToArray:
/* 182 */         rawFeature = JSONWriter.Feature.BeanToArray;
/*     */         break;
/*     */       case WriteMapNullValue:
/* 185 */         rawFeature = JSONWriter.Feature.WriteMapNullValue;
/*     */         break;
/*     */       case WriteEnumUsingToString:
/* 188 */         rawFeature = JSONWriter.Feature.WriteEnumUsingToString;
/*     */         break;
/*     */       case WriteEnumUsingName:
/* 191 */         rawFeature = JSONWriter.Feature.WriteEnumsUsingName;
/*     */         break;
/*     */       case WriteNullListAsEmpty:
/* 194 */         rawFeature = JSONWriter.Feature.WriteNullListAsEmpty;
/*     */         break;
/*     */       case WriteNullStringAsEmpty:
/* 197 */         rawFeature = JSONWriter.Feature.WriteNullStringAsEmpty;
/*     */         break;
/*     */       case WriteNullNumberAsZero:
/* 200 */         rawFeature = JSONWriter.Feature.WriteNullNumberAsZero;
/*     */         break;
/*     */       case WriteNullBooleanAsFalse:
/* 203 */         rawFeature = JSONWriter.Feature.WriteNullBooleanAsFalse;
/*     */         break;
/*     */       case WriteClassName:
/* 206 */         rawFeature = JSONWriter.Feature.WriteClassName;
/*     */         break;
/*     */       case NotWriteRootClassName:
/* 209 */         rawFeature = JSONWriter.Feature.NotWriteRootClassName;
/*     */         break;
/*     */       case WriteNonStringKeyAsString:
/* 212 */         rawFeature = JSONWriter.Feature.WriteNonStringKeyAsString;
/*     */         break;
/*     */       case NotWriteDefaultValue:
/* 215 */         rawFeature = JSONWriter.Feature.NotWriteDefaultValue;
/*     */         break;
/*     */       case BrowserCompatible:
/* 218 */         rawFeature = JSONWriter.Feature.BrowserCompatible;
/*     */         break;
/*     */       case BrowserSecure:
/* 221 */         rawFeature = JSONWriter.Feature.BrowserSecure;
/*     */         break;
/*     */       case IgnoreNonFieldGetter:
/* 224 */         rawFeature = JSONWriter.Feature.IgnoreNonFieldGetter;
/*     */         break;
/*     */       case WriteNonStringValueAsString:
/* 227 */         rawFeature = JSONWriter.Feature.WriteNonStringValueAsString;
/*     */         break;
/*     */       case IgnoreErrorGetter:
/* 230 */         rawFeature = JSONWriter.Feature.IgnoreErrorGetter;
/*     */         break;
/*     */       case WriteBigDecimalAsPlain:
/* 233 */         rawFeature = JSONWriter.Feature.WriteBigDecimalAsPlain;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (rawFeature != null) {
/* 240 */       return this.raw.isEnabled(rawFeature);
/*     */     }
/*     */     
/* 243 */     return false;
/*     */   }
/*     */   
/*     */   public SerializeWriter append(char c) {
/* 247 */     this.raw.writeRaw(c);
/* 248 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\SerializeWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */