/*     */ package com.alibaba.fastjson.serializer;
/*     */ import com.alibaba.fastjson.JSONException;
/*     */ import com.alibaba.fastjson.PropertyNamingStrategy;
/*     */ import com.alibaba.fastjson.util.TypeUtils;
/*     */ import com.alibaba.fastjson2.JSONWriter;
/*     */ import com.alibaba.fastjson2.PropertyNamingStrategy;
/*     */ import com.alibaba.fastjson2.util.TypeUtils;
/*     */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*     */ import com.alibaba.fastjson2.writer.ObjectWriterProvider;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ public class SerializeConfig {
/*  14 */   public static final SerializeConfig global = new SerializeConfig(null);
/*  15 */   public static final SerializeConfig globalInstance = global;
/*  16 */   public static final ObjectWriterProvider DEFAULT_PROVIDER = new ObjectWriterProvider(
/*  17 */       TypeUtils.compatibleWithFieldName ? 
/*  18 */       null : 
/*  19 */       PropertyNamingStrategy.CamelCase1x);
/*     */   
/*     */   public final boolean fieldBased;
/*     */   
/*     */   public PropertyNamingStrategy propertyNamingStrategy;
/*     */   
/*     */   private ObjectWriterProvider provider;
/*     */   
/*     */   public static SerializeConfig getGlobalInstance() {
/*  28 */     return global;
/*     */   }
/*     */   
/*     */   public SerializeConfig() {
/*  32 */     this(new ObjectWriterProvider());
/*     */   }
/*     */   
/*     */   public SerializeConfig(ObjectWriterProvider provider) {
/*  36 */     this.fieldBased = false;
/*  37 */     this.provider = provider;
/*     */   }
/*     */   
/*     */   public SerializeConfig(boolean fieldBased) {
/*  41 */     this.fieldBased = fieldBased;
/*     */   }
/*     */   
/*     */   public ObjectWriterProvider getProvider() {
/*  45 */     ObjectWriterProvider provider = this.provider;
/*  46 */     if (provider == null) {
/*  47 */       provider = DEFAULT_PROVIDER;
/*     */     }
/*     */     
/*  50 */     if (TypeUtils.compatibleWithFieldName && provider
/*  51 */       .getNamingStrategy() == PropertyNamingStrategy.CamelCase1x)
/*     */     {
/*  53 */       provider.setNamingStrategy(null);
/*     */     }
/*  55 */     return provider;
/*     */   }
/*     */   
/*     */   public boolean put(Type type, ObjectSerializer value) {
/*  59 */     ObjectWriterProvider provider = this.provider;
/*  60 */     if (provider == null) {
/*  61 */       provider = DEFAULT_PROVIDER;
/*     */     }
/*  63 */     return (provider.register(type, new ObjectSerializerAdapter(value), this.fieldBased) == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAsmEnable(boolean value) {}
/*     */   
/*     */   static final class ObjectSerializerAdapter
/*     */     implements ObjectWriter
/*     */   {
/*     */     final ObjectSerializer serializer;
/*     */     
/*     */     public ObjectSerializerAdapter(ObjectSerializer serializer) {
/*  75 */       this.serializer = serializer;
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(JSONWriter jsonWriter, Object object, Object fieldName, Type fieldType, long features) {
/*  80 */       JSONSerializer serializer = new JSONSerializer(jsonWriter);
/*     */       
/*     */       try {
/*  83 */         this.serializer.write(serializer, object, fieldName, fieldType, 0);
/*  84 */       } catch (IOException e) {
/*  85 */         throw new JSONException("serializer write error", e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void addFilter(Class<?> clazz, SerializeFilter filter) {
/*  91 */     ObjectWriter objectWriter = getProvider().getObjectWriter(clazz);
/*  92 */     objectWriter.setFilter(filter);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public boolean put(Object type, Object value) {
/*  97 */     return put((Type)type, (ObjectSerializer)value);
/*     */   }
/*     */   
/*     */   public ObjectSerializer getObjectWriter(Class<?> clazz) {
/* 101 */     ObjectWriter objectWriter = getProvider().getObjectWriter(clazz);
/* 102 */     if (objectWriter instanceof ObjectSerializer) {
/* 103 */       return (ObjectSerializer)objectWriter;
/*     */     }
/*     */     
/* 106 */     return new JavaBeanSerializer(objectWriter);
/*     */   }
/*     */   
/*     */   public final ObjectSerializer get(Type type) {
/* 110 */     ObjectWriter objectWriter = getProvider().getObjectWriter(type, TypeUtils.getClass(type));
/* 111 */     if (objectWriter instanceof ObjectSerializer) {
/* 112 */       return (ObjectSerializer)objectWriter;
/*     */     }
/*     */     
/* 115 */     return new JavaBeanSerializer(objectWriter);
/*     */   }
/*     */   
/*     */   public final ObjectSerializer createJavaBeanSerializer(Class<?> clazz) {
/* 119 */     ObjectWriter objectWriter = getProvider().getCreator().createObjectWriter(clazz);
/* 120 */     return new JavaBeanSerializer(objectWriter);
/*     */   }
/*     */   
/*     */   public void configEnumAsJavaBean(Class<? extends Enum>... enumClasses) {
/* 124 */     for (Class<? extends Enum> enumClass : enumClasses)
/* 125 */       put(enumClass, createJavaBeanSerializer(enumClass)); 
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\SerializeConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */