/*    */ package com.alibaba.fastjson.serializer;
/*    */ import com.alibaba.fastjson2.filter.BeanContext;
/*    */ 
/*    */ public class BeanContext extends BeanContext {
/*    */   public BeanContext(BeanContext ctx) {
/*  6 */     super(ctx
/*  7 */         .getBeanClass(), ctx
/*  8 */         .getMethod(), ctx
/*  9 */         .getField(), ctx
/* 10 */         .getName(), ctx
/* 11 */         .getLabel(), ctx
/* 12 */         .getFieldClass(), ctx
/* 13 */         .getFieldType(), ctx
/* 14 */         .getFeatures(), ctx
/* 15 */         .getFormat());
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\BeanContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */