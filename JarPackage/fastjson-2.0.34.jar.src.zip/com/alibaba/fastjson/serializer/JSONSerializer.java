/*     */ package com.alibaba.fastjson.serializer;
/*     */ 
/*     */ import com.alibaba.fastjson.JSON;
/*     */ import com.alibaba.fastjson2.JSONException;
/*     */ import com.alibaba.fastjson2.JSONWriter;
/*     */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*     */ import java.util.List;
/*     */ 
/*     */ public class JSONSerializer
/*     */ {
/*     */   public final SerializeWriter out;
/*     */   final JSONWriter raw;
/*     */   SerialContext context;
/*     */   
/*     */   public JSONSerializer() {
/*  16 */     this(new SerializeWriter());
/*     */   }
/*     */   
/*     */   public JSONSerializer(SerializeConfig config) {
/*  20 */     this(new SerializeWriter(config, new SerializerFeature[0]));
/*     */   }
/*     */   
/*     */   public JSONSerializer(JSONWriter raw) {
/*  24 */     this(new SerializeWriter(raw));
/*     */   }
/*     */   
/*     */   public JSONSerializer(SerializeWriter out) {
/*  28 */     this.out = out;
/*  29 */     this.raw = out.raw;
/*     */   }
/*     */   
/*     */   public JSONSerializer(SerializeWriter out, SerializeConfig config) {
/*  33 */     this.out = out;
/*  34 */     this.raw = out.raw;
/*     */   }
/*     */   
/*     */   public void config(SerializerFeature feature, boolean state) {
/*  38 */     if (!state) {
/*  39 */       throw new JSONException("not support");
/*     */     }
/*     */     
/*  42 */     JSONWriter.Context ctx = this.raw.getContext();
/*     */     
/*  44 */     switch (feature) {
/*     */       case UseISO8601DateFormat:
/*  46 */         ctx.setDateFormat("iso8601");
/*     */         break;
/*     */       case WriteMapNullValue:
/*  49 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNulls });
/*     */         break;
/*     */       case WriteNullListAsEmpty:
/*  52 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNullListAsEmpty });
/*     */         break;
/*     */       case WriteNullStringAsEmpty:
/*  55 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNullStringAsEmpty });
/*     */         break;
/*     */       case WriteNullNumberAsZero:
/*  58 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNullNumberAsZero });
/*     */         break;
/*     */       case WriteNullBooleanAsFalse:
/*  61 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNullBooleanAsFalse });
/*     */         break;
/*     */       case BrowserCompatible:
/*  64 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.BrowserCompatible });
/*     */         break;
/*     */       case BrowserSecure:
/*  67 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.BrowserSecure });
/*     */         break;
/*     */       case WriteClassName:
/*  70 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteClassName });
/*     */         break;
/*     */       case WriteNonStringValueAsString:
/*  73 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteNonStringValueAsString });
/*     */         break;
/*     */       case WriteEnumUsingToString:
/*  76 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.WriteEnumUsingToString });
/*     */         break;
/*     */       case NotWriteRootClassName:
/*  79 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.NotWriteRootClassName });
/*     */         break;
/*     */       case IgnoreErrorGetter:
/*  82 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.IgnoreErrorGetter });
/*     */         break;
/*     */       case WriteDateUseDateFormat:
/*  85 */         ctx.setDateFormat(JSON.DEFFAULT_DATE_FORMAT);
/*     */         break;
/*     */       case BeanToArray:
/*  88 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.BeanToArray });
/*     */         break;
/*     */       case UseSingleQuotes:
/*  91 */         ctx.config(new JSONWriter.Feature[] { JSONWriter.Feature.UseSingleQuotes });
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(boolean value) {
/*  99 */     this.raw.writeBool(value);
/*     */   }
/*     */   
/*     */   public void writeInt(int i) {
/* 103 */     this.raw.writeInt32(i);
/*     */   }
/*     */   
/*     */   public void write(String text) {
/* 107 */     this.raw.writeString(text);
/*     */   }
/*     */   
/*     */   public void writeLong(long i) {
/* 111 */     this.raw.writeInt64(i);
/*     */   }
/*     */   
/*     */   public void writeNull() {
/* 115 */     this.raw.writeNull();
/*     */   }
/*     */   
/*     */   public final void write(Object object) {
/* 119 */     this.raw.writeAny(object);
/*     */   }
/*     */   
/*     */   public final void writeAs(Object object, Class type) {
/* 123 */     ObjectWriter objectWriter = this.raw.getObjectWriter(type);
/* 124 */     objectWriter.write(this.raw, Integer.valueOf(0));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     return this.raw.toString();
/*     */   }
/*     */   
/*     */   public List<PropertyFilter> getPropertyFilters() {
/* 133 */     return this.out.getPropertyFilters();
/*     */   }
/*     */   
/*     */   public List<ValueFilter> getValueFilters() {
/* 137 */     return this.out.getValueFilters();
/*     */   }
/*     */   public List<NameFilter> getNameFilters() {
/* 140 */     return this.out.getNameFilters();
/*     */   }
/*     */   
/*     */   public List<BeforeFilter> getBeforeFilters() {
/* 144 */     return this.out.getBeforeFilters();
/*     */   }
/*     */   
/*     */   public List<AfterFilter> getAfterFilters() {
/* 148 */     return this.out.getAfterFilters();
/*     */   }
/*     */   
/*     */   public SerializeConfig getMapping() {
/* 152 */     return this.out.config;
/*     */   }
/*     */   
/*     */   public SerializeWriter getWriter() {
/* 156 */     return this.out;
/*     */   }
/*     */   
/*     */   public ObjectSerializer getObjectWriter(Class<?> clazz) {
/* 160 */     return this.out.config.getObjectWriter(clazz);
/*     */   }
/*     */   
/*     */   public static void write(SerializeWriter out, Object object) {
/* 164 */     out.raw.writeAny(object);
/*     */   }
/*     */   
/*     */   public SerialContext getContext() {
/* 168 */     return this.context;
/*     */   }
/*     */   
/*     */   public void setContext(SerialContext context) {
/* 172 */     this.context = context;
/*     */   }
/*     */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\JSONSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */