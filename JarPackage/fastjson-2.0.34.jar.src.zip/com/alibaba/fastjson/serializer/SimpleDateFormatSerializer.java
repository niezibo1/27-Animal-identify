/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class SimpleDateFormatSerializer
/*    */   implements ObjectSerializer {
/*    */   private final String pattern;
/*    */   
/*    */   public SimpleDateFormatSerializer(String pattern) {
/* 13 */     this.pattern = pattern;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
/* 21 */     if (object == null) {
/* 22 */       serializer.out.writeNull();
/*    */       
/*    */       return;
/*    */     } 
/* 26 */     Date date = (Date)object;
/* 27 */     SimpleDateFormat format = new SimpleDateFormat(this.pattern);
/* 28 */     String text = format.format(date);
/* 29 */     serializer.write(text);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\SimpleDateFormatSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */