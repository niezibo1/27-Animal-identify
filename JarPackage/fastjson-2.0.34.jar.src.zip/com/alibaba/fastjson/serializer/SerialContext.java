/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ public class SerialContext {
/*    */   public final SerialContext parent;
/*    */   public final Object object;
/*    */   public final Object fieldName;
/*    */   public final int features;
/*    */   
/*    */   public SerialContext(SerialContext parent, Object object, Object fieldName, int features, int fieldFeatures) {
/* 10 */     this.parent = parent;
/* 11 */     this.object = object;
/* 12 */     this.fieldName = fieldName;
/* 13 */     this.features = features;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\SerialContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */