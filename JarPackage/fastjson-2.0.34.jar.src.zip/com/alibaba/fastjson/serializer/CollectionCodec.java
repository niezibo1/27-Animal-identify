/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson.parser.DefaultJSONParser;
/*    */ import com.alibaba.fastjson.parser.deserializer.ObjectDeserializer;
/*    */ import com.alibaba.fastjson2.JSONReader;
/*    */ import com.alibaba.fastjson2.JSONWriter;
/*    */ import com.alibaba.fastjson2.reader.ObjectReader;
/*    */ import com.alibaba.fastjson2.writer.ObjectWriter;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ 
/*    */ public class CollectionCodec
/*    */   implements ObjectSerializer, ObjectDeserializer
/*    */ {
/* 15 */   public static final CollectionCodec instance = new CollectionCodec();
/*    */ 
/*    */   
/*    */   public Object deserialze(DefaultJSONParser parser, Type type, Object fieldName) {
/* 19 */     JSONReader reader = parser.getLexer().getReader();
/* 20 */     ObjectReader objectReader = reader.getContext().getObjectReader(type);
/* 21 */     return objectReader.readObject(reader, type, fieldName, 0L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
/* 32 */     JSONWriter raw = serializer.out.raw;
/* 33 */     ObjectWriter<?> objectWriter = raw.getContext().getObjectWriter(object.getClass());
/* 34 */     objectWriter.write(raw, object, fieldName, fieldType, 0L);
/*    */   }
/*    */ 
/*    */   
/*    */   public long getFeatures() {
/* 39 */     return 0L;
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\CollectionCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */