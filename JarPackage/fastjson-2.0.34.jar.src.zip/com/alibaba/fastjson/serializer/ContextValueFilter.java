/*   */ package com.alibaba.fastjson.serializer;
/*   */ import com.alibaba.fastjson2.filter.BeanContext;
/*   */ import com.alibaba.fastjson2.filter.ContextValueFilter;
/*   */ 
/*   */ public interface ContextValueFilter extends ContextValueFilter, SerializeFilter {
/*   */   default Object process(BeanContext context, Object object, String name, Object value) {
/* 7 */     return process(new BeanContext(context), object, name, value);
/*   */   }
/*   */   
/*   */   Object process(BeanContext paramBeanContext, Object paramObject1, String paramString, Object paramObject2);
/*   */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\ContextValueFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */