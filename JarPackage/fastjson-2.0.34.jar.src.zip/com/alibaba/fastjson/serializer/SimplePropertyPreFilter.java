/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson2.filter.SimplePropertyPreFilter;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class SimplePropertyPreFilter
/*    */   extends SimplePropertyPreFilter implements SerializeFilter {
/*    */   public SimplePropertyPreFilter(String... properties) {
/*  9 */     super(properties);
/*    */   }
/*    */   
/*    */   public SimplePropertyPreFilter(Class<?> clazz, String... properties) {
/* 13 */     super(clazz, properties);
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<String> getIncludes() {
/* 18 */     return super.getIncludes();
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<String> getExcludes() {
/* 23 */     return super.getExcludes();
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\SimplePropertyPreFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */