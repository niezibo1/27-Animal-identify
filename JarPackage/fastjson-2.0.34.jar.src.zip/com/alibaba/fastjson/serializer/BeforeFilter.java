package com.alibaba.fastjson.serializer;

import com.alibaba.fastjson2.filter.BeforeFilter;

public abstract class BeforeFilter extends BeforeFilter implements SerializeFilter {}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\BeforeFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */