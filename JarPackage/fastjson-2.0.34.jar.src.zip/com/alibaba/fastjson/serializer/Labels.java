/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ public class Labels {
/*    */   private static class DefaultLabelFilter
/*    */     extends com.alibaba.fastjson2.filter.Labels.DefaultLabelFilter
/*    */     implements LabelFilter {
/*    */     public DefaultLabelFilter(String[] includes, String[] excludes) {
/*  8 */       super(includes, excludes);
/*    */     }
/*    */   }
/*    */   
/*    */   public static LabelFilter includes(String... views) {
/* 13 */     return new DefaultLabelFilter(views, null);
/*    */   }
/*    */   
/*    */   public static LabelFilter excludes(String... views) {
/* 17 */     return new DefaultLabelFilter(null, views);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\Labels.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */