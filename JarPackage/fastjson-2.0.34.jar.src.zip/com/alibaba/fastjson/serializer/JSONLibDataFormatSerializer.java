/*    */ package com.alibaba.fastjson.serializer;
/*    */ 
/*    */ import com.alibaba.fastjson.JSONObject;
/*    */ import java.io.IOException;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSONLibDataFormatSerializer
/*    */   implements ObjectSerializer
/*    */ {
/*    */   public void write(JSONSerializer serializer, Object object, Object fieldName, Type fieldType, int features) throws IOException {
/* 22 */     if (object == null) {
/* 23 */       serializer.out.writeNull();
/*    */       
/*    */       return;
/*    */     } 
/* 27 */     Date date = (Date)object;
/*    */     
/* 29 */     JSONObject json = new JSONObject();
/* 30 */     json.put("date", Integer.valueOf(date.getDate()));
/* 31 */     json.put("day", Integer.valueOf(date.getDay()));
/* 32 */     json.put("hours", Integer.valueOf(date.getHours()));
/* 33 */     json.put("minutes", Integer.valueOf(date.getMinutes()));
/* 34 */     json.put("month", Integer.valueOf(date.getMonth()));
/* 35 */     json.put("seconds", Integer.valueOf(date.getSeconds()));
/* 36 */     json.put("time", Long.valueOf(date.getTime()));
/* 37 */     json.put("timezoneOffset", Integer.valueOf(date.getTimezoneOffset()));
/* 38 */     json.put("year", Integer.valueOf(date.getYear()));
/*    */     
/* 40 */     serializer.write(json);
/*    */   }
/*    */ }


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\JSONLibDataFormatSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */