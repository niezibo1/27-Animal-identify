package com.alibaba.fastjson.serializer;

public interface PropertyPreFilter extends SerializeFilter {}


/* Location:              D:\JarPackage\fastjson-2.0.34.jar!\com\alibaba\fastjson\serializer\PropertyPreFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */